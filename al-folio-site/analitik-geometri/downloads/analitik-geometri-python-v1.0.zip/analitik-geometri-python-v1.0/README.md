# Analitik Geometri — Python eşlikçisi

Prof. Dr. Zühal Küçükarslan Yüzbaşı · Prof. Dr. Bahadır Yüzbaşı

Python 3.12 veya 3.13 gereklidir. Arşivi açtıktan sonra paket kökünde:

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
python labs/bolum_01_koordinatlarla_geometrik_dusunme.py
python -m pytest
```

Windows: aktivasyon yerine `.venv\Scripts\python.exe` kullanın.
Bölüm bazlı açıklamalar: https://byuzbasi.github.io/analitik-geometri/
listings/ dosyaları tek kaynak içindeki blokları sırayla içerir.
Sentetik öğretim örnekleridir; fiziksel güvenlik veya kabul ölçütü değildir.
Bu paket kitap PDF'sini, özel verileri veya TeX kaynaklarını içermez.
