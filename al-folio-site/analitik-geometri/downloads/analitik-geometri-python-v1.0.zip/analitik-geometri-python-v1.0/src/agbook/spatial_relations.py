"""Uzayda kesişim, açı, izdüşüm ve uzaklık için güvenli yardımcılar.

Modül, Bölüm 19'un sonsuz doğru ve düzlem sözleşmesini uygular. Doğrular
``point + t*direction`` biçiminde, düzlemler ise ``(a, b, c, d)`` katsayı
sırasıyla verilir. Açılar yönsüz küçük açılardır ve radyan cinsinden
``[0, pi/2]`` aralığındadır. Uzaklıklar giriş koordinatlarının birimindedir.

Sayısal ilişki sınıfları açık açısal ve uzunluk eşiklerine bağlıdır. Bu
eşikler fiziksel ölçüm belirsizliği, üretim toleransı veya kabul kararı
değildir; sonuç nesneleri kullanılan eşikleri ve doğrulama artıklarını
birlikte raporlar.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array
from .spatial_lines_planes import canonical_plane_coefficients
from .spatial_vectors import cross_product_3d
from .vectors import vector_norm


LineLineRelation3D = Literal["coincident", "parallel", "intersecting", "skew"]
LinePlaneRelation3D = Literal["intersecting", "parallel", "contained"]
PlanePlaneRelation3D = Literal["intersecting", "parallel", "coincident"]


def _spatial_vector(value: ArrayLike, *, name: str) -> FloatArray:
    vector = _finite_array(value, name=name)
    if vector.shape != (3,):
        raise ValueError(f"{name}, (3,) biçiminde bir uzay noktası veya vektörü olmalıdır.")
    return vector.copy()


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="relative_tolerance")
    if tolerance >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _angular_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="angular_tolerance")
    if tolerance >= 1.0:
        raise ValueError("angular_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _finite_difference(first: FloatArray, second: FloatArray, *, context: str) -> FloatArray:
    with np.errstate(over="ignore", invalid="ignore"):
        difference = second - first
    if not np.all(np.isfinite(difference)):
        raise OverflowError(f"{context} kayan noktalı sayı aralığını aşıyor.")
    return difference


def _finite_norm(vector: FloatArray, *, context: str) -> float:
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        magnitude = vector_norm(vector)
    if not np.isfinite(magnitude):
        raise OverflowError(f"{context} kayan noktalı sayı aralığını aşıyor.")
    return magnitude


def _finite_dot(left: FloatArray, right: FloatArray, *, context: str) -> float:
    products = [float(a) * float(b) for a, b in zip(left, right, strict=True)]
    if not np.all(np.isfinite(products)):
        raise OverflowError(f"{context} ara çarpımı kayan noktalı sayı aralığını aşıyor.")
    result = math.fsum(products)
    if not np.isfinite(result):
        raise OverflowError(f"{context} kayan noktalı sayı aralığını aşıyor.")
    return result


def _unit_direction(
    value: ArrayLike,
    *,
    name: str,
    zero_tolerance: float = 0.0,
) -> tuple[FloatArray, float]:
    vector = _spatial_vector(value, name=name)
    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    magnitude = _finite_norm(vector, context=f"{name} normu")
    if magnitude <= tolerance:
        raise ValueError(f"{name} sıfır veya açık eşik altında olamaz.")
    with np.errstate(over="ignore", invalid="ignore", under="ignore", divide="ignore"):
        unit = vector / magnitude
    if not np.all(np.isfinite(unit)):
        raise OverflowError(f"{name} birimlendirmesi sayı aralığını aşıyor.")
    return unit, magnitude


def _canonical_unit_direction(value: FloatArray) -> FloatArray:
    direction = value.copy()
    first_nonzero = next(component for component in direction if component != 0.0)
    if first_nonzero < 0.0:
        direction = -direction
    direction[direction == 0.0] = 0.0
    return direction


def _distance_threshold(
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> tuple[float, float, float, float]:
    absolute = _nonnegative_finite(absolute_tolerance, name="absolute_tolerance")
    relative = _relative_tolerance(relative_tolerance)
    scale = _nonnegative_finite(reference_scale, name="reference_scale")
    with np.errstate(over="ignore", invalid="ignore"):
        threshold = absolute + relative * scale
    if not np.isfinite(threshold):
        raise OverflowError("Uzaklık eşiği kayan noktalı sayı aralığını aşıyor.")
    return absolute, relative, scale, float(threshold)


def _small_angle_between_units(first: FloatArray, second: FloatArray) -> float:
    dot_magnitude = abs(_finite_dot(first, second, context="Açı iç çarpımı"))
    cross = cross_product_3d(first, second)
    cross_magnitude = _finite_norm(cross, context="Açı vektörel çarpım normu")
    return float(np.arctan2(cross_magnitude, dot_magnitude))


def line_line_angle_3d(first_direction: ArrayLike, second_direction: ArrayLike) -> float:
    """İki uzay doğrusu arasındaki yönsüz küçük açıyı radyan olarak verir."""

    first_unit, _ = _unit_direction(first_direction, name="first_direction")
    second_unit, _ = _unit_direction(second_direction, name="second_direction")
    return _small_angle_between_units(first_unit, second_unit)


def plane_plane_angle_3d(first_plane: ArrayLike, second_plane: ArrayLike) -> float:
    """İki düzlem arasındaki yönsüz küçük açıyı radyan olarak verir."""

    first = canonical_plane_coefficients(first_plane)
    second = canonical_plane_coefficients(second_plane)
    return _small_angle_between_units(first[:3], second[:3])


def line_plane_angle_3d(line_direction: ArrayLike, plane: ArrayLike) -> float:
    """Bir doğru ile düzlem arasındaki küçük açıyı radyan olarak verir.

    Sonuç, doğru yönü ile düzlem normalinin açısının tümleyenidir. Doğru
    düzleme paralelse sıfır, düzleme dikse ``pi/2`` elde edilir.
    """

    direction, _ = _unit_direction(line_direction, name="line_direction")
    normal = canonical_plane_coefficients(plane)[:3]
    incidence = abs(_finite_dot(direction, normal, context="Doğru-düzlem iç çarpımı"))
    cross_magnitude = _finite_norm(
        cross_product_3d(direction, normal),
        context="Doğru-düzlem vektörel çarpım normu",
    )
    return float(np.arctan2(incidence, cross_magnitude))


@dataclass(frozen=True)
class PointLineProjection3D:
    """Bir noktanın sonsuz uzay doğrusundaki ortogonal izdüşümü."""

    foot: FloatArray
    parameter: float
    displacement: FloatArray
    distance: float
    foot_line_residual: float
    orthogonality_residual: float


def project_point_to_line_3d(
    line_point: ArrayLike,
    line_direction: ArrayLike,
    point: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> PointLineProjection3D:
    """Bir noktanın sonsuz doğru üzerindeki tek dikme ayağını verir."""

    anchor = _spatial_vector(line_point, name="line_point")
    candidate = _spatial_vector(point, name="point")
    direction, direction_norm = _unit_direction(
        line_direction,
        name="line_direction",
        zero_tolerance=zero_tolerance,
    )
    anchor_to_point = _finite_difference(anchor, candidate, context="Nokta-doğru farkı")
    signed_component = _finite_dot(
        anchor_to_point,
        direction,
        context="Nokta-doğru izdüşüm bileşeni",
    )
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        foot = anchor + signed_component * direction
        parameter = signed_component / direction_norm
    if not np.all(np.isfinite(foot)) or not np.isfinite(parameter):
        raise OverflowError("Nokta-doğru izdüşümü kayan noktalı sayı aralığını aşıyor.")
    displacement = _finite_difference(foot, candidate, context="Nokta-doğru dik bileşeni")
    distance = _finite_norm(displacement, context="Nokta-doğru uzaklığı")
    foot_offset = _finite_difference(anchor, foot, context="Doğru ayağı farkı")
    foot_residual = _finite_norm(
        cross_product_3d(foot_offset, direction),
        context="Doğru ayağı üyelik artığı",
    )
    orthogonality = _finite_dot(
        displacement,
        direction,
        context="Nokta-doğru diklik artığı",
    )
    return PointLineProjection3D(
        foot=foot,
        parameter=float(parameter),
        displacement=displacement,
        distance=distance,
        foot_line_residual=foot_residual,
        orthogonality_residual=orthogonality,
    )


def point_line_distance_3d(
    line_point: ArrayLike,
    line_direction: ArrayLike,
    point: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> float:
    """Bir noktanın sonsuz uzay doğrusuna Öklid uzaklığını verir."""

    return project_point_to_line_3d(
        line_point,
        line_direction,
        point,
        zero_tolerance=zero_tolerance,
    ).distance


@dataclass(frozen=True)
class PointPlaneProjection3D:
    """Bir noktanın düzlemdeki ortogonal izdüşümü ve artık denetimleri."""

    canonical_plane: FloatArray
    foot: FloatArray
    signed_distance: float
    distance: float
    displacement: FloatArray
    foot_plane_residual: float
    normal_alignment_residual: float


def project_point_to_plane_3d(plane: ArrayLike, point: ArrayLike) -> PointPlaneProjection3D:
    """Bir noktanın kanonik düzlem üzerindeki tek dikme ayağını verir."""

    canonical = canonical_plane_coefficients(plane)
    candidate = _spatial_vector(point, name="point")
    linear = _finite_dot(
        canonical[:3],
        candidate,
        context="Nokta-düzlem işaretli uzaklığı",
    )
    signed_distance = math.fsum((linear, float(canonical[3])))
    if not np.isfinite(signed_distance):
        raise OverflowError("Nokta-düzlem işaretli uzaklığı sayı aralığını aşıyor.")
    with np.errstate(over="ignore", invalid="ignore"):
        foot = candidate - signed_distance * canonical[:3]
    if not np.all(np.isfinite(foot)):
        raise OverflowError("Nokta-düzlem izdüşümü sayı aralığını aşıyor.")
    displacement = _finite_difference(foot, candidate, context="Nokta-düzlem dik bileşeni")
    foot_linear = _finite_dot(
        canonical[:3],
        foot,
        context="Düzlem ayağı denklem artığı",
    )
    foot_residual = math.fsum((foot_linear, float(canonical[3])))
    normal_alignment = _finite_norm(
        cross_product_3d(displacement, canonical[:3]),
        context="Düzlem izdüşümü normal doğrultu artığı",
    )
    return PointPlaneProjection3D(
        canonical_plane=canonical,
        foot=foot,
        signed_distance=float(signed_distance),
        distance=abs(float(signed_distance)),
        displacement=displacement,
        foot_plane_residual=float(foot_residual),
        normal_alignment_residual=normal_alignment,
    )


def signed_point_plane_distance_3d(plane: ArrayLike, point: ArrayLike) -> float:
    """Kanonik birim normal yönündeki işaretli nokta-düzlem uzaklığını verir."""

    return project_point_to_plane_3d(plane, point).signed_distance


def point_plane_distance_3d(plane: ArrayLike, point: ArrayLike) -> float:
    """Bir noktanın düzleme Öklid uzaklığını verir."""

    return project_point_to_plane_3d(plane, point).distance


@dataclass(frozen=True)
class LineLineDiagnostics3D:
    """İki sonsuz uzay doğrusunun ilişki ve en yakın nokta tanısı."""

    relation: LineLineRelation3D
    closest_point_first: FloatArray
    closest_point_second: FloatArray
    intersection_point: FloatArray | None
    first_parameter: float
    second_parameter: float
    separation_vector: FloatArray
    distance: float
    small_angle: float
    normalized_cross_magnitude: float
    coplanarity_residual: float | None
    condition_number: float
    singular_values: FloatArray
    first_line_residual: float
    second_line_residual: float
    first_orthogonality_residual: float
    second_orthogonality_residual: float
    angular_tolerance: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float
    distance_threshold: float
    numerically_ambiguous: bool


def line_line_diagnostics_3d(
    first_point: ArrayLike,
    first_direction: ArrayLike,
    second_point: ArrayLike,
    second_direction: ArrayLike,
    *,
    angular_tolerance: float,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> LineLineDiagnostics3D:
    """İki doğruyu çakışık, paralel, kesişen veya aykırı olarak sınıflandırır.

    Yönler önce birimlendirilir. Birim yönlerin vektörel çarpım normu
    ``angular_tolerance`` eşiğini aşmıyorsa doğrular sayısal olarak paralel
    kabul edilir. Diğer durumda en yakın iki nokta vektörel çarpım
    özdeşlikleriyle bulunur; iki sütunlu sistemin SVD tekil değerleri ise
    koşul tanısı için kullanılır. Noktalar arasındaki uzaklık
    ``absolute_tolerance + relative_tolerance*reference_scale`` eşiğini
    aşmıyorsa doğrular sayısal olarak kesişen kabul edilir.
    """

    point_first = _spatial_vector(first_point, name="first_point")
    point_second = _spatial_vector(second_point, name="second_point")
    direction_first, norm_first = _unit_direction(first_direction, name="first_direction")
    direction_second, norm_second = _unit_direction(second_direction, name="second_direction")
    angular = _angular_tolerance(angular_tolerance)
    absolute, relative, scale, distance_threshold = _distance_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    offset = _finite_difference(point_first, point_second, context="Doğru başlangıç farkı")
    cross = cross_product_3d(direction_first, direction_second)
    cross_magnitude = _finite_norm(cross, context="Doğru yönlerinin vektörel çarpımı")
    dot_magnitude = abs(
        _finite_dot(direction_first, direction_second, context="Doğru yönlerinin iç çarpımı")
    )
    small_angle = float(np.arctan2(cross_magnitude, dot_magnitude))
    system = np.column_stack([direction_first, -direction_second])
    singular_values = np.linalg.svd(system, compute_uv=False)
    if not np.all(np.isfinite(singular_values)):
        raise OverflowError("Doğru çifti tekil değerleri sayı aralığını aşıyor.")
    condition_number = (
        math.inf
        if singular_values[-1] == 0.0
        else float(singular_values[0] / singular_values[-1])
    )

    if cross_magnitude <= angular:
        along_first = _finite_dot(offset, direction_first, context="Paralel doğru izdüşümü")
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            closest_first = point_first + along_first * direction_first
            closest_second = point_second.copy()
            first_parameter = along_first / norm_first
        if not np.all(np.isfinite(closest_first)) or not np.isfinite(first_parameter):
            raise OverflowError("Paralel doğru en yakın nokta hesabı sayı aralığını aşıyor.")
        second_parameter = 0.0
        separation = _finite_difference(
            closest_first,
            closest_second,
            context="Paralel doğru ayırma vektörü",
        )
        distance = _finite_norm(separation, context="Paralel doğru uzaklığı")
        relation: LineLineRelation3D = (
            "coincident" if distance <= distance_threshold else "parallel"
        )
        coplanarity_residual = None
        numerically_ambiguous = bool(
            (0.0 < cross_magnitude <= angular)
            or (0.0 < distance <= distance_threshold)
        )
    else:
        cross_unit = cross / cross_magnitude
        offset_cross_second = cross_product_3d(offset, direction_second)
        offset_cross_first = cross_product_3d(offset, direction_first)
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            first_unit_parameter = _finite_dot(
                offset_cross_second,
                cross_unit,
                context="Birinci doğru en yakın nokta payı",
            ) / cross_magnitude
            second_unit_parameter = _finite_dot(
                offset_cross_first,
                cross_unit,
                context="İkinci doğru en yakın nokta payı",
            ) / cross_magnitude
            first_parameter = first_unit_parameter / norm_first
            second_parameter = second_unit_parameter / norm_second
            closest_first = point_first + first_unit_parameter * direction_first
            closest_second = point_second + second_unit_parameter * direction_second
        if (
            not np.isfinite(first_unit_parameter)
            or not np.isfinite(second_unit_parameter)
            or not np.isfinite(first_parameter)
            or not np.isfinite(second_parameter)
            or not np.all(np.isfinite(closest_first))
            or not np.all(np.isfinite(closest_second))
        ):
            raise OverflowError("Doğru çifti en yakın nokta hesabı sayı aralığını aşıyor.")
        separation = _finite_difference(
            closest_first,
            closest_second,
            context="Aykırı doğru ayırma vektörü",
        )
        distance = _finite_norm(separation, context="Doğrular arası uzaklık")
        relation = "intersecting" if distance <= distance_threshold else "skew"
        coplanarity_residual = _finite_dot(
            offset,
            cross_unit,
            context="Doğru çifti eşdüzlemlilik artığı",
        )
        numerically_ambiguous = bool(0.0 < distance <= distance_threshold)

    with np.errstate(over="ignore", invalid="ignore"):
        midpoint = closest_first + 0.5 * separation
    if not np.all(np.isfinite(midpoint)):
        raise OverflowError("Doğru çifti orta noktası sayı aralığını aşıyor.")
    intersection_point = midpoint if relation == "intersecting" else None
    first_offset = _finite_difference(
        point_first,
        closest_first,
        context="Birinci doğru üyelik farkı",
    )
    second_offset = _finite_difference(
        point_second,
        closest_second,
        context="İkinci doğru üyelik farkı",
    )
    first_line_residual = _finite_norm(
        cross_product_3d(first_offset, direction_first),
        context="Birinci doğru üyelik artığı",
    )
    second_line_residual = _finite_norm(
        cross_product_3d(second_offset, direction_second),
        context="İkinci doğru üyelik artığı",
    )
    first_orthogonality = _finite_dot(
        separation,
        direction_first,
        context="Birinci doğru ortak diklik artığı",
    )
    second_orthogonality = _finite_dot(
        separation,
        direction_second,
        context="İkinci doğru ortak diklik artığı",
    )
    return LineLineDiagnostics3D(
        relation=relation,
        closest_point_first=closest_first,
        closest_point_second=closest_second,
        intersection_point=intersection_point,
        first_parameter=float(first_parameter),
        second_parameter=float(second_parameter),
        separation_vector=separation,
        distance=distance,
        small_angle=small_angle,
        normalized_cross_magnitude=cross_magnitude,
        coplanarity_residual=(
            None if coplanarity_residual is None else float(coplanarity_residual)
        ),
        condition_number=condition_number,
        singular_values=singular_values.copy(),
        first_line_residual=first_line_residual,
        second_line_residual=second_line_residual,
        first_orthogonality_residual=first_orthogonality,
        second_orthogonality_residual=second_orthogonality,
        angular_tolerance=angular,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
        distance_threshold=distance_threshold,
        numerically_ambiguous=numerically_ambiguous,
    )


@dataclass(frozen=True)
class LinePlaneDiagnostics3D:
    """Bir sonsuz doğru ile düzlemin kesişim ve uzaklık tanısı."""

    relation: LinePlaneRelation3D
    intersection_point: FloatArray | None
    parameter: float | None
    line_plane_angle: float
    normalized_incidence: float
    signed_anchor_distance: float
    distance: float
    condition_indicator: float
    intersection_plane_residual: float | None
    angular_tolerance: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float
    distance_threshold: float
    numerically_ambiguous: bool


def line_plane_diagnostics_3d(
    line_point: ArrayLike,
    line_direction: ArrayLike,
    plane: ArrayLike,
    *,
    angular_tolerance: float,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> LinePlaneDiagnostics3D:
    """Doğru-düzlem çiftini kesişen, paralel veya içerilen olarak sınıflandırır."""

    anchor = _spatial_vector(line_point, name="line_point")
    direction, direction_norm = _unit_direction(line_direction, name="line_direction")
    canonical = canonical_plane_coefficients(plane)
    angular = _angular_tolerance(angular_tolerance)
    absolute, relative, scale, distance_threshold = _distance_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    incidence = _finite_dot(
        canonical[:3],
        direction,
        context="Doğru-düzlem geliş katsayısı",
    )
    incidence_magnitude = abs(incidence)
    cross_magnitude = _finite_norm(
        cross_product_3d(canonical[:3], direction),
        context="Doğru-düzlem açı bileşeni",
    )
    angle = float(np.arctan2(incidence_magnitude, cross_magnitude))
    anchor_linear = _finite_dot(
        canonical[:3],
        anchor,
        context="Doğru başlangıcı düzlem artığı",
    )
    signed_distance = math.fsum((anchor_linear, float(canonical[3])))
    if not np.isfinite(signed_distance):
        raise OverflowError("Doğru başlangıcı düzlem artığı sayı aralığını aşıyor.")

    if incidence_magnitude <= angular:
        relation: LinePlaneRelation3D = (
            "contained" if abs(signed_distance) <= distance_threshold else "parallel"
        )
        intersection_point = None
        parameter = None
        distance = 0.0 if relation == "contained" else abs(float(signed_distance))
        plane_residual = None
        condition_indicator = math.inf if incidence_magnitude == 0.0 else 1.0 / incidence_magnitude
        numerically_ambiguous = bool(
            (0.0 < incidence_magnitude <= angular)
            or (0.0 < abs(signed_distance) <= distance_threshold)
        )
    else:
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            parameter = -signed_distance / (incidence * direction_norm)
            intersection_point = anchor + parameter * (direction * direction_norm)
        if not np.isfinite(parameter) or not np.all(np.isfinite(intersection_point)):
            raise OverflowError("Doğru-düzlem kesişimi sayı aralığını aşıyor.")
        point_linear = _finite_dot(
            canonical[:3],
            intersection_point,
            context="Doğru-düzlem kesişim artığı",
        )
        plane_residual = math.fsum((point_linear, float(canonical[3])))
        relation = "intersecting"
        distance = 0.0
        condition_indicator = 1.0 / incidence_magnitude
        numerically_ambiguous = False

    return LinePlaneDiagnostics3D(
        relation=relation,
        intersection_point=intersection_point,
        parameter=(None if parameter is None else float(parameter)),
        line_plane_angle=angle,
        normalized_incidence=incidence_magnitude,
        signed_anchor_distance=float(signed_distance),
        distance=float(distance),
        condition_indicator=float(condition_indicator),
        intersection_plane_residual=(
            None if plane_residual is None else float(plane_residual)
        ),
        angular_tolerance=angular,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
        distance_threshold=distance_threshold,
        numerically_ambiguous=numerically_ambiguous,
    )


@dataclass(frozen=True)
class PlanePlaneDiagnostics3D:
    """İki düzlemin ilişki, açı, uzaklık ve kesişim doğrusu tanısı."""

    relation: PlanePlaneRelation3D
    line_point: FloatArray | None
    line_direction: FloatArray | None
    distance: float
    small_angle: float
    normalized_cross_magnitude: float
    aligned_offset_difference: float
    condition_number: float
    singular_values: FloatArray
    line_point_residuals: FloatArray | None
    angular_tolerance: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float
    distance_threshold: float
    numerically_ambiguous: bool


def plane_plane_diagnostics_3d(
    first_plane: ArrayLike,
    second_plane: ArrayLike,
    *,
    angular_tolerance: float,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> PlanePlaneDiagnostics3D:
    """İki düzlemi kesişen, paralel veya çakışık olarak sınıflandırır."""

    first = canonical_plane_coefficients(first_plane)
    second = canonical_plane_coefficients(second_plane)
    angular = _angular_tolerance(angular_tolerance)
    absolute, relative, scale, distance_threshold = _distance_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    dot = _finite_dot(first[:3], second[:3], context="Düzlem normalleri iç çarpımı")
    aligned_second = second.copy()
    if dot < 0.0:
        aligned_second = -aligned_second
    with np.errstate(over="ignore", invalid="ignore"):
        offset_difference = abs(float(first[3] - aligned_second[3]))
    if not np.isfinite(offset_difference):
        raise OverflowError("Paralel düzlemlerin sabit terim farkı sayı aralığını aşıyor.")
    cross = cross_product_3d(first[:3], second[:3])
    cross_magnitude = _finite_norm(cross, context="Düzlem normalleri vektörel çarpımı")
    small_angle = float(np.arctan2(cross_magnitude, abs(dot)))
    normal_matrix = np.vstack([first[:3], second[:3]])
    singular_values = np.linalg.svd(normal_matrix, compute_uv=False)
    if not np.all(np.isfinite(singular_values)):
        raise OverflowError("Düzlem çifti tekil değerleri sayı aralığını aşıyor.")
    condition_number = (
        math.inf
        if singular_values[-1] == 0.0
        else float(singular_values[0] / singular_values[-1])
    )

    if cross_magnitude <= angular:
        relation: PlanePlaneRelation3D = (
            "coincident" if offset_difference <= distance_threshold else "parallel"
        )
        line_point = None
        line_direction = None
        distance = 0.0 if relation == "coincident" else offset_difference
        residuals = None
        numerically_ambiguous = bool(
            (0.0 < cross_magnitude <= angular)
            or (0.0 < offset_difference <= distance_threshold)
        )
    else:
        left, values, right_transpose = np.linalg.svd(normal_matrix, full_matrices=False)
        rhs = -np.array([first[3], second[3]], dtype=float)
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            line_point = right_transpose.T @ ((left.T @ rhs) / values)
            line_direction = _canonical_unit_direction(cross / cross_magnitude)
        if not np.all(np.isfinite(line_point)) or not np.all(np.isfinite(line_direction)):
            raise OverflowError("Düzlem kesişim doğrusu sayı aralığını aşıyor.")
        residuals = np.array(
            [
                math.fsum(
                    (
                        _finite_dot(
                            first[:3],
                            line_point,
                            context="Birinci düzlem kesişim artığı",
                        ),
                        float(first[3]),
                    )
                ),
                math.fsum(
                    (
                        _finite_dot(
                            second[:3],
                            line_point,
                            context="İkinci düzlem kesişim artığı",
                        ),
                        float(second[3]),
                    )
                ),
            ],
            dtype=float,
        )
        if not np.all(np.isfinite(residuals)):
            raise OverflowError("Düzlem kesişim artıkları sayı aralığını aşıyor.")
        relation = "intersecting"
        distance = 0.0
        numerically_ambiguous = False

    return PlanePlaneDiagnostics3D(
        relation=relation,
        line_point=line_point,
        line_direction=line_direction,
        distance=float(distance),
        small_angle=small_angle,
        normalized_cross_magnitude=cross_magnitude,
        aligned_offset_difference=offset_difference,
        condition_number=condition_number,
        singular_values=singular_values.copy(),
        line_point_residuals=(None if residuals is None else residuals),
        angular_tolerance=angular,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
        distance_threshold=distance_threshold,
        numerically_ambiguous=numerically_ambiguous,
    )
