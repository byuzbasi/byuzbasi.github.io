"""Küreler, düzlem kesitleri ve küre sistemleri için güvenli yardımcılar.

Bir küre ``center`` merkezi ve negatif olmayan ``radius`` yarıçapıyla;
bir uzay doğrusu ``line_point + t*line_direction`` biçiminde; bir düzlem ise
``a*x + b*y + c*z + d = 0`` katsayı sırasıyla temsil edilir. Koordinatlar
uzunluk birimindeyken nokta kuvveti ve radikal denklem artıkları uzunluk
karesi birimindedir.

Sayısal ilişki sınıfları açık mutlak ve göreli toleranslara bağlıdır. Bu
toleranslar fiziksel ölçüm belirsizliği veya mühendislik kabul sınırı değildir;
sonuç nesneleri kullanılan eşikleri, rankı ve doğrulama artıklarını raporlar.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array
from .spatial_lines_planes import canonical_plane_coefficients


def _spatial_point(value: ArrayLike, *, name: str) -> FloatArray:
    point = _finite_array(value, name=name)
    if point.shape != (3,):
        raise ValueError(f"{name}, (3,) biçiminde bir uzay noktası olmalıdır.")
    return point.copy()


def _finite_scalar(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number):
        raise ValueError(f"{name} sonlu bir reel sayı olmalıdır.")
    return number


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = _finite_scalar(value, name=name)
    if number < 0.0:
        raise ValueError(f"{name} negatif olmayan bir sayı olmalıdır.")
    return number


def _positive_finite(value: float, *, name: str) -> float:
    number = _finite_scalar(value, name=name)
    if number <= 0.0:
        raise ValueError(f"{name} pozitif bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="relative_tolerance")
    if tolerance >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _rank_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="rank_tolerance")
    if tolerance >= 1.0:
        raise ValueError("rank_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _length_threshold(
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> tuple[float, float, float, float]:
    absolute = _nonnegative_finite(absolute_tolerance, name="absolute_tolerance")
    relative = _relative_tolerance(relative_tolerance)
    scale = _positive_finite(reference_scale, name="reference_scale")
    with np.errstate(over="ignore", invalid="ignore"):
        threshold = absolute + relative * scale
    if not np.isfinite(threshold):
        raise OverflowError("Uzunluk eşiği kayan noktalı sayı aralığını aşıyor.")
    return absolute, relative, scale, float(threshold)


def _finite_norm(vector: FloatArray, *, context: str) -> float:
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        magnitude = float(np.linalg.norm(vector))
    if not np.isfinite(magnitude):
        raise OverflowError(f"{context} kayan noktalı sayı aralığını aşıyor.")
    return magnitude


def _finite_dot(left: FloatArray, right: FloatArray, *, context: str) -> float:
    products = [float(a) * float(b) for a, b in zip(left, right, strict=True)]
    if not np.all(np.isfinite(products)):
        raise OverflowError(f"{context} ara çarpımı kayan noktalı sayı aralığını aşıyor.")
    result = math.fsum(products)
    if not np.isfinite(result):
        raise OverflowError(f"{context} kayan noktalı sayı aralığını aşıyor.")
    return result


def _sphere(center: ArrayLike, radius: float) -> tuple[FloatArray, float]:
    return (
        _spatial_point(center, name="center"),
        _nonnegative_finite(radius, name="radius"),
    )


def sphere_point_power(center: ArrayLike, radius: float, point: ArrayLike) -> float:
    """Bir noktanın küreye göre işaretli kuvvetini verir.

    Sonuç ``||point-center||²-radius²`` değeridir. Koordinatlar uzunluk
    birimindeyse sonuç uzunluk karesi birimindedir; değer küre yüzeyinin
    içinde negatif, üzerinde sıfır ve dışında pozitiftir.
    """

    center_array, radius_value = _sphere(center, radius)
    candidate = _spatial_point(point, name="point")
    with np.errstate(over="ignore", invalid="ignore"):
        offset = candidate - center_array
    squared_distance = _finite_dot(offset, offset, context="Nokta kuvveti uzaklık karesi")
    with np.errstate(over="ignore", invalid="ignore"):
        power = squared_distance - radius_value**2
    if not np.isfinite(power):
        raise OverflowError("Nokta kuvveti hesabı sayı aralığını aşıyor.")
    return float(power)


@dataclass(frozen=True)
class GeneralSphereDiagnostics:
    """``A(x²+y²+z²)+Dx+Ey+Fz+G=0`` denkleminin reel tanısı."""

    normalized_coefficients: FloatArray
    center: FloatArray
    radius_squared: float
    radius: float | None
    locus_type: str
    radius_squared_tolerance: float


def general_sphere_diagnostics(
    coefficients: ArrayLike,
    *,
    radius_squared_tolerance: float = 0.0,
) -> GeneralSphereDiagnostics:
    """Genel küre denklemini merkez-yarıçap verisine dönüştürür.

    ``coefficients`` sırası ``(A, D, E, F, G)`` olup ``A`` sıfır olamaz.
    ``radius_squared_tolerance`` uzunluk karesi birimindedir ve yalnız
    sıfıra yakın küre/nokta/boş reel yer sınıflandırmasını belirler.
    """

    values = _finite_array(coefficients, name="coefficients")
    if values.shape != (5,):
        raise ValueError(
            "coefficients, (A, D, E, F, G) sıralı (5,) biçiminde olmalıdır."
        )
    if values[0] == 0.0:
        raise ValueError("Genel küre denkleminde A sıfır olamaz.")
    tolerance = _nonnegative_finite(
        radius_squared_tolerance,
        name="radius_squared_tolerance",
    )
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        normalized = values / values[0]
        center = -0.5 * normalized[1:4]
    if not np.all(np.isfinite(normalized)) or not np.all(np.isfinite(center)):
        raise OverflowError("Genel küre normalizasyonu sayı aralığını aşıyor.")
    center_squared = _finite_dot(center, center, context="Küre merkez normu karesi")
    with np.errstate(over="ignore", invalid="ignore"):
        radius_squared = center_squared - float(normalized[4])
    if not np.isfinite(radius_squared):
        raise OverflowError("Küre yarıçap karesi hesabı sayı aralığını aşıyor.")

    if radius_squared > tolerance:
        locus_type = "sphere"
        radius: float | None = float(np.sqrt(radius_squared))
    elif radius_squared < -tolerance:
        locus_type = "empty"
        radius = None
    else:
        locus_type = "point"
        radius = 0.0

    return GeneralSphereDiagnostics(
        normalized_coefficients=normalized,
        center=center,
        radius_squared=float(radius_squared),
        radius=radius,
        locus_type=locus_type,
        radius_squared_tolerance=tolerance,
    )


@dataclass(frozen=True)
class SphereMembershipDiagnostics:
    """Tek noktanın küre yüzeyine açık toleranslı üyelik tanısı."""

    center_distance: float
    radial_residual: float
    radial_residual_magnitude: float
    algebraic_residual: float
    algebraic_residual_magnitude: float
    length_threshold: float
    algebraic_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float
    on_sphere: bool


def sphere_membership_diagnostics(
    center: ArrayLike,
    radius: float,
    point: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> SphereMembershipDiagnostics:
    """Bir noktanın radyal ve cebirsel küre artıklarını raporlar.

    Radyal artık uzunluk, cebirsel artık uzunluk karesi birimindedir. Üyelik
    kararı yalnız radyal artık ve ``atol + rtol*reference_scale`` eşiğiyle
    verilir.
    """

    center_array, radius_value = _sphere(center, radius)
    candidate = _spatial_point(point, name="point")
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        offset = candidate - center_array
    distance = _finite_norm(offset, context="Küre merkez uzaklığı")
    radial_residual = distance - radius_value
    algebraic_residual = sphere_point_power(center_array, radius_value, candidate)
    with np.errstate(over="ignore", invalid="ignore"):
        algebraic_threshold = threshold * (distance + radius_value)
    if not np.isfinite(algebraic_threshold):
        raise OverflowError("Küre cebirsel üyelik eşiği sayı aralığını aşıyor.")
    return SphereMembershipDiagnostics(
        center_distance=distance,
        radial_residual=float(radial_residual),
        radial_residual_magnitude=abs(float(radial_residual)),
        algebraic_residual=algebraic_residual,
        algebraic_residual_magnitude=abs(algebraic_residual),
        length_threshold=threshold,
        algebraic_threshold=float(algebraic_threshold),
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
        on_sphere=bool(abs(radial_residual) <= threshold),
    )


@dataclass(frozen=True)
class LineSphereIntersectionDiagnostics:
    """Bir sonsuz doğru ile küre yüzeyinin sayısal kesişim tanısı."""

    relation: str
    points: FloatArray
    parameters: FloatArray
    foot: FloatArray
    center_distance: float
    clearance: float
    half_chord_length: float | None
    chord_length: float | None
    direction_norm: float
    radial_residuals: FloatArray
    line_residuals: FloatArray
    length_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float


def line_sphere_intersections_3d(
    center: ArrayLike,
    radius: float,
    line_point: ArrayLike,
    line_direction: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> LineSphereIntersectionDiagnostics:
    """Doğru-küre ilişkisini ``disjoint``, ``tangent`` veya ``secant`` yapar.

    Sıfır yarıçaplı bir nokta küre doğru üzerinde ise ilişki ``point`` olur.
    Kesen durumda hesap, kuadratik köklerin çıkarılması yerine merkezin
    doğruya dik izdüşümü ve yarı kiriş uzunluğunu kullanır.
    """

    center_array, radius_value = _sphere(center, radius)
    anchor = _spatial_point(line_point, name="line_point")
    direction = _spatial_point(line_direction, name="line_direction")
    direction_norm = _finite_norm(direction, context="Doğru yön vektörü normu")
    if direction_norm == 0.0:
        raise ValueError("line_direction sıfır vektörü olamaz.")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        unit = direction / direction_norm
        center_offset = center_array - anchor
    if not np.all(np.isfinite(unit)) or not np.all(np.isfinite(center_offset)):
        raise OverflowError("Doğru-küre ara vektörü sayı aralığını aşıyor.")
    along = _finite_dot(center_offset, unit, context="Doğru-küre izdüşüm bileşeni")
    with np.errstate(over="ignore", invalid="ignore"):
        foot = anchor + along * unit
    if not np.all(np.isfinite(foot)):
        raise OverflowError("Doğru-küre dikme ayağı sayı aralığını aşıyor.")
    perpendicular = center_array - foot
    distance = _finite_norm(perpendicular, context="Merkezin doğruya uzaklığı")
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    clearance = distance - radius_value
    base_parameter = along / direction_norm

    if clearance > threshold:
        relation = "disjoint"
        points = np.empty((0, 3), dtype=float)
        parameters = np.empty((0,), dtype=float)
        half_chord: float | None = None
        chord: float | None = None
    elif radius_value == 0.0:
        relation = "point"
        points = foot.reshape(1, 3)
        parameters = np.array([base_parameter], dtype=float)
        half_chord = 0.0
        chord = 0.0
    elif clearance >= -threshold:
        relation = "tangent"
        points = foot.reshape(1, 3)
        parameters = np.array([base_parameter], dtype=float)
        half_chord = 0.0
        chord = 0.0
    else:
        relation = "secant"
        with np.errstate(over="ignore", invalid="ignore"):
            radicand = (radius_value - distance) * (radius_value + distance)
        if not np.isfinite(radicand):
            raise OverflowError("Doğru-küre kiriş hesabı sayı aralığını aşıyor.")
        if radicand < 0.0:
            raise ArithmeticError("Kesen sınıfında negatif kiriş radikandı oluştu.")
        half_chord = float(np.sqrt(radicand))
        chord = 2.0 * half_chord
        with np.errstate(over="ignore", invalid="ignore"):
            points = np.vstack((foot - half_chord * unit, foot + half_chord * unit))
            parameter_offset = half_chord / direction_norm
            parameters = np.array(
                [base_parameter - parameter_offset, base_parameter + parameter_offset],
                dtype=float,
            )

    if not np.all(np.isfinite(points)) or not np.all(np.isfinite(parameters)):
        raise OverflowError("Doğru-küre kesişim noktaları sayı aralığını aşıyor.")
    if points.shape[0] == 0:
        radial_residuals = np.empty((0,), dtype=float)
        line_residuals = np.empty((0,), dtype=float)
    else:
        radial_residuals = np.array(
            [
                _finite_norm(point - center_array, context="Küre kesişim yarıçapı")
                - radius_value
                for point in points
            ],
            dtype=float,
        )
        line_residuals = np.array(
            [
                _finite_norm(
                    np.cross(point - anchor, unit),
                    context="Küre kesişim doğru artığı",
                )
                for point in points
            ],
            dtype=float,
        )
    return LineSphereIntersectionDiagnostics(
        relation=relation,
        points=points,
        parameters=parameters,
        foot=foot,
        center_distance=distance,
        clearance=float(clearance),
        half_chord_length=half_chord,
        chord_length=chord,
        direction_norm=direction_norm,
        radial_residuals=radial_residuals,
        line_residuals=line_residuals,
        length_threshold=threshold,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
    )


@dataclass(frozen=True)
class SpherePlaneSectionDiagnostics:
    """Bir düzlemin küre yüzeyinde bıraktığı kesitin sayısal tanısı."""

    relation: str
    canonical_plane: FloatArray
    section_center: FloatArray
    section_radius: float | None
    signed_center_distance: float
    center_distance: float
    clearance: float
    section_center_plane_residual: float
    length_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float


def sphere_plane_section_diagnostics(
    center: ArrayLike,
    radius: float,
    plane: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> SpherePlaneSectionDiagnostics:
    """Düzlem-küre kesitini ``circle``, ``tangent`` veya ``disjoint`` yapar.

    Sıfır yarıçaplı kürenin düzlemdeki tek noktası için ilişki ``point`` olur.
    Düzlem katsayıları önce birim normal ve tek işaretle kanonikleştirilir.
    """

    center_array, radius_value = _sphere(center, radius)
    canonical = canonical_plane_coefficients(plane)
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    linear = _finite_dot(canonical[:3], center_array, context="Küre-düzlem uzaklığı")
    signed_distance = math.fsum((linear, float(canonical[3])))
    if not np.isfinite(signed_distance):
        raise OverflowError("Küre-düzlem işaretli uzaklığı sayı aralığını aşıyor.")
    distance = abs(signed_distance)
    with np.errstate(over="ignore", invalid="ignore"):
        section_center = center_array - signed_distance * canonical[:3]
    if not np.all(np.isfinite(section_center)):
        raise OverflowError("Küre-düzlem kesit merkezi sayı aralığını aşıyor.")
    clearance = distance - radius_value
    if clearance > threshold:
        relation = "disjoint"
        section_radius: float | None = None
    elif radius_value == 0.0:
        relation = "point"
        section_radius = 0.0
    elif clearance >= -threshold:
        relation = "tangent"
        section_radius = 0.0
    else:
        relation = "circle"
        with np.errstate(over="ignore", invalid="ignore"):
            radius_squared = (radius_value - distance) * (radius_value + distance)
        if not np.isfinite(radius_squared):
            raise OverflowError("Düzlem kesiti yarıçapı sayı aralığını aşıyor.")
        if radius_squared < 0.0:
            raise ArithmeticError("Çember kesiti sınıfında negatif yarıçap karesi oluştu.")
        section_radius = float(np.sqrt(radius_squared))
    section_residual = math.fsum(
        (
            _finite_dot(
                canonical[:3],
                section_center,
                context="Kesit merkezi düzlem artığı",
            ),
            float(canonical[3]),
        )
    )
    return SpherePlaneSectionDiagnostics(
        relation=relation,
        canonical_plane=canonical,
        section_center=section_center,
        section_radius=section_radius,
        signed_center_distance=float(signed_distance),
        center_distance=distance,
        clearance=float(clearance),
        section_center_plane_residual=float(section_residual),
        length_threshold=threshold,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
    )


def tangent_plane_at_sphere_point(
    center: ArrayLike,
    radius: float,
    point: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> FloatArray:
    """Pozitif yarıçaplı kürenin verilen yüzey noktasındaki teğet düzlemi.

    Dönen ``(a,b,c,d)`` katsayıları kanoniktir. Nokta açık uzunluk eşiği
    içinde küre yüzeyinde değilse veya küre bir nokta küreyse işlem reddedilir.
    """

    center_array, radius_value = _sphere(center, radius)
    if radius_value == 0.0:
        raise ValueError("Nokta kürenin tek bir teğet düzlemi yoktur.")
    candidate = _spatial_point(point, name="point")
    membership = sphere_membership_diagnostics(
        center_array,
        radius_value,
        candidate,
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    if not membership.on_sphere:
        raise ValueError("point, verilen açık eşik içinde küre yüzeyinde değildir.")
    normal = candidate - center_array
    normal_norm = _finite_norm(normal, context="Teğet düzlem normali")
    if normal_norm == 0.0:
        raise ValueError("Küre merkezi bir teğet noktası olamaz.")
    offset = -_finite_dot(normal, candidate, context="Teğet düzlem sabiti")
    return canonical_plane_coefficients([normal[0], normal[1], normal[2], offset])


@dataclass(frozen=True)
class SphereSphereIntersectionDiagnostics:
    """İki küre yüzeyinin göreli konumu ve varsa ortak geometrik yeri."""

    relation: str
    center_distance: float
    radius_sum: float
    radius_difference: float
    circle_center: FloatArray | None
    circle_radius: float | None
    circle_plane: FloatArray | None
    tangent_point: FloatArray | None
    tangent_power_residuals: FloatArray | None
    length_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float


def sphere_sphere_intersection_diagnostics(
    first_center: ArrayLike,
    first_radius: float,
    second_center: ArrayLike,
    second_radius: float,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> SphereSphereIntersectionDiagnostics:
    """İki küreyi yedi temel göreli konumdan biriyle sınıflandırır.

    İlişkiler ``coincident``, ``concentric_disjoint``, ``separate``,
    ``externally_tangent``, ``intersection_circle``, ``internally_tangent``
    ve ``contained`` değerleridir. Eşmerkez kararı açık uzunluk eşiğine bağlıdır.
    """

    first, r1 = _sphere(first_center, first_radius)
    second, r2 = _sphere(second_center, second_radius)
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        offset = second - first
        radius_sum = r1 + r2
        radius_difference = abs(r1 - r2)
    distance = _finite_norm(offset, context="Küre merkezleri uzaklığı")
    if not np.isfinite(radius_sum) or not np.isfinite(radius_difference):
        raise OverflowError("Küre yarıçap karşılaştırması sayı aralığını aşıyor.")

    circle_center: FloatArray | None = None
    circle_radius: float | None = None
    circle_plane: FloatArray | None = None
    tangent_point: FloatArray | None = None
    tangent_residuals: FloatArray | None = None

    if distance <= threshold:
        relation = "coincident" if radius_difference <= threshold else "concentric_disjoint"
    else:
        unit = offset / distance
        external_gap = distance - radius_sum
        internal_gap = distance - radius_difference
        if external_gap > threshold:
            relation = "separate"
        elif abs(external_gap) <= threshold:
            relation = "externally_tangent"
        elif internal_gap < -threshold:
            relation = "contained"
        elif abs(internal_gap) <= threshold:
            relation = "internally_tangent"
        else:
            relation = "intersection_circle"

        if relation in {"externally_tangent", "internally_tangent", "intersection_circle"}:
            numerator = math.fsum((r1 * r1, -(r2 * r2), distance * distance))
            with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                axial_distance = numerator / (2.0 * distance)
                circle_center = first + axial_distance * unit
            if not np.isfinite(axial_distance) or not np.all(np.isfinite(circle_center)):
                raise OverflowError("Küre kesişim merkezi sayı aralığını aşıyor.")
            circle_plane = canonical_plane_coefficients(
                [
                    unit[0],
                    unit[1],
                    unit[2],
                    -_finite_dot(unit, circle_center, context="Kesişim düzlemi sabiti"),
                ]
            )
            if relation == "intersection_circle":
                with np.errstate(over="ignore", invalid="ignore"):
                    radius_squared = (r1 - axial_distance) * (r1 + axial_distance)
                if not np.isfinite(radius_squared):
                    raise OverflowError("Kesişim çemberi yarıçapı sayı aralığını aşıyor.")
                if radius_squared < 0.0:
                    raise ArithmeticError(
                        "Çember kesişimi sınıfında negatif yarıçap karesi oluştu."
                    )
                circle_radius = float(np.sqrt(radius_squared))
            else:
                circle_radius = 0.0
                tangent_point = circle_center.copy()
                tangent_residuals = np.array(
                    [
                        sphere_point_power(first, r1, tangent_point),
                        sphere_point_power(second, r2, tangent_point),
                    ],
                    dtype=float,
                )

    return SphereSphereIntersectionDiagnostics(
        relation=relation,
        center_distance=distance,
        radius_sum=float(radius_sum),
        radius_difference=float(radius_difference),
        circle_center=circle_center,
        circle_radius=circle_radius,
        circle_plane=circle_plane,
        tangent_point=tangent_point,
        tangent_power_residuals=tangent_residuals,
        length_threshold=threshold,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
    )


@dataclass(frozen=True)
class RadicalPlaneDiagnostics:
    """İki kürenin eşit-kuvvet geometrik yerinin sayısal tanısı."""

    relation: str
    plane_coefficients: FloatArray | None
    center_distance: float
    radius_difference: float
    length_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float


def radical_plane_diagnostics(
    first_center: ArrayLike,
    first_radius: float,
    second_center: ArrayLike,
    second_radius: float,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> RadicalPlaneDiagnostics:
    """Radikal düzlemi veya eşmerkezli sınır durumunu sınıflandırır.

    Farklı merkezlerde sonuç ``plane``; özdeş kürelerde ``all_space``;
    eşmerkezli fakat farklı yarıçaplarda ``empty`` olur.
    """

    first, r1 = _sphere(first_center, first_radius)
    second, r2 = _sphere(second_center, second_radius)
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    offset = second - first
    distance = _finite_norm(offset, context="Radikal düzlem merkez uzaklığı")
    radius_difference = abs(r1 - r2)
    if distance <= threshold:
        relation = "all_space" if radius_difference <= threshold else "empty"
        plane: FloatArray | None = None
    else:
        first_squared = _finite_dot(first, first, context="Birinci merkez normu karesi")
        second_squared = _finite_dot(second, second, context="İkinci merkez normu karesi")
        with np.errstate(over="ignore", invalid="ignore"):
            normal = 2.0 * offset
            constant = math.fsum((first_squared, -(r1 * r1), -second_squared, r2 * r2))
        if not np.all(np.isfinite(normal)) or not np.isfinite(constant):
            raise OverflowError("Radikal düzlem katsayıları sayı aralığını aşıyor.")
        plane = canonical_plane_coefficients(
            [normal[0], normal[1], normal[2], constant]
        )
        relation = "plane"
    return RadicalPlaneDiagnostics(
        relation=relation,
        plane_coefficients=plane,
        center_distance=distance,
        radius_difference=float(radius_difference),
        length_threshold=threshold,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
    )


@dataclass(frozen=True)
class SphereSystemDiagnostics:
    """Kürelerin ortak eşit-kuvvet ve ortak yüzey geometrisinin SVD tanısı."""

    relation: str
    anchor: FloatArray | None
    direction_basis: FloatArray
    coefficient_matrix: FloatArray
    right_hand_side: FloatArray
    equation_residuals: FloatArray
    power_values: FloatArray
    power_spread: float
    rank: int
    singular_values: FloatArray
    singular_value_threshold: float
    condition_number: float | None
    common_locus_type: str
    common_points: FloatArray
    common_circle_center: FloatArray | None
    common_circle_radius: float | None
    common_circle_normal: FloatArray | None
    length_threshold: float
    power_threshold: float
    rank_tolerance: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float


def sphere_system_diagnostics(
    centers: ArrayLike,
    radii: ArrayLike,
    *,
    rank_tolerance: float,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> SphereSystemDiagnostics:
    """İki veya daha çok kürenin eşit-kuvvet sistemini SVD ile çözer.

    İlk kürenin denklemi diğerlerinden çıkarılır. Böylece ``A X = b`` doğrusal
    sistemi oluşur; ``A`` uzunluk, ``b`` ve denklem artıkları uzunluk karesi
    birimindedir. Tutarlı sistemin rankı 3, 2, 1 veya 0 olduğunda eşit-kuvvet
    geometrik yeri sırasıyla nokta, doğru, düzlem veya bütün uzaydır.
    ``common_locus_type`` ayrıca bu afin yerin ilk küre yüzeyiyle gerçek
    kesişimini raporlar.
    """

    center_values = _finite_array(centers, name="centers")
    radius_values = _finite_array(radii, name="radii")
    if center_values.ndim != 2 or center_values.shape[1] != 3:
        raise ValueError("centers, (m, 3) biçiminde olmalıdır.")
    if center_values.shape[0] < 2:
        raise ValueError("Küre sistemi en az iki küre içermelidir.")
    if radius_values.shape != (center_values.shape[0],):
        raise ValueError("radii, centers satır sayısıyla uyumlu (m,) biçiminde olmalıdır.")
    if np.any(radius_values < 0.0):
        raise ValueError("radii negatif olmayan sayılardan oluşmalıdır.")
    rank_relative = _rank_tolerance(rank_tolerance)
    absolute, relative, scale, length_threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )

    base_center = center_values[0]
    base_radius = float(radius_values[0])
    with np.errstate(over="ignore", invalid="ignore"):
        matrix = 2.0 * (center_values[1:] - base_center)
    if not np.all(np.isfinite(matrix)):
        raise OverflowError("Küre sistemi katsayı matrisi sayı aralığını aşıyor.")
    center_squared = np.array(
        [_finite_dot(row, row, context="Sistem merkez normu karesi") for row in center_values],
        dtype=float,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        reduced_constants = center_squared - radius_values**2
        right_hand_side = reduced_constants[1:] - reduced_constants[0]
    if not np.all(np.isfinite(right_hand_side)):
        raise OverflowError("Küre sistemi sağ tarafı sayı aralığını aşıyor.")

    try:
        left_vectors, singular_values, right_vectors = np.linalg.svd(
            matrix,
            full_matrices=True,
        )
    except np.linalg.LinAlgError as exc:
        raise ArithmeticError("Küre sistemi SVD ayrışımı yakınsamadı.") from exc
    if not np.all(np.isfinite(singular_values)):
        raise OverflowError("Küre sistemi tekil değerleri sonlu değildir.")
    largest = float(singular_values[0]) if singular_values.size else 0.0
    singular_threshold = max(2.0 * length_threshold, rank_relative * largest)
    rank = int(np.count_nonzero(singular_values > singular_threshold))
    if rank == 0:
        anchor = np.zeros(3, dtype=float)
    else:
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            coordinates = (
                left_vectors[:, :rank].T @ right_hand_side
            ) / singular_values[:rank]
            anchor = right_vectors[:rank].T @ coordinates
    if not np.all(np.isfinite(anchor)):
        raise OverflowError("Küre sistemi çözüm çapası sayı aralığını aşıyor.")
    direction_basis = right_vectors[rank:].copy()
    with np.errstate(over="ignore", invalid="ignore"):
        residuals = matrix @ anchor - right_hand_side
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Küre sistemi artıkları sayı aralığını aşıyor.")
    powers = np.array(
        [
            sphere_point_power(center_values[index], float(radius_values[index]), anchor)
            for index in range(center_values.shape[0])
        ],
        dtype=float,
    )
    power_spread = float(np.max(powers) - np.min(powers))
    center_scales = np.array(
        [_finite_norm(row, context="Küre sistemi merkez ölçeği") for row in center_values]
    )
    anchor_scale = _finite_norm(anchor, context="Küre sistemi çapa ölçeği")
    geometric_scale = max(
        scale,
        anchor_scale,
        float(np.max(center_scales, initial=0.0)),
        float(np.max(radius_values, initial=0.0)),
    )
    with np.errstate(over="ignore", invalid="ignore"):
        power_threshold = length_threshold * (2.0 * geometric_scale + length_threshold)
    if not np.isfinite(power_threshold):
        raise OverflowError("Küre sistemi güç eşiği sayı aralığını aşıyor.")
    consistent = bool(float(np.max(np.abs(residuals), initial=0.0)) <= power_threshold)
    if not consistent:
        relation = "empty"
        reported_anchor: FloatArray | None = None
    else:
        relation = {0: "all_space", 1: "plane", 2: "line", 3: "point"}[rank]
        reported_anchor = anchor
    condition_number = (
        float(singular_values[0] / singular_values[rank - 1]) if rank > 0 else None
    )

    common_locus_type = "none"
    common_points = np.empty((0, 3), dtype=float)
    common_circle_center: FloatArray | None = None
    common_circle_radius: float | None = None
    common_circle_normal: FloatArray | None = None

    if consistent and relation == "point":
        if abs(float(powers[0])) <= power_threshold:
            common_locus_type = "point"
            common_points = anchor.reshape(1, 3)
    elif consistent and relation == "line":
        line_result = line_sphere_intersections_3d(
            base_center,
            base_radius,
            anchor,
            direction_basis[0],
            absolute_tolerance=absolute,
            relative_tolerance=relative,
            reference_scale=scale,
        )
        common_points = line_result.points
        if line_result.relation == "secant":
            common_locus_type = "two_points"
        elif line_result.relation in {"tangent", "point"}:
            common_locus_type = "point"
    elif consistent and relation == "plane":
        normal = right_vectors[0]
        plane = canonical_plane_coefficients(
            [
                normal[0],
                normal[1],
                normal[2],
                -_finite_dot(normal, anchor, context="Sistem düzlemi sabiti"),
            ]
        )
        section = sphere_plane_section_diagnostics(
            base_center,
            base_radius,
            plane,
            absolute_tolerance=absolute,
            relative_tolerance=relative,
            reference_scale=scale,
        )
        if section.relation == "circle":
            common_locus_type = "circle"
            common_circle_center = section.section_center
            common_circle_radius = section.section_radius
            common_circle_normal = plane[:3]
        elif section.relation in {"tangent", "point"}:
            common_locus_type = "point"
            common_points = section.section_center.reshape(1, 3)
    elif consistent and relation == "all_space":
        if base_radius == 0.0:
            common_locus_type = "point"
            common_points = base_center.reshape(1, 3)
        else:
            common_locus_type = "sphere"

    return SphereSystemDiagnostics(
        relation=relation,
        anchor=reported_anchor,
        direction_basis=direction_basis,
        coefficient_matrix=matrix,
        right_hand_side=right_hand_side,
        equation_residuals=residuals,
        power_values=powers,
        power_spread=power_spread,
        rank=rank,
        singular_values=singular_values,
        singular_value_threshold=float(singular_threshold),
        condition_number=condition_number,
        common_locus_type=common_locus_type,
        common_points=common_points,
        common_circle_center=common_circle_center,
        common_circle_radius=common_circle_radius,
        common_circle_normal=common_circle_normal,
        length_threshold=length_threshold,
        power_threshold=float(power_threshold),
        rank_tolerance=rank_relative,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
    )


def sphere_pencil_member(
    first_coefficients: ArrayLike,
    second_coefficients: ArrayLike,
    parameter: float,
    *,
    radius_squared_tolerance: float = 0.0,
) -> GeneralSphereDiagnostics:
    """İki genel kürenin ölçekten bağımsız afin aile üyesini kurar.

    Her denklem önce ikinci derece katsayısı bir olacak biçimde normalize
    edilir; sonra ``S_t=(1-t)S_1+tS_2`` alınır. Üye gerçek küre, nokta küre
    veya boş reel geometrik yer olabilir.
    """

    first = general_sphere_diagnostics(first_coefficients)
    second = general_sphere_diagnostics(second_coefficients)
    parameter_value = _finite_scalar(parameter, name="parameter")
    tolerance = _nonnegative_finite(
        radius_squared_tolerance,
        name="radius_squared_tolerance",
    )
    with np.errstate(over="ignore", invalid="ignore"):
        coefficients = (
            (1.0 - parameter_value) * first.normalized_coefficients
            + parameter_value * second.normalized_coefficients
        )
    if not np.all(np.isfinite(coefficients)):
        raise OverflowError("Küre ailesi katsayıları sayı aralığını aşıyor.")
    return general_sphere_diagnostics(
        coefficients,
        radius_squared_tolerance=tolerance,
    )
