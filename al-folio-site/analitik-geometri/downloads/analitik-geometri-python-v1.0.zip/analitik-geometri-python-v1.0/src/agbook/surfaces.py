"""Silindirler, koniler ve dönel yüzeyler için güvenli yardımcılar.

Bu modül yüzey ile katıyı ayırır. Bir eksen, ``axis_point`` noktası ve
sıfır olmayan ``axis_direction`` yönüyle verilir. Dairesel silindir ve koni
tanıları koordinat eksenlerinden bağımsızdır. Dönel yüzeyler ise eksenel
koordinat ``s`` ve negatif olmayan yarıçap ``rho`` çiftlerinden üretilir.

Sayısal eşikler yalnız kayan noktalı sınıflandırma içindir; fiziksel ölçüm
belirsizliği, üretim toleransı veya mühendislik kabul sınırı değildir.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array
from .spatial_vectors import cross_product_3d


CylinderRadialRelation = Literal["inside", "on_surface", "outside"]
CylinderAxialRelation = Literal[
    "unbounded",
    "below",
    "lower_boundary",
    "within",
    "upper_boundary",
    "above",
]
ConeNappe = Literal["double", "positive", "negative"]
ConeSide = Literal["apex", "positive", "negative", "equatorial"]
ConeRelation = Literal["inside", "on_surface", "outside", "wrong_nappe"]


def _spatial_vector(value: ArrayLike, *, name: str) -> FloatArray:
    vector = _finite_array(value, name=name)
    if vector.shape != (3,):
        raise ValueError(f"{name}, (3,) biçiminde olmalıdır.")
    return vector.copy()


def _point_cloud(value: ArrayLike, *, name: str) -> FloatArray:
    points = _finite_array(value, name=name)
    if points.ndim != 2 or points.shape[1] != 3 or points.shape[0] == 0:
        raise ValueError(f"{name}, boş olmayan (n, 3) biçiminde olmalıdır.")
    return points.copy()


def _one_dimensional(value: ArrayLike, *, name: str) -> FloatArray:
    array = _finite_array(value, name=name)
    if array.ndim != 1 or array.size == 0:
        raise ValueError(f"{name}, boş olmayan tek boyutlu bir dizi olmalıdır.")
    return array.copy()


def _finite_scalar(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number):
        raise ValueError(f"{name} sonlu bir reel sayı olmalıdır.")
    return number


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = _finite_scalar(value, name=name)
    if number < 0.0:
        raise ValueError(f"{name} negatif olmayan bir sayı olmalıdır.")
    return number


def _positive_finite(value: float, *, name: str) -> float:
    number = _finite_scalar(value, name=name)
    if number <= 0.0:
        raise ValueError(f"{name} pozitif bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="relative_tolerance")
    if tolerance >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _angular_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="angular_tolerance")
    if tolerance >= math.pi:
        raise ValueError("angular_tolerance [0, pi) aralığında olmalıdır.")
    return tolerance


def _finite_norm(vector: FloatArray, *, context: str) -> float:
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        magnitude = float(np.linalg.norm(vector))
    if not np.isfinite(magnitude):
        raise OverflowError(f"{context} kayan noktalı sayı aralığını aşıyor.")
    return magnitude


def _finite_dot(left: FloatArray, right: FloatArray, *, context: str) -> float:
    products = [float(a) * float(b) for a, b in zip(left, right, strict=True)]
    if not np.all(np.isfinite(products)):
        raise OverflowError(f"{context} ara çarpımı sayı aralığını aşıyor.")
    result = math.fsum(products)
    if not np.isfinite(result):
        raise OverflowError(f"{context} sayı aralığını aşıyor.")
    return result


def _length_threshold(
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> tuple[float, float, float, float]:
    absolute = _nonnegative_finite(absolute_tolerance, name="absolute_tolerance")
    relative = _relative_tolerance(relative_tolerance)
    scale = _positive_finite(reference_scale, name="reference_scale")
    with np.errstate(over="ignore", invalid="ignore"):
        threshold = absolute + relative * scale
    if not np.isfinite(threshold):
        raise OverflowError("Uzunluk eşiği sayı aralığını aşıyor.")
    return absolute, relative, scale, float(threshold)


@dataclass(frozen=True)
class AxisFrame3D:
    """Bir eksene bağlı sağ yönlü ortonormal çerçeve."""

    axis_point: FloatArray
    unit_axis: FloatArray
    radial_u: FloatArray
    radial_v: FloatArray
    direction_norm: float
    used_default_reference: bool


def axis_frame_3d(
    axis_point: ArrayLike,
    axis_direction: ArrayLike,
    *,
    radial_reference: ArrayLike | None = None,
    direction_zero_tolerance: float = 0.0,
    angular_tolerance: float = 1e-12,
) -> AxisFrame3D:
    """Ekseni birimlendirir ve ``(radial_u, radial_v, unit_axis)`` kurar.

    ``radial_reference`` verilmezse eksene en az paralel Kartezyen baz yönü
    seçilir. Verilirse bu yön eksene dik düzleme izdüşürülür. Açısal eşik
    boyutsuzdur; yön sıfır eşiği ise ``axis_direction`` ile aynı birimdedir.
    """

    point = _spatial_vector(axis_point, name="axis_point")
    direction = _spatial_vector(axis_direction, name="axis_direction")
    zero_tolerance = _nonnegative_finite(
        direction_zero_tolerance,
        name="direction_zero_tolerance",
    )
    angle_tolerance = _angular_tolerance(angular_tolerance)
    direction_norm = _finite_norm(direction, context="Eksen yön normu")
    if direction_norm <= zero_tolerance:
        raise ValueError("Eksen yönü sıfır veya yön eşiğinin altında olamaz.")
    unit_axis = direction / direction_norm

    used_default = radial_reference is None
    if used_default:
        reference = np.eye(3, dtype=float)[int(np.argmin(np.abs(unit_axis)))]
    else:
        reference = _spatial_vector(radial_reference, name="radial_reference")
        reference_norm = _finite_norm(reference, context="Radyal başvuru normu")
        if reference_norm == 0.0:
            raise ValueError("radial_reference sıfır olamaz.")
        reference = reference / reference_norm

    projection = reference - _finite_dot(
        reference,
        unit_axis,
        context="Radyal başvuru eksen izdüşümü",
    ) * unit_axis
    projection_norm = _finite_norm(projection, context="Radyal başvuru dik bileşeni")
    if projection_norm <= math.sin(angle_tolerance):
        raise ValueError("radial_reference eksene paralel veya açısal eşik altındadır.")
    radial_u = projection / projection_norm
    radial_v = cross_product_3d(unit_axis, radial_u)
    radial_v_norm = _finite_norm(radial_v, context="İkinci radyal baz normu")
    if radial_v_norm == 0.0:
        raise RuntimeError("Eksen çerçevesi kurulamadı.")
    radial_v = radial_v / radial_v_norm
    return AxisFrame3D(
        axis_point=point,
        unit_axis=unit_axis,
        radial_u=radial_u,
        radial_v=radial_v,
        direction_norm=direction_norm,
        used_default_reference=used_default,
    )


@dataclass(frozen=True)
class AxisCoordinates3D:
    """Bir noktanın eksenel ve radyal ayrışımı."""

    axial_coordinate: float
    axis_projection: FloatArray
    radial_vector: FloatArray
    radial_distance: float
    reconstruction_residual: float


def axis_coordinates_3d(
    point: ArrayLike,
    axis_point: ArrayLike,
    axis_direction: ArrayLike,
    *,
    direction_zero_tolerance: float = 0.0,
) -> AxisCoordinates3D:
    """Noktayı eksen üzerindeki izdüşüm ve radyal bileşene ayırır."""

    candidate = _spatial_vector(point, name="point")
    frame = axis_frame_3d(
        axis_point,
        axis_direction,
        direction_zero_tolerance=direction_zero_tolerance,
    )
    offset = candidate - frame.axis_point
    axial = _finite_dot(offset, frame.unit_axis, context="Eksenel koordinat")
    projection = frame.axis_point + axial * frame.unit_axis
    radial = candidate - projection
    distance = _finite_norm(radial, context="Radyal uzaklık")
    reconstructed = projection + radial
    residual = _finite_norm(candidate - reconstructed, context="Eksen ayrışımı artığı")
    return AxisCoordinates3D(
        axial_coordinate=axial,
        axis_projection=projection,
        radial_vector=radial,
        radial_distance=distance,
        reconstruction_residual=residual,
    )


def _axial_bounds(value: tuple[float, float] | None) -> tuple[float, float] | None:
    if value is None:
        return None
    if len(value) != 2:
        raise ValueError("axial_bounds iki sayı içermelidir.")
    lower = _finite_scalar(value[0], name="axial_bounds[0]")
    upper = _finite_scalar(value[1], name="axial_bounds[1]")
    if not lower < upper:
        raise ValueError("axial_bounds için alt sınır üst sınırdan küçük olmalıdır.")
    return lower, upper


@dataclass(frozen=True)
class CircularCylinderDiagnostics:
    """Keyfî eksenli dairesel silindir yüzeyi ve katısı için tanı."""

    radius: float
    axial_coordinate: float
    radial_distance: float
    signed_radial_residual: float
    implicit_residual: float
    radial_relation: CylinderRadialRelation
    axial_relation: CylinderAxialRelation
    lateral_surface_member: bool
    cap_member: bool
    boundary_member: bool
    closed_solid_member: bool
    length_tolerance: float


def circular_cylinder_diagnostics(
    axis_point: ArrayLike,
    axis_direction: ArrayLike,
    radius: float,
    point: ArrayLike,
    *,
    axial_bounds: tuple[float, float] | None = None,
    absolute_tolerance: float = 0.0,
    relative_tolerance: float = 0.0,
    reference_scale: float = 1.0,
) -> CircularCylinderDiagnostics:
    """Dairesel silindirde yan yüzey, kapak ve kapalı katı üyeliğini ayırır."""

    radius_value = _nonnegative_finite(radius, name="radius")
    bounds = _axial_bounds(axial_bounds)
    _, _, _, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    coordinates = axis_coordinates_3d(point, axis_point, axis_direction)
    radial_residual = coordinates.radial_distance - radius_value
    if radial_residual < -threshold:
        radial_relation: CylinderRadialRelation = "inside"
    elif radial_residual > threshold:
        radial_relation = "outside"
    else:
        radial_relation = "on_surface"

    axial = coordinates.axial_coordinate
    if bounds is None:
        axial_relation: CylinderAxialRelation = "unbounded"
        axial_member = True
    else:
        lower, upper = bounds
        if axial < lower - threshold:
            axial_relation = "below"
        elif axial > upper + threshold:
            axial_relation = "above"
        elif abs(axial - lower) <= threshold:
            axial_relation = "lower_boundary"
        elif abs(axial - upper) <= threshold:
            axial_relation = "upper_boundary"
        else:
            axial_relation = "within"
        axial_member = axial_relation not in {"below", "above"}

    radial_member = radial_relation != "outside"
    lateral = radial_relation == "on_surface" and axial_member
    cap = (
        bounds is not None
        and axial_relation in {"lower_boundary", "upper_boundary"}
        and radial_member
    )
    with np.errstate(over="ignore", invalid="ignore"):
        implicit = coordinates.radial_distance**2 - radius_value**2
    if not np.isfinite(implicit):
        raise OverflowError("Silindir örtük artığı sayı aralığını aşıyor.")
    return CircularCylinderDiagnostics(
        radius=radius_value,
        axial_coordinate=axial,
        radial_distance=coordinates.radial_distance,
        signed_radial_residual=float(radial_residual),
        implicit_residual=float(implicit),
        radial_relation=radial_relation,
        axial_relation=axial_relation,
        lateral_surface_member=lateral,
        cap_member=cap,
        boundary_member=lateral or cap,
        closed_solid_member=radial_member and axial_member,
        length_tolerance=threshold,
    )


@dataclass(frozen=True)
class CircularConeDiagnostics:
    """Keyfî eksenli dairesel koni için kanat ve yüzey tanısı."""

    half_angle: float
    nappe: ConeNappe
    side: ConeSide
    axial_coordinate: float
    radial_distance: float
    expected_radial_distance: float
    signed_radial_residual: float
    implicit_residual: float
    relation: ConeRelation
    is_apex: bool
    allowed_nappe: bool
    length_tolerance: float


def circular_cone_diagnostics(
    apex: ArrayLike,
    axis_direction: ArrayLike,
    half_angle: float,
    point: ArrayLike,
    *,
    nappe: ConeNappe = "double",
    absolute_tolerance: float = 0.0,
    relative_tolerance: float = 0.0,
    reference_scale: float = 1.0,
) -> CircularConeDiagnostics:
    """Dairesel koninin tek veya çift kanadına göre nokta ilişkisini verir."""

    angle = _finite_scalar(half_angle, name="half_angle")
    if not 0.0 < angle < math.pi / 2.0:
        raise ValueError("half_angle, (0, pi/2) aralığında olmalıdır.")
    if nappe not in {"double", "positive", "negative"}:
        raise ValueError("nappe; 'double', 'positive' veya 'negative' olmalıdır.")
    _, _, _, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    apex_point = _spatial_vector(apex, name="apex")
    candidate = _spatial_vector(point, name="point")
    coordinates = axis_coordinates_3d(candidate, apex_point, axis_direction)
    axial = coordinates.axial_coordinate
    tangent = math.tan(angle)
    with np.errstate(over="ignore", invalid="ignore"):
        expected = abs(axial) * tangent
        implicit = coordinates.radial_distance**2 - (axial * tangent) ** 2
    if not np.isfinite(expected) or not np.isfinite(implicit):
        raise OverflowError("Koni hesabı sayı aralığını aşıyor.")
    radial_residual = coordinates.radial_distance - expected
    distance_to_apex = _finite_norm(candidate - apex_point, context="Tepe uzaklığı")
    is_apex = distance_to_apex <= threshold
    if is_apex:
        side: ConeSide = "apex"
    elif axial > threshold:
        side = "positive"
    elif axial < -threshold:
        side = "negative"
    else:
        side = "equatorial"

    allowed = nappe == "double" or side == "apex" or side == nappe
    if not allowed:
        relation: ConeRelation = "wrong_nappe"
    elif radial_residual < -threshold:
        relation = "inside"
    elif radial_residual > threshold:
        relation = "outside"
    else:
        relation = "on_surface"
    return CircularConeDiagnostics(
        half_angle=angle,
        nappe=nappe,
        side=side,
        axial_coordinate=axial,
        radial_distance=coordinates.radial_distance,
        expected_radial_distance=float(expected),
        signed_radial_residual=float(radial_residual),
        implicit_residual=float(implicit),
        relation=relation,
        is_apex=is_apex,
        allowed_nappe=allowed,
        length_tolerance=threshold,
    )


def ruled_surface_points(
    directrix_points: ArrayLike,
    generator_direction: ArrayLike,
    ruling_parameters: ArrayLike,
    *,
    direction_zero_tolerance: float = 0.0,
) -> FloatArray:
    """Bir doğrultman eğrisini sabit yönde öteleyerek silindirik yüzey örnekler."""

    directrix = _point_cloud(directrix_points, name="directrix_points")
    direction = _spatial_vector(generator_direction, name="generator_direction")
    parameters = _one_dimensional(ruling_parameters, name="ruling_parameters")
    zero_tolerance = _nonnegative_finite(
        direction_zero_tolerance,
        name="direction_zero_tolerance",
    )
    if _finite_norm(direction, context="Üreteç yön normu") <= zero_tolerance:
        raise ValueError("generator_direction sıfır veya yön eşiğinin altında olamaz.")
    with np.errstate(over="ignore", invalid="ignore"):
        points = directrix[:, None, :] + parameters[None, :, None] * direction
    if not np.all(np.isfinite(points)):
        raise OverflowError("Silindirik yüzey örneklemesi sayı aralığını aşıyor.")
    return np.asarray(points, dtype=float)


def conical_surface_points(
    apex: ArrayLike,
    directrix_points: ArrayLike,
    scale_parameters: ArrayLike,
) -> FloatArray:
    """Tepe ile doğrultman noktalarını birleştiren üreteçler üzerinde örnekler."""

    apex_point = _spatial_vector(apex, name="apex")
    directrix = _point_cloud(directrix_points, name="directrix_points")
    scales = _one_dimensional(scale_parameters, name="scale_parameters")
    with np.errstate(over="ignore", invalid="ignore"):
        offsets = directrix - apex_point
        points = apex_point + scales[None, :, None] * offsets[:, None, :]
    if not np.all(np.isfinite(points)):
        raise OverflowError("Konik yüzey örneklemesi sayı aralığını aşıyor.")
    return np.asarray(points, dtype=float)


def circular_cylinder_points(
    axis_point: ArrayLike,
    axis_direction: ArrayLike,
    radius: float,
    axial_values: ArrayLike,
    angles: ArrayLike,
    *,
    radial_reference: ArrayLike | None = None,
) -> FloatArray:
    """Dairesel silindiri açık eksenel ve açısal diziler üzerinde örnekler."""

    radius_value = _nonnegative_finite(radius, name="radius")
    axial = _one_dimensional(axial_values, name="axial_values")
    theta = _one_dimensional(angles, name="angles")
    frame = axis_frame_3d(
        axis_point,
        axis_direction,
        radial_reference=radial_reference,
    )
    radial_directions = (
        np.cos(theta)[:, None] * frame.radial_u
        + np.sin(theta)[:, None] * frame.radial_v
    )
    with np.errstate(over="ignore", invalid="ignore"):
        points = (
            frame.axis_point[None, None, :]
            + axial[:, None, None] * frame.unit_axis
            + radius_value * radial_directions[None, :, :]
        )
    if not np.all(np.isfinite(points)):
        raise OverflowError("Silindir parametrelemesi sayı aralığını aşıyor.")
    return np.asarray(points, dtype=float)


def circular_cone_points(
    apex: ArrayLike,
    axis_direction: ArrayLike,
    half_angle: float,
    axial_values: ArrayLike,
    angles: ArrayLike,
    *,
    radial_reference: ArrayLike | None = None,
) -> FloatArray:
    """İşaretli eksenel değerlerle tek veya çift dairesel koniyi örnekler."""

    angle = _finite_scalar(half_angle, name="half_angle")
    if not 0.0 < angle < math.pi / 2.0:
        raise ValueError("half_angle, (0, pi/2) aralığında olmalıdır.")
    axial = _one_dimensional(axial_values, name="axial_values")
    theta = _one_dimensional(angles, name="angles")
    frame = axis_frame_3d(
        apex,
        axis_direction,
        radial_reference=radial_reference,
    )
    radial_directions = (
        np.cos(theta)[:, None] * frame.radial_u
        + np.sin(theta)[:, None] * frame.radial_v
    )
    with np.errstate(over="ignore", invalid="ignore"):
        radii = np.abs(axial) * math.tan(angle)
        points = (
            frame.axis_point[None, None, :]
            + axial[:, None, None] * frame.unit_axis
            + radii[:, None, None] * radial_directions[None, :, :]
        )
    if not np.all(np.isfinite(points)):
        raise OverflowError("Koni parametrelemesi sayı aralığını aşıyor.")
    return np.asarray(points, dtype=float)


def surface_of_revolution_points(
    axis_point: ArrayLike,
    axis_direction: ArrayLike,
    axial_values: ArrayLike,
    radial_values: ArrayLike,
    angles: ArrayLike,
    *,
    radial_reference: ArrayLike | None = None,
) -> FloatArray:
    """``(s, rho)`` profilini eksen çevresinde döndürerek yüzey ağı üretir."""

    axial = _one_dimensional(axial_values, name="axial_values")
    radial = _one_dimensional(radial_values, name="radial_values")
    theta = _one_dimensional(angles, name="angles")
    if axial.shape != radial.shape:
        raise ValueError("axial_values ile radial_values aynı biçimde olmalıdır.")
    if np.any(radial < 0.0):
        raise ValueError("radial_values negatif olamaz.")
    frame = axis_frame_3d(
        axis_point,
        axis_direction,
        radial_reference=radial_reference,
    )
    radial_directions = (
        np.cos(theta)[:, None] * frame.radial_u
        + np.sin(theta)[:, None] * frame.radial_v
    )
    with np.errstate(over="ignore", invalid="ignore"):
        points = (
            frame.axis_point[None, None, :]
            + axial[:, None, None] * frame.unit_axis
            + radial[:, None, None] * radial_directions[None, :, :]
        )
    if not np.all(np.isfinite(points)):
        raise OverflowError("Dönel yüzey örneklemesi sayı aralığını aşıyor.")
    return np.asarray(points, dtype=float)


@dataclass(frozen=True)
class RevolutionPointDiagnostics:
    """Dönel yüzeyin tek parametre noktasındaki diferansiyel tanısı."""

    point: FloatArray
    profile_tangent: FloatArray
    angular_tangent: FloatArray
    oriented_normal: FloatArray
    normal_norm: float
    unit_normal: FloatArray | None
    area_density: float
    regular: bool
    is_axis_point: bool
    normal_zero_tolerance: float


def revolution_surface_point_diagnostics(
    axis_point: ArrayLike,
    axis_direction: ArrayLike,
    axial_coordinate: float,
    radial_coordinate: float,
    axial_derivative: float,
    radial_derivative: float,
    angle: float,
    *,
    radial_reference: ArrayLike | None = None,
    normal_zero_tolerance: float = 0.0,
) -> RevolutionPointDiagnostics:
    """Dönel yüzey noktasını, iki teğetini ve düzenlilik kararını verir."""

    axial = _finite_scalar(axial_coordinate, name="axial_coordinate")
    radial = _nonnegative_finite(radial_coordinate, name="radial_coordinate")
    axial_prime = _finite_scalar(axial_derivative, name="axial_derivative")
    radial_prime = _finite_scalar(radial_derivative, name="radial_derivative")
    theta = _finite_scalar(angle, name="angle")
    zero_tolerance = _nonnegative_finite(
        normal_zero_tolerance,
        name="normal_zero_tolerance",
    )
    frame = axis_frame_3d(
        axis_point,
        axis_direction,
        radial_reference=radial_reference,
    )
    radial_direction = math.cos(theta) * frame.radial_u + math.sin(theta) * frame.radial_v
    angular_direction = -math.sin(theta) * frame.radial_u + math.cos(theta) * frame.radial_v
    point = frame.axis_point + axial * frame.unit_axis + radial * radial_direction
    profile_tangent = axial_prime * frame.unit_axis + radial_prime * radial_direction
    angular_tangent = radial * angular_direction
    normal = cross_product_3d(profile_tangent, angular_tangent)
    normal_norm = _finite_norm(normal, context="Dönel yüzey normal normu")
    regular = normal_norm > zero_tolerance
    unit_normal = normal / normal_norm if regular else None
    return RevolutionPointDiagnostics(
        point=point,
        profile_tangent=profile_tangent,
        angular_tangent=angular_tangent,
        oriented_normal=normal,
        normal_norm=normal_norm,
        unit_normal=unit_normal,
        area_density=normal_norm,
        regular=regular,
        is_axis_point=radial == 0.0,
        normal_zero_tolerance=zero_tolerance,
    )


@dataclass(frozen=True)
class PiecewiseRevolutionDiagnostics:
    """Parçalı doğrusal profilin segment ve dönel alan özeti."""

    axial_values: FloatArray
    radial_values: FloatArray
    axial_differences: FloatArray
    radial_differences: FloatArray
    slant_lengths: FloatArray
    segment_types: tuple[str, ...]
    segment_lateral_areas: FloatArray
    total_lateral_area: float
    smooth_interior_joins: tuple[bool, ...]
    length_tolerance: float
    angular_tolerance: float


def piecewise_linear_revolution_diagnostics(
    axial_values: ArrayLike,
    radial_values: ArrayLike,
    *,
    length_tolerance: float = 0.0,
    angular_tolerance: float = 0.0,
) -> PiecewiseRevolutionDiagnostics:
    """Parçalı doğrusal profilin tam dönel segment alanlarını hesaplar.

    Ardışık profil noktalarının döndürülmesi sırasıyla silindir, konik kesik,
    koni, düzlemsel halka veya eksen üzerinde dejenere parça üretebilir.
    Alanlar kapak eklemez; yalnız verilen profil parçalarını döndürür.
    """

    axial = _one_dimensional(axial_values, name="axial_values")
    radial = _one_dimensional(radial_values, name="radial_values")
    if axial.shape != radial.shape:
        raise ValueError("axial_values ile radial_values aynı biçimde olmalıdır.")
    if axial.size < 2:
        raise ValueError("Parçalı profil en az iki nokta içermelidir.")
    if np.any(radial < 0.0):
        raise ValueError("radial_values negatif olamaz.")
    length_tol = _nonnegative_finite(length_tolerance, name="length_tolerance")
    angle_tol = _angular_tolerance(angular_tolerance)
    ds = np.diff(axial)
    dr = np.diff(radial)
    with np.errstate(over="ignore", invalid="ignore"):
        slant = np.hypot(ds, dr)
    if not np.all(np.isfinite(slant)):
        raise OverflowError("Profil parça uzunlukları sayı aralığını aşıyor.")
    if np.any(slant <= length_tol):
        raise ValueError("Profilde sıfır veya uzunluk eşiğinin altında parça var.")

    types: list[str] = []
    areas: list[float] = []
    for index, (delta_s, delta_r, segment_length) in enumerate(
        zip(ds, dr, slant, strict=True)
    ):
        first_radius = float(radial[index])
        second_radius = float(radial[index + 1])
        if first_radius <= length_tol and second_radius <= length_tol:
            segment_type = "axis"
        elif abs(float(delta_s)) <= length_tol:
            segment_type = "annulus"
        elif abs(float(delta_r)) <= length_tol:
            segment_type = "cylinder"
        elif min(first_radius, second_radius) <= length_tol:
            segment_type = "cone"
        else:
            segment_type = "frustum"
        with np.errstate(over="ignore", invalid="ignore"):
            area = math.pi * (first_radius + second_radius) * float(segment_length)
        if not np.isfinite(area):
            raise OverflowError("Dönel profil alanı sayı aralığını aşıyor.")
        types.append(segment_type)
        areas.append(float(area))

    smooth_joins: list[bool] = []
    directions = np.column_stack((ds, dr)) / slant[:, None]
    for left, right in zip(directions[:-1], directions[1:], strict=True):
        # Birim yönler arasındaki kiriş uzunluğu, sıfır açı yakınında
        # ``acos(dot)`` hesabından daha kararlıdır: ||u-v|| = 2 sin(theta/2).
        chord = _finite_norm(left - right, context="Profil birleşim yön farkı")
        angular_chord_threshold = 2.0 * math.sin(0.5 * angle_tol)
        smooth_joins.append(chord <= angular_chord_threshold)

    return PiecewiseRevolutionDiagnostics(
        axial_values=axial,
        radial_values=radial,
        axial_differences=np.asarray(ds, dtype=float),
        radial_differences=np.asarray(dr, dtype=float),
        slant_lengths=np.asarray(slant, dtype=float),
        segment_types=tuple(types),
        segment_lateral_areas=np.asarray(areas, dtype=float),
        total_lateral_area=math.fsum(areas),
        smooth_interior_joins=tuple(smooth_joins),
        length_tolerance=length_tol,
        angular_tolerance=angle_tol,
    )
