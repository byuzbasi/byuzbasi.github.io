"""Uzaydaki genel ikinci derece yüzeyler için hesap araçları.

Bir kuadrik

``A*x**2 + B*x*y + C*x*z + D*y**2 + E*y*z + F*z**2``
``+ G*x + H*y + I*z + J = 0``

biçiminde ve katsayı sırası ``(A, B, C, D, E, F, G, H, I, J)``
olarak tutulur. Kayan noktalı rank kararları yalnız kullanıcının verdiği
``relative_tolerance`` ile yapılır; varsayılan sıfırdır.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array


_LOCUS_TYPES = {
    "ellipsoid",
    "hyperboloid_one_sheet",
    "hyperboloid_two_sheets",
    "elliptic_cone",
    "elliptic_paraboloid",
    "hyperbolic_paraboloid",
    "elliptic_cylinder",
    "hyperbolic_cylinder",
    "parabolic_cylinder",
    "intersecting_planes",
    "parallel_planes",
    "double_plane",
    "line",
    "point",
    "plane",
    "all_space",
    "empty",
}


def _positive_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} sonlu ve pozitif bir sayı olmalıdır.")
    return number


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0 or number >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return number


def _coefficients(value: ArrayLike) -> FloatArray:
    coefficients = _finite_array(value, name="coefficients")
    if coefficients.shape != (10,):
        raise ValueError(
            "coefficients, (A, B, C, D, E, F, G, H, I, J) "
            "sıralı (10,) biçiminde olmalıdır."
        )
    return coefficients.copy()


def _point_rows(value: ArrayLike, *, name: str) -> tuple[FloatArray, bool]:
    points = _finite_array(value, name=name)
    if points.shape == (3,):
        return points.reshape(1, 3), True
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError(f"{name}, (3,) veya (n, 3) biçiminde olmalıdır.")
    return points, False


def quadric_matrices(
    coefficients: ArrayLike,
) -> tuple[FloatArray, FloatArray, FloatArray]:
    """Katsayılardan ``Q``, ``g`` ve homojen ``H`` matrislerini kurar.

    Dönen matrisler ``q(X)=X.T@Q@X+2*g.T@X+J`` ve
    ``q(X)=Xh.T@H@Xh`` özdeşliklerini sağlar; ``Xh=(x,y,z,1)`` olur.
    """

    a, b, c, d, e, f, g0, h0, i0, constant = _coefficients(coefficients)
    quadratic = np.array(
        [
            [a, 0.5 * b, 0.5 * c],
            [0.5 * b, d, 0.5 * e],
            [0.5 * c, 0.5 * e, f],
        ],
        dtype=float,
    )
    linear = np.array([0.5 * g0, 0.5 * h0, 0.5 * i0], dtype=float)
    homogeneous = np.block(
        [
            [quadratic, linear[:, None]],
            [linear[None, :], np.array([[constant]])],
        ]
    )
    return quadratic, linear, homogeneous


def _scaled_normalized_coefficients(
    coefficients: FloatArray,
    coordinate_scale: float,
) -> tuple[FloatArray, float]:
    with np.errstate(over="ignore", invalid="ignore"):
        scale_squared = coordinate_scale * coordinate_scale
        scaled = coefficients * np.array(
            [
                scale_squared,
                scale_squared,
                scale_squared,
                scale_squared,
                scale_squared,
                scale_squared,
                coordinate_scale,
                coordinate_scale,
                coordinate_scale,
                1.0,
            ]
        )
    if not np.all(np.isfinite(scaled)):
        raise OverflowError("Koordinat ölçekleme işlemi sayı aralığını aşıyor.")
    normalization = float(np.max(np.abs(scaled)))
    if normalization == 0.0:
        return np.zeros(10, dtype=float), 0.0
    normalized = scaled / normalization
    if not np.all(np.isfinite(normalized)):
        raise OverflowError("Katsayı normalizasyonu sayı aralığını aşıyor.")
    return normalized, normalization


def quadric_residuals(
    coefficients: ArrayLike,
    points: ArrayLike,
    *,
    coordinate_scale: float = 1.0,
) -> float | FloatArray:
    """Noktaların boyutsuz ve normalize edilmiş cebirsel artıklarını verir.

    ``coordinate_scale`` koordinatlarla aynı uzunluk birimindedir. Sonuç bir
    geometrik uzaklık değildir. Katsayıları ortak pozitif bir sayıyla çarpmak
    sonucu değiştirmez; ortak negatif çarpan yalnız artığın işaretini çevirir.
    """

    coefficient_array = _coefficients(coefficients)
    scale = _positive_finite(coordinate_scale, name="coordinate_scale")
    rows, single = _point_rows(points, name="points")
    normalized, normalization = _scaled_normalized_coefficients(coefficient_array, scale)
    if normalization == 0.0:
        residuals = np.zeros(rows.shape[0], dtype=float)
    else:
        z = rows / scale
        quadratic, linear, homogeneous = quadric_matrices(normalized)
        del homogeneous
        with np.errstate(over="ignore", invalid="ignore"):
            residuals = np.einsum("ni,ij,nj->n", z, quadratic, z)
            residuals += 2.0 * (z @ linear) + normalized[-1]
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Kuadrik artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


def transform_quadric(
    coefficients: ArrayLike,
    rotation: ArrayLike,
    translation: ArrayLike,
    *,
    orthogonality_tolerance: float = 1e-12,
) -> FloatArray:
    """``X = R@Y + t`` koordinat değişiminden sonraki katsayıları döndürür.

    ``rotation`` üç boyutlu ortogonal bir matristir; yansımalara da izin
    verilir. Dönen katsayılar ``Y`` değişkenine göre ``q(R@Y+t)=0``
    denklemini temsil eder.
    """

    coefficient_array = _coefficients(coefficients)
    rotation_array = _finite_array(rotation, name="rotation")
    translation_array = _finite_array(translation, name="translation")
    if rotation_array.shape != (3, 3):
        raise ValueError("rotation, (3, 3) biçiminde olmalıdır.")
    if translation_array.shape != (3,):
        raise ValueError("translation, (3,) biçiminde olmalıdır.")
    tolerance = _nonnegative_finite(
        orthogonality_tolerance,
        name="orthogonality_tolerance",
    )
    if tolerance >= 1.0:
        raise ValueError("orthogonality_tolerance [0, 1) aralığında olmalıdır.")
    gram_error = float(np.max(np.abs(rotation_array.T @ rotation_array - np.eye(3))))
    determinant = float(np.linalg.det(rotation_array))
    if gram_error > tolerance or abs(abs(determinant) - 1.0) > tolerance:
        raise ValueError("rotation verilen eşik içinde ortogonal olmalıdır.")

    _, _, homogeneous = quadric_matrices(coefficient_array)
    affine = np.eye(4)
    affine[:3, :3] = rotation_array
    affine[:3, 3] = translation_array
    with np.errstate(over="ignore", invalid="ignore"):
        transformed = affine.T @ homogeneous @ affine
    if not np.all(np.isfinite(transformed)):
        raise OverflowError("Kuadrik dönüşümü sayı aralığını aşıyor.")
    transformed = 0.5 * (transformed + transformed.T)
    return np.array(
        [
            transformed[0, 0],
            2.0 * transformed[0, 1],
            2.0 * transformed[0, 2],
            transformed[1, 1],
            2.0 * transformed[1, 2],
            transformed[2, 2],
            2.0 * transformed[0, 3],
            2.0 * transformed[1, 3],
            2.0 * transformed[2, 3],
            transformed[3, 3],
        ],
        dtype=float,
    )


def _canonical_vector_sign(vector: FloatArray) -> FloatArray:
    result = np.asarray(vector, dtype=float).copy()
    pivot = int(np.argmax(np.abs(result)))
    if result[pivot] < 0.0:
        result *= -1.0
    return result


def _canonical_eigenvectors(vectors: FloatArray) -> FloatArray:
    result = np.asarray(vectors, dtype=float).copy()
    for column in range(result.shape[1]):
        result[:, column] = _canonical_vector_sign(result[:, column])
    if np.linalg.det(result) < 0.0:
        result[:, -1] *= -1.0
    return result


def _canonical_plane(normal: FloatArray, constant: float) -> FloatArray:
    norm = float(np.linalg.norm(normal))
    if norm == 0.0 or not np.isfinite(norm):
        raise RuntimeError("Sıfır normal vektörlü düzlem üretilemez.")
    plane = np.r_[normal / norm, constant / norm]
    pivot = int(np.argmax(np.abs(plane[:3])))
    if plane[pivot] < 0.0:
        plane *= -1.0
    return plane


def _sorted_planes(planes: list[FloatArray]) -> FloatArray:
    if not planes:
        return np.empty((0, 4), dtype=float)
    return np.asarray(
        sorted(planes, key=lambda row: tuple(np.round(row, 15))),
        dtype=float,
    )


@dataclass(frozen=True)
class QuadricDiagnostics:
    """Genel kuadriğin geometrik ve sayısal tanısı."""

    coefficients: FloatArray
    normalized_coefficients: FloatArray
    coordinate_scale: float
    normalization_factor: float
    relative_tolerance: float
    decision_threshold: float
    quadratic_matrix: FloatArray
    linear_vector: FloatArray
    homogeneous_matrix: FloatArray
    eigenvalues: FloatArray
    eigenvectors: FloatArray
    quadratic_rank: int
    homogeneous_rank: int
    inertia: tuple[int, int, int]
    homogeneous_inertia: tuple[int, int, int]
    quadratic_determinant: float
    homogeneous_determinant: float
    locus_type: str
    degenerate: bool
    numerically_ambiguous: bool
    repeated_eigenvalues: bool
    center: FloatArray | None
    reference_point: FloatArray | None
    vertex: FloatArray | None
    semi_axes: FloatArray | None
    principal_directions: FloatArray | None
    free_directions: FloatArray
    axis_direction: FloatArray | None
    opening_direction: FloatArray | None
    canonical_linear: FloatArray
    canonical_constant: float
    component_planes: FloatArray


def quadric_diagnostics(
    coefficients: ArrayLike,
    *,
    coordinate_scale: float = 1.0,
    relative_tolerance: float = 0.0,
) -> QuadricDiagnostics:
    """Kuadriği ortogonal özayrışım, rank ve ataletle sınıflandırır.

    Koordinatlar önce ``coordinate_scale`` ile boyutsuzlaştırılır. On katsayı
    daha sonra ortak bir pozitif büyüklüğe bölünür. ``relative_tolerance`` bu
    normalize uzayda sıfır ve rank kararlarının açık eşiğidir. Pozitif eşik
    nedeniyle sıfır sayılan ama kayan noktada tam sıfır olmayan bir nicelik
    varsa ``numerically_ambiguous`` alanı ``True`` olur.

    ``degenerate`` homojen 4x4 matrisin rankının dörtten küçük olduğunu ifade
    eder. Bu nedenle düzgün bir silindir de projektif-cebirsel anlamda
    dejenere olabilir; alan yerel düzgünlük iddiası taşımaz.
    """

    coefficient_array = _coefficients(coefficients)
    scale = _positive_finite(coordinate_scale, name="coordinate_scale")
    tolerance = _relative_tolerance(relative_tolerance)
    normalized, normalization = _scaled_normalized_coefficients(coefficient_array, scale)

    if normalization == 0.0:
        return QuadricDiagnostics(
            coefficients=coefficient_array,
            normalized_coefficients=normalized,
            coordinate_scale=scale,
            normalization_factor=0.0,
            relative_tolerance=tolerance,
            decision_threshold=tolerance,
            quadratic_matrix=np.zeros((3, 3), dtype=float),
            linear_vector=np.zeros(3, dtype=float),
            homogeneous_matrix=np.zeros((4, 4), dtype=float),
            eigenvalues=np.zeros(3, dtype=float),
            eigenvectors=np.eye(3),
            quadratic_rank=0,
            homogeneous_rank=0,
            inertia=(0, 0, 3),
            homogeneous_inertia=(0, 0, 4),
            quadratic_determinant=0.0,
            homogeneous_determinant=0.0,
            locus_type="all_space",
            degenerate=True,
            numerically_ambiguous=False,
            repeated_eigenvalues=True,
            center=None,
            reference_point=None,
            vertex=None,
            semi_axes=None,
            principal_directions=None,
            free_directions=np.eye(3),
            axis_direction=None,
            opening_direction=None,
            canonical_linear=np.zeros(3, dtype=float),
            canonical_constant=0.0,
            component_planes=np.empty((0, 4), dtype=float),
        )

    quadratic, linear, homogeneous = quadric_matrices(normalized)
    eigenvalues, raw_eigenvectors = np.linalg.eigh(quadratic)
    eigenvectors = _canonical_eigenvectors(raw_eigenvectors)
    canonical_linear = eigenvectors.T @ linear
    homogeneous_eigenvalues = np.linalg.eigvalsh(homogeneous)

    positive = int(np.count_nonzero(eigenvalues > tolerance))
    negative = int(np.count_nonzero(eigenvalues < -tolerance))
    zero = 3 - positive - negative
    quadratic_rank = positive + negative
    h_positive = int(np.count_nonzero(homogeneous_eigenvalues > tolerance))
    h_negative = int(np.count_nonzero(homogeneous_eigenvalues < -tolerance))
    h_zero = 4 - h_positive - h_negative
    homogeneous_rank = h_positive + h_negative
    ambiguous_values: list[float] = []

    def is_zero(value: float) -> bool:
        magnitude = abs(float(value))
        if tolerance > 0.0 and 0.0 < magnitude <= tolerance:
            ambiguous_values.append(magnitude)
        return magnitude <= tolerance

    if tolerance > 0.0:
        for value in np.r_[eigenvalues, homogeneous_eigenvalues]:
            is_zero(float(value))

    repeated_eigenvalues = any(
        abs(float(eigenvalues[i] - eigenvalues[j])) <= tolerance
        for i in range(3)
        for j in range(i + 1, 3)
    )
    quadratic_determinant = float(np.linalg.det(quadratic))
    homogeneous_determinant = float(np.linalg.det(homogeneous))

    active = np.flatnonzero(np.abs(eigenvalues) > tolerance)
    null = np.flatnonzero(np.abs(eigenvalues) <= tolerance)
    shifted = np.zeros(3, dtype=float)
    if active.size:
        shifted[active] = -canonical_linear[active] / eigenvalues[active]
    reduced_constant = float(
        normalized[-1]
        - np.sum(canonical_linear[active] ** 2 / eigenvalues[active])
    )
    reference_z = eigenvectors @ shifted

    locus_type: str
    center: FloatArray | None = None
    reference_point: FloatArray | None = scale * reference_z
    vertex: FloatArray | None = None
    semi_axes: FloatArray | None = None
    principal_directions: FloatArray | None = None
    free_directions = eigenvectors[:, null].copy()
    axis_direction: FloatArray | None = None
    opening_direction: FloatArray | None = None
    component_planes: list[FloatArray] = []

    null_linear = canonical_linear[null]
    null_linear_norm = float(np.linalg.norm(null_linear))
    has_null_linear = null.size > 0 and not is_zero(null_linear_norm)

    if has_null_linear:
        unit_null_coordinates = null_linear / null_linear_norm
        linear_direction = eigenvectors[:, null] @ unit_null_coordinates
        null_shift = -reduced_constant / (2.0 * null_linear_norm)
        reference_z = reference_z + null_shift * linear_direction
        reference_point = scale * reference_z
        vertex = reference_point.copy()
        reduced_constant = 0.0

        if quadratic_rank == 2:
            active_values = eigenvalues[active]
            active_directions = eigenvectors[:, active]
            principal_directions = np.column_stack(
                [active_directions, linear_direction]
            )
            free_directions = np.empty((3, 0), dtype=float)
            if np.all(active_values > tolerance) or np.all(active_values < -tolerance):
                locus_type = "elliptic_paraboloid"
                opening_direction = -np.sign(active_values[0]) * linear_direction
            else:
                locus_type = "hyperbolic_paraboloid"
                opening_direction = _canonical_vector_sign(linear_direction)
            axis_direction = opening_direction.copy()
        elif quadratic_rank == 1:
            active_index = int(active[0])
            active_direction = eigenvectors[:, active_index]
            if null.size != 2:
                raise RuntimeError("Parabolik silindir için iki boyutlu çekirdek bekleniyordu.")
            perpendicular_null_coordinates = np.array(
                [-unit_null_coordinates[1], unit_null_coordinates[0]],
                dtype=float,
            )
            free_direction = _canonical_vector_sign(
                eigenvectors[:, null] @ perpendicular_null_coordinates
            )
            opening_direction = -np.sign(eigenvalues[active_index]) * linear_direction
            axis_direction = free_direction.copy()
            free_directions = free_direction[:, None]
            principal_directions = np.column_stack(
                [active_direction, opening_direction, free_direction]
            )
            locus_type = "parabolic_cylinder"
        else:
            normal = 2.0 * linear
            component_planes.append(
                _canonical_plane(normal, normalized[-1] * scale)
            )
            reference_point = -(normalized[-1] * scale) * normal / float(np.dot(normal, normal))
            vertex = None
            principal_directions = None
            free_directions = np.empty((3, 0), dtype=float)
            locus_type = "plane"

    elif quadratic_rank == 3:
        center = scale * reference_z
        reference_point = center.copy()
        free_directions = np.empty((3, 0), dtype=float)
        if positive in {0, 3}:
            if is_zero(reduced_constant):
                locus_type = "point"
                principal_directions = eigenvectors.copy()
            else:
                ratios = -reduced_constant / eigenvalues
                if np.all(ratios > tolerance):
                    locus_type = "ellipsoid"
                    order = np.argsort(np.sqrt(ratios))[::-1]
                    semi_axes = scale * np.sqrt(ratios[order])
                    principal_directions = eigenvectors[:, order]
                else:
                    if tolerance > 0.0:
                        for ratio in ratios:
                            is_zero(float(ratio))
                    locus_type = "empty"
        else:
            if is_zero(reduced_constant):
                locus_type = "elliptic_cone"
                principal_directions = eigenvectors.copy()
                if positive == 1:
                    axis_direction = eigenvectors[:, int(np.flatnonzero(eigenvalues > tolerance)[0])]
                else:
                    axis_direction = eigenvectors[:, int(np.flatnonzero(eigenvalues < -tolerance)[0])]
                axis_direction = _canonical_vector_sign(axis_direction)
            else:
                ratios = -reduced_constant / eigenvalues
                positive_ratios = np.flatnonzero(ratios > tolerance)
                negative_ratios = np.flatnonzero(ratios < -tolerance)
                if positive_ratios.size == 2:
                    locus_type = "hyperboloid_one_sheet"
                    axis_index = int(negative_ratios[0])
                elif positive_ratios.size == 1:
                    locus_type = "hyperboloid_two_sheets"
                    axis_index = int(positive_ratios[0])
                else:
                    raise RuntimeError("Beklenmeyen hiperboloit işaret örüntüsü.")
                order = np.r_[positive_ratios, negative_ratios]
                semi_axes = scale * np.sqrt(np.abs(ratios[order]))
                principal_directions = eigenvectors[:, order]
                axis_direction = _canonical_vector_sign(eigenvectors[:, axis_index])

    elif quadratic_rank == 2:
        active_values = eigenvalues[active]
        active_directions = eigenvectors[:, active]
        null_direction = _canonical_vector_sign(eigenvectors[:, int(null[0])])
        free_directions = null_direction[:, None]
        axis_direction = null_direction.copy()
        if np.all(active_values > tolerance) or np.all(active_values < -tolerance):
            if is_zero(reduced_constant):
                locus_type = "line"
                principal_directions = np.column_stack(
                    [active_directions, null_direction]
                )
            else:
                ratios = -reduced_constant / active_values
                if np.all(ratios > tolerance):
                    locus_type = "elliptic_cylinder"
                    active_order = np.argsort(np.sqrt(ratios))[::-1]
                    semi_axes = scale * np.sqrt(ratios[active_order])
                    principal_directions = np.column_stack(
                        [active_directions[:, active_order], null_direction]
                    )
                else:
                    if tolerance > 0.0:
                        for ratio in ratios:
                            is_zero(float(ratio))
                    locus_type = "empty"
        else:
            if is_zero(reduced_constant):
                locus_type = "intersecting_planes"
                positive_index = int(active[np.argmax(eigenvalues[active])])
                negative_index = int(active[np.argmin(eigenvalues[active])])
                positive_normal = (
                    np.sqrt(eigenvalues[positive_index])
                    * eigenvectors[:, positive_index]
                )
                negative_normal = (
                    np.sqrt(-eigenvalues[negative_index])
                    * eigenvectors[:, negative_index]
                )
                for normal in (
                    positive_normal + negative_normal,
                    positive_normal - negative_normal,
                ):
                    component_planes.append(
                        _canonical_plane(normal, -float(np.dot(normal, scale * reference_z)))
                    )
                principal_directions = np.column_stack(
                    [active_directions, null_direction]
                )
            else:
                locus_type = "hyperbolic_cylinder"
                ratios = -reduced_constant / active_values
                positive_index_local = int(np.flatnonzero(ratios > tolerance)[0])
                negative_index_local = int(np.flatnonzero(ratios < -tolerance)[0])
                order = np.array([positive_index_local, negative_index_local])
                semi_axes = scale * np.sqrt(np.abs(ratios[order]))
                principal_directions = np.column_stack(
                    [active_directions[:, order], null_direction]
                )

    elif quadratic_rank == 1:
        active_index = int(active[0])
        eigenvalue = float(eigenvalues[active_index])
        active_direction = eigenvectors[:, active_index]
        free_directions = eigenvectors[:, null].copy()
        ratio = float(-reduced_constant / eigenvalue)
        principal_directions = np.column_stack(
            [active_direction, free_directions]
        )
        if ratio > tolerance:
            locus_type = "parallel_planes"
            distance = float(np.sqrt(ratio))
            for coordinate in (
                shifted[active_index] - distance,
                shifted[active_index] + distance,
            ):
                component_planes.append(
                    _canonical_plane(active_direction, -scale * coordinate)
                )
        elif ratio < -tolerance:
            locus_type = "empty"
        else:
            is_zero(ratio)
            locus_type = "double_plane"
            component_planes.append(
                _canonical_plane(
                    active_direction,
                    -scale * shifted[active_index],
                )
            )

    else:
        if is_zero(normalized[-1]):
            locus_type = "all_space"
        else:
            locus_type = "empty"
        reference_point = None
        principal_directions = None
        free_directions = np.eye(3)

    if locus_type not in _LOCUS_TYPES:
        raise RuntimeError(f"Bilinmeyen kuadrik sınıfı üretildi: {locus_type}")
    planes = _sorted_planes(component_planes)
    return QuadricDiagnostics(
        coefficients=coefficient_array,
        normalized_coefficients=normalized,
        coordinate_scale=scale,
        normalization_factor=normalization,
        relative_tolerance=tolerance,
        decision_threshold=tolerance,
        quadratic_matrix=quadratic,
        linear_vector=linear,
        homogeneous_matrix=homogeneous,
        eigenvalues=eigenvalues,
        eigenvectors=eigenvectors,
        quadratic_rank=quadratic_rank,
        homogeneous_rank=homogeneous_rank,
        inertia=(positive, negative, zero),
        homogeneous_inertia=(h_positive, h_negative, h_zero),
        quadratic_determinant=quadratic_determinant,
        homogeneous_determinant=homogeneous_determinant,
        locus_type=locus_type,
        degenerate=homogeneous_rank < 4,
        numerically_ambiguous=bool(ambiguous_values),
        repeated_eigenvalues=repeated_eigenvalues,
        center=center,
        reference_point=reference_point,
        vertex=vertex,
        semi_axes=semi_axes,
        principal_directions=principal_directions,
        free_directions=free_directions,
        axis_direction=axis_direction,
        opening_direction=opening_direction,
        canonical_linear=canonical_linear,
        canonical_constant=reduced_constant,
        component_planes=planes,
    )


@dataclass(frozen=True)
class QuadricPlaneTrace:
    """``X=p+B(u,v)`` düzlemindeki iki boyutlu kuadrik iz."""

    plane_point: FloatArray
    plane_basis: FloatArray
    conic_coefficients: FloatArray
    basis_gram: FloatArray
    orthonormal: bool


def quadric_plane_trace(
    coefficients: ArrayLike,
    plane_point: ArrayLike,
    plane_basis: ArrayLike,
    *,
    basis_tolerance: float = 0.0,
    orthonormal_tolerance: float = 1e-12,
) -> QuadricPlaneTrace:
    """Bir düzlem üzerindeki izi 2B genel konik katsayılarına indirger.

    ``plane_basis`` sütunları düzlemdeki iki bağımsız yönü içerir. Sütunlar
    ortonormalse ``(u,v)`` fiziksel uzunluk koordinatlarıdır; değilse cebirsel
    iz yine doğrudur fakat metrik yarı eksen yorumları doğrudan yapılamaz.
    """

    coefficient_array = _coefficients(coefficients)
    point = _finite_array(plane_point, name="plane_point")
    basis = _finite_array(plane_basis, name="plane_basis")
    if point.shape != (3,):
        raise ValueError("plane_point, (3,) biçiminde olmalıdır.")
    if basis.shape != (3, 2):
        raise ValueError("plane_basis, (3, 2) biçiminde olmalıdır.")
    rank_tolerance = _nonnegative_finite(basis_tolerance, name="basis_tolerance")
    ortho_tolerance = _nonnegative_finite(
        orthonormal_tolerance,
        name="orthonormal_tolerance",
    )
    cross_norm = float(np.linalg.norm(np.cross(basis[:, 0], basis[:, 1])))
    if cross_norm <= rank_tolerance:
        raise ValueError("plane_basis sütunları verilen eşikte bağımsız olmalıdır.")

    quadratic, linear, _ = quadric_matrices(coefficient_array)
    trace_quadratic = basis.T @ quadratic @ basis
    trace_linear = basis.T @ (quadratic @ point + linear)
    trace_constant = float(
        point @ quadratic @ point + 2.0 * np.dot(linear, point) + coefficient_array[-1]
    )
    conic_coefficients = np.array(
        [
            trace_quadratic[0, 0],
            2.0 * trace_quadratic[0, 1],
            trace_quadratic[1, 1],
            2.0 * trace_linear[0],
            2.0 * trace_linear[1],
            trace_constant,
        ],
        dtype=float,
    )
    gram = basis.T @ basis
    orthonormal = bool(
        np.allclose(gram, np.eye(2), atol=ortho_tolerance, rtol=0.0)
    )
    return QuadricPlaneTrace(
        plane_point=point.copy(),
        plane_basis=basis.copy(),
        conic_coefficients=conic_coefficients,
        basis_gram=gram,
        orthonormal=orthonormal,
    )


@dataclass(frozen=True)
class QuadricTangentPlaneDiagnostics:
    """Bir kuadrik noktasındaki düzenlilik ve teğet düzlem tanısı."""

    point: FloatArray
    raw_value: float
    normalized_residual: float
    gradient: FloatArray
    normalized_gradient: FloatArray
    gradient_norm: float
    regular: bool
    plane_coefficients: FloatArray | None
    point_on_surface: bool


def quadric_tangent_plane_diagnostics(
    coefficients: ArrayLike,
    point: ArrayLike,
    *,
    coordinate_scale: float = 1.0,
    gradient_tolerance: float = 0.0,
    residual_tolerance: float = 0.0,
) -> QuadricTangentPlaneDiagnostics:
    """Bir noktada gradyanı ve varsa teğet düzlemi hesaplar.

    Düzenlilik kararı, normalize edilmiş boyutsuz polinomun ``Z=X/s``
    değişkenine göre gradyan normuna dayanır. ``gradient_tolerance`` ve
    ``residual_tolerance`` bu normalize uzayda açık mutlak eşiklerdir.
    Nokta yüzeyde değilse gradyan düzenli olsa bile ``plane_coefficients``
    döndürülmez; böylece doğrusal yaklaşım teğet düzlem diye sunulmaz.
    """

    coefficient_array = _coefficients(coefficients)
    point_array = _finite_array(point, name="point")
    if point_array.shape != (3,):
        raise ValueError("point, (3,) biçiminde olmalıdır.")
    scale = _positive_finite(coordinate_scale, name="coordinate_scale")
    grad_tolerance = _nonnegative_finite(
        gradient_tolerance,
        name="gradient_tolerance",
    )
    res_tolerance = _nonnegative_finite(
        residual_tolerance,
        name="residual_tolerance",
    )

    quadratic_raw, linear_raw, _ = quadric_matrices(coefficient_array)
    with np.errstate(over="ignore", invalid="ignore"):
        raw_value = float(
            point_array @ quadratic_raw @ point_array
            + 2.0 * np.dot(linear_raw, point_array)
            + coefficient_array[-1]
        )
        gradient = 2.0 * (quadratic_raw @ point_array + linear_raw)
    normalized, normalization = _scaled_normalized_coefficients(
        coefficient_array,
        scale,
    )
    if normalization == 0.0:
        normalized_residual = 0.0
        normalized_gradient = np.zeros(3, dtype=float)
    else:
        quadratic, linear, _ = quadric_matrices(normalized)
        z = point_array / scale
        normalized_residual = float(
            z @ quadratic @ z + 2.0 * np.dot(linear, z) + normalized[-1]
        )
        normalized_gradient = 2.0 * (quadratic @ z + linear)
    if (
        not np.isfinite(raw_value)
        or not np.all(np.isfinite(gradient))
        or not np.isfinite(normalized_residual)
        or not np.all(np.isfinite(normalized_gradient))
    ):
        raise OverflowError("Teğet düzlem tanısı sayı aralığını aşıyor.")

    gradient_norm = float(np.linalg.norm(normalized_gradient))
    regular = gradient_norm > grad_tolerance
    point_on_surface = abs(normalized_residual) <= res_tolerance
    plane_coefficients: FloatArray | None = None
    if regular and point_on_surface:
        plane_coefficients = _canonical_plane(
            gradient,
            -float(np.dot(gradient, point_array)),
        )
    return QuadricTangentPlaneDiagnostics(
        point=point_array.copy(),
        raw_value=raw_value,
        normalized_residual=normalized_residual,
        gradient=gradient,
        normalized_gradient=normalized_gradient,
        gradient_norm=gradient_norm,
        regular=regular,
        plane_coefficients=plane_coefficients,
        point_on_surface=point_on_surface,
    )
