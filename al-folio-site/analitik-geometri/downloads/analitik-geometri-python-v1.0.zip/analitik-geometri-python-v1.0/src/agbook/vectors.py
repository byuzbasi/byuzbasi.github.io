"""Bölüm 2 için iç çarpım, açı ve ortogonal izdüşüm hesapları.

İşlevler yalnız boş olmayan, tek boyutlu ve sonlu reel dizileri kabul eder.
Sıfır veya uygulamanın belirlediği eşiğin altındaki doğrultular için açı ve
izdüşüm tanımsız olduğundan açık ``ValueError`` yükseltilir.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _point, _same_dimension


def _validated_tolerance(value: float) -> float:
    tolerance = float(value)
    if tolerance < 0.0 or not np.isfinite(tolerance):
        raise ValueError("zero_tolerance sonlu ve negatif olmayan bir sayı olmalıdır.")
    return tolerance


def inner_product(u: ArrayLike, v: ArrayLike) -> float:
    """Aynı boyuttaki iki reel vektörün Öklid iç çarpımını döndürür."""

    vector_u, vector_v = _same_dimension(u, v)
    return float(np.dot(vector_u, vector_v))


def vector_norm(v: ArrayLike) -> float:
    """Bir reel vektörün ölçeklenmiş Öklid normunu hesaplar.

    Önce en büyük mutlak bileşene bölmek, ara karelerin gereksiz taşmasını
    veya alt-taşmasını azaltır. Sonuç, gerçek norm kayan nokta aralığının
    dışındaysa yine sonsuz olabilir.
    """

    vector = _point(v, name="v")
    scale = float(np.max(np.abs(vector)))
    if scale == 0.0:
        return 0.0
    return float(scale * np.sqrt(np.dot(vector / scale, vector / scale)))


def unit_vector(v: ArrayLike, *, zero_tolerance: float = 0.0) -> FloatArray:
    """``v`` doğrultusundaki birim vektörü döndürür.

    ``zero_tolerance`` normla aynı birimdedir. Norm bu eşikten büyük değilse
    doğrultu güvenilir biçimde tanımlı kabul edilmez.
    """

    tolerance = _validated_tolerance(zero_tolerance)
    vector = _point(v, name="v")
    magnitude = vector_norm(vector)
    if magnitude <= tolerance:
        raise ValueError("Sıfır veya eşik altındaki vektörün yönü tanımlı değildir.")
    return vector / magnitude


def angle_between(
    u: ArrayLike,
    v: ArrayLike,
    *,
    degrees: bool = False,
    zero_tolerance: float = 0.0,
) -> float:
    """İki sıfır olmayan vektör arasındaki küçük açıyı hesaplar.

    Açı varsayılan olarak radyan, ``degrees=True`` iken derece cinsindedir.
    Normalize edilmiş iç çarpım, yuvarlamayla ``[-1, 1]`` dışına çıkarsa
    ``arccos`` öncesinde bu kapalı aralığa kırpılır.
    """

    vector_u, vector_v = _same_dimension(u, v)
    direction_u = unit_vector(vector_u, zero_tolerance=zero_tolerance)
    direction_v = unit_vector(vector_v, zero_tolerance=zero_tolerance)
    cosine = float(np.clip(np.dot(direction_u, direction_v), -1.0, 1.0))
    endpoint_tolerance = 8.0 * np.finfo(float).eps
    if cosine >= 1.0 - endpoint_tolerance:
        cosine = 1.0
    elif cosine <= -1.0 + endpoint_tolerance:
        cosine = -1.0
    angle = float(np.arccos(cosine))
    return float(np.rad2deg(angle)) if degrees else angle


def scalar_projection(
    vector: ArrayLike,
    direction: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> float:
    """``vector`` vektörünün yönlendirilmiş skaler bileşenini döndürür."""

    value, target = _same_dimension(vector, direction)
    target_unit = unit_vector(target, zero_tolerance=zero_tolerance)
    return float(np.dot(value, target_unit))


def vector_projection(
    vector: ArrayLike,
    direction: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """``vector`` vektörünü ``direction`` doğrultusuna dik izdüşürür."""

    value, target = _same_dimension(vector, direction)
    target_unit = unit_vector(target, zero_tolerance=zero_tolerance)
    return float(np.dot(value, target_unit)) * target_unit


@dataclass(frozen=True)
class OrthogonalDecomposition:
    """Bir vektörün seçilen doğrultudaki paralel ve dik bileşenleri."""

    scalar_component: float
    parallel: FloatArray
    perpendicular: FloatArray
    reconstruction_residual: float
    orthogonality_residual: float


def orthogonal_decomposition(
    vector: ArrayLike,
    direction: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> OrthogonalDecomposition:
    """Bir vektörü seçilen doğrultuya paralel ve dik bileşenlere ayırır.

    ``orthogonality_residual`` boyutsuzdur ve dik bileşenin normu sıfırsa
    tanım gereği sıfır raporlanır. ``reconstruction_residual`` girdi
    vektörüyle aynı birimdedir.
    """

    value, target = _same_dimension(vector, direction)
    target_unit = unit_vector(target, zero_tolerance=zero_tolerance)
    scalar_component = float(np.dot(value, target_unit))
    parallel = scalar_component * target_unit
    perpendicular = value - parallel
    reconstruction_residual = vector_norm(parallel + perpendicular - value)
    perpendicular_norm = vector_norm(perpendicular)
    if perpendicular_norm == 0.0:
        orthogonality_residual = 0.0
    else:
        orthogonality_residual = abs(float(np.dot(perpendicular, target_unit))) / perpendicular_norm
    return OrthogonalDecomposition(
        scalar_component=scalar_component,
        parallel=parallel,
        perpendicular=perpendicular,
        reconstruction_residual=reconstruction_residual,
        orthogonality_residual=orthogonality_residual,
    )
