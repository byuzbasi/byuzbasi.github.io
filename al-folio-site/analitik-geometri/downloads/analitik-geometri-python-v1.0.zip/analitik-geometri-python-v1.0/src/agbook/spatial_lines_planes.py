"""Uzay doğruları, düzlemleri ve afin çözüm kümeleri için güvenli yardımcılar.

Modül, Bölüm 18'in temsil ve rank sözleşmesini uygular. Koordinatlar ve yön
vektörleri üç bileşenlidir; düzlem katsayıları ``(a, b, c, d)`` sırasını
kullanır. Sayısal rank tanısı, denklem satırlarını normalleştirir ve sabit
sütununu kullanıcının verdiği ``reference_scale`` ile boyutsuzlaştırır.
Bu tanı fiziksel ölçüm belirsizliği veya geometrik kabul kararı değildir.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array
from .spatial_vectors import cross_product_3d
from .vectors import vector_norm


AffineSolutionClass3D = Literal["empty", "space", "plane", "line", "point"]


def _spatial_vector(value: ArrayLike, *, name: str) -> FloatArray:
    vector = _finite_array(value, name=name)
    if vector.shape != (3,):
        raise ValueError(f"{name}, (3,) biçiminde bir uzay noktası veya vektörü olmalıdır.")
    return vector.copy()


def _point_cloud_3d(value: ArrayLike, *, name: str) -> FloatArray:
    points = _finite_array(value, name=name)
    if points.ndim != 2 or points.shape[0] == 0 or points.shape[1] != 3:
        raise ValueError(f"{name}, (n, 3) biçiminde boş olmayan bir nokta dizisi olmalıdır.")
    return points.copy()


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return number


def _positive_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} sonlu ve kesin pozitif bir sayı olmalıdır.")
    return number


def _rank_relative_tolerance(value: float) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or not 0.0 < tolerance < 1.0:
        raise ValueError(
            "rank_relative_tolerance sonlu ve (0, 1) aralığında olmalıdır."
        )
    return tolerance


def _relative_tolerance(value: float) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or not 0.0 <= tolerance < 1.0:
        raise ValueError("relative_tolerance sonlu ve [0, 1) aralığında olmalıdır.")
    return tolerance


def _finite_difference(a: FloatArray, b: FloatArray) -> FloatArray:
    with np.errstate(over="ignore", invalid="ignore"):
        difference = b - a
    if not np.all(np.isfinite(difference)):
        raise OverflowError("Uzay koordinatı farkı kayan noktalı sayı aralığını aşıyor.")
    return difference


def _finite_norm(vector: FloatArray, *, context: str) -> float:
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        magnitude = vector_norm(vector)
    if not np.isfinite(magnitude):
        raise OverflowError(f"{context} sayı aralığını aşıyor.")
    return magnitude


def _finite_dot(left: FloatArray, right: FloatArray, *, context: str) -> float:
    products = [float(a) * float(b) for a, b in zip(left, right, strict=True)]
    if not np.all(np.isfinite(products)):
        raise OverflowError(f"{context} ara çarpımı kayan noktalı sayı aralığını aşıyor.")
    result = math.fsum(products)
    if not np.isfinite(result):
        raise OverflowError(f"{context} kayan noktalı sayı aralığını aşıyor.")
    return result


def _plane_coefficients(value: ArrayLike) -> FloatArray:
    coefficients = _finite_array(value, name="coefficients")
    if coefficients.shape != (4,):
        raise ValueError("coefficients, (a, b, c, d) sıralı (4,) dizi olmalıdır.")
    magnitude = _finite_norm(coefficients[:3], context="Düzlem normalinin normu")
    if magnitude == 0.0:
        raise ValueError("Düzlem denkleminde (a, b, c) sıfır olamaz.")
    return coefficients.copy()


def parametric_line_points_3d(
    point: ArrayLike,
    direction: ArrayLike,
    parameters: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """``point + t*direction`` noktalarını ``(n, 3)`` dizisi olarak üretir.

    Kitap sözleşmesinde nokta ve yön aynı uzunluk biriminde, ``t`` ise
    boyutsuzdur. Sıfır ya da açık eşik altındaki yön bir doğru tanımlamaz.
    """

    anchor = _spatial_vector(point, name="point")
    vector = _spatial_vector(direction, name="direction")
    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    magnitude = _finite_norm(vector, context="Doğru yönünün normu")
    if magnitude <= tolerance:
        raise ValueError("Sıfır veya eşik altındaki yön bir uzay doğrusu tanımlamaz.")
    parameter_array = _finite_array(parameters, name="parameters")
    if parameter_array.ndim != 1 or parameter_array.size == 0:
        raise ValueError("parameters, (n,) biçiminde boş olmayan bir dizi olmalıdır.")
    with np.errstate(over="ignore", invalid="ignore"):
        points = anchor + parameter_array[:, None] * vector
    if not np.all(np.isfinite(points)):
        raise OverflowError("Parametrik uzay doğrusu sayı aralığını aşıyor.")
    return points


def canonical_plane_coefficients(
    coefficients: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """Düzlem katsayılarını birim normal ve belirli işaretle kanonikleştirir.

    Girdi ``a*x + b*y + c*z + d = 0`` biçimindedir. Normalin normu bire
    getirilir; ilk sıfır olmayan normal bileşeni pozitif seçilir. Koordinatlar
    uzunluk birimindeyse kanonik ``d`` aynı uzunluk birimindedir.
    """

    values = _finite_array(coefficients, name="coefficients")
    if values.shape != (4,):
        raise ValueError("coefficients, (a, b, c, d) sıralı (4,) dizi olmalıdır.")
    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    magnitude = _finite_norm(values[:3], context="Düzlem normalinin normu")
    if magnitude <= tolerance:
        raise ValueError("Sıfır veya eşik altındaki normal bir düzlem tanımlamaz.")
    canonical = values / magnitude
    if not np.all(np.isfinite(canonical)):
        raise OverflowError("Kanonik düzlem katsayıları sayı aralığını aşıyor.")
    first_nonzero = next(value for value in canonical[:3] if value != 0.0)
    if first_nonzero < 0.0:
        canonical = -canonical
    canonical[canonical == 0.0] = 0.0
    return canonical


def plane_from_point_normal(
    point: ArrayLike,
    normal: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """Bir nokta ve sıfır olmayan normalden kanonik düzlem üretir."""

    anchor = _spatial_vector(point, name="point")
    normal_vector = _spatial_vector(normal, name="normal")
    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    magnitude = _finite_norm(normal_vector, context="Düzlem normalinin normu")
    if magnitude <= tolerance:
        raise ValueError("Sıfır veya eşik altındaki normal bir düzlem tanımlamaz.")
    offset = -_finite_dot(normal_vector, anchor, context="Düzlem sabit terimi")
    return canonical_plane_coefficients(
        np.concatenate([normal_vector, [offset]]),
        zero_tolerance=tolerance,
    )


def plane_from_points_3d(
    a: ArrayLike,
    b: ArrayLike,
    c: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """Doğrusal olmayan üç uzay noktasından kanonik düzlem üretir.

    ``zero_tolerance``, ``AB x AC`` normuyla aynı alan birimindedir. Üç
    nokta doğrusal, çakışık ya da bu alan eşiğinin altındaysa düzlem güvenilir
    biçimde tanımlanmış kabul edilmez.
    """

    point_a = _spatial_vector(a, name="a")
    point_b = _spatial_vector(b, name="b")
    point_c = _spatial_vector(c, name="c")
    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    edge_ab = _finite_difference(point_a, point_b)
    edge_ac = _finite_difference(point_a, point_c)
    normal = cross_product_3d(edge_ab, edge_ac)
    area = _finite_norm(normal, context="Üç noktanın alan normu")
    if area <= tolerance:
        raise ValueError(
            "Doğrusal, çakışık veya eşik altındaki üç nokta tek bir düzlem tanımlamaz."
        )
    return plane_from_point_normal(point_a, normal)


def plane_residuals_3d(coefficients: ArrayLike, points: ArrayLike) -> FloatArray:
    """Noktalar için ham ``a*x + b*y + c*z + d`` artıklarını döndürür.

    Ham artık ortak katsayı çarpanıyla ölçeklenir ve bu nedenle tek başına
    geometrik uzaklık değildir.
    """

    values = _plane_coefficients(coefficients)
    point_array = _point_cloud_3d(points, name="points")
    residuals = []
    for point in point_array:
        linear = _finite_dot(values[:3], point, context="Düzlem denklem artığı")
        residual = math.fsum((linear, float(values[3])))
        if not np.isfinite(residual):
            raise OverflowError("Düzlem denklem artığı sayı aralığını aşıyor.")
        residuals.append(residual)
    return np.asarray(residuals, dtype=float)


@dataclass(frozen=True)
class PlaneMembershipDiagnostics3D:
    """Bir noktanın kanonik düzlem denklemine üyelik tanısı."""

    canonical_coefficients: FloatArray
    normalized_residual: float
    residual_magnitude: float
    threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float
    on_plane: bool


def plane_membership_diagnostics_3d(
    coefficients: ArrayLike,
    point: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> PlaneMembershipDiagnostics3D:
    """Düzlem üyeliğini katsayı ölçeğinden bağımsız bir artıkla sınar.

    Normal birimlendirildiği için artık koordinatların uzunluk birimindedir.
    Karar eşiği ``absolute_tolerance + relative_tolerance*reference_scale``
    olur; bu eşik fiziksel uygunluk ölçütü değildir.
    """

    canonical = canonical_plane_coefficients(coefficients)
    candidate = _spatial_vector(point, name="point")
    absolute = _nonnegative_finite(absolute_tolerance, name="absolute_tolerance")
    relative = _relative_tolerance(relative_tolerance)
    scale = _nonnegative_finite(reference_scale, name="reference_scale")
    linear = _finite_dot(canonical[:3], candidate, context="Düzlem üyelik artığı")
    residual = math.fsum((linear, float(canonical[3])))
    with np.errstate(over="ignore", invalid="ignore"):
        threshold = absolute + relative * scale
    if not np.isfinite(residual):
        raise OverflowError("Düzlem üyelik artığı sayı aralığını aşıyor.")
    if not np.isfinite(threshold):
        raise OverflowError("Düzlem üyelik eşiği sayı aralığını aşıyor.")
    magnitude = abs(residual)
    return PlaneMembershipDiagnostics3D(
        canonical_coefficients=canonical,
        normalized_residual=float(residual),
        residual_magnitude=float(magnitude),
        threshold=float(threshold),
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
        on_plane=bool(magnitude <= threshold),
    )


@dataclass(frozen=True)
class AffineSystem3DDiagnostics:
    """``A x = b`` düzlem sisteminin açık eşikli rank tanısı."""

    coefficient_rank: int
    augmented_rank: int
    solution_dimension: int | None
    classification: AffineSolutionClass3D
    consistent: bool
    rank_relative_tolerance: float
    reference_scale: float
    rank_threshold: float
    coefficient_singular_values: FloatArray
    augmented_singular_values: FloatArray
    least_squares_point: FloatArray
    maximum_equation_residual: float


def _normalized_plane_system(
    coefficient_matrix: FloatArray,
    right_hand_side: FloatArray,
) -> tuple[FloatArray, FloatArray]:
    normalized_matrix = np.zeros_like(coefficient_matrix, dtype=float)
    normalized_rhs = np.zeros_like(right_hand_side, dtype=float)
    for index, row in enumerate(coefficient_matrix):
        magnitude = _finite_norm(row, context="Düzlem sistemi satır normu")
        if magnitude == 0.0:
            normalized_rhs[index] = right_hand_side[index]
            continue
        with np.errstate(over="ignore", invalid="ignore", under="ignore"):
            normalized_matrix[index] = row / magnitude
            normalized_rhs[index] = right_hand_side[index] / magnitude
        if not np.all(np.isfinite(normalized_matrix[index])) or not np.isfinite(
            normalized_rhs[index]
        ):
            raise OverflowError("Düzlem sistemi normalleştirmesi sayı aralığını aşıyor.")
        first_nonzero = next(value for value in normalized_matrix[index] if value != 0.0)
        if first_nonzero < 0.0:
            normalized_matrix[index] *= -1.0
            normalized_rhs[index] *= -1.0
    return normalized_matrix, normalized_rhs


def _solution_class(
    coefficient_rank: int,
    augmented_rank: int,
) -> tuple[AffineSolutionClass3D, int | None, bool]:
    if augmented_rank > coefficient_rank:
        return "empty", None, False
    dimension = 3 - coefficient_rank
    classes: dict[int, AffineSolutionClass3D] = {
        3: "space",
        2: "plane",
        1: "line",
        0: "point",
    }
    return classes[dimension], dimension, True


def affine_system_diagnostics_3d(
    coefficient_matrix: ArrayLike,
    right_hand_side: ArrayLike,
    *,
    rank_relative_tolerance: float,
    reference_scale: float,
) -> AffineSystem3DDiagnostics:
    """Üç bilinmeyenli afin sistemi rank yoluyla sınıflandırır.

    ``coefficient_matrix`` tam ``(m, 3)``, ``right_hand_side`` ise ``(m,)``
    biçiminde olmalıdır; ``m=0`` bütün uzayı tanımlar. Sıfır olmayan her
    denklem satırı önce normalleştirilir. Genişletilmiş matrisin sabit sütunu
    ``reference_scale`` uzunluğuna bölünerek boyutsuzlaştırılır. Katsayı ve
    genişletilmiş rankları aynı SVD eşiğiyle hesaplanır.
    """

    matrix = _finite_array(coefficient_matrix, name="coefficient_matrix")
    rhs = _finite_array(right_hand_side, name="right_hand_side")
    if matrix.ndim != 2 or matrix.shape[1:] != (3,):
        raise ValueError("coefficient_matrix, (m, 3) biçiminde olmalıdır.")
    if rhs.ndim != 1 or rhs.shape != (matrix.shape[0],):
        raise ValueError("right_hand_side, coefficient_matrix satırlarıyla eşleşmelidir.")
    tolerance = _rank_relative_tolerance(rank_relative_tolerance)
    scale = _positive_finite(reference_scale, name="reference_scale")

    if matrix.shape[0] == 0:
        empty = np.empty(0, dtype=float)
        return AffineSystem3DDiagnostics(
            coefficient_rank=0,
            augmented_rank=0,
            solution_dimension=3,
            classification="space",
            consistent=True,
            rank_relative_tolerance=tolerance,
            reference_scale=scale,
            rank_threshold=0.0,
            coefficient_singular_values=empty.copy(),
            augmented_singular_values=empty.copy(),
            least_squares_point=np.zeros(3, dtype=float),
            maximum_equation_residual=0.0,
        )

    normalized_matrix, normalized_rhs = _normalized_plane_system(matrix, rhs)
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        dimensionless_rhs = normalized_rhs / scale
    if not np.all(np.isfinite(dimensionless_rhs)):
        raise OverflowError("Boyutsuz genişletilmiş matris sayı aralığını aşıyor.")
    augmented = np.column_stack([normalized_matrix, dimensionless_rhs])

    left, coefficient_values, right_transpose = np.linalg.svd(
        normalized_matrix,
        full_matrices=False,
    )
    augmented_values = np.linalg.svd(augmented, compute_uv=False)
    largest = max(
        float(coefficient_values[0]) if coefficient_values.size else 0.0,
        float(augmented_values[0]) if augmented_values.size else 0.0,
    )
    threshold = tolerance * largest
    coefficient_rank = int(np.count_nonzero(coefficient_values > threshold))
    augmented_rank = int(np.count_nonzero(augmented_values > threshold))
    classification, solution_dimension, consistent = _solution_class(
        coefficient_rank,
        augmented_rank,
    )

    retained = coefficient_values > threshold
    if np.any(retained):
        coordinates = (left[:, retained].T @ normalized_rhs) / coefficient_values[retained]
        candidate = right_transpose[retained].T @ coordinates
    else:
        candidate = np.zeros(3, dtype=float)
    if not np.all(np.isfinite(candidate)):
        raise OverflowError("En küçük normlu sistem adayı sayı aralığını aşıyor.")
    with np.errstate(over="ignore", invalid="ignore"):
        residuals = normalized_matrix @ candidate - normalized_rhs
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Düzlem sistemi artığı sayı aralığını aşıyor.")
    maximum_residual = float(np.max(np.abs(residuals), initial=0.0))

    return AffineSystem3DDiagnostics(
        coefficient_rank=coefficient_rank,
        augmented_rank=augmented_rank,
        solution_dimension=solution_dimension,
        classification=classification,
        consistent=consistent,
        rank_relative_tolerance=tolerance,
        reference_scale=scale,
        rank_threshold=float(threshold),
        coefficient_singular_values=coefficient_values.copy(),
        augmented_singular_values=augmented_values.copy(),
        least_squares_point=np.asarray(candidate, dtype=float),
        maximum_equation_residual=maximum_residual,
    )
