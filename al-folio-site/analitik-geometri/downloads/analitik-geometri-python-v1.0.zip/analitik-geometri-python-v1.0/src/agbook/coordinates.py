"""Bölüm 8 için Kartezyen ve kutupsal koordinat dönüşümleri.

Kutupsal girdiler ``(r, theta)`` sırasındadır ve açı radyan cinsindedir.
Kartezyen girdiden üretilen kanonik temsil ``r >= 0`` ve
``0 <= theta < 2*pi`` koşullarını taşır; orijinde açı kod sözleşmesi olarak
sıfır seçilir.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array


def _coordinate_pairs(value: ArrayLike, *, name: str) -> FloatArray:
    pairs = _finite_array(value, name=name)
    if pairs.ndim == 1:
        if pairs.shape != (2,):
            raise ValueError(f"{name}, (2,) biçiminde tek koordinat çifti olmalıdır.")
    elif pairs.ndim == 2:
        if pairs.shape[0] == 0 or pairs.shape[1] != 2:
            raise ValueError(
                f"{name}, (n, 2) biçiminde boş olmayan koordinat çiftleri olmalıdır."
            )
    else:
        raise ValueError(f"{name}, (2,) veya (n, 2) biçiminde olmalıdır.")
    return pairs


def polar_to_cartesian(polar_points: ArrayLike) -> FloatArray:
    """``(r, theta)`` çiftlerini ``(x, y)`` Kartezyen koordinatlarına çevirir.

    Negatif yarıçap kabul edilir; böylece
    ``(r, theta)`` ile ``(-r, theta+pi)`` aynı noktayı temsil eder.
    """

    polar = _coordinate_pairs(polar_points, name="polar_points")
    radius = polar[..., 0]
    angle = polar[..., 1]
    cartesian = np.stack(
        (radius * np.cos(angle), radius * np.sin(angle)),
        axis=-1,
    )
    if not np.all(np.isfinite(cartesian)):
        raise ValueError("Kutupsal dönüşüm sonlu olmayan bir çıktı üretti.")
    return cartesian


def cartesian_to_polar(points: ArrayLike) -> FloatArray:
    """``(x, y)`` çiftlerini kanonik ``(r, theta)`` biçimine çevirir.

    Sonuçta ``r >= 0`` ve ``0 <= theta < 2*pi`` olur. Orijinde geometrik açı
    tanımsızdır; yeniden üretilebilir kod çıktısı için ``theta=0`` seçilir.
    """

    cartesian = _coordinate_pairs(points, name="points")
    x_coordinate = cartesian[..., 0]
    y_coordinate = cartesian[..., 1]
    radius = np.hypot(x_coordinate, y_coordinate)
    angle = np.mod(np.arctan2(y_coordinate, x_coordinate), 2.0 * np.pi)
    angle = np.where(radius == 0.0, 0.0, angle)
    polar = np.stack((radius, angle), axis=-1)
    if not np.all(np.isfinite(polar)):
        raise ValueError("Kartezyen dönüşüm sonlu olmayan bir çıktı üretti.")
    return polar
