"""Bölüm 3 için düzlemsel determinant, alan ve yönelim hesapları.

Bu modül yalnız sonlu reel koordinatları kabul eder. Kayan noktalı bir
determinantın sıfıra yakın olması matematiksel eşdoğrusallığı kanıtlamaz;
``orientation_diagnostics`` bu nedenle eşik içindeki sonuçları
``uncertain`` olarak bildirir.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array, _point, _same_dimension
from .vectors import vector_norm


OrientationClass = Literal[
    "counterclockwise",
    "clockwise",
    "uncertain",
    "degenerate",
]


def _planar_pair(u: ArrayLike, v: ArrayLike) -> tuple[FloatArray, FloatArray]:
    vector_u, vector_v = _same_dimension(u, v)
    if vector_u.shape != (2,):
        raise ValueError("u ve v, (2,) biçiminde düzlemsel vektörler olmalıdır.")
    return vector_u, vector_v


def _relative_tolerance(value: float) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or not 0.0 <= tolerance < 1.0:
        raise ValueError("relative_tolerance sonlu ve [0, 1) aralığında olmalıdır.")
    return tolerance


def _finite_difference(a: FloatArray, b: FloatArray) -> FloatArray:
    with np.errstate(over="ignore", invalid="ignore"):
        difference = b - a
    if not np.all(np.isfinite(difference)):
        raise OverflowError("Koordinat farkı kayan noktalı sayı aralığını aşıyor.")
    return difference


def determinant_2d(u: ArrayLike, v: ArrayLike) -> float:
    """Sütunları ``u`` ve ``v`` olan 2 x 2 matrisin determinantı.

    Sonuç, koordinatlar fiziksel uzunluk taşıyorsa uzunluğun karesi
    birimindedir. Ara çarpımlardan biri sonlu değilse sessizce ``inf``
    döndürmek yerine ``OverflowError`` yükseltilir.
    """

    vector_u, vector_v = _planar_pair(u, v)
    first = float(vector_u[0]) * float(vector_v[1])
    second = float(vector_u[1]) * float(vector_v[0])
    if not np.isfinite(first) or not np.isfinite(second):
        raise OverflowError("Determinantın ara çarpımı kayan noktalı sayı aralığını aşıyor.")
    result = math.fsum((first, -second))
    if not np.isfinite(result):
        raise OverflowError("Determinant kayan noktalı sayı aralığını aşıyor.")
    return result


def signed_double_area(a: ArrayLike, b: ArrayLike, c: ArrayLike) -> float:
    """Sıralı ``A, B, C`` üçgeninin yönlü alanının iki katını döndürür."""

    point_a, point_b = _same_dimension(a, b)
    point_c = _point(c, name="c")
    if point_a.shape != (2,) or point_c.shape != (2,):
        raise ValueError("a, b ve c, (2,) biçiminde düzlemsel noktalar olmalıdır.")
    edge_ab = _finite_difference(point_a, point_b)
    edge_ac = _finite_difference(point_a, point_c)
    return determinant_2d(edge_ab, edge_ac)


def triangle_area(a: ArrayLike, b: ArrayLike, c: ArrayLike) -> float:
    """Üç düzlemsel noktanın negatif olmayan üçgen alanını döndürür."""

    return 0.5 * abs(signed_double_area(a, b, c))


@dataclass(frozen=True)
class OrientationDiagnostics:
    """Üç noktanın yönelim işareti için ölçekten bağımsız tanı bilgisi.

    ``normalized_determinant`` standart sağ yönlü Kartezyen çerçevede
    ``AB`` ile ``AC`` arasındaki yönlü açının sinüsüdür. Mutlak değeri
    ``relative_tolerance`` eşiğini aşmıyorsa sınıf ``uncertain`` olur.
    """

    signed_double_area: float
    normalized_determinant: float
    relative_tolerance: float
    classification: OrientationClass


def orientation_diagnostics(
    a: ArrayLike,
    b: ArrayLike,
    c: ArrayLike,
    *,
    relative_tolerance: float,
) -> OrientationDiagnostics:
    """``A -> B -> C`` dönüşünün yönelimini ölçek duyarlı sınıflandırır.

    Pozitif sonuç saat yönünün tersini, negatif sonuç saat yönünü gösterir.
    Bu işaret sözleşmesi standart sağ yönlü Kartezyen çerçeve içindir.
    Yaklaşık sıfır sonucu eşdoğrusallık kanıtı olarak sunulmaz.
    """

    tolerance = _relative_tolerance(relative_tolerance)
    point_a, point_b = _same_dimension(a, b)
    point_c = _point(c, name="c")
    if point_a.shape != (2,) or point_c.shape != (2,):
        raise ValueError("a, b ve c, (2,) biçiminde düzlemsel noktalar olmalıdır.")

    edge_ab = _finite_difference(point_a, point_b)
    edge_ac = _finite_difference(point_a, point_c)
    signed_area = determinant_2d(edge_ab, edge_ac)
    scale_ab = float(np.max(np.abs(edge_ab)))
    scale_ac = float(np.max(np.abs(edge_ac)))
    if scale_ab == 0.0 or scale_ac == 0.0 or np.array_equal(point_b, point_c):
        return OrientationDiagnostics(signed_area, 0.0, tolerance, "degenerate")

    scaled_ab = edge_ab / scale_ab
    scaled_ac = edge_ac / scale_ac
    denominator = vector_norm(scaled_ab) * vector_norm(scaled_ac)
    normalized = float(np.clip(determinant_2d(scaled_ab, scaled_ac) / denominator, -1.0, 1.0))
    if abs(normalized) <= tolerance:
        classification: OrientationClass = "uncertain"
    elif normalized > 0.0:
        classification = "counterclockwise"
    else:
        classification = "clockwise"
    return OrientationDiagnostics(signed_area, normalized, tolerance, classification)


def _polygon_vertices(vertices: ArrayLike) -> FloatArray:
    points = _finite_array(vertices, name="vertices")
    if points.ndim != 2 or points.shape[1:] != (2,) or points.shape[0] < 3:
        raise ValueError("vertices, en az üç satırlı (n, 2) biçiminde olmalıdır.")
    return points


def polygon_signed_area(vertices: ArrayLike) -> float:
    """Sınır sırasındaki düzlemsel köşelerin yönlü çokgen alanını verir.

    Köşeler basit çokgen sınırı boyunca sıralanmalıdır. İşlev kesişim veya
    sıralama denetimi yapmaz; öz-kesişimli girdide sonuç cebirsel alandır.
    İlk köşeyi sonda yinelemek sonucu değiştirmez. Çeviri kaynaklı büyük
    sayı iptalini azaltmak için üçgen yelpazesi ilk köşeye taşınır ve
    terimler ``math.fsum`` ile toplanır.
    """

    points = _polygon_vertices(vertices)
    origin = points[0]
    terms = []
    for index in range(1, points.shape[0] - 1):
        first = _finite_difference(origin, points[index])
        second = _finite_difference(origin, points[index + 1])
        terms.append(determinant_2d(first, second))
    return 0.5 * math.fsum(terms)


def polygon_area(vertices: ArrayLike) -> float:
    """Sıralı basit çokgenin negatif olmayan alanını döndürür."""

    return abs(polygon_signed_area(vertices))
