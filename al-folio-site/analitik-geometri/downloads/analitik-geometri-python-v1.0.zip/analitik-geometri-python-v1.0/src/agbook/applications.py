"""Bütünleştirici analitik geometri uygulamaları.

Bu modül ölçme-haritalama, CAD/robotik, bilgisayarlı görü, geometrik optik
ve yörünge geometrisinde yinelenen dört işlemi güvenilir bir sayısal
sözleşmede toplar: eşlenik nokta kaydı, iğne deliği kamera izdüşümü ve DLT
üçgenleme, ışın-düzlem kesişimi/yansıması ve odak merkezli uzay elipsi.

Girdiler sonlu ve eksiksiz olmalıdır. Fonksiyonlar birim dönüşümü, eksik
değer doldurma, gözlem silme veya fiziksel kabul kararı yapmaz. Sayısal
eşikler yalnız rank ve geometrik sınıflandırma içindir.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array
from .model_fitting import DesignDiagnostics


@dataclass(frozen=True)
class SimilarityRegistrationResult:
    """Eşlenik noktalardan kestirilen yön-koruyan benzerlik dönüşümü."""

    dimension: int
    rotation: FloatArray
    translation: FloatArray
    scale: float
    homogeneous_matrix: FloatArray
    source_centroid: FloatArray
    target_centroid: FloatArray
    transformed_source: FloatArray
    residual_vectors: FloatArray
    residual_norms: FloatArray
    rms_residual: float
    weighted_rms_residual: float
    weights: FloatArray
    scale_estimated: bool
    reflection_correction_applied: bool
    diagnostics: DesignDiagnostics


@dataclass(frozen=True)
class PinholeProjectionResult:
    """Merkezî kamera izdüşümü ve projektif derinlik tanıları."""

    image_points: FloatArray
    homogeneous_image_points: FloatArray
    projective_depths: FloatArray
    in_front: np.ndarray
    camera_matrix: FloatArray
    relative_tolerance: float


@dataclass(frozen=True)
class TriangulationResult:
    """Çoklu bilinen kameradan DLT ile kestirilen tek uzay noktası."""

    point: FloatArray
    homogeneous_point: FloatArray
    reprojected_points: FloatArray
    residual_vectors: FloatArray
    residual_norms: FloatArray
    rms_reprojection: float
    projective_depths: FloatArray
    in_front: np.ndarray
    diagnostics: DesignDiagnostics


@dataclass(frozen=True)
class RayPlaneIntersectionResult:
    """Yönlü ışın ile düzlemin kesişim sınıfı ve varsa kesişim noktası."""

    classification: Literal["intersecting", "behind", "parallel", "coplanar"]
    point: FloatArray | None
    ray_parameter: float | None
    origin: FloatArray
    unit_direction: FloatArray
    plane_point: FloatArray
    unit_normal: FloatArray
    denominator: float
    signed_origin_distance: float


@dataclass(frozen=True)
class OrbitEllipse3D:
    """Bir odağı ve apsis uzaklıkları bilinen uzay elipsinin çerçevesi."""

    focus: FloatArray
    center: FloatArray
    second_focus: FloatArray
    periapsis: FloatArray
    apoapsis: FloatArray
    periapsis_direction: FloatArray
    transverse_direction: FloatArray
    plane_normal: FloatArray
    periapsis_radius: float
    apoapsis_radius: float
    semi_major_axis: float
    semi_minor_axis: float
    focal_distance: float
    eccentricity: float
    semi_latus_rectum: float


def _relative_tolerance(value: float) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or tolerance < 0.0 or tolerance >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return number


def _positive_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} sonlu ve pozitif olmalıdır.")
    return number


def _point_rows(
    value: ArrayLike,
    *,
    dimensions: tuple[int, ...],
    minimum_rows: int,
    name: str,
) -> FloatArray:
    points = _finite_array(value, name=name)
    if points.ndim != 2 or points.shape[1] not in dimensions:
        forms = " veya ".join(f"(n, {dimension})" for dimension in dimensions)
        raise ValueError(f"{name}, {forms} biçiminde olmalıdır.")
    if points.shape[0] < minimum_rows:
        raise ValueError(f"{name} en az {minimum_rows} satır içermelidir.")
    return points.copy()


def _vector(value: ArrayLike, *, dimension: int, name: str) -> FloatArray:
    vector = _finite_array(value, name=name)
    if vector.shape != (dimension,):
        raise ValueError(f"{name}, ({dimension},) biçiminde olmalıdır.")
    return vector.copy()


def _unit_vector(value: ArrayLike, *, dimension: int, name: str) -> FloatArray:
    vector = _vector(value, dimension=dimension, name=name)
    norm = float(np.linalg.norm(vector))
    if norm <= np.finfo(float).tiny:
        raise ValueError(f"{name} sıfır vektörü olamaz.")
    return vector / norm


def _design_diagnostics(
    matrix: FloatArray,
    *,
    relative_tolerance: float,
) -> DesignDiagnostics:
    tolerance = _relative_tolerance(relative_tolerance)
    singular_values = np.linalg.svd(matrix, compute_uv=False)
    largest = float(singular_values[0]) if singular_values.size else 0.0
    threshold = tolerance * largest
    rank = int(np.count_nonzero(singular_values > threshold))
    if singular_values.size == 0 or singular_values[-1] <= threshold:
        condition = float("inf")
    else:
        condition = largest / float(singular_values[-1])
    gap: float | None = None
    if singular_values.size >= 2:
        smallest = float(singular_values[-1])
        gap = (
            float("inf")
            if smallest <= np.finfo(float).tiny
            else float(singular_values[-2] / smallest)
        )
    return DesignDiagnostics(
        singular_values=singular_values,
        effective_rank=rank,
        relative_tolerance=tolerance,
        decision_threshold=threshold,
        condition_number=condition,
        nullspace_gap=gap,
    )


def _registration_weights(weights: ArrayLike | None, count: int) -> FloatArray:
    if weights is None:
        return np.ones(count, dtype=float)
    values = _finite_array(weights, name="weights")
    if values.shape != (count,):
        raise ValueError("weights, nokta sayısıyla aynı uzunlukta olmalıdır.")
    if np.any(values <= 0.0):
        raise ValueError("weights değerlerinin tümü pozitif olmalıdır.")
    return values.copy()


def fit_similarity_registration(
    source_points: ArrayLike,
    target_points: ArrayLike,
    *,
    estimate_scale: bool = True,
    weights: ArrayLike | None = None,
    relative_tolerance: float = 1.0e-12,
) -> SimilarityRegistrationResult:
    """Eşlenik 2B/3B noktalar arasında yön-koruyan benzerlik uydurur.

    Dönen değer, satır biçimindeki noktalar için
    ``target = scale * source @ rotation.T + translation`` sözleşmesini
    kullanır. ``estimate_scale=False`` seçildiğinde ölçek tam olarak birdir.
    Yansıma hiçbir zaman dönüşüme alınmaz; SVD işareti gerekirse düzeltilir.
    """

    tolerance = _relative_tolerance(relative_tolerance)
    source = _point_rows(
        source_points,
        dimensions=(2, 3),
        minimum_rows=2,
        name="source_points",
    )
    target = _point_rows(
        target_points,
        dimensions=(2, 3),
        minimum_rows=2,
        name="target_points",
    )
    if source.shape != target.shape:
        raise ValueError("source_points ve target_points aynı biçimde olmalıdır.")
    count, dimension = source.shape
    if dimension == 3 and count < 3:
        raise ValueError("Üç boyutlu kayıt için en az üç eşlenik nokta gerekir.")

    point_weights = _registration_weights(weights, count)
    weight_sum = float(np.sum(point_weights))
    normalized_weights = point_weights / weight_sum
    source_centroid = np.sum(normalized_weights[:, None] * source, axis=0)
    target_centroid = np.sum(normalized_weights[:, None] * target, axis=0)
    centered_source = source - source_centroid
    centered_target = target - target_centroid

    weighted_source = np.sqrt(normalized_weights)[:, None] * centered_source
    weighted_target = np.sqrt(normalized_weights)[:, None] * centered_target
    source_singular = np.linalg.svd(weighted_source, compute_uv=False)
    target_singular = np.linalg.svd(weighted_target, compute_uv=False)
    source_threshold = tolerance * float(source_singular[0])
    target_threshold = tolerance * float(target_singular[0])
    source_rank = int(np.count_nonzero(source_singular > source_threshold))
    target_rank = int(np.count_nonzero(target_singular > target_threshold))
    required_rank = dimension - 1
    if source_rank < required_rank or target_rank < required_rank:
        raise ValueError(
            "Nokta düzeni dönüşümü belirlemek için yetersiz ranka sahiptir."
        )

    cross_covariance = centered_source.T @ (
        normalized_weights[:, None] * centered_target
    )
    left, singular_values, right_transpose = np.linalg.svd(cross_covariance)
    correction = np.eye(dimension)
    provisional = right_transpose.T @ left.T
    reflection_correction = bool(np.linalg.det(provisional) < 0.0)
    if reflection_correction:
        correction[-1, -1] = -1.0
    rotation = right_transpose.T @ correction @ left.T

    if estimate_scale:
        denominator = float(
            np.sum(normalized_weights * np.sum(centered_source**2, axis=1))
        )
        if denominator <= np.finfo(float).tiny:
            raise ValueError("Kaynak nokta kümesinin ölçek kestirimi için yayılımı yoktur.")
        numerator = float(np.sum(singular_values * np.diag(correction)))
        scale = numerator / denominator
        if not np.isfinite(scale) or scale <= np.finfo(float).tiny:
            raise ValueError("Pozitif bir benzerlik ölçeği kestirilemedi.")
    else:
        scale = 1.0

    translation = target_centroid - scale * (rotation @ source_centroid)
    transformed = scale * (source @ rotation.T) + translation
    residual_vectors = target - transformed
    residual_norms = np.linalg.norm(residual_vectors, axis=1)
    rms = float(np.sqrt(np.mean(residual_norms**2)))
    weighted_rms = float(np.sqrt(np.sum(normalized_weights * residual_norms**2)))

    homogeneous = np.eye(dimension + 1)
    homogeneous[:dimension, :dimension] = scale * rotation
    homogeneous[:dimension, dimension] = translation
    diagnostics = _design_diagnostics(
        cross_covariance,
        relative_tolerance=tolerance,
    )
    return SimilarityRegistrationResult(
        dimension=dimension,
        rotation=rotation,
        translation=translation,
        scale=float(scale),
        homogeneous_matrix=homogeneous,
        source_centroid=source_centroid,
        target_centroid=target_centroid,
        transformed_source=transformed,
        residual_vectors=residual_vectors,
        residual_norms=residual_norms,
        rms_residual=rms,
        weighted_rms_residual=weighted_rms,
        weights=point_weights,
        scale_estimated=bool(estimate_scale),
        reflection_correction_applied=reflection_correction,
        diagnostics=diagnostics,
    )


def apply_similarity_registration(
    points: ArrayLike,
    registration: SimilarityRegistrationResult,
) -> FloatArray:
    """Bir kayıt sonucunu aynı boyuttaki nokta satırlarına uygular."""

    rows = _point_rows(
        points,
        dimensions=(registration.dimension,),
        minimum_rows=1,
        name="points",
    )
    return registration.scale * (rows @ registration.rotation.T) + registration.translation


def _canonical_camera_matrix(camera_matrix: ArrayLike) -> FloatArray:
    matrix = _finite_array(camera_matrix, name="camera_matrix")
    if matrix.shape != (3, 4):
        raise ValueError("camera_matrix, (3, 4) biçiminde olmalıdır.")
    if np.linalg.matrix_rank(matrix) < 3:
        raise ValueError("camera_matrix rankı üç olmalıdır.")
    left_determinant = float(np.linalg.det(matrix[:, :3]))
    if abs(left_determinant) <= np.finfo(float).tiny:
        raise ValueError("Sonlu merkezli kamera için sol 3x3 blok tersinir olmalıdır.")
    canonical = matrix.copy()
    if left_determinant < 0.0:
        canonical *= -1.0
    canonical /= np.linalg.norm(canonical)
    return canonical


def project_pinhole(
    camera_matrix: ArrayLike,
    points: ArrayLike,
    *,
    relative_tolerance: float = 1.0e-12,
) -> PinholeProjectionResult:
    """Sonlu 3B noktaları bilinen bir iğne deliği kameraya izdüşürür.

    Görüntü koordinatları piksel veya normalize kamera koordinatı olabilir;
    bunun anlamını kamera matrisi belirler. Negatif projektif derinlikli
    noktalar silinmez, ``in_front=False`` olarak raporlanır.
    """

    tolerance = _relative_tolerance(relative_tolerance)
    camera = _canonical_camera_matrix(camera_matrix)
    rows = _point_rows(
        points,
        dimensions=(3,),
        minimum_rows=1,
        name="points",
    )
    homogeneous_points = np.column_stack((rows, np.ones(rows.shape[0])))
    image_homogeneous = homogeneous_points @ camera.T
    depth = image_homogeneous[:, 2]
    row_scale = np.max(np.abs(image_homogeneous), axis=1)
    invalid = np.abs(depth) <= tolerance * np.maximum(row_scale, 1.0)
    if np.any(invalid):
        indices = np.flatnonzero(invalid).tolist()
        raise ValueError(f"İzdüşümü sonlu olmayan nokta indisleri: {indices}")
    image = image_homogeneous[:, :2] / depth[:, None]
    return PinholeProjectionResult(
        image_points=image,
        homogeneous_image_points=image_homogeneous,
        projective_depths=depth,
        in_front=depth > 0.0,
        camera_matrix=camera,
        relative_tolerance=tolerance,
    )


def triangulate_point_dlt(
    camera_matrices: ArrayLike,
    image_points: ArrayLike,
    *,
    relative_tolerance: float = 1.0e-12,
) -> TriangulationResult:
    """En az iki bilinen kameradan tek bir 3B noktayı doğrusal DLT ile bulur.

    Her görüntü noktası ``(u, v)`` biçimindedir. Tasarım satırları birim
    norma ölçeklenir; sonuç görüntülere geri izdüşürülerek piksel artıkları
    ve projektif derinlik işaretleri raporlanır.
    """

    tolerance = _relative_tolerance(relative_tolerance)
    matrices = _finite_array(camera_matrices, name="camera_matrices")
    if matrices.ndim != 3 or matrices.shape[1:] != (3, 4):
        raise ValueError("camera_matrices, (m, 3, 4) biçiminde olmalıdır.")
    if matrices.shape[0] < 2:
        raise ValueError("DLT üçgenleme için en az iki kamera gerekir.")
    observations = _point_rows(
        image_points,
        dimensions=(2,),
        minimum_rows=2,
        name="image_points",
    )
    if observations.shape[0] != matrices.shape[0]:
        raise ValueError("Her kamera için tam bir görüntü noktası verilmelidir.")

    cameras = np.stack([_canonical_camera_matrix(matrix) for matrix in matrices])
    rows: list[FloatArray] = []
    for camera, (u_coordinate, v_coordinate) in zip(cameras, observations):
        first = u_coordinate * camera[2] - camera[0]
        second = v_coordinate * camera[2] - camera[1]
        for row in (first, second):
            norm = float(np.linalg.norm(row))
            if norm <= np.finfo(float).tiny:
                raise ValueError("DLT tasarımında sıfır satır oluştu.")
            rows.append(row / norm)
    design = np.vstack(rows)
    diagnostics = _design_diagnostics(design, relative_tolerance=tolerance)
    if diagnostics.effective_rank < 3:
        raise ValueError("Kamera geometrisi benzersiz bir 3B nokta belirlemiyor.")
    _, _, right_transpose = np.linalg.svd(design)
    homogeneous = right_transpose[-1].copy()
    pivot = int(np.argmax(np.abs(homogeneous)))
    if homogeneous[pivot] < 0.0:
        homogeneous *= -1.0
    if abs(homogeneous[3]) <= tolerance * np.linalg.norm(homogeneous):
        raise ValueError("DLT çözümü sonlu bir Öklid noktası değildir.")
    point = homogeneous[:3] / homogeneous[3]
    homogeneous = np.concatenate((point, [1.0]))

    reprojected: list[FloatArray] = []
    depths: list[float] = []
    in_front: list[bool] = []
    for camera in cameras:
        projection = project_pinhole(
            camera,
            point[None, :],
            relative_tolerance=tolerance,
        )
        reprojected.append(projection.image_points[0])
        depths.append(float(projection.projective_depths[0]))
        in_front.append(bool(projection.in_front[0]))
    reprojected_array = np.vstack(reprojected)
    residual_vectors = observations - reprojected_array
    residual_norms = np.linalg.norm(residual_vectors, axis=1)
    rms = float(np.sqrt(np.mean(residual_norms**2)))
    return TriangulationResult(
        point=point,
        homogeneous_point=homogeneous,
        reprojected_points=reprojected_array,
        residual_vectors=residual_vectors,
        residual_norms=residual_norms,
        rms_reprojection=rms,
        projective_depths=np.asarray(depths),
        in_front=np.asarray(in_front, dtype=bool),
        diagnostics=diagnostics,
    )


def ray_plane_intersection(
    origin: ArrayLike,
    direction: ArrayLike,
    plane_point: ArrayLike,
    plane_normal: ArrayLike,
    *,
    relative_tolerance: float = 1.0e-12,
    distance_tolerance: float = 1.0e-12,
) -> RayPlaneIntersectionResult:
    """Yönlü bir ışının düzlemle ilişkisini sınıflandırır.

    Yön içeride birimlenir; dolayısıyla ``ray_parameter`` giriş koordinatının
    uzunluk birimindedir. Negatif parametreli doğru kesişimi ``behind`` diye
    raporlanır ve ışın üzerinde kabul edilmez.
    """

    tolerance = _relative_tolerance(relative_tolerance)
    distance_limit = _nonnegative_finite(
        distance_tolerance,
        name="distance_tolerance",
    )
    ray_origin = _vector(origin, dimension=3, name="origin")
    ray_direction = _unit_vector(direction, dimension=3, name="direction")
    point_on_plane = _vector(plane_point, dimension=3, name="plane_point")
    normal = _unit_vector(plane_normal, dimension=3, name="plane_normal")
    denominator = float(normal @ ray_direction)
    signed_distance = float(normal @ (ray_origin - point_on_plane))
    if abs(denominator) <= tolerance:
        classification: Literal["parallel", "coplanar"]
        classification = "coplanar" if abs(signed_distance) <= distance_limit else "parallel"
        return RayPlaneIntersectionResult(
            classification=classification,
            point=None,
            ray_parameter=None,
            origin=ray_origin,
            unit_direction=ray_direction,
            plane_point=point_on_plane,
            unit_normal=normal,
            denominator=denominator,
            signed_origin_distance=signed_distance,
        )
    parameter = -signed_distance / denominator
    point = ray_origin + parameter * ray_direction
    classification = "intersecting" if parameter >= -distance_limit else "behind"
    if abs(parameter) <= distance_limit:
        parameter = 0.0
        point = ray_origin.copy()
    return RayPlaneIntersectionResult(
        classification=classification,
        point=point,
        ray_parameter=float(parameter),
        origin=ray_origin,
        unit_direction=ray_direction,
        plane_point=point_on_plane,
        unit_normal=normal,
        denominator=denominator,
        signed_origin_distance=signed_distance,
    )


def reflect_direction(direction: ArrayLike, normal: ArrayLike) -> FloatArray:
    """Bir yönü birim yüzey normaline göre speküler olarak yansıtır.

    Giriş yönünün normu korunur. Normalin işareti sonucu değiştirmez.
    """

    vector = _vector(direction, dimension=3, name="direction")
    if np.linalg.norm(vector) <= np.finfo(float).tiny:
        raise ValueError("direction sıfır vektörü olamaz.")
    unit_normal = _unit_vector(normal, dimension=3, name="normal")
    return vector - 2.0 * float(vector @ unit_normal) * unit_normal


def orbit_ellipse_frame_3d(
    focus: ArrayLike,
    periapsis_direction: ArrayLike,
    plane_normal: ArrayLike,
    periapsis_radius: float,
    apoapsis_radius: float,
    *,
    relative_tolerance: float = 1.0e-12,
) -> OrbitEllipse3D:
    """Odak, düzlem ve apsis uzaklıklarından uzay elipsi kurar.

    Bu işlev yalnız geometriktir; zaman, hız, kütleçekim parametresi veya
    yörünge yayılımı hesaplamaz. ``periapsis_direction`` düzleme izdüşürülür
    ve izdüşüm sıfıra yakınsa girdi reddedilir.
    """

    tolerance = _relative_tolerance(relative_tolerance)
    focal_point = _vector(focus, dimension=3, name="focus")
    normal = _unit_vector(plane_normal, dimension=3, name="plane_normal")
    proposed_direction = _vector(
        periapsis_direction,
        dimension=3,
        name="periapsis_direction",
    )
    in_plane = proposed_direction - float(proposed_direction @ normal) * normal
    in_plane_norm = float(np.linalg.norm(in_plane))
    proposed_norm = float(np.linalg.norm(proposed_direction))
    if proposed_norm <= np.finfo(float).tiny:
        raise ValueError("periapsis_direction sıfır vektörü olamaz.")
    if in_plane_norm <= tolerance * proposed_norm:
        raise ValueError("periapsis_direction yörünge düzleminde bir yön belirlemiyor.")
    axis_u = in_plane / in_plane_norm
    axis_v = np.cross(normal, axis_u)
    axis_v /= np.linalg.norm(axis_v)

    periapsis_distance = _positive_finite(
        periapsis_radius,
        name="periapsis_radius",
    )
    apoapsis_distance = _positive_finite(
        apoapsis_radius,
        name="apoapsis_radius",
    )
    if apoapsis_distance < periapsis_distance:
        raise ValueError("apoapsis_radius, periapsis_radius değerinden küçük olamaz.")

    semi_major = 0.5 * (periapsis_distance + apoapsis_distance)
    focal_distance = 0.5 * (apoapsis_distance - periapsis_distance)
    semi_minor = float(np.sqrt(periapsis_distance * apoapsis_distance))
    eccentricity = focal_distance / semi_major
    semi_latus_rectum = semi_minor * semi_minor / semi_major
    center = focal_point - focal_distance * axis_u
    second_focus = focal_point - 2.0 * focal_distance * axis_u
    periapsis = focal_point + periapsis_distance * axis_u
    apoapsis = focal_point - apoapsis_distance * axis_u
    return OrbitEllipse3D(
        focus=focal_point,
        center=center,
        second_focus=second_focus,
        periapsis=periapsis,
        apoapsis=apoapsis,
        periapsis_direction=axis_u,
        transverse_direction=axis_v,
        plane_normal=normal,
        periapsis_radius=periapsis_distance,
        apoapsis_radius=apoapsis_distance,
        semi_major_axis=semi_major,
        semi_minor_axis=semi_minor,
        focal_distance=focal_distance,
        eccentricity=eccentricity,
        semi_latus_rectum=semi_latus_rectum,
    )


def orbit_ellipse_points_3d(
    frame: OrbitEllipse3D,
    eccentric_anomalies: ArrayLike,
) -> FloatArray:
    """Uzay elipsini verilen eksantrik anomali değerlerinde örnekler."""

    parameters = _finite_array(eccentric_anomalies, name="eccentric_anomalies")
    if parameters.ndim != 1 or parameters.size < 1:
        raise ValueError("eccentric_anomalies, boş olmayan bir boyutlu dizi olmalıdır.")
    cosine = np.cos(parameters)[:, None]
    sine = np.sin(parameters)[:, None]
    return (
        frame.center
        + frame.semi_major_axis * cosine * frame.periapsis_direction
        + frame.semi_minor_axis * sine * frame.transverse_direction
    )
