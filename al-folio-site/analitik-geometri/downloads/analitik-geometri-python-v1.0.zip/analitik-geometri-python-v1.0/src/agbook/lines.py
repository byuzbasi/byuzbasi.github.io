"""Bölüm 5-6 için düzlemsel doğru temsilleri ve Öklid hesapları.

Doğrular kanonik genel katsayılarla temsil edilir. Normal vektör birim
uzunluğa ölçeklenir; ilk sıfır olmayan normal bileşeni pozitif seçilir.
Bu işaret kuralı geometrik yön değil, tekrarlanabilir bir sayısal temsil
sağlar. Ham denklem artıkları katsayı ölçeğine bağlı tutulur; üyelik
kararında tolerans aynı ölçekle dönüştürülür.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array, _point, _same_dimension
from .vectors import unit_vector, vector_norm


def _plane_point(value: ArrayLike, *, name: str) -> FloatArray:
    point = _point(value, name=name)
    if point.shape != (2,):
        raise ValueError(f"{name}, (2,) biçiminde bir düzlem noktası veya vektörü olmalıdır.")
    return point


def _zero_tolerance(value: float) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or tolerance < 0.0:
        raise ValueError("zero_tolerance sonlu ve negatif olmayan bir sayı olmalıdır.")
    return tolerance


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="relative_tolerance")
    if tolerance >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _angular_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="angular_tolerance")
    if tolerance >= 1.0:
        raise ValueError("angular_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _finite_scalar(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number):
        raise ValueError(f"{name} sonlu bir reel sayı olmalıdır.")
    return number


def _line_coefficients(value: ArrayLike) -> FloatArray:
    coefficients = _finite_array(value, name="coefficients")
    if coefficients.shape != (3,):
        raise ValueError("coefficients, (a, b, c) sıralı (3,) biçiminde olmalıdır.")
    return coefficients


def _point_cloud_2d(value: ArrayLike, *, name: str) -> FloatArray:
    points = _finite_array(value, name=name)
    if points.ndim != 2 or points.shape[0] == 0 or points.shape[1] != 2:
        raise ValueError(f"{name}, (n, 2) biçiminde boş olmayan bir nokta dizisi olmalıdır.")
    return points


def canonical_line_coefficients(
    coefficients: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """``a*x + b*y + c = 0`` katsayılarını kanonik olarak ölçekler.

    ``(a, b)`` normalinin normu ``zero_tolerance`` eşiğinden büyük olmalıdır.
    Çıktıda normal birim uzunluktadır ve ilk sıfır olmayan normal bileşeni
    pozitiftir. Ortak sıfır olmayan katsayı katları aynı çıktıyı verir.
    """

    tolerance = _zero_tolerance(zero_tolerance)
    values = _line_coefficients(coefficients)
    normal_norm = vector_norm(values[:2])
    if normal_norm <= tolerance:
        raise ValueError("Genel doğru denkleminde (a, b) sıfır veya eşik altında olamaz.")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        canonical = values / normal_norm
    if not np.all(np.isfinite(canonical)):
        raise OverflowError("Kanonik doğru katsayıları kayan noktalı sayı aralığını aşıyor.")
    if canonical[0] < 0.0 or (canonical[0] == 0.0 and canonical[1] < 0.0):
        canonical = -canonical
    canonical[canonical == 0.0] = 0.0
    return canonical


def line_direction(
    coefficients: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """Genel doğru katsayılarından kanonik birim yön ``(-b, a)`` üretir."""

    canonical = canonical_line_coefficients(
        coefficients,
        zero_tolerance=zero_tolerance,
    )
    return np.array([-canonical[1], canonical[0]], dtype=float)


def line_from_point_direction(
    point: ArrayLike,
    direction: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """Bir nokta ve sıfır olmayan yönden kanonik genel doğruyu kurar."""

    anchor = _plane_point(point, name="point")
    vector = _plane_point(direction, name="direction")
    direction_unit = unit_vector(vector, zero_tolerance=_zero_tolerance(zero_tolerance))
    normal = np.array([-direction_unit[1], direction_unit[0]], dtype=float)
    with np.errstate(over="ignore", invalid="ignore"):
        offset = -float(np.dot(normal, anchor))
    if not np.isfinite(offset):
        raise OverflowError("Doğrunun sabit katsayısı kayan noktalı sayı aralığını aşıyor.")
    return canonical_line_coefficients(
        [normal[0], normal[1], offset],
        zero_tolerance=zero_tolerance,
    )


def line_from_points(
    first: ArrayLike,
    second: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """İki farklı düzlem noktasından geçen kanonik genel doğruyu kurar."""

    point_first, point_second = _same_dimension(first, second)
    if point_first.shape != (2,):
        raise ValueError("first ve second, (2,) biçiminde düzlem noktaları olmalıdır.")
    with np.errstate(over="ignore", invalid="ignore"):
        direction = point_second - point_first
    if not np.all(np.isfinite(direction)):
        raise OverflowError("İki nokta arasındaki yön kayan noktalı sayı aralığını aşıyor.")
    return line_from_point_direction(
        point_first,
        direction,
        zero_tolerance=zero_tolerance,
    )


def parametric_line_points(
    point: ArrayLike,
    direction: ArrayLike,
    parameters: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """``point + t*direction`` noktalarını ``(n, 2)`` dizisi olarak üretir."""

    anchor = _plane_point(point, name="point")
    vector = _plane_point(direction, name="direction")
    unit_vector(vector, zero_tolerance=_zero_tolerance(zero_tolerance))
    parameter_array = _finite_array(parameters, name="parameters")
    if parameter_array.ndim != 1 or parameter_array.size == 0:
        raise ValueError("parameters, (n,) biçiminde boş olmayan bir dizi olmalıdır.")
    with np.errstate(over="ignore", invalid="ignore"):
        points = anchor + parameter_array[:, None] * vector
    if not np.all(np.isfinite(points)):
        raise OverflowError("Parametrik doğru noktaları kayan noktalı sayı aralığını aşıyor.")
    return points


def line_residuals(coefficients: ArrayLike, points: ArrayLike) -> FloatArray:
    """Noktalar için ham ``a*x + b*y + c`` denklem artıklarını döndürür.

    Artıklar katsayılarla aynı ortak çarpan altında ölçeklenir ve bu nedenle
    tek başına geometrik uzaklık değildir. ``points`` zorunlu olarak
    ``(n, 2)`` biçimindedir.
    """

    values = _line_coefficients(coefficients)
    point_array = _point_cloud_2d(points, name="points")
    with np.errstate(over="ignore", invalid="ignore"):
        residuals = point_array @ values[:2] + values[2]
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Doğru denklem artığı kayan noktalı sayı aralığını aşıyor.")
    return residuals


@dataclass(frozen=True)
class LineMembershipDiagnostics:
    """Tek noktanın genel doğru denklemine sayısal üyelik tanısı."""

    residual: float
    residual_magnitude: float
    coefficient_norm: float
    threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float
    on_line: bool


def line_membership_diagnostics(
    coefficients: ArrayLike,
    point: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> LineMembershipDiagnostics:
    """Bir noktanın doğru üyeliğini katsayı ölçeğiyle uyumlu sınar.

    Geometrik koordinat ölçeğindeki eşik ``atol + rtol*scale`` biçimindedir.
    Genel denklem bu eşiği ``||(a,b)||`` ile çarpar; böylece denklemin ortak
    sıfır olmayan bir sayıyla ölçeklenmesi kararı değiştirmez.
    """

    values = _line_coefficients(coefficients)
    candidate = _plane_point(point, name="point")
    coefficient_norm = vector_norm(values[:2])
    if coefficient_norm == 0.0:
        raise ValueError("Genel doğru denkleminde (a, b) sıfır olamaz.")
    absolute = _nonnegative_finite(absolute_tolerance, name="absolute_tolerance")
    relative = _relative_tolerance(relative_tolerance)
    scale = _nonnegative_finite(reference_scale, name="reference_scale")
    with np.errstate(over="ignore", invalid="ignore"):
        residual = float(np.dot(values[:2], candidate) + values[2])
        coordinate_threshold = absolute + relative * scale
        threshold = coefficient_norm * coordinate_threshold
    if not np.isfinite(residual):
        raise OverflowError("Doğru denklem artığı kayan noktalı sayı aralığını aşıyor.")
    if not np.isfinite(threshold):
        raise OverflowError("Doğru üyelik eşiği kayan noktalı sayı aralığını aşıyor.")
    magnitude = abs(residual)
    return LineMembershipDiagnostics(
        residual=residual,
        residual_magnitude=magnitude,
        coefficient_norm=coefficient_norm,
        threshold=float(threshold),
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
        on_line=bool(magnitude <= threshold),
    )


def _aligned_canonical_lines(
    first: ArrayLike,
    second: ArrayLike,
) -> tuple[FloatArray, FloatArray]:
    """İki doğruyu birim ve mümkün olduğunda aynı yönlü normallere getirir."""

    first_canonical = canonical_line_coefficients(first)
    second_canonical = canonical_line_coefficients(second)
    if float(np.dot(first_canonical[:2], second_canonical[:2])) < 0.0:
        second_canonical = -second_canonical
    return first_canonical, second_canonical


@dataclass(frozen=True)
class LineIntersectionDiagnostics:
    """İki doğrunun açık toleranslı kesişim ve koşul tanısı.

    ``relation`` alanı ``intersecting``, ``parallel`` veya ``coincident``
    değerlerinden biridir. Bu sınıf matematiksel özdeşlik iddiası değil,
    verilen toleranslar altındaki sayısal kararı kaydeder.
    """

    relation: str
    point: FloatArray | None
    normalized_determinant: float
    normalized_determinant_magnitude: float
    angular_tolerance: float
    aligned_offset_difference: float
    distance_threshold: float
    condition_number: float
    residuals: FloatArray | None


def line_intersection_diagnostics(
    first: ArrayLike,
    second: ArrayLike,
    *,
    angular_tolerance: float,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> LineIntersectionDiagnostics:
    """İki genel doğruyu kesişen, paralel veya çakışık olarak sınıflandırır.

    Normaller önce birim uzunluğa ve ortak işaret sözleşmesine getirilir.
    Birim normallerin determinant büyüklüğü ``angular_tolerance`` eşiğini
    aşarsa tam ranklı 2x2 sistem çözülür. Aksi durumda birim ve aynı yönlü
    denklemlerin sabit terim farkı, uzunluk ölçeğindeki
    ``absolute_tolerance + relative_tolerance*reference_scale`` eşiğiyle
    karşılaştırılır. Dolayısıyla sonuç, kesin teoremden ayrı bir sayısal
    sınıflandırmadır.
    """

    angular = _angular_tolerance(angular_tolerance)
    absolute = _nonnegative_finite(absolute_tolerance, name="absolute_tolerance")
    relative = _relative_tolerance(relative_tolerance)
    scale = _nonnegative_finite(reference_scale, name="reference_scale")
    first_canonical, second_canonical = _aligned_canonical_lines(first, second)
    normal_matrix = np.vstack([first_canonical[:2], second_canonical[:2]])
    determinant = float(
        normal_matrix[0, 0] * normal_matrix[1, 1]
        - normal_matrix[0, 1] * normal_matrix[1, 0]
    )
    determinant_magnitude = abs(determinant)
    offset_difference = abs(float(first_canonical[2] - second_canonical[2]))
    with np.errstate(over="ignore", invalid="ignore"):
        distance_threshold = absolute + relative * scale
    if not np.isfinite(distance_threshold):
        raise OverflowError("Doğru ilişkisi uzaklık eşiği kayan noktalı sayı aralığını aşıyor.")
    condition_number = float(np.linalg.cond(normal_matrix))

    if determinant_magnitude <= angular:
        relation = "coincident" if offset_difference <= distance_threshold else "parallel"
        return LineIntersectionDiagnostics(
            relation=relation,
            point=None,
            normalized_determinant=determinant,
            normalized_determinant_magnitude=determinant_magnitude,
            angular_tolerance=angular,
            aligned_offset_difference=offset_difference,
            distance_threshold=float(distance_threshold),
            condition_number=condition_number,
            residuals=None,
        )

    right_hand_side = -np.array([first_canonical[2], second_canonical[2]], dtype=float)
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        point = np.linalg.solve(normal_matrix, right_hand_side)
    if not np.all(np.isfinite(point)):
        raise OverflowError("Doğru kesişimi kayan noktalı sayı aralığını aşıyor.")
    residuals = np.array(
        [
            float(np.dot(first_canonical[:2], point) + first_canonical[2]),
            float(np.dot(second_canonical[:2], point) + second_canonical[2]),
        ],
        dtype=float,
    )
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Kesişim artıkları kayan noktalı sayı aralığını aşıyor.")
    return LineIntersectionDiagnostics(
        relation="intersecting",
        point=point,
        normalized_determinant=determinant,
        normalized_determinant_magnitude=determinant_magnitude,
        angular_tolerance=angular,
        aligned_offset_difference=offset_difference,
        distance_threshold=float(distance_threshold),
        condition_number=condition_number,
        residuals=residuals,
    )


def line_angle(first: ArrayLike, second: ArrayLike) -> float:
    """İki geometrik doğru arasındaki küçük açıyı radyan olarak döndürür.

    Sonuç ``[0, pi/2]`` aralığındadır ve doğru denklemlerinin ortak sıfır
    olmayan katsayılarla ölçeklenmesinden veya işaretinden bağımsızdır.
    """

    first_canonical = canonical_line_coefficients(first)
    second_canonical = canonical_line_coefficients(second)
    dot_magnitude = abs(float(np.dot(first_canonical[:2], second_canonical[:2])))
    determinant_magnitude = abs(
        float(
            first_canonical[0] * second_canonical[1]
            - first_canonical[1] * second_canonical[0]
        )
    )
    return float(np.arctan2(determinant_magnitude, dot_magnitude))


def signed_point_line_distance(coefficients: ArrayLike, point: ArrayLike) -> float:
    """Kanonik birim normal yönündeki işaretli nokta-doğru uzaklığı."""

    canonical = canonical_line_coefficients(coefficients)
    candidate = _plane_point(point, name="point")
    with np.errstate(over="ignore", invalid="ignore"):
        distance = float(np.dot(canonical[:2], candidate) + canonical[2])
    if not np.isfinite(distance):
        raise OverflowError("İşaretli nokta-doğru uzaklığı sayı aralığını aşıyor.")
    return distance


def point_line_distance(coefficients: ArrayLike, point: ArrayLike) -> float:
    """Bir düzlem noktasının sonsuz doğruya Öklid uzaklığını döndürür."""

    return abs(signed_point_line_distance(coefficients, point))


@dataclass(frozen=True)
class PointLineProjection:
    """Bir noktanın sonsuz doğru üzerindeki ortogonal izdüşüm tanısı."""

    foot: FloatArray
    signed_distance: float
    distance: float
    foot_residual: float
    orthogonality_residual: float


def project_point_to_line(
    coefficients: ArrayLike,
    point: ArrayLike,
) -> PointLineProjection:
    """Noktanın doğru üzerindeki tek dikme ayağını ve denetim artıklarını verir."""

    canonical = canonical_line_coefficients(coefficients)
    candidate = _plane_point(point, name="point")
    with np.errstate(over="ignore", invalid="ignore"):
        signed_distance = float(np.dot(canonical[:2], candidate) + canonical[2])
        foot = candidate - signed_distance * canonical[:2]
    if not np.isfinite(signed_distance) or not np.all(np.isfinite(foot)):
        raise OverflowError("Dikme ayağı hesabı kayan noktalı sayı aralığını aşıyor.")
    direction = np.array([-canonical[1], canonical[0]], dtype=float)
    foot_residual = float(np.dot(canonical[:2], foot) + canonical[2])
    orthogonality_residual = float(np.dot(candidate - foot, direction))
    return PointLineProjection(
        foot=foot,
        signed_distance=signed_distance,
        distance=abs(signed_distance),
        foot_residual=foot_residual,
        orthogonality_residual=orthogonality_residual,
    )


def parallel_line_through_point(
    coefficients: ArrayLike,
    point: ArrayLike,
) -> FloatArray:
    """Verilen noktadan geçen ve verilen doğruya paralel kanonik doğruyu kurar."""

    canonical = canonical_line_coefficients(coefficients)
    anchor = _plane_point(point, name="point")
    with np.errstate(over="ignore", invalid="ignore"):
        offset = -float(np.dot(canonical[:2], anchor))
    if not np.isfinite(offset):
        raise OverflowError("Paralel doğrunun sabit terimi sayı aralığını aşıyor.")
    return canonical_line_coefficients([canonical[0], canonical[1], offset])


def perpendicular_line_through_point(
    coefficients: ArrayLike,
    point: ArrayLike,
) -> FloatArray:
    """Verilen noktadan geçen ve verilen doğruya dik kanonik doğruyu kurar."""

    canonical = canonical_line_coefficients(coefficients)
    return line_from_point_direction(point, canonical[:2])


def parallel_line_at_offset(
    coefficients: ArrayLike,
    signed_offset: float,
) -> FloatArray:
    """Doğruyu kanonik normal yönünde işaretli uzaklık kadar öteler.

    Pozitif ``signed_offset``, nokta kümesini kanonik birim normal yönünde
    taşır. Bu işaret bir fiziksel yönelim değil, deterministik katsayı
    sözleşmesidir.
    """

    canonical = canonical_line_coefficients(coefficients)
    offset = _finite_scalar(signed_offset, name="signed_offset")
    with np.errstate(over="ignore", invalid="ignore"):
        shifted = canonical.copy()
        shifted[2] -= offset
    if not np.all(np.isfinite(shifted)):
        raise OverflowError("Paralel doğru ötelemesi kayan noktalı sayı aralığını aşıyor.")
    return canonical_line_coefficients(shifted)


def line_pencil_member(
    first: ArrayLike,
    second: ArrayLike,
    first_weight: float,
    second_weight: float,
    *,
    angular_tolerance: float,
) -> FloatArray:
    """Kesişen iki kanonik doğrunun homojen demetinden bir üye üretir.

    Giriş doğruları önce kanonikleştirilir. Ağırlıkların ortak sıfır olmayan
    katı aynı üyeyi verir. Temel doğrular verilen ``angular_tolerance``
    altında paralelse ortak noktalı doğru demeti tanımlanmaz.
    """

    angular = _angular_tolerance(angular_tolerance)
    first_canonical = canonical_line_coefficients(first)
    second_canonical = canonical_line_coefficients(second)
    normalized_determinant = abs(
        float(
            first_canonical[0] * second_canonical[1]
            - first_canonical[1] * second_canonical[0]
        )
    )
    if normalized_determinant <= angular:
        raise ValueError("Doğru demeti için temel doğrular tolerans altında paralel olamaz.")
    weights = _finite_array([first_weight, second_weight], name="weights")
    weight_scale = float(np.max(np.abs(weights)))
    if weight_scale == 0.0:
        raise ValueError("Doğru demeti ağırlıklarının ikisi birden sıfır olamaz.")
    normalized_weights = weights / weight_scale
    with np.errstate(over="ignore", invalid="ignore"):
        combined = (
            normalized_weights[0] * first_canonical
            + normalized_weights[1] * second_canonical
        )
    if not np.all(np.isfinite(combined)):
        raise OverflowError("Doğru demeti birleşimi kayan noktalı sayı aralığını aşıyor.")
    return canonical_line_coefficients(combined)
