"""Bölüm 7 için düzlemsel rijit hareket ve çerçeve hesapları.

Matematiksel metinde noktalar sütun vektördür. Python API'sinde tek nokta
``(2,)``, çoklu noktalar ise satırları nokta olan ``(n, 2)`` dizileridir.
İşlevler sonlu reel girdileri ve ortogonal çerçeveleri açıkça doğrular;
genel afin dönüşüm veya sessiz yayınlama uygulamaz.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from .foundations import (
    FloatArray,
    _finite_array,
    _point,
    _rigid_inputs,
    rigid_transform,
    rotation_matrix_2d,
)
from .lines import canonical_line_coefficients


def _plane_point(value: ArrayLike, *, name: str) -> FloatArray:
    point = _point(value, name=name)
    if point.shape != (2,):
        raise ValueError(f"{name}, (2,) biçiminde bir düzlem noktası veya vektörü olmalıdır.")
    return point


def _plane_points(value: ArrayLike, *, name: str) -> FloatArray:
    points = _finite_array(value, name=name)
    if points.ndim == 1:
        if points.shape != (2,):
            raise ValueError(f"{name}, (2,) biçiminde tek nokta olmalıdır.")
    elif points.ndim == 2:
        if points.shape[0] == 0 or points.shape[1] != 2:
            raise ValueError(f"{name}, (n, 2) biçiminde boş olmayan bir nokta dizisi olmalıdır.")
    else:
        raise ValueError(f"{name}, (2,) veya (n, 2) biçiminde olmalıdır.")
    return points


def _nonnegative_tolerance(value: float, *, name: str) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or tolerance < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return tolerance


@dataclass(frozen=True)
class RigidMotion2D:
    """``F(x)=Qx+t`` hareketinin doğrusal ve öteleme bileşenleri."""

    matrix: FloatArray
    translation: FloatArray

    @property
    def determinant(self) -> float:
        """Ortogonal doğrusal kısmın yönelim işaretini döndürür."""

        return float(np.linalg.det(self.matrix))


def reflection_matrix_2d(
    axis_direction: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """Orijinden geçen eksene göre yansıma matrisi ``2*u*u.T-I``.

    ``axis_direction`` sıfır olmayan bir eksen yönüdür; büyüklüğü sonucu
    değiştirmez. ``zero_tolerance`` yön normu için açık sayısal eşiktir.
    """

    direction = _plane_point(axis_direction, name="axis_direction")
    tolerance = _nonnegative_tolerance(zero_tolerance, name="zero_tolerance")
    norm = float(np.linalg.norm(direction))
    if norm <= tolerance:
        raise ValueError("Yansıma ekseni yönünün normu eşikten büyük olmalıdır.")
    unit = direction / norm
    matrix = 2.0 * np.outer(unit, unit) - np.eye(2)
    matrix[matrix == 0.0] = 0.0
    return matrix


def rotate_about_point(
    points: ArrayLike,
    theta: float,
    center: ArrayLike,
    *,
    atol: float = 1e-12,
) -> FloatArray:
    """Noktaları ``center`` çevresinde ``theta`` radyan döndürür."""

    point_array = _plane_points(points, name="points")
    pivot = _plane_point(center, name="center")
    matrix = rotation_matrix_2d(theta)
    translation = pivot - matrix @ pivot
    return rigid_transform(point_array, matrix, translation, atol=atol)


def line_reflection_motion(
    coefficients: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> RigidMotion2D:
    """``a*x+b*y+c=0`` doğrusuna yansımanın ``Q`` ve ``t`` verisini kurar."""

    canonical = canonical_line_coefficients(
        coefficients,
        zero_tolerance=zero_tolerance,
    )
    normal = canonical[:2]
    offset = canonical[2]
    matrix = np.eye(2) - 2.0 * np.outer(normal, normal)
    translation = -2.0 * offset * normal
    matrix[matrix == 0.0] = 0.0
    translation[translation == 0.0] = 0.0
    return RigidMotion2D(matrix=matrix, translation=translation)


def reflect_across_line(
    points: ArrayLike,
    coefficients: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
    atol: float = 1e-12,
) -> FloatArray:
    """Noktaları verilen sonsuz doğruya göre yansıtır."""

    point_array = _plane_points(points, name="points")
    motion = line_reflection_motion(
        coefficients,
        zero_tolerance=zero_tolerance,
    )
    return rigid_transform(
        point_array,
        motion.matrix,
        motion.translation,
        atol=atol,
    )


def compose_rigid_motions(
    q_after: ArrayLike,
    t_after: ArrayLike,
    q_before: ArrayLike,
    t_before: ArrayLike,
    *,
    atol: float = 1e-12,
) -> RigidMotion2D:
    """Önce ``before``, sonra ``after`` hareketinin bileşimini döndürür.

    Sonuç ``Q=Q_after@Q_before`` ve
    ``t=Q_after@t_before+t_after`` parametrelerini taşır.
    """

    after_matrix, after_translation = _rigid_inputs(q_after, t_after, atol=atol)
    before_matrix, before_translation = _rigid_inputs(q_before, t_before, atol=atol)
    matrix = after_matrix @ before_matrix
    translation = after_matrix @ before_translation + after_translation
    _rigid_inputs(matrix, translation, atol=atol)
    return RigidMotion2D(matrix=matrix, translation=translation)


def inverse_rigid_motion(
    q: ArrayLike,
    t: ArrayLike,
    *,
    atol: float = 1e-12,
) -> RigidMotion2D:
    """``F(x)=Qx+t`` hareketinin ``Q.T`` ve ``-Q.T@t`` tersini kurar."""

    matrix, translation = _rigid_inputs(q, t, atol=atol)
    inverse_matrix = matrix.T
    inverse_translation = -(inverse_matrix @ translation)
    return RigidMotion2D(
        matrix=inverse_matrix,
        translation=inverse_translation,
    )


def coordinates_from_frame(
    local_points: ArrayLike,
    origin: ArrayLike,
    axes: ArrayLike,
    *,
    atol: float = 1e-12,
) -> FloatArray:
    """Ortonormal yerel çerçeve koordinatlarını dünya koordinatlarına taşır.

    ``axes`` sütunları dünya koordinatlarında yerel birim eksenlerdir.
    Matematiksel eşitlik ``x_world=origin+axes@x_local`` biçimindedir.
    """

    points = _plane_points(local_points, name="local_points")
    frame_origin = _plane_point(origin, name="origin")
    matrix, translation = _rigid_inputs(axes, frame_origin, atol=atol)
    return rigid_transform(points, matrix, translation, atol=atol)


def coordinates_in_frame(
    world_points: ArrayLike,
    origin: ArrayLike,
    axes: ArrayLike,
    *,
    atol: float = 1e-12,
) -> FloatArray:
    """Dünya noktalarını verilen ortonormal çerçevede koordinatlandırır."""

    points = _plane_points(world_points, name="world_points")
    frame_origin = _plane_point(origin, name="origin")
    matrix, translation = _rigid_inputs(axes, frame_origin, atol=atol)
    inverse = inverse_rigid_motion(matrix, translation, atol=atol)
    return rigid_transform(
        points,
        inverse.matrix,
        inverse.translation,
        atol=atol,
    )
