"""Konik geometrisi, odak--doğrultman ve yansıma denetimleri.

Bu modül, düzlemsel bir koniği odak ``focus``, doğrultman
``a*x+b*y+c=0`` ve pozitif dışmerkezlik ``eccentricity`` ile denetler.
Ayrıca yalnız standart çift koni ``x^2+y^2=z^2`` ile
``z=h+u*x+v*y`` düzleminin kesit türünü sınıflandırır. Bölüm 12 için normal
parabol, Bölüm 13 için normal ve çember olmayan elips, Bölüm 14 için normal
hiperbol yardımcılarını sağlar. Bölüm 15 için ortak bir odak--doğrultman
çerçevesinde kutupsal ve rasyonel parametrizasyon yardımcıları ekler. Bu özel
tanılar genel ikinci derece denklem sınıflandırmasının yerine geçmez.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array, _point
from .lines import canonical_line_coefficients


ConicType = Literal["ellipse", "parabola", "hyperbola"]
ConeSectionType = Literal[
    "circle",
    "ellipse",
    "parabola",
    "hyperbola",
    "point",
    "repeated_line",
    "intersecting_lines",
]


def _plane_point(value: ArrayLike, *, name: str) -> FloatArray:
    point = _point(value, name=name)
    if point.shape != (2,):
        raise ValueError(f"{name}, (2,) biçiminde bir düzlem noktası olmalıdır.")
    return point


def _point_rows(
    value: ArrayLike,
    *,
    name: str,
) -> tuple[FloatArray, bool]:
    points = _finite_array(value, name=name)
    if points.ndim == 1:
        if points.shape != (2,):
            raise ValueError(f"{name}, (2,) biçiminde tek bir nokta olmalıdır.")
        return points.reshape(1, 2), True
    if points.ndim == 2:
        if points.shape[0] == 0 or points.shape[1] != 2:
            raise ValueError(
                f"{name}, (n, 2) biçiminde boş olmayan bir nokta dizisi olmalıdır."
            )
        return points, False
    raise ValueError(f"{name}, (2,) veya (n, 2) biçiminde olmalıdır.")


def _finite_scalar(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number):
        raise ValueError(f"{name} sonlu bir reel sayı olmalıdır.")
    return number


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = _finite_scalar(value, name=name)
    if number < 0.0:
        raise ValueError(f"{name} negatif olamaz.")
    return number


def _positive_finite(value: float, *, name: str) -> float:
    number = _finite_scalar(value, name=name)
    if number <= 0.0:
        raise ValueError(f"{name} kesin pozitif olmalıdır.")
    return number


def _eccentricity(value: float) -> float:
    return _positive_finite(value, name="eccentricity")


def _focus_directrix_distances(
    points: ArrayLike,
    focus: ArrayLike,
    directrix: ArrayLike,
) -> tuple[FloatArray, FloatArray, bool]:
    rows, single = _point_rows(points, name="points")
    focal_point = _plane_point(focus, name="focus")
    line = canonical_line_coefficients(directrix)
    with np.errstate(over="ignore", invalid="ignore"):
        focus_distances = np.linalg.norm(rows - focal_point, axis=1)
        directrix_distances = np.abs(rows @ line[:2] + line[2])
    if not np.all(np.isfinite(focus_distances)) or not np.all(
        np.isfinite(directrix_distances)
    ):
        raise OverflowError("Odak--doğrultman uzaklığı sayı aralığını aşıyor.")
    return focus_distances, directrix_distances, single


def classify_eccentricity(
    eccentricity: float,
    *,
    atol: float = 0.0,
) -> ConicType:
    """Pozitif dışmerkezliği elips, parabol veya hiperbol diye sınıflandırır.

    Varsayılan ``atol=0`` kesin matematiksel eşiği kullanır. Pozitif bir
    ``atol`` verilirse ``abs(e-1)<=atol`` sayısal olarak parabol sınırı kabul
    edilir; bu bant fiziksel veya istatistiksel belirsizlik değildir.
    """

    value = _eccentricity(eccentricity)
    tolerance = _nonnegative_finite(atol, name="atol")
    if tolerance >= 1.0:
        raise ValueError("atol, [0, 1) aralığında olmalıdır.")
    if abs(value - 1.0) <= tolerance:
        return "parabola"
    if value < 1.0:
        return "ellipse"
    return "hyperbola"


def focus_directrix_residuals(
    points: ArrayLike,
    focus: ArrayLike,
    directrix: ArrayLike,
    eccentricity: float,
) -> float | FloatArray:
    """``||p-focus|| - e*distance(p, directrix)`` artıklarını hesaplar.

    Artık koordinatlarla aynı uzunluk birimindedir. Doğrultman üzerindeki
    noktalar kabul edilir; işlev oran almadığı için sıfıra bölme yapmaz.
    """

    value = _eccentricity(eccentricity)
    focus_distances, directrix_distances, single = _focus_directrix_distances(
        points,
        focus,
        directrix,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        residuals = focus_distances - value * directrix_distances
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Odak--doğrultman artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


def focus_directrix_ratios(
    points: ArrayLike,
    focus: ArrayLike,
    directrix: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> float | FloatArray:
    """Odak uzaklığının doğrultman uzaklığına oranını hesaplar.

    ``zero_tolerance`` koordinatlarla aynı uzunluk birimindedir. Doğrultman
    uzaklığı bu eşik veya altında olan noktalar oranı tanımsız kıldığı için
    açık hatayla reddedilir.
    """

    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    focus_distances, directrix_distances, single = _focus_directrix_distances(
        points,
        focus,
        directrix,
    )
    if np.any(directrix_distances <= tolerance):
        raise ValueError("Doğrultman üzerindeki veya eşiğe yakın noktada oran tanımsızdır.")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        ratios = focus_distances / directrix_distances
    if not np.all(np.isfinite(ratios)):
        raise OverflowError("Odak--doğrultman oranı sayı aralığını aşıyor.")
    if single:
        return float(ratios[0])
    return ratios


@dataclass(frozen=True)
class FocusDirectrixDiagnostics:
    """Bir nokta dizisinin odak--doğrultman geometrik yer tanısı."""

    conic_type: ConicType
    eccentricity: float
    focus_distances: FloatArray
    directrix_distances: FloatArray
    ratios: FloatArray
    residuals: FloatArray
    scaled_residuals: FloatArray
    maximum_absolute_residual: float
    maximum_scaled_residual: float


def focus_directrix_diagnostics(
    points: ArrayLike,
    focus: ArrayLike,
    directrix: ArrayLike,
    eccentricity: float,
    *,
    reference_scale: float,
    classification_tolerance: float = 0.0,
    directrix_zero_tolerance: float = 0.0,
) -> FocusDirectrixDiagnostics:
    """Uzaklıkları, oranları, mutlak ve ölçeksiz artıkları birlikte verir.

    ``reference_scale`` koordinatlarla aynı uzunluk biriminde kesin pozitif
    bir tabandır. Ölçeksiz artık paydası
    ``max(d_F, e*d_L, reference_scale)`` olarak kurulur.
    """

    value = _eccentricity(eccentricity)
    scale = _positive_finite(reference_scale, name="reference_scale")
    zero_tolerance = _nonnegative_finite(
        directrix_zero_tolerance,
        name="directrix_zero_tolerance",
    )
    focus_distances, directrix_distances, _ = _focus_directrix_distances(
        points,
        focus,
        directrix,
    )
    if np.any(directrix_distances <= zero_tolerance):
        raise ValueError("Doğrultman üzerindeki veya eşiğe yakın noktada oran tanımsızdır.")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        weighted_directrix = value * directrix_distances
        residuals = focus_distances - weighted_directrix
        denominators = np.maximum(
            np.maximum(focus_distances, weighted_directrix),
            scale,
        )
        scaled_residuals = residuals / denominators
        ratios = focus_distances / directrix_distances
    arrays = (weighted_directrix, residuals, denominators, scaled_residuals, ratios)
    if not all(np.all(np.isfinite(array)) for array in arrays):
        raise OverflowError("Odak--doğrultman tanısı sayı aralığını aşıyor.")
    return FocusDirectrixDiagnostics(
        conic_type=classify_eccentricity(
            value,
            atol=classification_tolerance,
        ),
        eccentricity=value,
        focus_distances=focus_distances,
        directrix_distances=directrix_distances,
        ratios=ratios,
        residuals=residuals,
        scaled_residuals=scaled_residuals,
        maximum_absolute_residual=float(np.max(np.abs(residuals), initial=0.0)),
        maximum_scaled_residual=float(
            np.max(np.abs(scaled_residuals), initial=0.0)
        ),
    )


@dataclass(frozen=True)
class StandardConePlaneDiagnostics:
    """Standart çift koninin özel bir düzlemle kesit türü."""

    section_type: ConeSectionType
    degenerate: bool
    slope_norm: float
    quadratic_determinant: float
    offset: float


def classify_standard_cone_plane(
    slopes: ArrayLike,
    offset: float,
    *,
    slope_tolerance: float = 0.0,
    offset_tolerance: float = 0.0,
) -> StandardConePlaneDiagnostics:
    """``x^2+y^2=z^2`` ile ``z=h+u*x+v*y`` kesitini sınıflandırır.

    ``slopes=(u,v)`` boyutsuzdur; ``offset=h`` koordinatların uzunluk
    birimindedir. Toleranslar yalnız sayısal sınır sözleşmesidir. İşlev genel
    bir konik sınıflandırıcısı değildir.
    """

    slope_vector = _plane_point(slopes, name="slopes")
    plane_offset = _finite_scalar(offset, name="offset")
    slope_tol = _nonnegative_finite(slope_tolerance, name="slope_tolerance")
    offset_tol = _nonnegative_finite(offset_tolerance, name="offset_tolerance")
    if slope_tol >= 0.5:
        raise ValueError("slope_tolerance, [0, 0.5) aralığında olmalıdır.")
    slope_norm = float(np.linalg.norm(slope_vector))
    if not np.isfinite(slope_norm):
        raise OverflowError("Düzlem eğim normu sayı aralığını aşıyor.")
    determinant = float(1.0 - slope_norm * slope_norm)
    if not np.isfinite(determinant):
        raise OverflowError("Kesit determinantı sayı aralığını aşıyor.")

    degenerate = abs(plane_offset) <= offset_tol
    near_horizontal = slope_norm <= slope_tol
    near_generator = abs(slope_norm - 1.0) <= slope_tol
    if degenerate:
        if near_generator:
            section_type: ConeSectionType = "repeated_line"
        elif slope_norm < 1.0:
            section_type = "point"
        else:
            section_type = "intersecting_lines"
    elif near_horizontal:
        section_type = "circle"
    elif near_generator:
        section_type = "parabola"
    elif slope_norm < 1.0:
        section_type = "ellipse"
    else:
        section_type = "hyperbola"

    return StandardConePlaneDiagnostics(
        section_type=section_type,
        degenerate=degenerate,
        slope_norm=slope_norm,
        quadratic_determinant=determinant,
        offset=plane_offset,
    )


def _unit_plane_direction(value: ArrayLike, *, name: str) -> FloatArray:
    direction = _plane_point(value, name=name)
    norm = float(np.linalg.norm(direction))
    if not np.isfinite(norm):
        raise OverflowError(f"{name} normu sayı aralığını aşıyor.")
    if norm == 0.0:
        raise ValueError(f"{name} sıfır vektörü olamaz.")
    return direction / norm


def _parameter_values(
    value: ArrayLike,
    *,
    name: str = "parameters",
) -> tuple[FloatArray, bool]:
    parameters = _finite_array(value, name=name)
    if parameters.ndim == 0:
        return parameters.reshape(1), True
    if parameters.ndim == 1 and parameters.size > 0:
        return parameters, False
    raise ValueError(f"{name}, bir skaler veya boş olmayan (n,) dizisi olmalıdır.")


PolarConicBranch = Literal["focus_side", "far_side"]


def _polar_conic_branch(value: str) -> PolarConicBranch:
    if value == "focus_side":
        return "focus_side"
    if value == "far_side":
        return "far_side"
    raise ValueError("branch, 'focus_side' veya 'far_side' olmalıdır.")


@dataclass(frozen=True)
class PolarConicFrame:
    """Odak merkezli kutupsal bir koniğin yönlendirilmiş çerçevesi.

    ``axis_direction`` kutupsal eksenin birim yönü, ``transverse_direction``
    onun saat yönü tersindeki birim dikidir. Doğrultman
    ``u·(X-F)=ell/e`` doğrusu, ``semilatus_rectum=ell`` ise kesin pozitif
    uzunluktur. ``rational_limit_point``, sonlu ``t`` değerlerinin atladığı
    elips noktası veya hiperbolün ikinci tepesidir; parabol için ``None``'dır.
    """

    focus: FloatArray
    axis_direction: FloatArray
    transverse_direction: FloatArray
    eccentricity: float
    semilatus_rectum: float
    directrix: FloatArray
    conic_type: ConicType
    rational_limit_point: FloatArray | None
    rational_singular_parameters: FloatArray


def polar_conic_frame(
    focus: ArrayLike,
    axis_direction: ArrayLike,
    eccentricity: float,
    semilatus_rectum: float,
) -> PolarConicFrame:
    """Odak, kutupsal eksen, dışmerkezlik ve yarı odak kirişiyle çerçeve kurar.

    Doğrultmanın odağa uzaklığı ``ell/e``'dir. Rasyonel parametrenin paydası
    hiperbol durumunda iki gerçek kökte sıfır olur; bu kökler asimptotik
    doğrultuları temsil eder ve ``rational_singular_parameters`` alanında
    küçükten büyüğe verilir.
    """

    focal_point = _plane_point(focus, name="focus")
    axis = _unit_plane_direction(axis_direction, name="axis_direction")
    transverse = np.array([-axis[1], axis[0]], dtype=float)
    value = _eccentricity(eccentricity)
    semilatus = _positive_finite(
        semilatus_rectum,
        name="semilatus_rectum",
    )
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        directrix_offset = -(float(axis @ focal_point) + semilatus / value)
    if not np.isfinite(directrix_offset):
        raise OverflowError("Kutupsal konik doğrultmanı sayı aralığını aşıyor.")
    directrix = canonical_line_coefficients(
        [axis[0], axis[1], directrix_offset]
    )

    conic_type = classify_eccentricity(value)
    if value == 1.0:
        limit_point = None
        singular_parameters = np.empty(0, dtype=float)
    else:
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            candidate = focal_point - semilatus / (1.0 - value) * axis
        if not np.all(np.isfinite(candidate)):
            raise OverflowError("Rasyonel sınır noktası sayı aralığını aşıyor.")
        limit_point = candidate
        if value > 1.0:
            singular = float(np.sqrt((1.0 + value) / (value - 1.0)))
            singular_parameters = np.array([-singular, singular], dtype=float)
        else:
            singular_parameters = np.empty(0, dtype=float)

    return PolarConicFrame(
        focus=focal_point,
        axis_direction=axis,
        transverse_direction=transverse,
        eccentricity=value,
        semilatus_rectum=semilatus,
        directrix=directrix,
        conic_type=conic_type,
        rational_limit_point=limit_point,
        rational_singular_parameters=singular_parameters,
    )


def _polar_conic_denominators(
    angles: FloatArray,
    eccentricity: float,
    branch: PolarConicBranch,
) -> FloatArray:
    with np.errstate(over="ignore", invalid="ignore"):
        cosines = np.cos(angles)
        if branch == "focus_side":
            denominators = 1.0 + eccentricity * cosines
        else:
            denominators = eccentricity * cosines - 1.0
    if not np.all(np.isfinite(denominators)):
        raise OverflowError("Kutupsal konik paydası sayı aralığını aşıyor.")
    return denominators


def polar_conic_radii(
    eccentricity: float,
    semilatus_rectum: float,
    angles: ArrayLike,
    *,
    branch: str = "focus_side",
    denominator_tolerance: float = 0.0,
) -> float | FloatArray:
    """Geçerli ışınlarda ``rho=ell/(1+e*cos(theta))`` yarıçapını verir.

    ``focus_side`` odak tarafındaki standart, negatif olmayan yarıçap koludur.
    ``far_side`` yalnız hiperbol için doğrultmanın öte yanındaki ikinci kolu
    ``rho=ell/(e*cos(theta)-1)`` biçiminde üretir. İlgili payda mutlak toleransın
    üstünde değilse ışın üzerinde sonlu bir nokta yoktur ve işlev hata verir.
    """

    value = _eccentricity(eccentricity)
    semilatus = _positive_finite(
        semilatus_rectum,
        name="semilatus_rectum",
    )
    selected_branch = _polar_conic_branch(branch)
    if selected_branch == "far_side" and value <= 1.0:
        raise ValueError("far_side kolu yalnız e>1 olan hiperbol için tanımlıdır.")
    tolerance = _nonnegative_finite(
        denominator_tolerance,
        name="denominator_tolerance",
    )
    values, single = _parameter_values(angles, name="angles")
    denominators = _polar_conic_denominators(
        values,
        value,
        selected_branch,
    )
    if np.any(denominators <= tolerance):
        raise ValueError(
            "Seçilen açı için kutupsal payda pozitif toleransın üstünde olmalıdır."
        )
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        radii = semilatus / denominators
    if not np.all(np.isfinite(radii)):
        raise OverflowError("Kutupsal konik yarıçapı sayı aralığını aşıyor.")
    if single:
        return float(radii[0])
    return radii


def polar_conic_points(
    focus: ArrayLike,
    axis_direction: ArrayLike,
    eccentricity: float,
    semilatus_rectum: float,
    angles: ArrayLike,
    *,
    branch: str = "focus_side",
    denominator_tolerance: float = 0.0,
) -> FloatArray:
    """Odak merkezli kutupsal konik noktalarını dünya koordinatlarında verir."""

    frame = polar_conic_frame(
        focus,
        axis_direction,
        eccentricity,
        semilatus_rectum,
    )
    selected_branch = _polar_conic_branch(branch)
    values, single = _parameter_values(angles, name="angles")
    radii = np.asarray(
        polar_conic_radii(
            frame.eccentricity,
            frame.semilatus_rectum,
            values,
            branch=selected_branch,
            denominator_tolerance=denominator_tolerance,
        ),
        dtype=float,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        directions = (
            np.cos(values)[:, None] * frame.axis_direction
            + np.sin(values)[:, None] * frame.transverse_direction
        )
        points = frame.focus + radii[:, None] * directions
    if not np.all(np.isfinite(points)):
        raise OverflowError("Kutupsal konik noktaları sayı aralığını aşıyor.")
    if single:
        return points[0]
    return points


def rational_conic_points(
    focus: ArrayLike,
    axis_direction: ArrayLike,
    eccentricity: float,
    semilatus_rectum: float,
    parameters: ArrayLike,
    *,
    denominator_tolerance: float = 0.0,
) -> FloatArray:
    """``t=tan(theta/2)`` ile koniğin rasyonel parametrizasyonunu verir.

    Payda ``(1+e)+(1-e)t^2`` biçimindedir. Sonlu ``t`` elipste bir noktayı
    atlar, parabolde tüm sonlu noktaları verir ve hiperbolde iki gerçek tekil
    parametreyle ayrılan üç aralık üzerinden iki kolu tarar.
    """

    frame = polar_conic_frame(
        focus,
        axis_direction,
        eccentricity,
        semilatus_rectum,
    )
    tolerance = _nonnegative_finite(
        denominator_tolerance,
        name="denominator_tolerance",
    )
    values, single = _parameter_values(parameters)
    with np.errstate(over="ignore", invalid="ignore"):
        squared = values * values
        denominators = (
            1.0 + frame.eccentricity
            + (1.0 - frame.eccentricity) * squared
        )
    if not np.all(np.isfinite(denominators)):
        raise OverflowError("Rasyonel konik paydası sayı aralığını aşıyor.")
    if np.any(np.abs(denominators) <= tolerance):
        raise ValueError("Rasyonel konik paydası sıfır toleransından uzak olmalıdır.")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        local_axis = frame.semilatus_rectum * (1.0 - squared) / denominators
        local_transverse = (
            2.0 * frame.semilatus_rectum * values / denominators
        )
        points = (
            frame.focus
            + local_axis[:, None] * frame.axis_direction
            + local_transverse[:, None] * frame.transverse_direction
        )
    if not np.all(np.isfinite(points)):
        raise OverflowError("Rasyonel konik noktaları sayı aralığını aşıyor.")
    if single:
        return points[0]
    return points


def polar_conic_algebraic_residuals(
    points: ArrayLike,
    focus: ArrayLike,
    axis_direction: ArrayLike,
    eccentricity: float,
    semilatus_rectum: float,
) -> float | FloatArray:
    """Odak-yerel ikinci derece denklemin boyutsuz artıklarını verir.

    Yerel koordinatlar ``xi=u·(X-F)`` ve ``eta=v·(X-F)`` olmak üzere sınanan
    denklem ``(1-e^2)xi^2+eta^2+2*e*ell*xi-ell^2=0`` biçimindedir. Denklem
    ``ell^2`` ile ölçeklenir; bu nedenle sonuç uzunluk biriminden bağımsızdır.
    """

    frame = polar_conic_frame(
        focus,
        axis_direction,
        eccentricity,
        semilatus_rectum,
    )
    rows, single = _point_rows(points, name="points")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        displacements = rows - frame.focus
        xi = (displacements @ frame.axis_direction) / frame.semilatus_rectum
        eta = (
            displacements @ frame.transverse_direction
        ) / frame.semilatus_rectum
        residuals = (
            (1.0 - frame.eccentricity * frame.eccentricity) * xi * xi
            + eta * eta
            + 2.0 * frame.eccentricity * xi
            - 1.0
        )
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Kutupsal konik cebirsel artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


@dataclass(frozen=True)
class PolarConicDiagnostics:
    """Bir kutupsal konik örneklemesinin geometrik ve sayısal tanıları."""

    angles: FloatArray
    branch: PolarConicBranch
    points: FloatArray
    radii: FloatArray
    denominators: FloatArray
    algebraic_residuals: FloatArray
    focus_directrix_residuals: FloatArray
    maximum_absolute_algebraic_residual: float
    maximum_absolute_focus_directrix_residual: float


def polar_conic_diagnostics(
    focus: ArrayLike,
    axis_direction: ArrayLike,
    eccentricity: float,
    semilatus_rectum: float,
    angles: ArrayLike,
    *,
    branch: str = "focus_side",
    denominator_tolerance: float = 0.0,
) -> PolarConicDiagnostics:
    """Kutupsal örneklemenin payda, denklem ve odak--doğrultman tanısını verir.

    Cebirsel artık boyutsuz, odak--doğrultman artığı ise koordinatlarla aynı
    uzunluk birimindedir. Tolerans yalnız sıfıra yakın paydaları dışlama
    sözleşmesidir; ölçüm belirsizliğini temsil etmez.
    """

    frame = polar_conic_frame(
        focus,
        axis_direction,
        eccentricity,
        semilatus_rectum,
    )
    selected_branch = _polar_conic_branch(branch)
    values, _ = _parameter_values(angles, name="angles")
    radii = np.asarray(
        polar_conic_radii(
            frame.eccentricity,
            frame.semilatus_rectum,
            values,
            branch=selected_branch,
            denominator_tolerance=denominator_tolerance,
        ),
        dtype=float,
    )
    points = np.asarray(
        polar_conic_points(
            frame.focus,
            frame.axis_direction,
            frame.eccentricity,
            frame.semilatus_rectum,
            values,
            branch=selected_branch,
            denominator_tolerance=denominator_tolerance,
        ),
        dtype=float,
    )
    denominators = _polar_conic_denominators(
        values,
        frame.eccentricity,
        selected_branch,
    )
    algebraic_residuals = np.asarray(
        polar_conic_algebraic_residuals(
            points,
            frame.focus,
            frame.axis_direction,
            frame.eccentricity,
            frame.semilatus_rectum,
        ),
        dtype=float,
    )
    geometric_residuals = np.asarray(
        focus_directrix_residuals(
            points,
            frame.focus,
            frame.directrix,
            frame.eccentricity,
        ),
        dtype=float,
    )
    return PolarConicDiagnostics(
        angles=values.copy(),
        branch=selected_branch,
        points=points,
        radii=radii,
        denominators=denominators,
        algebraic_residuals=algebraic_residuals,
        focus_directrix_residuals=geometric_residuals,
        maximum_absolute_algebraic_residual=float(
            np.max(np.abs(algebraic_residuals), initial=0.0)
        ),
        maximum_absolute_focus_directrix_residual=float(
            np.max(np.abs(geometric_residuals), initial=0.0)
        ),
    )


@dataclass(frozen=True)
class ParabolaFrame:
    """Yönlendirilmiş normal bir parabolün Öklid çerçevesi.

    ``axis_direction`` tepeden odağa ve açılma yönüne bakan birim vektördür.
    ``transverse_direction`` bunun saat yönü tersindeki birim dikidir.
    ``focal_length`` tepe--odak uzaklığıdır ve kesin pozitiftir.
    """

    vertex: FloatArray
    focus: FloatArray
    directrix: FloatArray
    axis_direction: FloatArray
    transverse_direction: FloatArray
    focal_length: float


def parabola_frame_from_vertex_axis(
    vertex: ArrayLike,
    axis_direction: ArrayLike,
    focal_length: float,
) -> ParabolaFrame:
    """Tepe, açılma yönü ve odak uzaklığından normal parabol kurar."""

    vertex_point = _plane_point(vertex, name="vertex")
    axis = _unit_plane_direction(axis_direction, name="axis_direction")
    focal_distance = _positive_finite(focal_length, name="focal_length")
    transverse = np.array([-axis[1], axis[0]], dtype=float)
    focus = vertex_point + focal_distance * axis
    directrix = canonical_line_coefficients(
        [axis[0], axis[1], focal_distance - float(axis @ vertex_point)]
    )
    if not np.all(np.isfinite(focus)):
        raise OverflowError("Parabol odağı sayı aralığını aşıyor.")
    return ParabolaFrame(
        vertex=vertex_point.copy(),
        focus=focus,
        directrix=directrix,
        axis_direction=axis,
        transverse_direction=transverse,
        focal_length=focal_distance,
    )


def parabola_frame_from_focus_directrix(
    focus: ArrayLike,
    directrix: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> ParabolaFrame:
    """Odak ve doğrultmandan tepeyi, ekseni ve odak uzaklığını çıkarır.

    ``zero_tolerance`` koordinatlarla aynı uzunluk birimindedir. Odağın
    doğrultmana uzaklığı bu eşik veya altındaysa normal parabol tanımsızdır.
    """

    focus_point = _plane_point(focus, name="focus")
    line = canonical_line_coefficients(directrix)
    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    signed_distance = float(focus_point @ line[:2] + line[2])
    if not np.isfinite(signed_distance):
        raise OverflowError("Odak--doğrultman uzaklığı sayı aralığını aşıyor.")
    if abs(signed_distance) <= tolerance:
        raise ValueError("Odak doğrultman üzerinde veya eşiğe çok yakındır.")
    foot = focus_point - signed_distance * line[:2]
    vertex = 0.5 * (focus_point + foot)
    axis = np.copysign(1.0, signed_distance) * line[:2]
    focal_distance = 0.5 * abs(signed_distance)
    frame = parabola_frame_from_vertex_axis(vertex, axis, focal_distance)
    return ParabolaFrame(
        vertex=frame.vertex,
        focus=focus_point.copy(),
        directrix=line,
        axis_direction=frame.axis_direction,
        transverse_direction=frame.transverse_direction,
        focal_length=frame.focal_length,
    )


def parabola_points(
    vertex: ArrayLike,
    axis_direction: ArrayLike,
    focal_length: float,
    parameters: ArrayLike,
) -> FloatArray:
    """``X(t)=V+f*t^2*u+2*f*t*v`` parametrizasyonunu değerlendirir.

    Burada ``u`` açılma yönündeki birim eksen, ``v`` onun birim diki,
    ``f`` pozitif odak uzaklığı ve ``t`` boyutsuz parametredir. Skaler
    parametre için ``(2,)``, dizi için ``(n, 2)`` döndürülür.
    """

    frame = parabola_frame_from_vertex_axis(vertex, axis_direction, focal_length)
    values, single = _parameter_values(parameters)
    with np.errstate(over="ignore", invalid="ignore"):
        axial = frame.focal_length * values**2
        transverse = 2.0 * frame.focal_length * values
        points = (
            frame.vertex
            + axial[:, None] * frame.axis_direction
            + transverse[:, None] * frame.transverse_direction
        )
    if not np.all(np.isfinite(points)):
        raise OverflowError("Parabol noktaları sayı aralığını aşıyor.")
    if single:
        return points[0]
    return points


def parabola_algebraic_residuals(
    points: ArrayLike,
    vertex: ArrayLike,
    axis_direction: ArrayLike,
    focal_length: float,
) -> float | FloatArray:
    """Yönlendirilmiş parabol için ``eta^2-4*f*xi`` artığını verir.

    Artık koordinat uzunluğunun karesi birimindedir. ``xi`` eksen,
    ``eta`` enine yerel koordinattır.
    """

    rows, single = _point_rows(points, name="points")
    frame = parabola_frame_from_vertex_axis(vertex, axis_direction, focal_length)
    offsets = rows - frame.vertex
    with np.errstate(over="ignore", invalid="ignore"):
        axial = offsets @ frame.axis_direction
        transverse = offsets @ frame.transverse_direction
        residuals = transverse**2 - 4.0 * frame.focal_length * axial
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Parabol artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


def parabola_tangent_line(
    vertex: ArrayLike,
    axis_direction: ArrayLike,
    focal_length: float,
    parameter: float,
) -> FloatArray:
    """Verilen parametre noktasındaki teğetin kanonik doğru katsayıları."""

    frame = parabola_frame_from_vertex_axis(vertex, axis_direction, focal_length)
    value = _finite_scalar(parameter, name="parameter")
    normal = value * frame.transverse_direction - frame.axis_direction
    constant = (
        float(frame.axis_direction @ frame.vertex)
        - value * float(frame.transverse_direction @ frame.vertex)
        - frame.focal_length * value**2
    )
    return canonical_line_coefficients([normal[0], normal[1], constant])


@dataclass(frozen=True)
class ParabolaReflectionDiagnostics:
    """Eksen-paralel ışınların ideal paraboldeki yansıma tanısı."""

    parameters: FloatArray
    points: FloatArray
    unit_normals: FloatArray
    incident_directions: FloatArray
    reflected_directions: FloatArray
    focus_directions: FloatArray
    direction_errors: FloatArray
    focus_line_residuals: FloatArray
    maximum_direction_error: float
    maximum_focus_line_residual: float


def parabola_reflection_diagnostics(
    vertex: ArrayLike,
    axis_direction: ArrayLike,
    focal_length: float,
    parameters: ArrayLike,
) -> ParabolaReflectionDiagnostics:
    """İdeal yansıma yönünü odak doğrultusuyla karşılaştırır.

    Parabol açılma yönü ``u`` ise gelen birim ışınlar ``-u`` yönünde kabul
    edilir. Yansıma ``d-2(d*n)n`` formülüyle hesaplanır. Sonuç geometrik
    optiğe aittir; kırınım, yüzey hatası veya elektromanyetik kazanç modeli
    değildir.
    """

    frame = parabola_frame_from_vertex_axis(vertex, axis_direction, focal_length)
    values, _ = _parameter_values(parameters)
    points = parabola_points(
        frame.vertex,
        frame.axis_direction,
        frame.focal_length,
        values,
    )
    denominators = np.sqrt(1.0 + values**2)
    unit_normals = (
        -frame.axis_direction
        + values[:, None] * frame.transverse_direction
    ) / denominators[:, None]
    incident = np.broadcast_to(-frame.axis_direction, points.shape).copy()
    reflected = incident - 2.0 * np.sum(
        incident * unit_normals,
        axis=1,
    )[:, None] * unit_normals
    focus_vectors = frame.focus - points
    focus_norms = np.linalg.norm(focus_vectors, axis=1)
    focus_directions = focus_vectors / focus_norms[:, None]
    direction_errors = np.linalg.norm(reflected - focus_directions, axis=1)
    focus_line_residuals = np.abs(
        focus_vectors[:, 0] * reflected[:, 1]
        - focus_vectors[:, 1] * reflected[:, 0]
    )
    arrays = (
        points,
        unit_normals,
        incident,
        reflected,
        focus_directions,
        direction_errors,
        focus_line_residuals,
    )
    if not all(np.all(np.isfinite(array)) for array in arrays):
        raise OverflowError("Parabol yansıma tanısı sayı aralığını aşıyor.")
    return ParabolaReflectionDiagnostics(
        parameters=values.copy(),
        points=points,
        unit_normals=unit_normals,
        incident_directions=incident,
        reflected_directions=reflected,
        focus_directions=focus_directions,
        direction_errors=direction_errors,
        focus_line_residuals=focus_line_residuals,
        maximum_direction_error=float(
            np.max(direction_errors, initial=0.0)
        ),
        maximum_focus_line_residual=float(
            np.max(focus_line_residuals, initial=0.0)
        ),
    )


def parabolic_reflector_focal_length(
    aperture_diameter: float,
    depth: float,
) -> float:
    """İdeal parabol kesitinde ``f=D^2/(16*d)`` odak uzaklığını verir."""

    diameter = _positive_finite(aperture_diameter, name="aperture_diameter")
    sag = _positive_finite(depth, name="depth")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        focal_distance = diameter**2 / (16.0 * sag)
    if not np.isfinite(focal_distance) or focal_distance <= 0.0:
        raise OverflowError("Reflektör odak uzaklığı sayı aralığını aşıyor.")
    return float(focal_distance)


@dataclass(frozen=True)
class EllipseFrame:
    """Yönlendirilmiş, çember olmayan normal bir elipsin Öklid çerçevesi.

    ``major_direction`` birim büyük eksen yönüdür; ``minor_direction`` bunun
    saat yönü tersindeki birim dikidir. Odaklar sırasıyla
    ``center - focal_distance * major_direction`` ve
    ``center + focal_distance * major_direction`` noktalarıdır. API,
    büyük ekseni tekil tutmak için kesin olarak ``semi_major > semi_minor > 0``
    ister; çember sınırı mevcut çember yardımcılarıyla ele alınır.
    """

    center: FloatArray
    first_focus: FloatArray
    second_focus: FloatArray
    major_direction: FloatArray
    minor_direction: FloatArray
    first_directrix: FloatArray
    second_directrix: FloatArray
    semi_major: float
    semi_minor: float
    focal_distance: float
    eccentricity: float


def _ellipse_axes(
    semi_major: float,
    semi_minor: float,
) -> tuple[float, float, float, float]:
    """Normal elipsin ``a``, ``b``, ``c`` ve ``e`` niceliklerini doğrular."""

    major = _positive_finite(semi_major, name="semi_major")
    minor = _positive_finite(semi_minor, name="semi_minor")
    if major <= minor:
        raise ValueError(
            "Normal elips için semi_major > semi_minor > 0 olmalıdır; "
            "eşitlik çember sınırıdır."
        )
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        focal_distance = float(np.sqrt((major - minor) * (major + minor)))
        eccentricity = focal_distance / major
    if not np.isfinite(focal_distance) or not np.isfinite(eccentricity):
        raise OverflowError("Elips eksen bağıntısı sayı aralığını aşıyor.")
    if focal_distance <= 0.0 or not 0.0 < eccentricity < 1.0:
        raise ValueError("Elips eksen ayrımı kayan noktalı gösterimde seçilemiyor.")
    return major, minor, focal_distance, eccentricity


def ellipse_frame_from_center_axes(
    center: ArrayLike,
    major_axis_direction: ArrayLike,
    semi_major: float,
    semi_minor: float,
) -> EllipseFrame:
    """Merkez, büyük eksen yönü ve yarı eksenlerden normal elips kurar."""

    center_point = _plane_point(center, name="center")
    major_direction = _unit_plane_direction(
        major_axis_direction,
        name="major_axis_direction",
    )
    major, minor, focal_distance, eccentricity = _ellipse_axes(
        semi_major,
        semi_minor,
    )
    minor_direction = np.array(
        [-major_direction[1], major_direction[0]],
        dtype=float,
    )
    first_focus = center_point - focal_distance * major_direction
    second_focus = center_point + focal_distance * major_direction
    directrix_offset = major / eccentricity
    first_directrix = canonical_line_coefficients(
        [
            major_direction[0],
            major_direction[1],
            directrix_offset - float(major_direction @ center_point),
        ]
    )
    second_directrix = canonical_line_coefficients(
        [
            major_direction[0],
            major_direction[1],
            -directrix_offset - float(major_direction @ center_point),
        ]
    )
    arrays = (
        first_focus,
        second_focus,
        minor_direction,
        first_directrix,
        second_directrix,
    )
    if not all(np.all(np.isfinite(array)) for array in arrays):
        raise OverflowError("Elips çerçevesi sayı aralığını aşıyor.")
    return EllipseFrame(
        center=center_point.copy(),
        first_focus=first_focus,
        second_focus=second_focus,
        major_direction=major_direction,
        minor_direction=minor_direction,
        first_directrix=first_directrix,
        second_directrix=second_directrix,
        semi_major=major,
        semi_minor=minor,
        focal_distance=focal_distance,
        eccentricity=eccentricity,
    )


def ellipse_frame_from_foci(
    first_focus: ArrayLike,
    second_focus: ArrayLike,
    semi_major: float,
    *,
    focus_tolerance: float = 0.0,
) -> EllipseFrame:
    """İki sıralı odak ve yarı büyük eksenden normal elips kurar.

    ``focus_tolerance`` koordinatlarla aynı uzunluk birimindedir. Odaklar
    arası uzaklık bu eşik veya altındaysa büyük eksen yönü tekil olduğundan
    işlev girdiyi reddeder. Ayrıca ``semi_major`` doğrusal dışmerkezlikten
    kesin büyük olmalıdır.
    """

    first = _plane_point(first_focus, name="first_focus")
    second = _plane_point(second_focus, name="second_focus")
    major = _positive_finite(semi_major, name="semi_major")
    tolerance = _nonnegative_finite(focus_tolerance, name="focus_tolerance")
    difference = second - first
    separation = float(np.linalg.norm(difference))
    if not np.isfinite(separation):
        raise OverflowError("Odaklar arası uzaklık sayı aralığını aşıyor.")
    if separation <= tolerance:
        raise ValueError("Odaklar çakışık veya seçilen eşiğe çok yakındır.")
    focal_distance = 0.5 * separation
    if major <= focal_distance:
        raise ValueError("semi_major, yarı odak uzaklığından kesin büyük olmalıdır.")
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        minor = float(np.sqrt((major - focal_distance) * (major + focal_distance)))
    if not np.isfinite(minor):
        raise OverflowError("Elips yarı küçük ekseni sayı aralığını aşıyor.")
    if minor <= 0.0 or minor >= major:
        raise ValueError("Odaklar ve yarı büyük eksen normal elips üretmiyor.")
    center = first + 0.5 * difference
    frame = ellipse_frame_from_center_axes(
        center,
        difference,
        major,
        minor,
    )
    return EllipseFrame(
        center=frame.center,
        first_focus=first.copy(),
        second_focus=second.copy(),
        major_direction=frame.major_direction,
        minor_direction=frame.minor_direction,
        first_directrix=frame.first_directrix,
        second_directrix=frame.second_directrix,
        semi_major=frame.semi_major,
        semi_minor=frame.semi_minor,
        focal_distance=focal_distance,
        eccentricity=focal_distance / major,
    )


def ellipse_points(
    center: ArrayLike,
    major_axis_direction: ArrayLike,
    semi_major: float,
    semi_minor: float,
    parameters: ArrayLike,
) -> FloatArray:
    """``X(t)=C+a*cos(t)*u+b*sin(t)*v`` noktalarını hesaplar.

    ``t`` boyutsuzdur ve radyan olarak yorumlanır. Skaler parametre için
    ``(2,)``, boş olmayan bir parametre dizisi için ``(n, 2)`` döndürülür.
    """

    frame = ellipse_frame_from_center_axes(
        center,
        major_axis_direction,
        semi_major,
        semi_minor,
    )
    values, single = _parameter_values(parameters)
    with np.errstate(over="ignore", invalid="ignore"):
        points = (
            frame.center
            + (frame.semi_major * np.cos(values))[:, None]
            * frame.major_direction
            + (frame.semi_minor * np.sin(values))[:, None]
            * frame.minor_direction
        )
    if not np.all(np.isfinite(points)):
        raise OverflowError("Elips noktaları sayı aralığını aşıyor.")
    if single:
        return points[0]
    return points


def ellipse_algebraic_residuals(
    points: ArrayLike,
    center: ArrayLike,
    major_axis_direction: ArrayLike,
    semi_major: float,
    semi_minor: float,
) -> float | FloatArray:
    """Yönlendirilmiş standart elips denkleminin boyutsuz artığını verir."""

    rows, single = _point_rows(points, name="points")
    frame = ellipse_frame_from_center_axes(
        center,
        major_axis_direction,
        semi_major,
        semi_minor,
    )
    offsets = rows - frame.center
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        axial = offsets @ frame.major_direction
        transverse = offsets @ frame.minor_direction
        residuals = (
            (axial / frame.semi_major) ** 2
            + (transverse / frame.semi_minor) ** 2
            - 1.0
        )
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Elips cebirsel artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


def ellipse_focal_sum_residuals(
    points: ArrayLike,
    first_focus: ArrayLike,
    second_focus: ArrayLike,
    semi_major: float,
) -> float | FloatArray:
    """İki odak uzaklığı toplamının ``2*a`` değerinden uzunluk artığını verir."""

    rows, single = _point_rows(points, name="points")
    frame = ellipse_frame_from_foci(first_focus, second_focus, semi_major)
    with np.errstate(over="ignore", invalid="ignore"):
        first_distances = np.linalg.norm(rows - frame.first_focus, axis=1)
        second_distances = np.linalg.norm(rows - frame.second_focus, axis=1)
        residuals = first_distances + second_distances - 2.0 * frame.semi_major
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Elips odak-toplam artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


def ellipse_tangent_line(
    center: ArrayLike,
    major_axis_direction: ArrayLike,
    semi_major: float,
    semi_minor: float,
    parameter: float,
) -> FloatArray:
    """Verilen trigonometrik parametrede teğetin kanonik katsayılarını verir."""

    frame = ellipse_frame_from_center_axes(
        center,
        major_axis_direction,
        semi_major,
        semi_minor,
    )
    value = _finite_scalar(parameter, name="parameter")
    point = ellipse_points(
        frame.center,
        frame.major_direction,
        frame.semi_major,
        frame.semi_minor,
        value,
    )
    normal = (
        np.cos(value) / frame.semi_major * frame.major_direction
        + np.sin(value) / frame.semi_minor * frame.minor_direction
    )
    constant = -float(normal @ point)
    return canonical_line_coefficients([normal[0], normal[1], constant])


@dataclass(frozen=True)
class EllipseReflectionDiagnostics:
    """Birinci odaktan çıkan ideal ışınların ikinci odağa yansıma tanısı."""

    parameters: FloatArray
    points: FloatArray
    unit_normals: FloatArray
    incident_directions: FloatArray
    reflected_directions: FloatArray
    focus_directions: FloatArray
    focal_path_lengths: FloatArray
    focal_sum_residuals: FloatArray
    direction_errors: FloatArray
    focus_line_residuals: FloatArray
    maximum_focal_sum_residual: float
    maximum_direction_error: float
    maximum_focus_line_residual: float


def ellipse_reflection_diagnostics(
    center: ArrayLike,
    major_axis_direction: ArrayLike,
    semi_major: float,
    semi_minor: float,
    parameters: ArrayLike,
) -> EllipseReflectionDiagnostics:
    """İdeal elips yansımasını ve sabit kırık yol uzunluğunu denetler.

    Gelen birim yön birinci odaktan sınır noktasına, hedef yön sınır
    noktasından ikinci odağa bakar. Yansıma ``d-2(d*n)n`` formülüyle
    hesaplanır. Sonuç iki boyutlu geometrik ışın modelidir; dalga, soğurma,
    faz veya yüzey kusuru modeli değildir.
    """

    frame = ellipse_frame_from_center_axes(
        center,
        major_axis_direction,
        semi_major,
        semi_minor,
    )
    values, _ = _parameter_values(parameters)
    points = ellipse_points(
        frame.center,
        frame.major_direction,
        frame.semi_major,
        frame.semi_minor,
        values,
    )
    normal_vectors = (
        (np.cos(values) / frame.semi_major)[:, None]
        * frame.major_direction
        + (np.sin(values) / frame.semi_minor)[:, None]
        * frame.minor_direction
    )
    normal_norms = np.linalg.norm(normal_vectors, axis=1)
    unit_normals = normal_vectors / normal_norms[:, None]
    incident_vectors = points - frame.first_focus
    target_vectors = frame.second_focus - points
    first_distances = np.linalg.norm(incident_vectors, axis=1)
    second_distances = np.linalg.norm(target_vectors, axis=1)
    incident_directions = incident_vectors / first_distances[:, None]
    focus_directions = target_vectors / second_distances[:, None]
    reflected_directions = incident_directions - 2.0 * np.sum(
        incident_directions * unit_normals,
        axis=1,
    )[:, None] * unit_normals
    focal_path_lengths = first_distances + second_distances
    focal_sum_residuals = focal_path_lengths - 2.0 * frame.semi_major
    direction_errors = np.linalg.norm(
        reflected_directions - focus_directions,
        axis=1,
    )
    focus_line_residuals = np.abs(
        target_vectors[:, 0] * reflected_directions[:, 1]
        - target_vectors[:, 1] * reflected_directions[:, 0]
    )
    arrays = (
        points,
        unit_normals,
        incident_directions,
        reflected_directions,
        focus_directions,
        focal_path_lengths,
        focal_sum_residuals,
        direction_errors,
        focus_line_residuals,
    )
    if not all(np.all(np.isfinite(array)) for array in arrays):
        raise OverflowError("Elips yansıma tanısı sayı aralığını aşıyor.")
    return EllipseReflectionDiagnostics(
        parameters=values.copy(),
        points=points,
        unit_normals=unit_normals,
        incident_directions=incident_directions,
        reflected_directions=reflected_directions,
        focus_directions=focus_directions,
        focal_path_lengths=focal_path_lengths,
        focal_sum_residuals=focal_sum_residuals,
        direction_errors=direction_errors,
        focus_line_residuals=focus_line_residuals,
        maximum_focal_sum_residual=float(
            np.max(np.abs(focal_sum_residuals), initial=0.0)
        ),
        maximum_direction_error=float(np.max(direction_errors, initial=0.0)),
        maximum_focus_line_residual=float(
            np.max(focus_line_residuals, initial=0.0)
        ),
    )


@dataclass(frozen=True)
class HyperbolaFrame:
    """Yönlendirilmiş normal bir hiperbolün Öklid çerçevesi.

    ``transverse_direction`` birim asal eksen yönüdür;
    ``conjugate_direction`` bunun saat yönü tersindeki birim dikidir.
    Sıralı odaklar ``center - focal_distance * transverse_direction`` ve
    ``center + focal_distance * transverse_direction`` noktalarıdır.
    ``semi_transverse`` ile ``semi_conjugate`` kesin pozitiftir; aralarında
    büyüklük sırası aranmaz ve eşitlik dik hiperbolü verir.
    """

    center: FloatArray
    first_focus: FloatArray
    second_focus: FloatArray
    transverse_direction: FloatArray
    conjugate_direction: FloatArray
    first_directrix: FloatArray
    second_directrix: FloatArray
    first_asymptote: FloatArray
    second_asymptote: FloatArray
    semi_transverse: float
    semi_conjugate: float
    focal_distance: float
    eccentricity: float


def _hyperbola_axes(
    semi_transverse: float,
    semi_conjugate: float,
) -> tuple[float, float, float, float]:
    """Normal hiperbolün ``a``, ``b``, ``c`` ve ``e`` niceliklerini doğrular."""

    transverse = _positive_finite(semi_transverse, name="semi_transverse")
    conjugate = _positive_finite(semi_conjugate, name="semi_conjugate")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        focal_distance = float(np.hypot(transverse, conjugate))
        eccentricity = focal_distance / transverse
    if not np.isfinite(focal_distance) or not np.isfinite(eccentricity):
        raise OverflowError("Hiperbol eksen bağıntısı sayı aralığını aşıyor.")
    if focal_distance <= transverse or eccentricity <= 1.0:
        raise ValueError(
            "Hiperbol eksen ayrımı kayan noktalı gösterimde seçilemiyor."
        )
    return transverse, conjugate, focal_distance, eccentricity


def _hyperbola_branch(branch: int) -> int:
    """Hiperbol kolunu yalnız ``-1`` veya ``+1`` olarak doğrular."""

    if isinstance(branch, (bool, np.bool_)):
        raise ValueError("branch yalnız -1 veya +1 olmalıdır.")
    value = _finite_scalar(branch, name="branch")
    if value not in (-1.0, 1.0):
        raise ValueError("branch yalnız -1 veya +1 olmalıdır.")
    return int(value)


def hyperbola_frame_from_center_axes(
    center: ArrayLike,
    transverse_axis_direction: ArrayLike,
    semi_transverse: float,
    semi_conjugate: float,
) -> HyperbolaFrame:
    """Merkez, asal eksen yönü ve yarı eksenlerden normal hiperbol kurar."""

    center_point = _plane_point(center, name="center")
    transverse_direction = _unit_plane_direction(
        transverse_axis_direction,
        name="transverse_axis_direction",
    )
    transverse, conjugate, focal_distance, eccentricity = _hyperbola_axes(
        semi_transverse,
        semi_conjugate,
    )
    conjugate_direction = np.array(
        [-transverse_direction[1], transverse_direction[0]],
        dtype=float,
    )
    first_focus = center_point - focal_distance * transverse_direction
    second_focus = center_point + focal_distance * transverse_direction
    directrix_offset = transverse / eccentricity
    first_directrix = canonical_line_coefficients(
        [
            transverse_direction[0],
            transverse_direction[1],
            directrix_offset - float(transverse_direction @ center_point),
        ]
    )
    second_directrix = canonical_line_coefficients(
        [
            transverse_direction[0],
            transverse_direction[1],
            -directrix_offset - float(transverse_direction @ center_point),
        ]
    )
    slope = conjugate / transverse
    first_normal = conjugate_direction - slope * transverse_direction
    second_normal = conjugate_direction + slope * transverse_direction
    first_asymptote = canonical_line_coefficients(
        [first_normal[0], first_normal[1], -float(first_normal @ center_point)]
    )
    second_asymptote = canonical_line_coefficients(
        [second_normal[0], second_normal[1], -float(second_normal @ center_point)]
    )
    arrays = (
        first_focus,
        second_focus,
        conjugate_direction,
        first_directrix,
        second_directrix,
        first_asymptote,
        second_asymptote,
    )
    if not all(np.all(np.isfinite(array)) for array in arrays):
        raise OverflowError("Hiperbol çerçevesi sayı aralığını aşıyor.")
    return HyperbolaFrame(
        center=center_point.copy(),
        first_focus=first_focus,
        second_focus=second_focus,
        transverse_direction=transverse_direction,
        conjugate_direction=conjugate_direction,
        first_directrix=first_directrix,
        second_directrix=second_directrix,
        first_asymptote=first_asymptote,
        second_asymptote=second_asymptote,
        semi_transverse=transverse,
        semi_conjugate=conjugate,
        focal_distance=focal_distance,
        eccentricity=eccentricity,
    )


def hyperbola_frame_from_foci(
    first_focus: ArrayLike,
    second_focus: ArrayLike,
    semi_transverse: float,
    *,
    focus_tolerance: float = 0.0,
) -> HyperbolaFrame:
    """İki sıralı odak ve yarı asal eksenden normal hiperbol kurar.

    ``focus_tolerance`` koordinatlarla aynı uzunluk birimindedir. Odaklar
    arası uzaklık bu eşik veya altındaysa asal eksen yönü tekil olduğundan
    işlev girdiyi reddeder. Normal hiperbol için ``semi_transverse``, yarı
    odak uzaklığından kesin küçük olmalıdır.
    """

    first = _plane_point(first_focus, name="first_focus")
    second = _plane_point(second_focus, name="second_focus")
    transverse = _positive_finite(
        semi_transverse,
        name="semi_transverse",
    )
    tolerance = _nonnegative_finite(focus_tolerance, name="focus_tolerance")
    difference = second - first
    separation = float(np.linalg.norm(difference))
    if not np.isfinite(separation):
        raise OverflowError("Odaklar arası uzaklık sayı aralığını aşıyor.")
    if separation <= tolerance:
        raise ValueError("Odaklar çakışık veya seçilen eşiğe çok yakındır.")
    focal_distance = 0.5 * separation
    if transverse >= focal_distance:
        raise ValueError(
            "semi_transverse, yarı odak uzaklığından kesin küçük olmalıdır."
        )
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        conjugate = float(
            np.sqrt(focal_distance - transverse)
            * np.sqrt(focal_distance + transverse)
        )
    if not np.isfinite(conjugate):
        raise OverflowError("Hiperbol yarı eşlenik ekseni sayı aralığını aşıyor.")
    if conjugate <= 0.0:
        raise ValueError("Odaklar ve yarı asal eksen normal hiperbol üretmiyor.")
    center = first + 0.5 * difference
    frame = hyperbola_frame_from_center_axes(
        center,
        difference,
        transverse,
        conjugate,
    )
    return HyperbolaFrame(
        center=frame.center,
        first_focus=first.copy(),
        second_focus=second.copy(),
        transverse_direction=frame.transverse_direction,
        conjugate_direction=frame.conjugate_direction,
        first_directrix=frame.first_directrix,
        second_directrix=frame.second_directrix,
        first_asymptote=frame.first_asymptote,
        second_asymptote=frame.second_asymptote,
        semi_transverse=frame.semi_transverse,
        semi_conjugate=conjugate,
        focal_distance=focal_distance,
        eccentricity=focal_distance / transverse,
    )


def hyperbola_points(
    center: ArrayLike,
    transverse_axis_direction: ArrayLike,
    semi_transverse: float,
    semi_conjugate: float,
    parameters: ArrayLike,
    *,
    branch: int,
) -> FloatArray:
    """``X_s(t)=C+s*a*cosh(t)*u+b*sinh(t)*v`` noktalarını hesaplar.

    ``t`` boyutsuzdur, ``branch`` yalnız ``-1`` veya ``+1`` olabilir.
    Skaler parametre için ``(2,)``, boş olmayan bir parametre dizisi için
    ``(n, 2)`` döndürülür.
    """

    frame = hyperbola_frame_from_center_axes(
        center,
        transverse_axis_direction,
        semi_transverse,
        semi_conjugate,
    )
    sign = _hyperbola_branch(branch)
    values, single = _parameter_values(parameters)
    with np.errstate(over="ignore", invalid="ignore"):
        points = (
            frame.center
            + (sign * frame.semi_transverse * np.cosh(values))[:, None]
            * frame.transverse_direction
            + (frame.semi_conjugate * np.sinh(values))[:, None]
            * frame.conjugate_direction
        )
    if not np.all(np.isfinite(points)):
        raise OverflowError("Hiperbol noktaları sayı aralığını aşıyor.")
    if single:
        return points[0]
    return points


def hyperbola_algebraic_residuals(
    points: ArrayLike,
    center: ArrayLike,
    transverse_axis_direction: ArrayLike,
    semi_transverse: float,
    semi_conjugate: float,
) -> float | FloatArray:
    """Yönlendirilmiş standart hiperbol denkleminin boyutsuz artığını verir."""

    rows, single = _point_rows(points, name="points")
    frame = hyperbola_frame_from_center_axes(
        center,
        transverse_axis_direction,
        semi_transverse,
        semi_conjugate,
    )
    offsets = rows - frame.center
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        axial = offsets @ frame.transverse_direction
        conjugate = offsets @ frame.conjugate_direction
        residuals = (
            (axial / frame.semi_transverse) ** 2
            - (conjugate / frame.semi_conjugate) ** 2
            - 1.0
        )
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Hiperbol cebirsel artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


def hyperbola_focal_difference_residuals(
    points: ArrayLike,
    first_focus: ArrayLike,
    second_focus: ArrayLike,
    semi_transverse: float,
) -> float | FloatArray:
    """Mutlak odak uzaklığı farkının ``2*a`` değerinden artığını verir.

    Artık koordinatlarla aynı uzunluk birimindedir ve iki kol için de aynı
    geometrik yer koşulunu sınar. İşaretli fark, odakların verilen sırasına
    bağlıdır ve toplu tanı işlevinde ayrıca raporlanır.
    """

    rows, single = _point_rows(points, name="points")
    frame = hyperbola_frame_from_foci(
        first_focus,
        second_focus,
        semi_transverse,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        first_distances = np.linalg.norm(rows - frame.first_focus, axis=1)
        second_distances = np.linalg.norm(rows - frame.second_focus, axis=1)
        residuals = (
            np.abs(first_distances - second_distances)
            - 2.0 * frame.semi_transverse
        )
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Hiperbol odak-fark artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


def hyperbola_asymptote_lines(
    center: ArrayLike,
    transverse_axis_direction: ArrayLike,
    semi_transverse: float,
    semi_conjugate: float,
) -> FloatArray:
    """Merkezden geçen iki asimptotun kanonik doğru katsayılarını verir."""

    frame = hyperbola_frame_from_center_axes(
        center,
        transverse_axis_direction,
        semi_transverse,
        semi_conjugate,
    )
    return np.vstack([frame.first_asymptote, frame.second_asymptote])


def hyperbola_tangent_line(
    center: ArrayLike,
    transverse_axis_direction: ArrayLike,
    semi_transverse: float,
    semi_conjugate: float,
    parameter: float,
    *,
    branch: int,
) -> FloatArray:
    """Verilen hiperbolik parametrede teğetin kanonik katsayılarını verir."""

    frame = hyperbola_frame_from_center_axes(
        center,
        transverse_axis_direction,
        semi_transverse,
        semi_conjugate,
    )
    sign = _hyperbola_branch(branch)
    value = _finite_scalar(parameter, name="parameter")
    point = hyperbola_points(
        frame.center,
        frame.transverse_direction,
        frame.semi_transverse,
        frame.semi_conjugate,
        value,
        branch=sign,
    )
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        normal = (
            sign * np.cosh(value) / frame.semi_transverse
            * frame.transverse_direction
            - np.sinh(value) / frame.semi_conjugate
            * frame.conjugate_direction
        )
    if not np.all(np.isfinite(normal)):
        raise OverflowError("Hiperbol teğeti sayı aralığını aşıyor.")
    constant = -float(normal @ point)
    return canonical_line_coefficients([normal[0], normal[1], constant])


@dataclass(frozen=True)
class HyperbolaDiagnostics:
    """Bir hiperbol kolunun üyelik ve asimptot tanıları."""

    parameters: FloatArray
    branch: int
    points: FloatArray
    signed_focal_differences: FloatArray
    focal_difference_residuals: FloatArray
    algebraic_residuals: FloatArray
    nearest_asymptote_distances: FloatArray
    maximum_absolute_focal_difference_residual: float
    maximum_absolute_algebraic_residual: float


def hyperbola_diagnostics(
    center: ArrayLike,
    transverse_axis_direction: ArrayLike,
    semi_transverse: float,
    semi_conjugate: float,
    parameters: ArrayLike,
    *,
    branch: int,
) -> HyperbolaDiagnostics:
    """Bir kolun odak-fark, denklem ve en yakın asimptot uzaklığını verir.

    Odak-fark artığı uzunluk biriminde, cebirsel artık boyutsuz ve asimptot
    uzaklığı koordinatlarla aynı uzunluk birimindedir. Bu sayılar fiziksel
    ölçüm belirsizliği değil, verilen noktaların ideal modele sayısal uyumudur.
    """

    frame = hyperbola_frame_from_center_axes(
        center,
        transverse_axis_direction,
        semi_transverse,
        semi_conjugate,
    )
    sign = _hyperbola_branch(branch)
    values, _ = _parameter_values(parameters)
    points = hyperbola_points(
        frame.center,
        frame.transverse_direction,
        frame.semi_transverse,
        frame.semi_conjugate,
        values,
        branch=sign,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        first_distances = np.linalg.norm(points - frame.first_focus, axis=1)
        second_distances = np.linalg.norm(points - frame.second_focus, axis=1)
        signed_differences = first_distances - second_distances
        focal_residuals = np.abs(signed_differences) - 2.0 * frame.semi_transverse
        algebraic_residuals = np.asarray(
            hyperbola_algebraic_residuals(
                points,
                frame.center,
                frame.transverse_direction,
                frame.semi_transverse,
                frame.semi_conjugate,
            ),
            dtype=float,
        )
        first_distances_to_line = np.abs(
            points @ frame.first_asymptote[:2] + frame.first_asymptote[2]
        )
        second_distances_to_line = np.abs(
            points @ frame.second_asymptote[:2] + frame.second_asymptote[2]
        )
        nearest_asymptote_distances = np.minimum(
            first_distances_to_line,
            second_distances_to_line,
        )
    arrays = (
        points,
        signed_differences,
        focal_residuals,
        algebraic_residuals,
        nearest_asymptote_distances,
    )
    if not all(np.all(np.isfinite(array)) for array in arrays):
        raise OverflowError("Hiperbol tanısı sayı aralığını aşıyor.")
    return HyperbolaDiagnostics(
        parameters=values.copy(),
        branch=sign,
        points=points,
        signed_focal_differences=signed_differences,
        focal_difference_residuals=focal_residuals,
        algebraic_residuals=algebraic_residuals,
        nearest_asymptote_distances=nearest_asymptote_distances,
        maximum_absolute_focal_difference_residual=float(
            np.max(np.abs(focal_residuals), initial=0.0)
        ),
        maximum_absolute_algebraic_residual=float(
            np.max(np.abs(algebraic_residuals), initial=0.0)
        ),
    )
