"""Uzay vektörleri, alan, hacim ve yönelim için güvenli yardımcılar.

Vektörel çarpım yalnız standart yönlendirilmiş ``R^3`` uzayında tanımlanır;
bu nedenle ilgili bütün girdiler tam ``(3,)`` biçiminde olmalıdır. Ham alan
ve hacimler fiziksel birim taşır. ``spatial_orientation_diagnostics`` ise
ölçekten bağımsız bir karma çarpım kullanır ve yakın eşdüzlemlilik kararını
yalnız kullanıcının verdiği ``relative_tolerance`` ile işaretler.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array
from .vectors import vector_norm


SpatialOrientationClass = Literal[
    "right_handed",
    "left_handed",
    "coplanar",
    "uncertain",
    "degenerate",
]


def _spatial_vector(value: ArrayLike, *, name: str) -> FloatArray:
    vector = _finite_array(value, name=name)
    if vector.shape != (3,):
        raise ValueError(f"{name}, (3,) biçiminde bir uzay vektörü olmalıdır.")
    return vector.copy()


def _spatial_pair(
    u: ArrayLike,
    v: ArrayLike,
) -> tuple[FloatArray, FloatArray]:
    return _spatial_vector(u, name="u"), _spatial_vector(v, name="v")


def _finite_difference(a: FloatArray, b: FloatArray) -> FloatArray:
    with np.errstate(over="ignore", invalid="ignore"):
        difference = b - a
    if not np.all(np.isfinite(difference)):
        raise OverflowError("Uzay koordinatı farkı kayan noktalı sayı aralığını aşıyor.")
    return difference


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or not 0.0 <= tolerance < 1.0:
        raise ValueError("relative_tolerance sonlu ve [0, 1) aralığında olmalıdır.")
    return tolerance


def _difference_of_products(
    first_left: float,
    first_right: float,
    second_left: float,
    second_right: float,
) -> float:
    first = float(first_left) * float(first_right)
    second = float(second_left) * float(second_right)
    if not np.isfinite(first) or not np.isfinite(second):
        raise OverflowError("Vektörel çarpımın ara çarpımı sayı aralığını aşıyor.")
    result = math.fsum((first, -second))
    if not np.isfinite(result):
        raise OverflowError("Vektörel çarpım sayı aralığını aşıyor.")
    return result


def cross_product_3d(u: ArrayLike, v: ArrayLike) -> FloatArray:
    """Standart sağ yönlü ``R^3`` çerçevesinde ``u x v`` değerini döndürür.

    Vektörler fiziksel uzunluk taşıyorsa sonuç uzunluğun karesi birimindedir.
    İşlev iki bileşenli vektörleri sessizce üç boyuta gömmez.
    """

    vector_u, vector_v = _spatial_pair(u, v)
    return np.array(
        [
            _difference_of_products(
                vector_u[1], vector_v[2], vector_u[2], vector_v[1]
            ),
            _difference_of_products(
                vector_u[2], vector_v[0], vector_u[0], vector_v[2]
            ),
            _difference_of_products(
                vector_u[0], vector_v[1], vector_u[1], vector_v[0]
            ),
        ],
        dtype=float,
    )


def unit_normal_3d(
    u: ArrayLike,
    v: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """``u, v`` sırasının belirlediği birim normali döndürür.

    ``zero_tolerance`` vektörel çarpımın normuyla aynı alan birimindedir.
    Alan bu eşikten büyük değilse güvenilir bir normal tanımlanmaz.
    """

    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    normal = cross_product_3d(u, v)
    magnitude = vector_norm(normal)
    if not np.isfinite(magnitude):
        raise OverflowError("Normal vektörün büyüklüğü sayı aralığını aşıyor.")
    if magnitude <= tolerance:
        raise ValueError(
            "Paralel, sıfır veya eşik altındaki vektörlerin birim normali tanımlı değildir."
        )
    return normal / magnitude


def parallelogram_area_3d(u: ArrayLike, v: ArrayLike) -> float:
    """Kenarları ``u`` ve ``v`` olan paralelkenarın alanını döndürür."""

    area = vector_norm(cross_product_3d(u, v))
    if not np.isfinite(area):
        raise OverflowError("Paralelkenar alanı sayı aralığını aşıyor.")
    return area


def triangle_area_3d(a: ArrayLike, b: ArrayLike, c: ArrayLike) -> float:
    """Üç uzay noktasının oluşturduğu üçgenin negatif olmayan alanı."""

    point_a = _spatial_vector(a, name="a")
    point_b = _spatial_vector(b, name="b")
    point_c = _spatial_vector(c, name="c")
    edge_ab = _finite_difference(point_a, point_b)
    edge_ac = _finite_difference(point_a, point_c)
    return 0.5 * parallelogram_area_3d(edge_ab, edge_ac)


def scalar_triple_product(
    u: ArrayLike,
    v: ArrayLike,
    w: ArrayLike,
) -> float:
    """Yönlü karma çarpımı ``u . (v x w)`` olarak hesaplar.

    Sonuç, vektörler uzunluk birimindeyse uzunluğun küpü birimindedir.
    Pozitif işaret, sıralı üçlünün standart çerçevede sağ yönlü olduğunu
    gösterir.
    """

    vector_u = _spatial_vector(u, name="u")
    vector_v = _spatial_vector(v, name="v")
    vector_w = _spatial_vector(w, name="w")
    cross = cross_product_3d(vector_v, vector_w)
    terms = [float(vector_u[index]) * float(cross[index]) for index in range(3)]
    if not np.all(np.isfinite(terms)):
        raise OverflowError("Karma çarpımın ara çarpımı sayı aralığını aşıyor.")
    result = math.fsum(terms)
    if not np.isfinite(result):
        raise OverflowError("Karma çarpım sayı aralığını aşıyor.")
    return result


def parallelepiped_volume(
    u: ArrayLike,
    v: ArrayLike,
    w: ArrayLike,
) -> float:
    """Kenarları ``u, v, w`` olan paralelyüzün hacmini döndürür."""

    return abs(scalar_triple_product(u, v, w))


def tetrahedron_signed_volume(
    a: ArrayLike,
    b: ArrayLike,
    c: ArrayLike,
    d: ArrayLike,
) -> float:
    """Sıralı ``A, B, C, D`` tetrahedronunun yönlü hacmini döndürür.

    İşaret ``AB . (AC x AD)`` sırasına bağlıdır. Mutlak değerin altıda biri
    değil, doğrudan tetrahedron hacmi döndürülür.
    """

    point_a = _spatial_vector(a, name="a")
    point_b = _spatial_vector(b, name="b")
    point_c = _spatial_vector(c, name="c")
    point_d = _spatial_vector(d, name="d")
    edge_ab = _finite_difference(point_a, point_b)
    edge_ac = _finite_difference(point_a, point_c)
    edge_ad = _finite_difference(point_a, point_d)
    return scalar_triple_product(edge_ab, edge_ac, edge_ad) / 6.0


def tetrahedron_volume(
    a: ArrayLike,
    b: ArrayLike,
    c: ArrayLike,
    d: ArrayLike,
) -> float:
    """Dört uzay noktasının oluşturduğu tetrahedronun hacmini döndürür."""

    return abs(tetrahedron_signed_volume(a, b, c, d))


@dataclass(frozen=True)
class SpatialOrientationDiagnostics:
    """Üç uzay vektörünün yönelimi için boyutlu ve boyutsuz tanı."""

    scalar_triple_product: float
    normalized_triple_product: float
    relative_tolerance: float
    classification: SpatialOrientationClass
    numerically_ambiguous: bool


def spatial_orientation_diagnostics(
    u: ArrayLike,
    v: ArrayLike,
    w: ArrayLike,
    *,
    relative_tolerance: float,
) -> SpatialOrientationDiagnostics:
    """Sıralı ``u, v, w`` üçlüsünün el yönünü ve eşdüzlemliliğini tanır.

    Boyutsuz nicelik ``u_hat . (v_hat x w_hat)`` olup ``[-1, 1]``
    aralığındadır. Vektörlerden biri sıfırsa sınıf ``degenerate``; nicelik
    kayan noktada tam sıfırsa ``coplanar`` olur. Sıfırdan farklı fakat açık
    ``relative_tolerance`` eşiğinin içindeki değer ``uncertain`` ve
    ``numerically_ambiguous=True`` olarak raporlanır.
    """

    tolerance = _relative_tolerance(relative_tolerance)
    vector_u = _spatial_vector(u, name="u")
    vector_v = _spatial_vector(v, name="v")
    vector_w = _spatial_vector(w, name="w")
    raw = scalar_triple_product(vector_u, vector_v, vector_w)
    norms = np.array(
        [vector_norm(vector_u), vector_norm(vector_v), vector_norm(vector_w)],
        dtype=float,
    )
    if not np.all(np.isfinite(norms)):
        raise OverflowError("Vektör normu sayı aralığını aşıyor.")
    if np.any(norms == 0.0):
        return SpatialOrientationDiagnostics(
            scalar_triple_product=raw,
            normalized_triple_product=0.0,
            relative_tolerance=tolerance,
            classification="degenerate",
            numerically_ambiguous=False,
        )

    normalized_vectors = (vector_u / norms[0], vector_v / norms[1], vector_w / norms[2])
    normalized = scalar_triple_product(*normalized_vectors)
    normalized = float(np.clip(normalized, -1.0, 1.0))
    if normalized == 0.0:
        classification: SpatialOrientationClass = "coplanar"
        ambiguous = False
    elif abs(normalized) <= tolerance:
        classification = "uncertain"
        ambiguous = True
    elif normalized > 0.0:
        classification = "right_handed"
        ambiguous = False
    else:
        classification = "left_handed"
        ambiguous = False
    return SpatialOrientationDiagnostics(
        scalar_triple_product=raw,
        normalized_triple_product=normalized,
        relative_tolerance=tolerance,
        classification=classification,
        numerically_ambiguous=ambiguous,
    )
