"""Genel ikinci derece denklemler için matris ve sınıflandırma araçları.

Bir denklem ``A*x**2 + B*x*y + C*y**2 + D*x + E*y + F0 = 0``
biçiminde ve katsayı sırası ``(A, B, C, D, E, F0)`` olarak tutulur.
Kayan noktalı rank kararları yalnız kullanıcının verdiği
``relative_tolerance`` ile yapılır; varsayılan sıfır, cebirsel sınırları
örtük bir yakınlık kuralıyla değiştirmez.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array


_LOCUS_TYPES = {
    "circle",
    "ellipse",
    "hyperbola",
    "parabola",
    "intersecting_lines",
    "parallel_lines",
    "double_line",
    "point",
    "line",
    "empty",
    "plane",
}


def _positive_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} sonlu ve pozitif bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0 or number >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return number


def _coefficients(value: ArrayLike) -> FloatArray:
    coefficients = _finite_array(value, name="coefficients")
    if coefficients.shape != (6,):
        raise ValueError(
            "coefficients, (A, B, C, D, E, F0) sıralı (6,) biçiminde olmalıdır."
        )
    return coefficients.copy()


def _point_rows(value: ArrayLike, *, name: str) -> tuple[FloatArray, bool]:
    points = _finite_array(value, name=name)
    if points.shape == (2,):
        return points.reshape(1, 2), True
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"{name}, (2,) veya (n, 2) biçiminde olmalıdır.")
    return points, False


def quadratic_conic_matrices(
    coefficients: ArrayLike,
) -> tuple[FloatArray, FloatArray, FloatArray]:
    """Katsayılardan ``Q``, ``g`` ve homojen ``H`` matrislerini kurar.

    Dönen matrisler ``q(X)=X.T@Q@X+2*g.T@X+F0`` ve
    ``q(X)=Xh.T@H@Xh`` özdeşliklerini sağlar; ``Xh=(x,y,1)`` olur.
    """

    a, b, c, d, e, constant = _coefficients(coefficients)
    quadratic = np.array([[a, 0.5 * b], [0.5 * b, c]], dtype=float)
    linear = np.array([0.5 * d, 0.5 * e], dtype=float)
    homogeneous = np.block(
        [
            [quadratic, linear[:, None]],
            [linear[None, :], np.array([[constant]])],
        ]
    )
    return quadratic, linear, homogeneous


def _scaled_normalized_coefficients(
    coefficients: FloatArray,
    coordinate_scale: float,
) -> tuple[FloatArray, float]:
    with np.errstate(over="ignore", invalid="ignore"):
        scale_squared = coordinate_scale * coordinate_scale
        scaled = coefficients * np.array(
            [scale_squared, scale_squared, scale_squared, coordinate_scale, coordinate_scale, 1.0]
        )
    if not np.all(np.isfinite(scaled)):
        raise OverflowError("Koordinat ölçekleme işlemi sayı aralığını aşıyor.")
    normalization = float(np.max(np.abs(scaled)))
    if normalization == 0.0:
        return np.zeros(6, dtype=float), 0.0
    normalized = scaled / normalization
    if not np.all(np.isfinite(normalized)):
        raise OverflowError("Katsayı normalizasyonu sayı aralığını aşıyor.")
    return normalized, normalization


def quadratic_conic_residuals(
    coefficients: ArrayLike,
    points: ArrayLike,
    *,
    coordinate_scale: float = 1.0,
) -> float | FloatArray:
    """Noktaların ölçekten bağımsız, normalize edilmiş artıklarını verir.

    ``coordinate_scale`` koordinatlarla aynı uzunluk birimindedir. Noktalar bu
    ölçeğe, denklem katsayıları ise en büyük mutlak boyutsuz katsayıya bölünür.
    Sonuç bu nedenle boyutsuzdur; geometrik uzaklık değildir. Ortak negatif
    katsayı çarpanı artığın işaretini çevirebilir, fakat mutlak değerini
    değiştirmez.
    """

    coefficient_array = _coefficients(coefficients)
    scale = _positive_finite(coordinate_scale, name="coordinate_scale")
    rows, single = _point_rows(points, name="points")
    normalized, normalization = _scaled_normalized_coefficients(coefficient_array, scale)
    if normalization == 0.0:
        residuals = np.zeros(rows.shape[0], dtype=float)
    else:
        z = rows / scale
        a, b, c, d, e, constant = normalized
        with np.errstate(over="ignore", invalid="ignore"):
            residuals = (
                a * z[:, 0] ** 2
                + b * z[:, 0] * z[:, 1]
                + c * z[:, 1] ** 2
                + d * z[:, 0]
                + e * z[:, 1]
                + constant
            )
    if not np.all(np.isfinite(residuals)):
        raise OverflowError("Genel ikinci derece artığı sayı aralığını aşıyor.")
    if single:
        return float(residuals[0])
    return residuals


def transform_quadratic_conic(
    coefficients: ArrayLike,
    rotation: ArrayLike,
    translation: ArrayLike,
    *,
    orthogonality_tolerance: float = 1e-12,
) -> FloatArray:
    """``X = R@Y + t`` koordinat değişiminden sonraki katsayıları döndürür.

    ``rotation`` iki boyutlu ortogonal bir matris, ``translation`` ise eski
    koordinatlarda bir öteleme vektöridir. Dönen katsayılar ``Y`` değişkenine
    göre ``q(R@Y+t)=0`` denklemini temsil eder. Ortogonallik için kullanılan
    mutlak eşik ``orthogonality_tolerance`` ile açıkça verilir.
    """

    coefficient_array = _coefficients(coefficients)
    rotation_array = _finite_array(rotation, name="rotation")
    translation_array = _finite_array(translation, name="translation")
    if rotation_array.shape != (2, 2):
        raise ValueError("rotation, (2, 2) biçiminde olmalıdır.")
    if translation_array.shape != (2,):
        raise ValueError("translation, (2,) biçiminde olmalıdır.")
    tolerance = float(orthogonality_tolerance)
    if not np.isfinite(tolerance) or tolerance < 0.0 or tolerance >= 1.0:
        raise ValueError("orthogonality_tolerance [0, 1) aralığında olmalıdır.")
    gram_error = float(np.max(np.abs(rotation_array.T @ rotation_array - np.eye(2))))
    determinant = float(np.linalg.det(rotation_array))
    if gram_error > tolerance or abs(abs(determinant) - 1.0) > tolerance:
        raise ValueError("rotation verilen eşik içinde ortogonal olmalıdır.")

    _, _, homogeneous = quadratic_conic_matrices(coefficient_array)
    affine = np.eye(3)
    affine[:2, :2] = rotation_array
    affine[:2, 2] = translation_array
    with np.errstate(over="ignore", invalid="ignore"):
        transformed = affine.T @ homogeneous @ affine
    if not np.all(np.isfinite(transformed)):
        raise OverflowError("İkinci derece denklem dönüşümü sayı aralığını aşıyor.")
    transformed = 0.5 * (transformed + transformed.T)
    return np.array(
        [
            transformed[0, 0],
            2.0 * transformed[0, 1],
            transformed[1, 1],
            2.0 * transformed[0, 2],
            2.0 * transformed[1, 2],
            transformed[2, 2],
        ],
        dtype=float,
    )


def _canonical_vector_sign(vector: FloatArray) -> FloatArray:
    result = np.asarray(vector, dtype=float).copy()
    pivot = int(np.argmax(np.abs(result)))
    if result[pivot] < 0.0:
        result *= -1.0
    return result


def _canonical_eigenvectors(vectors: FloatArray) -> FloatArray:
    result = np.asarray(vectors, dtype=float).copy()
    for column in range(result.shape[1]):
        result[:, column] = _canonical_vector_sign(result[:, column])
    return result


def _canonical_line(normal: FloatArray, constant: float) -> FloatArray:
    norm = float(np.linalg.norm(normal))
    if norm == 0.0 or not np.isfinite(norm):
        raise RuntimeError("Sıfır normal vektörlü doğru üretilemez.")
    line = np.r_[normal / norm, constant / norm]
    pivot = int(np.argmax(np.abs(line[:2])))
    if line[pivot] < 0.0:
        line *= -1.0
    return line


def _sorted_lines(lines: list[FloatArray]) -> FloatArray:
    if not lines:
        return np.empty((0, 3), dtype=float)
    return np.asarray(sorted(lines, key=lambda row: tuple(np.round(row, 15))), dtype=float)


def _orientation(direction: FloatArray | None) -> float | None:
    if direction is None:
        return None
    angle = float(np.arctan2(direction[1], direction[0]) % np.pi)
    if np.isclose(angle, np.pi, atol=4.0 * np.finfo(float).eps, rtol=0.0):
        return 0.0
    return angle


@dataclass(frozen=True)
class QuadraticConicDiagnostics:
    """Genel ikinci derece denklemin eksiksiz geometrik ve sayısal tanısı."""

    coefficients: FloatArray
    normalized_coefficients: FloatArray
    coordinate_scale: float
    normalization_factor: float
    relative_tolerance: float
    decision_threshold: float
    quadratic_matrix: FloatArray
    linear_vector: FloatArray
    homogeneous_matrix: FloatArray
    eigenvalues: FloatArray
    eigenvectors: FloatArray
    quadratic_rank: int
    homogeneous_rank: int
    inertia: tuple[int, int, int]
    discriminant: float
    quadratic_determinant: float
    homogeneous_determinant: float
    locus_type: str
    degenerate: bool
    numerically_ambiguous: bool
    center: FloatArray | None
    vertex: FloatArray | None
    semi_axes: FloatArray | None
    principal_directions: FloatArray | None
    focal_parameter: float | None
    orientation_radians: float | None
    canonical_constant: float | None
    component_lines: FloatArray


def quadratic_conic_diagnostics(
    coefficients: ArrayLike,
    *,
    coordinate_scale: float = 1.0,
    relative_tolerance: float = 0.0,
) -> QuadraticConicDiagnostics:
    """Genel ikinci derece denklemi rank ve atalet üzerinden sınıflandırır.

    Koordinatlar ``coordinate_scale`` ile boyutsuzlaştırılır; ardından altı
    katsayı ortak bir pozitif büyüklüğe bölünür. ``relative_tolerance`` bu
    normalize edilmiş uzayda rank ve sıfır kararlarının eşiğidir. Eşik sıfır
    değilse, eşik tarafından sıfır sayılan fakat kayan noktada tam sıfır
    olmayan karar nicelikleri ``numerically_ambiguous`` alanını etkinleştirir.
    """

    coefficient_array = _coefficients(coefficients)
    scale = _positive_finite(coordinate_scale, name="coordinate_scale")
    tolerance = _relative_tolerance(relative_tolerance)
    normalized, normalization = _scaled_normalized_coefficients(coefficient_array, scale)

    if normalization == 0.0:
        zero2 = np.zeros((2, 2), dtype=float)
        zero3 = np.zeros((3, 3), dtype=float)
        return QuadraticConicDiagnostics(
            coefficients=coefficient_array,
            normalized_coefficients=normalized,
            coordinate_scale=scale,
            normalization_factor=normalization,
            relative_tolerance=tolerance,
            decision_threshold=tolerance,
            quadratic_matrix=zero2,
            linear_vector=np.zeros(2, dtype=float),
            homogeneous_matrix=zero3,
            eigenvalues=np.zeros(2, dtype=float),
            eigenvectors=np.eye(2),
            quadratic_rank=0,
            homogeneous_rank=0,
            inertia=(0, 0, 2),
            discriminant=0.0,
            quadratic_determinant=0.0,
            homogeneous_determinant=0.0,
            locus_type="plane",
            degenerate=True,
            numerically_ambiguous=False,
            center=None,
            vertex=None,
            semi_axes=None,
            principal_directions=None,
            focal_parameter=None,
            orientation_radians=None,
            canonical_constant=0.0,
            component_lines=np.empty((0, 3), dtype=float),
        )

    quadratic, linear, homogeneous = quadratic_conic_matrices(normalized)
    eigenvalues, raw_eigenvectors = np.linalg.eigh(quadratic)
    eigenvectors = _canonical_eigenvectors(raw_eigenvectors)
    homogeneous_eigenvalues = np.linalg.eigvalsh(homogeneous)
    positive = int(np.count_nonzero(eigenvalues > tolerance))
    negative = int(np.count_nonzero(eigenvalues < -tolerance))
    zero = 2 - positive - negative
    quadratic_rank = positive + negative
    homogeneous_rank = int(np.count_nonzero(np.abs(homogeneous_eigenvalues) > tolerance))
    ambiguous_values: list[float] = []

    def is_zero(value: float) -> bool:
        magnitude = abs(float(value))
        if tolerance > 0.0 and 0.0 < magnitude <= tolerance:
            ambiguous_values.append(magnitude)
        return magnitude <= tolerance

    if tolerance > 0.0:
        for value in np.r_[eigenvalues, homogeneous_eigenvalues]:
            is_zero(float(value))

    a, b, c, _, _, constant = normalized
    discriminant = float(b * b - 4.0 * a * c)
    quadratic_determinant = float(np.linalg.det(quadratic))
    homogeneous_determinant = float(np.linalg.det(homogeneous))

    locus_type: str
    center: FloatArray | None = None
    vertex: FloatArray | None = None
    semi_axes: FloatArray | None = None
    principal_directions: FloatArray | None = None
    focal_parameter: float | None = None
    orientation_radians: float | None = None
    canonical_constant: float | None = None
    component_lines: list[FloatArray] = []

    if quadratic_rank == 2:
        center_z = np.linalg.solve(quadratic, -linear)
        center = scale * center_z
        canonical_constant = float(constant + np.dot(linear, center_z))

        if positive == 2 or negative == 2:
            if is_zero(canonical_constant):
                locus_type = "point"
            else:
                ratios = -canonical_constant / eigenvalues
                if np.all(ratios > tolerance):
                    axis_lengths = scale * np.sqrt(ratios)
                    circle_gap = float(abs(eigenvalues[1] - eigenvalues[0]))
                    if is_zero(circle_gap):
                        locus_type = "circle"
                        semi_axes = np.array([axis_lengths[0], axis_lengths[0]])
                        principal_directions = np.eye(2)
                    else:
                        locus_type = "ellipse"
                        order = np.argsort(axis_lengths)[::-1]
                        semi_axes = axis_lengths[order]
                        principal_directions = eigenvectors[:, order]
                        orientation_radians = _orientation(principal_directions[:, 0])
                else:
                    if tolerance > 0.0:
                        for ratio in ratios:
                            is_zero(float(ratio))
                    locus_type = "empty"
        else:
            if is_zero(canonical_constant):
                locus_type = "intersecting_lines"
                positive_index = int(np.argmax(eigenvalues))
                negative_index = int(np.argmin(eigenvalues))
                positive_normal = np.sqrt(eigenvalues[positive_index]) * eigenvectors[:, positive_index]
                negative_normal = np.sqrt(-eigenvalues[negative_index]) * eigenvectors[:, negative_index]
                for normal in (positive_normal + negative_normal, positive_normal - negative_normal):
                    unit_line = _canonical_line(normal, -float(np.dot(normal, center_z)))
                    unit_line[2] *= scale
                    component_lines.append(unit_line)
            else:
                locus_type = "hyperbola"
                ratios = -canonical_constant / eigenvalues
                transverse_index = int(np.argmax(ratios))
                conjugate_index = 1 - transverse_index
                semi_axes = scale * np.array(
                    [np.sqrt(ratios[transverse_index]), np.sqrt(-ratios[conjugate_index])]
                )
                principal_directions = np.column_stack(
                    [
                        eigenvectors[:, transverse_index],
                        eigenvectors[:, conjugate_index],
                    ]
                )
                orientation_radians = _orientation(principal_directions[:, 0])

    elif quadratic_rank == 1:
        nonzero_index = int(np.argmax(np.abs(eigenvalues)))
        zero_index = 1 - nonzero_index
        eigenvalue = float(eigenvalues[nonzero_index])
        rotated_linear = eigenvectors.T @ linear
        nonzero_linear = float(rotated_linear[nonzero_index])
        null_linear = float(rotated_linear[zero_index])
        shifted_nonzero = -nonzero_linear / eigenvalue
        canonical_constant = float(constant - nonzero_linear * nonzero_linear / eigenvalue)
        nonzero_direction = eigenvectors[:, nonzero_index]
        null_direction = eigenvectors[:, zero_index]

        if not is_zero(null_linear):
            locus_type = "parabola"
            shifted_null = -canonical_constant / (2.0 * null_linear)
            vertex_z = (
                shifted_nonzero * nonzero_direction + shifted_null * null_direction
            )
            vertex = scale * vertex_z
            signed_focal = -null_linear / (2.0 * eigenvalue)
            opening_direction = np.sign(signed_focal) * null_direction
            focal_parameter = scale * abs(signed_focal)
            principal_directions = np.column_stack(
                [opening_direction, nonzero_direction]
            )
            orientation_radians = _orientation(opening_direction)
        else:
            ratio = float(-canonical_constant / eigenvalue)
            if ratio > tolerance:
                locus_type = "parallel_lines"
                distance = float(np.sqrt(ratio))
                for coordinate in (shifted_nonzero - distance, shifted_nonzero + distance):
                    component_lines.append(
                        _canonical_line(nonzero_direction, -scale * coordinate)
                    )
            elif ratio < -tolerance:
                locus_type = "empty"
            else:
                is_zero(ratio)
                locus_type = "double_line"
                component_lines.append(
                    _canonical_line(nonzero_direction, -scale * shifted_nonzero)
                )

    else:
        linear_norm = float(np.linalg.norm(linear))
        if linear_norm > tolerance:
            locus_type = "line"
            component_lines.append(_canonical_line(2.0 * linear / scale, constant))
        elif is_zero(constant):
            locus_type = "plane"
        else:
            locus_type = "empty"
        if tolerance > 0.0:
            for value in linear:
                is_zero(float(value))
        canonical_constant = float(constant)

    if locus_type not in _LOCUS_TYPES:
        raise RuntimeError(f"Bilinmeyen konik sınıfı üretildi: {locus_type}")
    # Aynı eşiklerle yürütülen blok indirgeme, sıfır toleransında dahi
    # kuramsal rankı yuvarlama artıklarından bağımsız tutar.
    if quadratic_rank == 2:
        homogeneous_rank = 2 if locus_type in {"point", "intersecting_lines"} else 3
    elif quadratic_rank == 1:
        if locus_type == "parabola":
            homogeneous_rank = 3
        elif locus_type == "double_line":
            homogeneous_rank = 1
        else:
            homogeneous_rank = 2
    else:
        if locus_type == "line":
            homogeneous_rank = 2
        elif locus_type == "plane":
            homogeneous_rank = 0
        else:
            homogeneous_rank = 1
    lines = _sorted_lines(component_lines)
    return QuadraticConicDiagnostics(
        coefficients=coefficient_array,
        normalized_coefficients=normalized,
        coordinate_scale=scale,
        normalization_factor=normalization,
        relative_tolerance=tolerance,
        decision_threshold=tolerance,
        quadratic_matrix=quadratic,
        linear_vector=linear,
        homogeneous_matrix=homogeneous,
        eigenvalues=eigenvalues,
        eigenvectors=eigenvectors,
        quadratic_rank=quadratic_rank,
        homogeneous_rank=homogeneous_rank,
        inertia=(positive, negative, zero),
        discriminant=discriminant,
        quadratic_determinant=quadratic_determinant,
        homogeneous_determinant=homogeneous_determinant,
        locus_type=locus_type,
        degenerate=homogeneous_rank < 3,
        numerically_ambiguous=bool(ambiguous_values),
        center=center,
        vertex=vertex,
        semi_axes=semi_axes,
        principal_directions=principal_directions,
        focal_parameter=focal_parameter,
        orientation_radians=orientation_radians,
        canonical_constant=canonical_constant,
        component_lines=lines,
    )
