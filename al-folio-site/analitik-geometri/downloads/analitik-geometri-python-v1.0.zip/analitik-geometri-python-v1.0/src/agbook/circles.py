"""Bölüm 10 için düzlemsel çember, kiriş, teğet ve kutupsal hesapları.

Bir çember ``center`` merkezi ve negatif olmayan ``radius`` yarıçapıyla;
bir doğru ise ``a*x + b*y + c = 0`` katsayılarıyla temsil edilir. Geometrik
eşitlik ile kayan noktalı sınıflandırma ayrıdır: karar veren bütün işlevler
mutlak ve göreli toleransları sonuç nesnesinde açıkça saklar.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array, _point
from .lines import (
    canonical_line_coefficients,
    line_direction,
    line_intersection_diagnostics,
    project_point_to_line,
)
from .vectors import vector_norm


def _plane_point(value: ArrayLike, *, name: str) -> FloatArray:
    point = _point(value, name=name)
    if point.shape != (2,):
        raise ValueError(f"{name}, (2,) biçiminde bir düzlem noktası olmalıdır.")
    return point


def _finite_scalar(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number):
        raise ValueError(f"{name} sonlu bir reel sayı olmalıdır.")
    return number


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = _finite_scalar(value, name=name)
    if number < 0.0:
        raise ValueError(f"{name} negatif olmayan bir sayı olmalıdır.")
    return number


def _positive_finite(value: float, *, name: str) -> float:
    number = _finite_scalar(value, name=name)
    if number <= 0.0:
        raise ValueError(f"{name} pozitif bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="relative_tolerance")
    if tolerance >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _length_threshold(
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> tuple[float, float, float, float]:
    absolute = _nonnegative_finite(absolute_tolerance, name="absolute_tolerance")
    relative = _relative_tolerance(relative_tolerance)
    scale = _positive_finite(reference_scale, name="reference_scale")
    with np.errstate(over="ignore", invalid="ignore"):
        threshold = absolute + relative * scale
    if not np.isfinite(threshold):
        raise OverflowError("Uzunluk eşiği kayan noktalı sayı aralığını aşıyor.")
    return absolute, relative, scale, float(threshold)


def _circle(center: ArrayLike, radius: float) -> tuple[FloatArray, float]:
    center_array = _plane_point(center, name="center")
    radius_value = _nonnegative_finite(radius, name="radius")
    return center_array, radius_value


def point_power(
    center: ArrayLike,
    radius: float,
    point: ArrayLike,
) -> float:
    """Bir noktanın çembere göre işaretli kuvvetini döndürür.

    Sonuç ``||point-center||²-radius²`` değeridir ve koordinatlar uzunluk
    birimindeyse uzunluk karesi birimi taşır. Değer çemberin içinde negatif,
    üzerinde sıfır ve dışında pozitiftir.
    """

    center_array, radius_value = _circle(center, radius)
    candidate = _plane_point(point, name="point")
    with np.errstate(over="ignore", invalid="ignore"):
        offset = candidate - center_array
        power = float(np.dot(offset, offset) - radius_value**2)
    if not np.isfinite(power):
        raise OverflowError("Nokta kuvveti hesabı sayı aralığını aşıyor.")
    return power


@dataclass(frozen=True)
class GeneralCircleDiagnostics:
    """``A(x²+y²)+Dx+Ey+F=0`` denkleminin reel geometri tanısı."""

    normalized_coefficients: FloatArray
    center: FloatArray
    radius_squared: float
    radius: float | None
    locus_type: str
    radius_squared_tolerance: float


def general_circle_diagnostics(
    coefficients: ArrayLike,
    *,
    radius_squared_tolerance: float = 0.0,
) -> GeneralCircleDiagnostics:
    """Genel çember denklemini merkez-yarıçap verisine dönüştürür.

    ``coefficients`` sırası ``(A, D, E, F)`` olup denklem
    ``A*(x**2+y**2)+D*x+E*y+F=0`` biçimindedir. ``A`` sıfır olamaz.
    ``radius_squared_tolerance`` uzunluk karesi birimindedir ve yalnız
    sıfıra yakın reel/boş yer sınıflandırmasını belirler.
    """

    values = _finite_array(coefficients, name="coefficients")
    if values.shape != (4,):
        raise ValueError("coefficients, (A, D, E, F) sıralı (4,) biçiminde olmalıdır.")
    if values[0] == 0.0:
        raise ValueError("Genel çember denkleminde A sıfır olamaz.")
    tolerance = _nonnegative_finite(
        radius_squared_tolerance,
        name="radius_squared_tolerance",
    )
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        normalized = values / values[0]
        center = -0.5 * normalized[1:3]
        radius_squared = float(np.dot(center, center) - normalized[3])
    if not np.all(np.isfinite(normalized)) or not np.all(np.isfinite(center)):
        raise OverflowError("Genel çember normalizasyonu sayı aralığını aşıyor.")
    if not np.isfinite(radius_squared):
        raise OverflowError("Yarıçap karesi hesabı sayı aralığını aşıyor.")

    if radius_squared > tolerance:
        locus_type = "circle"
        radius: float | None = float(np.sqrt(radius_squared))
    elif radius_squared < -tolerance:
        locus_type = "empty"
        radius = None
    else:
        locus_type = "point"
        radius = 0.0

    return GeneralCircleDiagnostics(
        normalized_coefficients=normalized,
        center=center,
        radius_squared=radius_squared,
        radius=radius,
        locus_type=locus_type,
        radius_squared_tolerance=tolerance,
    )


@dataclass(frozen=True)
class CircleMembershipDiagnostics:
    """Tek noktanın çembere açık toleranslı üyelik tanısı."""

    center_distance: float
    radial_residual: float
    radial_residual_magnitude: float
    algebraic_residual: float
    algebraic_residual_magnitude: float
    length_threshold: float
    algebraic_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float
    on_circle: bool


def circle_membership_diagnostics(
    center: ArrayLike,
    radius: float,
    point: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> CircleMembershipDiagnostics:
    """Bir noktanın radyal ve cebirsel çember artıklarını raporlar.

    Radyal artık ``||point-center||-radius`` uzunluk, cebirsel artık ise
    ``||point-center||²-radius²`` uzunluk karesi birimindedir. Üyelik kararı
    yalnız radyal artıkla ve ``atol + rtol*reference_scale`` eşiğiyle verilir.
    """

    center_array, radius_value = _circle(center, radius)
    candidate = _plane_point(point, name="point")
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        offset = candidate - center_array
        center_distance = vector_norm(offset)
        radial_residual = center_distance - radius_value
        algebraic_residual = float(np.dot(offset, offset) - radius_value**2)
        algebraic_threshold = threshold * (center_distance + radius_value)
    if not all(
        np.isfinite(value)
        for value in (center_distance, radial_residual, algebraic_residual, algebraic_threshold)
    ):
        raise OverflowError("Çember üyelik tanısı sayı aralığını aşıyor.")
    return CircleMembershipDiagnostics(
        center_distance=center_distance,
        radial_residual=radial_residual,
        radial_residual_magnitude=abs(radial_residual),
        algebraic_residual=algebraic_residual,
        algebraic_residual_magnitude=abs(algebraic_residual),
        length_threshold=threshold,
        algebraic_threshold=float(algebraic_threshold),
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
        on_circle=bool(abs(radial_residual) <= threshold),
    )


@dataclass(frozen=True)
class CircleLineIntersectionDiagnostics:
    """Bir sonsuz doğru ile çemberin sayısal kesişim tanısı."""

    relation: str
    points: FloatArray
    foot: FloatArray
    center_distance: float
    signed_center_distance: float
    clearance: float
    half_chord_length: float | None
    chord_length: float | None
    line_coefficients: FloatArray
    line_residuals: FloatArray
    radial_residuals: FloatArray
    length_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float


def circle_line_intersections(
    center: ArrayLike,
    radius: float,
    line: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> CircleLineIntersectionDiagnostics:
    """Doğruyu ``disjoint``, ``tangent`` veya ``secant`` olarak sınıflandırır.

    Merkezin doğruya uzaklığı ``d`` ile yarıçap ``r`` karşılaştırılır.
    Kesen durumda yarı kiriş ``sqrt(r²-d²)`` ile bulunur. Tolerans bandındaki
    durumda dikme ayağı yaklaşık tek temas noktası olarak döndürülür; bu karar
    kesin geometrik özdeşlik değil, kaydedilmiş bir sayısal sözleşmedir.
    """

    center_array, radius_value = _circle(center, radius)
    if radius_value == 0.0:
        raise ValueError("Doğru-çember kesişimi için radius pozitif olmalıdır.")
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    canonical = canonical_line_coefficients(line)
    projection = project_point_to_line(canonical, center_array)
    distance = projection.distance
    clearance = distance - radius_value

    if clearance > threshold:
        relation = "disjoint"
        points = np.empty((0, 2), dtype=float)
        half_chord_length: float | None = None
        chord_length: float | None = None
    elif clearance < -threshold:
        relation = "secant"
        with np.errstate(over="ignore", invalid="ignore"):
            radicand = radius_value**2 - distance**2
        if not np.isfinite(radicand):
            raise OverflowError("Kiriş uzunluğu hesabı sayı aralığını aşıyor.")
        if radicand < 0.0:
            raise ArithmeticError("Kesen sınıfında negatif kiriş radikandı oluştu.")
        half_chord_length = float(np.sqrt(radicand))
        chord_length = 2.0 * half_chord_length
        direction = line_direction(canonical)
        points = np.vstack(
            [
                projection.foot - half_chord_length * direction,
                projection.foot + half_chord_length * direction,
            ]
        )
    else:
        relation = "tangent"
        points = projection.foot.reshape(1, 2)
        half_chord_length = 0.0
        chord_length = 0.0

    with np.errstate(over="ignore", invalid="ignore"):
        line_residual_values = points @ canonical[:2] + canonical[2]
        radial_residual_values = np.linalg.norm(points - center_array, axis=1) - radius_value
    if not np.all(np.isfinite(points)) or not np.all(np.isfinite(line_residual_values)):
        raise OverflowError("Doğru-çember kesişim noktaları sayı aralığını aşıyor.")
    if not np.all(np.isfinite(radial_residual_values)):
        raise OverflowError("Doğru-çember radyal artıkları sayı aralığını aşıyor.")

    return CircleLineIntersectionDiagnostics(
        relation=relation,
        points=points,
        foot=projection.foot,
        center_distance=distance,
        signed_center_distance=projection.signed_distance,
        clearance=clearance,
        half_chord_length=half_chord_length,
        chord_length=chord_length,
        line_coefficients=canonical,
        line_residuals=line_residual_values,
        radial_residuals=radial_residual_values,
        length_threshold=threshold,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
    )


def tangent_line_at_circle_point(
    center: ArrayLike,
    radius: float,
    point: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> FloatArray:
    """Çember üzerindeki noktadan geçen kanonik teğet doğrusunu kurar."""

    center_array, radius_value = _circle(center, radius)
    if radius_value == 0.0:
        raise ValueError("Nokta çemberin tek bir teğet doğrusu yoktur.")
    candidate = _plane_point(point, name="point")
    membership = circle_membership_diagnostics(
        center_array,
        radius_value,
        candidate,
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    if not membership.on_circle:
        raise ValueError("point, verilen tolerans altında çember üzerinde değildir.")
    normal = candidate - center_array
    with np.errstate(over="ignore", invalid="ignore"):
        offset = -float(np.dot(normal, candidate))
    if not np.isfinite(offset):
        raise OverflowError("Teğet doğrusu katsayıları sayı aralığını aşıyor.")
    return canonical_line_coefficients([normal[0], normal[1], offset])


@dataclass(frozen=True)
class TangentPointsDiagnostics:
    """Bir noktadan çembere çizilen reel teğetlerin temas noktaları."""

    relation: str
    points: FloatArray
    center_distance: float
    tangent_length: float | None
    length_threshold: float
    radial_residuals: FloatArray
    orthogonality_residuals: FloatArray


def tangent_points_from_point(
    center: ArrayLike,
    radius: float,
    point: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> TangentPointsDiagnostics:
    """Dış, sınır veya iç noktadan reel temas noktalarını hesaplar.

    Sonuç ``outside`` için iki, ``on_circle`` için bir, ``inside`` için sıfır
    temas noktası içerir. Teğet uzunluğu dış noktada ``sqrt(rho²-r²)`` olur;
    burada ``rho`` noktanın merkeze uzaklığıdır.
    """

    center_array, radius_value = _circle(center, radius)
    if radius_value == 0.0:
        raise ValueError("Teğet noktaları için radius pozitif olmalıdır.")
    candidate = _plane_point(point, name="point")
    _, _, _, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        displacement = candidate - center_array
        center_distance = vector_norm(displacement)
        clearance = center_distance - radius_value
    if not np.isfinite(clearance):
        raise OverflowError("Teğet noktası sınıflandırması sayı aralığını aşıyor.")

    if clearance < -threshold:
        relation = "inside"
        points = np.empty((0, 2), dtype=float)
        tangent_length: float | None = None
    elif clearance <= threshold:
        relation = "on_circle"
        if center_distance == 0.0:
            raise ArithmeticError("Sınır sınıfında sıfır merkez uzaklığı oluştu.")
        points = (center_array + radius_value * displacement / center_distance).reshape(1, 2)
        tangent_length = 0.0
    else:
        relation = "outside"
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            distance_squared = center_distance**2
            tangent_squared = distance_squared - radius_value**2
            base = center_array + (radius_value**2 / distance_squared) * displacement
            perpendicular = np.array([-displacement[1], displacement[0]], dtype=float)
            factor = radius_value * np.sqrt(tangent_squared) / distance_squared
            points = np.vstack([base - factor * perpendicular, base + factor * perpendicular])
            tangent_length = float(np.sqrt(tangent_squared))

    with np.errstate(over="ignore", invalid="ignore"):
        radial_residuals = np.linalg.norm(points - center_array, axis=1) - radius_value
        orthogonality_residuals = np.einsum(
            "ij,ij->i",
            points - center_array,
            candidate - points,
        )
    if not np.all(np.isfinite(points)) or not np.all(np.isfinite(radial_residuals)):
        raise OverflowError("Teğet noktaları veya artıkları sayı aralığını aşıyor.")
    if not np.all(np.isfinite(orthogonality_residuals)):
        raise OverflowError("Teğet diklik artıkları sayı aralığını aşıyor.")
    return TangentPointsDiagnostics(
        relation=relation,
        points=points,
        center_distance=center_distance,
        tangent_length=tangent_length,
        length_threshold=threshold,
        radial_residuals=radial_residuals,
        orthogonality_residuals=orthogonality_residuals,
    )


def polar_line_of_point(
    center: ArrayLike,
    radius: float,
    point: ArrayLike,
    *,
    zero_tolerance: float = 0.0,
) -> FloatArray:
    """``(point-center)·(x-center)=radius²`` kutupsal doğrusunu kurar.

    Kutup merkezle çakışırsa sol taraftaki normal sıfır olur ve sonlu bir
    kutupsal doğru tanımlanamaz. ``zero_tolerance`` bu sayısal çakışma
    kararının uzunluk eşiğidir.
    """

    center_array, radius_value = _circle(center, radius)
    if radius_value == 0.0:
        raise ValueError("Kutupsal doğru için radius pozitif olmalıdır.")
    pole = _plane_point(point, name="point")
    tolerance = _nonnegative_finite(zero_tolerance, name="zero_tolerance")
    with np.errstate(over="ignore", invalid="ignore"):
        normal = pole - center_array
    if vector_norm(normal) <= tolerance:
        raise ValueError("Çember merkezinin sonlu bir kutupsal doğrusu yoktur.")
    with np.errstate(over="ignore", invalid="ignore"):
        offset = -float(np.dot(normal, center_array)) - radius_value**2
    if not np.isfinite(offset):
        raise OverflowError("Kutupsal doğru katsayıları sayı aralığını aşıyor.")
    return canonical_line_coefficients(
        [normal[0], normal[1], offset],
        zero_tolerance=tolerance,
    )


@dataclass(frozen=True)
class RadicalAxisDiagnostics:
    """İki çemberin eşit-kuvvet geometrik yerinin sayısal tanısı.

    ``relation`` alanı farklı merkezlerde ``line``; aynı merkez ve aynı
    yarıçapta ``all_plane``; aynı merkez ve farklı yarıçapta ``empty`` olur.
    ``line_coefficients`` yalnız ``line`` durumunda kanonik ``(a,b,c)``
    doğru katsayılarını içerir.
    """

    relation: str
    line_coefficients: FloatArray | None
    center_distance: float
    radius_difference: float
    length_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float


def radical_axis_diagnostics(
    first_center: ArrayLike,
    first_radius: float,
    second_center: ArrayLike,
    second_radius: float,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> RadicalAxisDiagnostics:
    """İki çemberin radikal eksenini veya eşmerkezli sınırını sınıflandırır.

    Farklı merkezlerde eşit-kuvvet denklemi bir doğrudur. Merkezler verilen
    uzunluk eşiği altında çakışıyorsa yarıçap farkı aynı eşikle sınanır;
    böylece bütün düzlem ile boş geometrik yer sahte bir doğruya çevrilmez.
    """

    first_center_array, first_radius_value = _circle(first_center, first_radius)
    second_center_array, second_radius_value = _circle(second_center, second_radius)
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        center_offset = second_center_array - first_center_array
        center_distance = vector_norm(center_offset)
        radius_difference = abs(first_radius_value - second_radius_value)
    if not np.isfinite(center_distance) or not np.isfinite(radius_difference):
        raise OverflowError("Radikal eksen sınıflandırması sayı aralığını aşıyor.")

    if center_distance <= threshold:
        relation = "all_plane" if radius_difference <= threshold else "empty"
        line_coefficients: FloatArray | None = None
    else:
        with np.errstate(over="ignore", invalid="ignore"):
            normal = 2.0 * center_offset
            offset = float(
                np.dot(first_center_array, first_center_array)
                - first_radius_value**2
                - np.dot(second_center_array, second_center_array)
                + second_radius_value**2
            )
        if not np.all(np.isfinite(normal)) or not np.isfinite(offset):
            raise OverflowError("Radikal eksen katsayıları sayı aralığını aşıyor.")
        line_coefficients = canonical_line_coefficients(
            [normal[0], normal[1], offset]
        )
        relation = "line"

    return RadicalAxisDiagnostics(
        relation=relation,
        line_coefficients=line_coefficients,
        center_distance=center_distance,
        radius_difference=radius_difference,
        length_threshold=threshold,
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
    )


@dataclass(frozen=True)
class RadicalCenterDiagnostics:
    """Üç çemberin ortak eşit-kuvvet geometrik yerinin tanısı.

    ``relation`` alanı ``point``, ``line``, ``all_plane`` veya ``empty``
    değerlerinden biridir. Yalnız ``point`` durumunda ``point`` ve güç
    denetimleri; yalnız ``line`` durumunda ``line_coefficients`` doludur.
    """

    relation: str
    point: FloatArray | None
    line_coefficients: FloatArray | None
    pairwise_relations: tuple[str, str, str]
    pairwise_lines: tuple[FloatArray | None, FloatArray | None, FloatArray | None]
    axis_residuals: FloatArray | None
    power_values: FloatArray | None
    power_spread: float | None
    condition_number: float | None
    max_axis_residual: float | None
    angular_tolerance: float
    length_threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float


def radical_center_diagnostics(
    centers: ArrayLike,
    radii: ArrayLike,
    *,
    angular_tolerance: float,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> RadicalCenterDiagnostics:
    """Üç çemberin ortak kuvvet geometrik yerini sınıflandırır.

    İkişerli radikal eksenler kanonik doğrulara dönüştürülür. İki bağımsız
    eksen tek bir radikal merkez; yalnız bir bağımsız eksen bir doğru;
    çelişkili paralel eksenler boş geometrik yer üretir. Üç özdeş çemberde
    eşit-kuvvet koşulu bütün düzlemde sağlanır.
    """

    center_values = _finite_array(centers, name="centers")
    radius_values = _finite_array(radii, name="radii")
    if center_values.shape != (3, 2):
        raise ValueError("centers, üç düzlem merkezi için (3, 2) biçiminde olmalıdır.")
    if radius_values.shape != (3,):
        raise ValueError("radii, üç yarıçap için (3,) biçiminde olmalıdır.")
    if np.any(radius_values < 0.0):
        raise ValueError("radii negatif olmayan sayılardan oluşmalıdır.")
    angular = _nonnegative_finite(angular_tolerance, name="angular_tolerance")
    if angular >= 1.0:
        raise ValueError("angular_tolerance [0, 1) aralığında olmalıdır.")
    absolute, relative, scale, threshold = _length_threshold(
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        reference_scale=reference_scale,
    )

    pairs = ((0, 1), (0, 2), (1, 2))
    axes = tuple(
        radical_axis_diagnostics(
            center_values[i],
            float(radius_values[i]),
            center_values[j],
            float(radius_values[j]),
            absolute_tolerance=absolute,
            relative_tolerance=relative,
            reference_scale=scale,
        )
        for i, j in pairs
    )
    pairwise_relations = tuple(axis.relation for axis in axes)
    pairwise_lines = tuple(axis.line_coefficients for axis in axes)

    def result(
        relation: str,
        *,
        point: FloatArray | None = None,
        line: FloatArray | None = None,
        residuals: FloatArray | None = None,
        powers: FloatArray | None = None,
        condition_number: float | None = None,
    ) -> RadicalCenterDiagnostics:
        if residuals is None:
            max_residual: float | None = None
        else:
            max_residual = float(np.max(np.abs(residuals), initial=0.0))
        if powers is None:
            power_spread: float | None = None
        else:
            power_spread = float(np.max(powers) - np.min(powers))
        return RadicalCenterDiagnostics(
            relation=relation,
            point=point,
            line_coefficients=line,
            pairwise_relations=pairwise_relations,
            pairwise_lines=pairwise_lines,
            axis_residuals=residuals,
            power_values=powers,
            power_spread=power_spread,
            condition_number=condition_number,
            max_axis_residual=max_residual,
            angular_tolerance=angular,
            length_threshold=threshold,
            absolute_tolerance=absolute,
            relative_tolerance=relative,
            reference_scale=scale,
        )

    if "empty" in pairwise_relations:
        return result("empty")

    lines = [line for line in pairwise_lines if line is not None]
    if not lines:
        return result("all_plane")

    base = lines[0]
    candidate: FloatArray | None = None
    condition_number: float | None = None
    for line in lines[1:]:
        intersection = line_intersection_diagnostics(
            base,
            line,
            angular_tolerance=angular,
            absolute_tolerance=absolute,
            relative_tolerance=relative,
            reference_scale=scale,
        )
        if intersection.relation == "parallel":
            return result("empty")
        if intersection.relation == "intersecting":
            candidate = intersection.point
            condition_number = intersection.condition_number
            break

    if candidate is None:
        return result("line", line=base)

    line_array = np.vstack(lines)
    with np.errstate(over="ignore", invalid="ignore"):
        residuals = line_array[:, :2] @ candidate + line_array[:, 2]
        powers = np.array(
            [
                point_power(center_values[i], float(radius_values[i]), candidate)
                for i in range(3)
            ],
            dtype=float,
        )
    if not np.all(np.isfinite(residuals)) or not np.all(np.isfinite(powers)):
        raise OverflowError("Radikal merkez denetimi sayı aralığını aşıyor.")
    if float(np.max(np.abs(residuals), initial=0.0)) > threshold:
        return result("empty", residuals=residuals, powers=powers)
    return result(
        "point",
        point=candidate,
        residuals=residuals,
        powers=powers,
        condition_number=condition_number,
    )


def circle_pencil_member(
    first_coefficients: ArrayLike,
    second_coefficients: ArrayLike,
    parameter: float,
    *,
    radius_squared_tolerance: float = 0.0,
) -> GeneralCircleDiagnostics:
    """İki genel çemberin ölçekten bağımsız afin demet üyesini kurar.

    Her denklem önce ``x²+y²`` katsayısı bir olacak biçimde normalize edilir.
    Sonra ``S_t=(1-t)S_1+tS_2`` birleşimi alınır. Bu nedenle giriş
    denklemlerinin ayrı ayrı sıfır olmayan katsayılarla çarpılması sonucu
    değiştirmez. Üye normal çember, nokta çember veya boş reel yer olabilir.
    """

    first = general_circle_diagnostics(first_coefficients)
    second = general_circle_diagnostics(second_coefficients)
    parameter_value = _finite_scalar(parameter, name="parameter")
    tolerance = _nonnegative_finite(
        radius_squared_tolerance,
        name="radius_squared_tolerance",
    )
    with np.errstate(over="ignore", invalid="ignore"):
        coefficients = (
            (1.0 - parameter_value) * first.normalized_coefficients
            + parameter_value * second.normalized_coefficients
        )
    if not np.all(np.isfinite(coefficients)):
        raise OverflowError("Çember demeti katsayıları sayı aralığını aşıyor.")
    return general_circle_diagnostics(
        coefficients,
        radius_squared_tolerance=tolerance,
    )
