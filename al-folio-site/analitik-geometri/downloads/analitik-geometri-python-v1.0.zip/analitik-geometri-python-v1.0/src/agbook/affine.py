"""Bölüm 8 için düzlemsel afin dönüşüm hesapları.

Matematiksel metinde noktalar sütun vektördür. Python API'sinde tek nokta
``(2,)``, çoklu noktalar ise satırları nokta olan ``(n, 2)`` dizileridir.
Genel afin dönüşümün doğrusal kısmı tekil olabilir; yalnız ters alma işlemi
tersinirlik gerektirir.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array, _point


def _plane_points(value: ArrayLike, *, name: str) -> FloatArray:
    points = _finite_array(value, name=name)
    if points.ndim == 1:
        if points.shape != (2,):
            raise ValueError(f"{name}, (2,) biçiminde tek nokta olmalıdır.")
    elif points.ndim == 2:
        if points.shape[0] == 0 or points.shape[1] != 2:
            raise ValueError(
                f"{name}, (n, 2) biçiminde boş olmayan bir nokta dizisi olmalıdır."
            )
    else:
        raise ValueError(f"{name}, (2,) veya (n, 2) biçiminde olmalıdır.")
    return points


def _affine_inputs(
    matrix: ArrayLike,
    translation: ArrayLike,
) -> tuple[FloatArray, FloatArray]:
    linear = _finite_array(matrix, name="matrix")
    shift = _point(translation, name="translation")
    if linear.shape != (2, 2) or shift.shape != (2,):
        raise ValueError(
            "Düzlemsel afin dönüşüm için matrix (2, 2), translation (2,) biçiminde olmalıdır."
        )
    return linear, shift


def _nonnegative_tolerance(value: float, *, name: str) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or tolerance < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return tolerance


@dataclass(frozen=True)
class AffineMap2D:
    """``F(x)=A*x+b`` dönüşümünün doğrusal ve öteleme bileşenleri."""

    matrix: FloatArray
    translation: FloatArray

    @property
    def determinant(self) -> float:
        """Doğrusal kısmın yönlü alan ölçeğini döndürür."""

        return float(np.linalg.det(self.matrix))

    @property
    def rank(self) -> int:
        """Doğrusal kısmın NumPy varsayılan eşiğindeki sayısal rankını döndürür."""

        return int(np.linalg.matrix_rank(self.matrix))

    @property
    def condition_number(self) -> float:
        """Doğrusal kısmın 2-norm koşul sayısını döndürür."""

        return float(np.linalg.cond(self.matrix))


def apply_affine_map(
    points: ArrayLike,
    matrix: ArrayLike,
    translation: ArrayLike,
) -> FloatArray:
    """Noktalara ``F(x)=A*x+b`` afin dönüşümünü uygular.

    Çoklu noktalar satırlarda tutulduğu için kod işlemi
    ``points @ matrix.T + translation`` biçimindedir. ``matrix`` tekil
    olabilir; işlev yalnız görüntüyü hesaplar ve tersinirlik varsaymaz.
    """

    point_array = _plane_points(points, name="points")
    linear, shift = _affine_inputs(matrix, translation)
    transformed = point_array @ linear.T + shift
    if not np.all(np.isfinite(transformed)):
        raise ValueError("Afin dönüşüm sonlu olmayan bir çıktı üretti.")
    return transformed


def compose_affine_maps(
    matrix_after: ArrayLike,
    translation_after: ArrayLike,
    matrix_before: ArrayLike,
    translation_before: ArrayLike,
) -> AffineMap2D:
    """Önce ``before``, sonra ``after`` dönüşümünün bileşimini döndürür."""

    after_linear, after_shift = _affine_inputs(matrix_after, translation_after)
    before_linear, before_shift = _affine_inputs(matrix_before, translation_before)
    matrix = after_linear @ before_linear
    translation = after_linear @ before_shift + after_shift
    if not np.all(np.isfinite(matrix)) or not np.all(np.isfinite(translation)):
        raise ValueError("Afin dönüşüm bileşimi sonlu olmayan katsayı üretti.")
    return AffineMap2D(matrix=matrix, translation=translation)


def inverse_affine_map(
    matrix: ArrayLike,
    translation: ArrayLike,
    *,
    singular_tolerance: float = 0.0,
) -> AffineMap2D:
    """Tersinir ``F(x)=A*x+b`` dönüşümünün tersini kurar.

    ``singular_tolerance`` determinant için mutlak ve ölçeğe bağlı bir
    eşiktir. ``abs(det(A))`` bu eşikten büyük değilse ters alma reddedilir.
    """

    linear, shift = _affine_inputs(matrix, translation)
    tolerance = _nonnegative_tolerance(
        singular_tolerance,
        name="singular_tolerance",
    )
    determinant = float(np.linalg.det(linear))
    if not np.isfinite(determinant):
        raise ValueError("matrix determinantı sonlu olmalıdır.")
    if abs(determinant) <= tolerance:
        raise ValueError("Afin dönüşüm verilen eşikte tekildir; tersi yoktur.")
    try:
        inverse_matrix = np.linalg.inv(linear)
    except np.linalg.LinAlgError as error:
        raise ValueError("Afin dönüşüm tekildir; tersi yoktur.") from error
    inverse_translation = -(inverse_matrix @ shift)
    if not np.all(np.isfinite(inverse_matrix)) or not np.all(
        np.isfinite(inverse_translation)
    ):
        raise ValueError("Afin dönüşümün tersi sonlu olmayan katsayı üretti.")
    return AffineMap2D(
        matrix=inverse_matrix,
        translation=inverse_translation,
    )


def homogeneous_affine_matrix(
    matrix: ArrayLike,
    translation: ArrayLike,
) -> FloatArray:
    """Düzlemsel afin dönüşümün ``3 x 3`` homojen matrisini kurar."""

    linear, shift = _affine_inputs(matrix, translation)
    homogeneous = np.eye(3, dtype=float)
    homogeneous[:2, :2] = linear
    homogeneous[:2, 2] = shift
    return homogeneous
