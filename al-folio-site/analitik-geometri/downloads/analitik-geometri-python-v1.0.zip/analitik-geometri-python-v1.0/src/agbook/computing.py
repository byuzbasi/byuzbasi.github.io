"""Bölüm 4 için dizi, tolerans ve yeniden üretilebilirlik yardımcıları.

Bu modül geometrik bir nesnenin sayısal temsilini açık tutar: nokta
kümeleri ``(n, d)`` biçimindedir, karşılaştırma toleranslarının birimleri
zorunlu olarak belirtilir ve fiziksel kabul kararı sayısal eşitlikten ayrı
tutulur. Bütün girdiler sonlu reel sayılara dönüştürülür; sessiz NumPy
yayınlamasına izin verilmez.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import ArrayLike

from .foundations import FloatArray, _finite_array, _same_dimension
from .vectors import vector_norm


ToleranceClass = Literal["accept", "review", "reject"]


def _nonnegative_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} sonlu ve negatif olmayan bir sayı olmalıdır.")
    return number


def _relative_tolerance(value: float) -> float:
    tolerance = _nonnegative_finite(value, name="relative_tolerance")
    if tolerance >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _point_cloud(value: ArrayLike, *, name: str) -> FloatArray:
    points = _finite_array(value, name=name)
    if points.ndim != 2 or points.shape[0] == 0 or points.shape[1] == 0:
        raise ValueError(f"{name}, (n, d) biçiminde boş olmayan bir nokta dizisi olmalıdır.")
    return points


def _finite_differences(first: FloatArray, second: FloatArray) -> FloatArray:
    with np.errstate(over="ignore", invalid="ignore"):
        differences = first - second
    if not np.all(np.isfinite(differences)):
        raise OverflowError("Koordinat farkı kayan noktalı sayı aralığını aşıyor.")
    return differences


def _row_norms(vectors: FloatArray) -> FloatArray:
    """Son eksen boyunca taşmaya daha dayanıklı Öklid normları."""

    scales = np.max(np.abs(vectors), axis=-1)
    ratios = np.divide(
        vectors,
        scales[..., None],
        out=np.zeros_like(vectors),
        where=scales[..., None] != 0.0,
    )
    with np.errstate(over="ignore", invalid="ignore"):
        norms = scales * np.sqrt(np.sum(ratios * ratios, axis=-1))
    if not np.all(np.isfinite(norms)):
        raise OverflowError("Öklid normu kayan noktalı sayı aralığını aşıyor.")
    return norms


def pairwise_distances(points: ArrayLike) -> FloatArray:
    """Satırları nokta olan dizinin ikili Öklid uzaklık matrisini döndürür.

    Girdi ``(n, d)``, çıktı ``(n, n)`` biçimindedir. İşlev yalnız aynı nokta
    kümesi içindeki uzaklıkları hesaplar; bir boyutlu girdiyi nokta bulutu
    saymaz ve yayınlama yoluyla anlam tahmin etmez.
    """

    point_array = _point_cloud(points, name="points")
    differences = _finite_differences(
        point_array[:, None, :],
        point_array[None, :, :],
    )
    distances = _row_norms(differences)
    np.fill_diagonal(distances, 0.0)
    return distances


@dataclass(frozen=True)
class GeometricComparison:
    """İki nokta arasındaki açık ölçekli sayısal karşılaştırma."""

    distance: float
    threshold: float
    absolute_tolerance: float
    relative_tolerance: float
    reference_scale: float
    close: bool


def geometric_close(
    a: ArrayLike,
    b: ArrayLike,
    *,
    absolute_tolerance: float,
    relative_tolerance: float,
    reference_scale: float,
) -> GeometricComparison:
    """İki noktayı ``atol + rtol * scale`` eşiğiyle karşılaştırır.

    ``absolute_tolerance`` ve ``reference_scale`` koordinatlarla aynı
    birimdedir; ``relative_tolerance`` boyutsuzdur. Referans ölçeği iki
    noktadan bağımsız verildiği için karşılaştırma ``a`` ve ``b`` açısından
    simetriktir. Hiçbir tolerans için sessiz varsayılan kullanılmaz.
    """

    point_a, point_b = _same_dimension(a, b)
    absolute = _nonnegative_finite(absolute_tolerance, name="absolute_tolerance")
    relative = _relative_tolerance(relative_tolerance)
    scale = _nonnegative_finite(reference_scale, name="reference_scale")
    difference = _finite_differences(point_a, point_b)
    distance = vector_norm(difference)
    with np.errstate(over="ignore", invalid="ignore"):
        threshold = absolute + relative * scale
    if not np.isfinite(threshold):
        raise OverflowError("Karşılaştırma eşiği kayan noktalı sayı aralığını aşıyor.")
    return GeometricComparison(
        distance=distance,
        threshold=float(threshold),
        absolute_tolerance=absolute,
        relative_tolerance=relative,
        reference_scale=scale,
        close=bool(distance <= threshold),
    )


@dataclass(frozen=True)
class PointSetToleranceDiagnostics:
    """Nominal ve gözlenen nokta kümeleri için fiziksel kabul tanısı."""

    point_errors: FloatArray
    point_classifications: tuple[ToleranceClass, ...]
    overall_classification: ToleranceClass
    specification_limit: float
    measurement_uncertainty: float
    worst_error: float
    worst_index: int


def point_set_tolerance_diagnostics(
    nominal: ArrayLike,
    observed: ArrayLike,
    *,
    specification_limit: float,
    measurement_uncertainty: float,
) -> PointSetToleranceDiagnostics:
    """Nokta hatalarını kabul, inceleme veya ret olarak sınıflandırır.

    İki dizi tam olarak aynı ``(n, d)`` biçiminde ve aynı fiziksel birimde
    olmalıdır. ``T`` şartname sınırı, ``u`` ölçüm belirsizliği ve ``d_i``
    i'inci nokta hatası olmak üzere ``d_i + u <= T`` kabul,
    ``d_i - u > T`` ret, aradaki durum incelemedir. Bu fiziksel karar
    toleransı, kayan noktalı eşitlik toleransı değildir.
    """

    nominal_points = _point_cloud(nominal, name="nominal")
    observed_points = _point_cloud(observed, name="observed")
    if nominal_points.shape != observed_points.shape:
        raise ValueError("nominal ve observed tam olarak aynı (n, d) biçiminde olmalıdır.")
    limit = _nonnegative_finite(specification_limit, name="specification_limit")
    uncertainty = _nonnegative_finite(
        measurement_uncertainty,
        name="measurement_uncertainty",
    )
    errors = _row_norms(_finite_differences(observed_points, nominal_points))
    classifications: list[ToleranceClass] = []
    for error in errors:
        upper = float(error) + uncertainty
        lower = float(error) - uncertainty
        if not np.isfinite(upper):
            raise OverflowError("Hata ile belirsizlik toplamı sayı aralığını aşıyor.")
        if upper <= limit:
            classifications.append("accept")
        elif lower > limit:
            classifications.append("reject")
        else:
            classifications.append("review")

    if "reject" in classifications:
        overall: ToleranceClass = "reject"
    elif "review" in classifications:
        overall = "review"
    else:
        overall = "accept"
    worst_index = int(np.argmax(errors))
    return PointSetToleranceDiagnostics(
        point_errors=errors,
        point_classifications=tuple(classifications),
        overall_classification=overall,
        specification_limit=limit,
        measurement_uncertainty=uncertainty,
        worst_error=float(errors[worst_index]),
        worst_index=worst_index,
    )


def canonical_array_sha256(value: ArrayLike) -> str:
    """Sonlu bir sayısal dizinin kanonik binary64 SHA-256 özetini verir.

    Değerler önce kitabın hesaplama türü olan IEEE 754 binary64'e,
    ardından küçük sonlu C-sıralı bayt dizisine dönüştürülür. Dizi şekli
    özete katılır; böylece aynı sayıları farklı şekillerde taşıyan diziler
    aynı imzayı üretmez. Özet kaynak metninin değil, hesapta kullanılan
    sayısal temsilin kimliğidir.
    """

    array = _finite_array(value, name="value")
    if array.size == 0:
        raise ValueError("value boş olmayan bir sayısal dizi olmalıdır.")
    canonical = np.ascontiguousarray(array.astype(np.dtype("<f8"), copy=False))
    shape = ",".join(str(length) for length in canonical.shape)
    header = f"agbook-float64-v1|shape={shape}|".encode("ascii")
    digest = hashlib.sha256()
    digest.update(header)
    digest.update(canonical.tobytes(order="C"))
    return digest.hexdigest()
