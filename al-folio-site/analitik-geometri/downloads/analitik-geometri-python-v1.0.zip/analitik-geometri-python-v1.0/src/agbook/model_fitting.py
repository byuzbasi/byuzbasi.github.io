"""Geometrik modeller için ölçek-duyarlı olmayan sayısal uydurma araçları.

Bu modül doğru, çember, konik ve kuadrik uydurmayı tek bir açık protokolde
toplar: girdiyi doğrula, izotropik olarak normalleştir, QR/SVD tabanlı modeli
kur, özgün koordinatlara dön ve rank/artık tanılarını raporla. Eksik değerler
sessizce doldurulmaz; hiçbir gözlem kendiliğinden çıkarılmaz.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike
from scipy.optimize import least_squares

from .foundations import FloatArray, _finite_array
from .quadratic_conics import QuadraticConicDiagnostics, quadratic_conic_diagnostics
from .quadrics import QuadricDiagnostics, quadric_diagnostics


@dataclass(frozen=True)
class PointNormalization:
    """İzotropik benzerlik normalizasyonunun bütün tersinir bileşenleri."""

    points: FloatArray
    center: FloatArray
    scale: float
    rms_radius: float
    transform: FloatArray
    inverse_transform: FloatArray


@dataclass(frozen=True)
class DesignDiagnostics:
    """Bir tasarım matrisinin SVD tabanlı sayısal tanısı."""

    singular_values: FloatArray
    effective_rank: int
    relative_tolerance: float
    decision_threshold: float
    condition_number: float
    nullspace_gap: float | None


@dataclass(frozen=True)
class LineFitResult:
    """İki boyutlu toplam en küçük kareler doğru uydurması."""

    point: FloatArray
    direction: FloatArray
    normal: FloatArray
    coefficients: FloatArray
    orthogonal_residuals: FloatArray
    rms_orthogonal: float
    diagnostics: DesignDiagnostics
    normalization: PointNormalization


@dataclass(frozen=True)
class VerticalLineFitResult:
    """Dikey artık kullanan ``y = slope*x + intercept`` uydurması."""

    slope: float
    intercept: float
    vertical_residuals: FloatArray
    rms_vertical: float
    diagnostics: DesignDiagnostics


@dataclass(frozen=True)
class CircleFitResult:
    """Cebirsel başlangıçlı geometrik çember uydurmasının sonucu."""

    center: FloatArray
    radius: float
    algebraic_center: FloatArray
    algebraic_radius: float
    signed_radial_residuals: FloatArray
    rms_geometric: float
    initial_sum_squares: float
    final_sum_squares: float
    loss: str
    loss_scale: float | None
    success: bool
    iterations: int
    measurement_sigma: float | None
    covariance: FloatArray | None
    standard_errors: FloatArray | None
    diagnostics: DesignDiagnostics
    normalization: PointNormalization


@dataclass(frozen=True)
class ImplicitResidualDiagnostics:
    """Örtük polinom için birinci mertebe uzaklık yaklaşımı."""

    algebraic_residuals: FloatArray
    gradient_norms: FloatArray
    approximate_signed_distances: FloatArray
    valid: np.ndarray
    gradient_tolerance: float


@dataclass(frozen=True)
class ConicFitResult:
    """Altı katsayılı örtük konik uydurması ve tanıları."""

    coefficients: FloatArray
    method: str
    algebraic_residuals: FloatArray
    first_order_residuals: ImplicitResidualDiagnostics
    diagnostics: DesignDiagnostics
    conic_diagnostics: QuadraticConicDiagnostics
    normalization: PointNormalization


@dataclass(frozen=True)
class QuadricFitResult:
    """On katsayılı örtük kuadrik uydurması ve tanıları."""

    coefficients: FloatArray
    algebraic_residuals: FloatArray
    first_order_residuals: ImplicitResidualDiagnostics
    diagnostics: DesignDiagnostics
    quadric_diagnostics: QuadricDiagnostics
    normalization: PointNormalization


def _relative_tolerance(value: float) -> float:
    tolerance = float(value)
    if not np.isfinite(tolerance) or tolerance < 0.0 or tolerance >= 1.0:
        raise ValueError("relative_tolerance [0, 1) aralığında olmalıdır.")
    return tolerance


def _positive_finite(value: float, *, name: str) -> float:
    number = float(value)
    if not np.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} sonlu ve pozitif olmalıdır.")
    return number


def _point_rows(
    value: ArrayLike,
    *,
    dimensions: tuple[int, ...],
    minimum_rows: int,
    name: str = "points",
) -> FloatArray:
    points = _finite_array(value, name=name)
    if points.ndim != 2 or points.shape[1] not in dimensions:
        choices = " veya ".join(f"(n, {dimension})" for dimension in dimensions)
        raise ValueError(f"{name}, {choices} biçiminde olmalıdır.")
    if points.shape[0] < minimum_rows:
        raise ValueError(f"{name} en az {minimum_rows} satır içermelidir.")
    return points.copy()


def _canonical_vector(vector: ArrayLike) -> FloatArray:
    result = np.asarray(vector, dtype=float).copy()
    norm = float(np.linalg.norm(result))
    if norm == 0.0 or not np.isfinite(norm):
        raise ValueError("Sıfır veya sonlu olmayan katsayı vektörü kanonikleştirilemez.")
    result /= norm
    pivot = int(np.argmax(np.abs(result)))
    if result[pivot] < 0.0:
        result *= -1.0
    return result


def _design_diagnostics(
    matrix: FloatArray,
    *,
    relative_tolerance: float,
) -> DesignDiagnostics:
    tolerance = _relative_tolerance(relative_tolerance)
    singular_values = np.linalg.svd(matrix, compute_uv=False)
    largest = float(singular_values[0]) if singular_values.size else 0.0
    threshold = tolerance * largest
    rank = int(np.count_nonzero(singular_values > threshold))
    if singular_values.size == 0 or singular_values[-1] <= threshold:
        condition = float("inf")
    else:
        condition = largest / float(singular_values[-1])
    gap: float | None = None
    if singular_values.size >= 2:
        smallest = float(singular_values[-1])
        gap = (
            float("inf")
            if smallest <= np.finfo(float).tiny
            else float(singular_values[-2] / smallest)
        )
    return DesignDiagnostics(
        singular_values=singular_values,
        effective_rank=rank,
        relative_tolerance=tolerance,
        decision_threshold=threshold,
        condition_number=condition,
        nullspace_gap=gap,
    )


def normalize_points_isotropic(points: ArrayLike) -> PointNormalization:
    """Noktaları sıfır merkezli ve RMS yarıçapı ``sqrt(d)`` olacak ölçekler.

    Girdi ``(n, 2)`` veya ``(n, 3)`` biçimindedir. Dönüşüm homojen
    koordinatlarda ``x_normalized = T @ x`` eşitliğini sağlar.
    """

    rows = _point_rows(points, dimensions=(2, 3), minimum_rows=2)
    dimension = rows.shape[1]
    center = np.mean(rows, axis=0)
    centered = rows - center
    rms_radius = float(np.sqrt(np.mean(np.sum(centered * centered, axis=1))))
    if not np.isfinite(rms_radius) or rms_radius <= np.finfo(float).tiny:
        raise ValueError("Nokta kümesinin izotropik normalizasyon için yayılımı yoktur.")
    scale = float(np.sqrt(dimension) / rms_radius)
    normalized = scale * centered
    transform = np.eye(dimension + 1)
    transform[:dimension, :dimension] *= scale
    transform[:dimension, dimension] = -scale * center
    inverse = np.eye(dimension + 1)
    inverse[:dimension, :dimension] /= scale
    inverse[:dimension, dimension] = center
    return PointNormalization(
        points=normalized,
        center=center,
        scale=scale,
        rms_radius=rms_radius,
        transform=transform,
        inverse_transform=inverse,
    )


def fit_line_tls(
    points: ArrayLike,
    *,
    relative_tolerance: float = 1e-12,
) -> LineFitResult:
    """Bir doğruyu iki koordinata da dik artıklarla SVD üzerinden uydurur."""

    rows = _point_rows(points, dimensions=(2,), minimum_rows=2)
    normalization = normalize_points_isotropic(rows)
    _, _, right_vectors = np.linalg.svd(normalization.points, full_matrices=False)
    diagnostics = _design_diagnostics(
        normalization.points,
        relative_tolerance=relative_tolerance,
    )
    if diagnostics.effective_rank < 1:
        raise ValueError("Doğru uydurması için en az bir değişim doğrultusu gerekir.")
    direction = _canonical_vector(right_vectors[0])
    normal = np.array([-direction[1], direction[0]], dtype=float)
    normal = _canonical_vector(normal)
    direction = np.array([normal[1], -normal[0]], dtype=float)
    point = normalization.center.copy()
    constant = -float(normal @ point)
    coefficients = np.r_[normal, constant]
    residuals = (rows - point) @ normal
    return LineFitResult(
        point=point,
        direction=direction,
        normal=normal,
        coefficients=coefficients,
        orthogonal_residuals=residuals,
        rms_orthogonal=float(np.sqrt(np.mean(residuals * residuals))),
        diagnostics=diagnostics,
        normalization=normalization,
    )


def fit_line_vertical_ols(
    points: ArrayLike,
    *,
    relative_tolerance: float = 1e-12,
) -> VerticalLineFitResult:
    """Karşılaştırma için yalnız düşey artık kullanan doğruyu uydurur."""

    rows = _point_rows(points, dimensions=(2,), minimum_rows=2)
    design = np.column_stack((rows[:, 0], np.ones(rows.shape[0])))
    diagnostics = _design_diagnostics(design, relative_tolerance=relative_tolerance)
    if diagnostics.effective_rank < 2:
        raise ValueError("Dikey OLS için x koordinatlarında yayılım gerekir.")
    solution, _, _, _ = np.linalg.lstsq(
        design,
        rows[:, 1],
        rcond=_relative_tolerance(relative_tolerance),
    )
    residuals = rows[:, 1] - design @ solution
    return VerticalLineFitResult(
        slope=float(solution[0]),
        intercept=float(solution[1]),
        vertical_residuals=residuals,
        rms_vertical=float(np.sqrt(np.mean(residuals * residuals))),
        diagnostics=diagnostics,
    )


def _circle_algebraic_initial(
    normalization: PointNormalization,
    *,
    relative_tolerance: float,
) -> tuple[FloatArray, float, DesignDiagnostics]:
    points = normalization.points
    design = np.column_stack((points, np.ones(points.shape[0])))
    diagnostics = _design_diagnostics(design, relative_tolerance=relative_tolerance)
    if diagnostics.effective_rank < 3:
        raise ValueError("Çember uydurması için noktalar doğrusal olmamalıdır.")
    target = -np.sum(points * points, axis=1)
    solution, _, _, _ = np.linalg.lstsq(
        design,
        target,
        rcond=_relative_tolerance(relative_tolerance),
    )
    center = -0.5 * solution[:2]
    radius_squared = float(center @ center - solution[2])
    if radius_squared <= np.finfo(float).eps or not np.isfinite(radius_squared):
        raise ValueError("Cebirsel başlangıç pozitif bir çember yarıçapı üretmedi.")
    return center, float(np.sqrt(radius_squared)), diagnostics


def fit_circle_geometric(
    points: ArrayLike,
    *,
    loss: str = "linear",
    loss_scale: float | None = None,
    measurement_sigma: float | None = None,
    relative_tolerance: float = 1e-12,
    max_nfev: int = 1000,
) -> CircleFitResult:
    """Çemberi imzalı radyal artıkların geometrik en küçük kareleriyle uydurur.

    ``loss='linear'`` olağan en küçük karelerdir. ``soft_l1`` veya ``huber``
    ancak aynı uzunluk birimindeki ``loss_scale`` açıkça verilirse kullanılır.
    Kovaryans yalnız doğrusal kayıp ve açık ``measurement_sigma`` altında,
    bağımsız izotropik Gauss koordinat hatalarının yerel yaklaşımıdır.
    """

    rows = _point_rows(points, dimensions=(2,), minimum_rows=3)
    tolerance = _relative_tolerance(relative_tolerance)
    if loss not in {"linear", "soft_l1", "huber"}:
        raise ValueError("loss, 'linear', 'soft_l1' veya 'huber' olmalıdır.")
    if loss == "linear":
        if loss_scale is not None:
            raise ValueError("loss_scale yalnız sağlam kayıpta verilmelidir.")
        normalized_loss_scale = 1.0
    else:
        if loss_scale is None:
            raise ValueError("Sağlam kayıp için loss_scale açıkça verilmelidir.")
        normalized_loss_scale = _positive_finite(loss_scale, name="loss_scale")

    sigma: float | None = None
    if measurement_sigma is not None:
        if loss != "linear":
            raise ValueError("Gauss kovaryansı sağlam kayıpla birlikte raporlanmaz.")
        sigma = _positive_finite(measurement_sigma, name="measurement_sigma")

    evaluations = int(max_nfev)
    if evaluations < 1:
        raise ValueError("max_nfev pozitif bir tam sayı olmalıdır.")

    normalization = normalize_points_isotropic(rows)
    center0_n, radius0_n, diagnostics = _circle_algebraic_initial(
        normalization,
        relative_tolerance=tolerance,
    )
    initial_parameters = np.r_[center0_n, np.log(radius0_n)]

    def residual_function(parameters: FloatArray) -> FloatArray:
        center_n = parameters[:2]
        radius_n = float(np.exp(parameters[2]))
        return np.linalg.norm(normalization.points - center_n, axis=1) - radius_n

    def jacobian_function(parameters: FloatArray) -> FloatArray:
        center_n = parameters[:2]
        radius_n = float(np.exp(parameters[2]))
        offsets = center_n - normalization.points
        distances = np.linalg.norm(offsets, axis=1)
        unit = np.divide(
            offsets,
            distances[:, None],
            out=np.zeros_like(offsets),
            where=distances[:, None] > np.finfo(float).tiny,
        )
        return np.column_stack((unit, -np.full(rows.shape[0], radius_n)))

    if loss != "linear":
        normalized_loss_scale *= normalization.scale
    optimized = least_squares(
        residual_function,
        initial_parameters,
        jac=jacobian_function,
        loss=loss,
        f_scale=normalized_loss_scale,
        x_scale="jac",
        max_nfev=evaluations,
    )
    if not optimized.success:
        raise RuntimeError(f"Geometrik çember uydurması yakınsamadı: {optimized.message}")

    center_n = optimized.x[:2]
    radius_n = float(np.exp(optimized.x[2]))
    center = normalization.center + center_n / normalization.scale
    radius = radius_n / normalization.scale
    algebraic_center = normalization.center + center0_n / normalization.scale
    algebraic_radius = radius0_n / normalization.scale
    residuals = np.linalg.norm(rows - center, axis=1) - radius
    initial_residuals = np.linalg.norm(rows - algebraic_center, axis=1) - algebraic_radius

    covariance: FloatArray | None = None
    standard_errors: FloatArray | None = None
    if sigma is not None:
        offsets = center - rows
        distances = np.linalg.norm(offsets, axis=1)
        unit = np.divide(
            offsets,
            distances[:, None],
            out=np.zeros_like(offsets),
            where=distances[:, None] > np.finfo(float).tiny,
        )
        physical_jacobian = np.column_stack((unit, -np.ones(rows.shape[0])))
        jacobian_diagnostics = _design_diagnostics(
            physical_jacobian,
            relative_tolerance=tolerance,
        )
        if jacobian_diagnostics.effective_rank < 3:
            raise ValueError("Yerel çember kovaryansı için Jacobian tam ranklı değildir.")
        covariance = sigma * sigma * np.linalg.inv(
            physical_jacobian.T @ physical_jacobian
        )
        standard_errors = np.sqrt(np.diag(covariance))

    return CircleFitResult(
        center=center,
        radius=radius,
        algebraic_center=algebraic_center,
        algebraic_radius=algebraic_radius,
        signed_radial_residuals=residuals,
        rms_geometric=float(np.sqrt(np.mean(residuals * residuals))),
        initial_sum_squares=float(initial_residuals @ initial_residuals),
        final_sum_squares=float(residuals @ residuals),
        loss=loss,
        loss_scale=None if loss_scale is None else float(loss_scale),
        success=bool(optimized.success),
        iterations=int(optimized.nfev),
        measurement_sigma=sigma,
        covariance=covariance,
        standard_errors=standard_errors,
        diagnostics=diagnostics,
        normalization=normalization,
    )


def _conic_design(points: FloatArray) -> FloatArray:
    x, y = points.T
    return np.column_stack((x * x, x * y, y * y, x, y, np.ones_like(x)))


def _quadric_design(points: FloatArray) -> FloatArray:
    x, y, z = points.T
    return np.column_stack(
        (
            x * x,
            x * y,
            x * z,
            y * y,
            y * z,
            z * z,
            x,
            y,
            z,
            np.ones_like(x),
        )
    )


def _conic_matrix(coefficients: ArrayLike) -> FloatArray:
    a, b, c, d, e, f = np.asarray(coefficients, dtype=float)
    return np.array(
        [[a, 0.5 * b, 0.5 * d], [0.5 * b, c, 0.5 * e], [0.5 * d, 0.5 * e, f]],
        dtype=float,
    )


def _conic_coefficients(matrix: FloatArray) -> FloatArray:
    matrix = 0.5 * (matrix + matrix.T)
    return np.array(
        [
            matrix[0, 0],
            2.0 * matrix[0, 1],
            matrix[1, 1],
            2.0 * matrix[0, 2],
            2.0 * matrix[1, 2],
            matrix[2, 2],
        ]
    )


def _quadric_matrix(coefficients: ArrayLike) -> FloatArray:
    a, b, c, d, e, f, g, h, i, j = np.asarray(coefficients, dtype=float)
    return np.array(
        [
            [a, 0.5 * b, 0.5 * c, 0.5 * g],
            [0.5 * b, d, 0.5 * e, 0.5 * h],
            [0.5 * c, 0.5 * e, f, 0.5 * i],
            [0.5 * g, 0.5 * h, 0.5 * i, j],
        ],
        dtype=float,
    )


def _quadric_coefficients(matrix: FloatArray) -> FloatArray:
    matrix = 0.5 * (matrix + matrix.T)
    return np.array(
        [
            matrix[0, 0],
            2.0 * matrix[0, 1],
            2.0 * matrix[0, 2],
            matrix[1, 1],
            2.0 * matrix[1, 2],
            matrix[2, 2],
            2.0 * matrix[0, 3],
            2.0 * matrix[1, 3],
            2.0 * matrix[2, 3],
            matrix[3, 3],
        ]
    )


def implicit_first_order_residuals(
    coefficients: ArrayLike,
    points: ArrayLike,
    *,
    gradient_tolerance: float = 1e-12,
) -> ImplicitResidualDiagnostics:
    """Konik/kuadrik için ``q(x)/||grad q(x)||`` yerel yaklaşımını verir.

    Gradyan normu eşiği aşmayan satırlarda uzaklık ``nan`` olur ve ``valid``
    alanı ``False`` döner. Bu nicelik gerçek en kısa uzaklık değil, yalnız
    düzenli noktaların yakınında geçerli birinci mertebe yaklaşımdır.
    """

    tolerance = float(gradient_tolerance)
    if not np.isfinite(tolerance) or tolerance < 0.0:
        raise ValueError("gradient_tolerance sonlu ve negatif olmayan olmalıdır.")
    coefficient_array = _finite_array(coefficients, name="coefficients")
    if coefficient_array.shape == (6,):
        rows = _point_rows(points, dimensions=(2,), minimum_rows=1)
        design = _conic_design(rows)
        a, b, c, d, e, _ = coefficient_array
        gradients = np.column_stack(
            (2.0 * a * rows[:, 0] + b * rows[:, 1] + d,
             b * rows[:, 0] + 2.0 * c * rows[:, 1] + e)
        )
    elif coefficient_array.shape == (10,):
        rows = _point_rows(points, dimensions=(3,), minimum_rows=1)
        design = _quadric_design(rows)
        matrix = _quadric_matrix(coefficient_array)
        gradients = 2.0 * (rows @ matrix[:3, :3].T + matrix[:3, 3])
    else:
        raise ValueError("coefficients, konik için (6,) veya kuadrik için (10,) olmalıdır.")
    algebraic = design @ coefficient_array
    gradient_norms = np.linalg.norm(gradients, axis=1)
    valid = gradient_norms > tolerance
    approximate = np.full(rows.shape[0], np.nan, dtype=float)
    approximate[valid] = algebraic[valid] / gradient_norms[valid]
    return ImplicitResidualDiagnostics(
        algebraic_residuals=algebraic,
        gradient_norms=gradient_norms,
        approximate_signed_distances=approximate,
        valid=valid,
        gradient_tolerance=tolerance,
    )


def _conic_result(
    rows: FloatArray,
    normalization: PointNormalization,
    normalized_coefficients: FloatArray,
    diagnostics: DesignDiagnostics,
    *,
    method: str,
    relative_tolerance: float,
    gradient_tolerance: float,
) -> ConicFitResult:
    normalized_matrix = _conic_matrix(normalized_coefficients)
    world_matrix = normalization.transform.T @ normalized_matrix @ normalization.transform
    coefficients = _canonical_vector(_conic_coefficients(world_matrix))
    algebraic = _conic_design(rows) @ coefficients
    first_order = implicit_first_order_residuals(
        coefficients,
        rows,
        gradient_tolerance=gradient_tolerance,
    )
    conic = quadratic_conic_diagnostics(
        coefficients,
        coordinate_scale=normalization.rms_radius,
        relative_tolerance=relative_tolerance,
    )
    return ConicFitResult(
        coefficients=coefficients,
        method=method,
        algebraic_residuals=algebraic,
        first_order_residuals=first_order,
        diagnostics=diagnostics,
        conic_diagnostics=conic,
        normalization=normalization,
    )


def fit_conic_implicit(
    points: ArrayLike,
    *,
    relative_tolerance: float = 1e-12,
    gradient_tolerance: float = 1e-12,
) -> ConicFitResult:
    """Genel koniği normalize tasarım matrisinin en küçük sağ tekil vektörüyle uydurur."""

    rows = _point_rows(points, dimensions=(2,), minimum_rows=6)
    normalization = normalize_points_isotropic(rows)
    design = _conic_design(normalization.points)
    diagnostics = _design_diagnostics(design, relative_tolerance=relative_tolerance)
    if diagnostics.effective_rank < 5:
        raise ValueError("Konik verisi beş bağımsız katsayı oranını belirlemiyor.")
    _, _, right_vectors = np.linalg.svd(design, full_matrices=False)
    return _conic_result(
        rows,
        normalization,
        right_vectors[-1],
        diagnostics,
        method="homogeneous_svd",
        relative_tolerance=_relative_tolerance(relative_tolerance),
        gradient_tolerance=gradient_tolerance,
    )


def fit_ellipse_direct(
    points: ArrayLike,
    *,
    relative_tolerance: float = 1e-12,
    gradient_tolerance: float = 1e-12,
) -> ConicFitResult:
    """Elipsi Fitzgibbon türü ``4AC-B^2>0`` kısıtıyla doğrudan uydurur."""

    rows = _point_rows(points, dimensions=(2,), minimum_rows=6)
    tolerance = _relative_tolerance(relative_tolerance)
    normalization = normalize_points_isotropic(rows)
    x, y = normalization.points.T
    quadratic_design = np.column_stack((x * x, x * y, y * y))
    affine_design = np.column_stack((x, y, np.ones_like(x)))
    design = np.column_stack((quadratic_design, affine_design))
    diagnostics = _design_diagnostics(design, relative_tolerance=tolerance)
    if diagnostics.effective_rank < 5:
        raise ValueError("Elips verisi beş bağımsız katsayı oranını belirlemiyor.")
    affine_diagnostics = _design_diagnostics(
        affine_design,
        relative_tolerance=tolerance,
    )
    if affine_diagnostics.effective_rank < 3:
        raise ValueError("Elips uydurması için afin tasarım rankı üç olmalıdır.")

    s1 = quadratic_design.T @ quadratic_design
    s2 = quadratic_design.T @ affine_design
    s3 = affine_design.T @ affine_design
    transfer = -np.linalg.solve(s3, s2.T)
    constraint = np.array([[0.0, 0.0, 2.0], [0.0, -1.0, 0.0], [2.0, 0.0, 0.0]])
    reduced = np.linalg.solve(constraint, s1 + s2 @ transfer)
    _, eigenvectors = np.linalg.eig(reduced)
    candidates: list[FloatArray] = []
    for index in range(eigenvectors.shape[1]):
        candidate = np.real_if_close(eigenvectors[:, index], tol=1000)
        if np.iscomplexobj(candidate):
            continue
        candidate = np.asarray(candidate, dtype=float)
        if 4.0 * candidate[0] * candidate[2] - candidate[1] ** 2 > 0.0:
            candidates.append(np.r_[candidate, transfer @ candidate])
    if not candidates:
        raise ValueError("Veri, elips kısıtını sağlayan reel bir doğrudan çözüm üretmedi.")
    normalized_coefficients = min(
        candidates,
        key=lambda coefficient: float(np.linalg.norm(design @ coefficient)),
    )
    return _conic_result(
        rows,
        normalization,
        normalized_coefficients,
        diagnostics,
        method="direct_ellipse_constraint",
        relative_tolerance=tolerance,
        gradient_tolerance=gradient_tolerance,
    )


def fit_quadric_implicit(
    points: ArrayLike,
    *,
    relative_tolerance: float = 1e-12,
    gradient_tolerance: float = 1e-12,
) -> QuadricFitResult:
    """Genel kuadriği normalize tasarım matrisinin en küçük tekil vektörüyle uydurur."""

    rows = _point_rows(points, dimensions=(3,), minimum_rows=10)
    tolerance = _relative_tolerance(relative_tolerance)
    normalization = normalize_points_isotropic(rows)
    design = _quadric_design(normalization.points)
    diagnostics = _design_diagnostics(design, relative_tolerance=tolerance)
    if diagnostics.effective_rank < 9:
        raise ValueError("Kuadrik verisi dokuz bağımsız katsayı oranını belirlemiyor.")
    _, _, right_vectors = np.linalg.svd(design, full_matrices=False)
    normalized_matrix = _quadric_matrix(right_vectors[-1])
    world_matrix = normalization.transform.T @ normalized_matrix @ normalization.transform
    coefficients = _canonical_vector(_quadric_coefficients(world_matrix))
    algebraic = _quadric_design(rows) @ coefficients
    first_order = implicit_first_order_residuals(
        coefficients,
        rows,
        gradient_tolerance=gradient_tolerance,
    )
    quadric = quadric_diagnostics(
        coefficients,
        coordinate_scale=normalization.rms_radius,
        relative_tolerance=tolerance,
    )
    return QuadricFitResult(
        coefficients=coefficients,
        algebraic_residuals=algebraic,
        first_order_residuals=first_order,
        diagnostics=diagnostics,
        quadric_diagnostics=quadric,
        normalization=normalization,
    )
