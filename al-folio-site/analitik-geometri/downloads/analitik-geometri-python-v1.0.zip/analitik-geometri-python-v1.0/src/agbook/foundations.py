"""Bölüm 1 için koordinat, rijit hareket ve üçleme hesapları.

İşlevler kitapta tanımlanan Öklid geometrisini doğrudan uygular. Tüm
girdiler sonlu reel sayılara dönüştürülür; sessiz yayınlama (broadcasting)
ve belirsiz dizi şekilleri özellikle reddedilir.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import ArrayLike, NDArray


FloatArray = NDArray[np.float64]


def _finite_array(value: ArrayLike, *, name: str) -> FloatArray:
    array = np.asarray(value, dtype=float)
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} yalnız sonlu reel sayılar içermelidir.")
    return array


def _point(value: ArrayLike, *, name: str) -> FloatArray:
    point = _finite_array(value, name=name)
    if point.ndim != 1 or point.size == 0:
        raise ValueError(f"{name}, (n,) biçiminde boş olmayan bir nokta olmalıdır.")
    return point


def _same_dimension(a: ArrayLike, b: ArrayLike) -> tuple[FloatArray, FloatArray]:
    point_a = _point(a, name="a")
    point_b = _point(b, name="b")
    if point_a.shape != point_b.shape:
        raise ValueError("a ve b aynı boyutta olmalıdır.")
    return point_a, point_b


def displacement(a: ArrayLike, b: ArrayLike) -> FloatArray:
    """A noktasından B noktasına yer değiştirme vektörü ``b - a``."""

    point_a, point_b = _same_dimension(a, b)
    return point_b - point_a


def euclidean_distance(a: ArrayLike, b: ArrayLike) -> float:
    """A ve B arasındaki Öklid uzaklığını döndürür."""

    return float(np.linalg.norm(displacement(a, b)))


def midpoint(a: ArrayLike, b: ArrayLike) -> FloatArray:
    """A ile B doğru parçasının orta noktasını döndürür."""

    point_a, point_b = _same_dimension(a, b)
    return 0.5 * (point_a + point_b)


def internal_division(a: ArrayLike, b: ArrayLike, m: float, n: float) -> FloatArray:
    """``AP:PB = m:n`` olacak iç bölme noktasını döndürür.

    ``m`` ve ``n`` sonlu ve kesin pozitif olmalıdır. Sonuç
    ``(n*a + m*b)/(m+n)`` biçimindeki afin birleşimdir.
    """

    point_a, point_b = _same_dimension(a, b)
    weights = _finite_array([m, n], name="m ve n")
    if np.any(weights <= 0.0):
        raise ValueError("İç bölme için m ve n kesin pozitif olmalıdır.")
    return (n * point_a + m * point_b) / (m + n)


def affine_combination(
    points: ArrayLike,
    weights: ArrayLike,
    *,
    atol: float = 1e-12,
) -> FloatArray:
    """Katsayıları bire toplamlanan noktaların afin birleşimini hesaplar."""

    point_array = _finite_array(points, name="points")
    weight_array = _finite_array(weights, name="weights")
    if point_array.ndim != 2 or point_array.shape[0] == 0:
        raise ValueError("points, (k, n) biçiminde boş olmayan bir dizi olmalıdır.")
    if weight_array.ndim != 1 or weight_array.shape[0] != point_array.shape[0]:
        raise ValueError("weights, points dizisinin satır sayısıyla eşleşmelidir.")
    if atol < 0.0 or not np.isfinite(atol):
        raise ValueError("atol sonlu ve negatif olmayan bir sayı olmalıdır.")
    if not np.isclose(np.sum(weight_array), 1.0, atol=atol, rtol=0.0):
        raise ValueError("Afin birleşim katsayılarının toplamı 1 olmalıdır.")
    return weight_array @ point_array


def rotation_matrix_2d(theta: float) -> FloatArray:
    """Radyan cinsinden ``theta`` açısının saat yönü tersine dönme matrisi."""

    angle = float(theta)
    if not np.isfinite(angle):
        raise ValueError("theta sonlu bir reel sayı olmalıdır.")
    cosine = np.cos(angle)
    sine = np.sin(angle)
    return np.array([[cosine, -sine], [sine, cosine]], dtype=float)


def _rigid_inputs(q: ArrayLike, b: ArrayLike, *, atol: float) -> tuple[FloatArray, FloatArray]:
    matrix = _finite_array(q, name="q")
    translation = _point(b, name="b")
    if matrix.shape != (2, 2) or translation.shape != (2,):
        raise ValueError("Düzlemsel bir hareket için q (2, 2), b ise (2,) biçiminde olmalıdır.")
    if atol < 0.0 or not np.isfinite(atol):
        raise ValueError("atol sonlu ve negatif olmayan bir sayı olmalıdır.")
    if not np.allclose(matrix.T @ matrix, np.eye(2), atol=atol, rtol=0.0):
        raise ValueError("q, verilen tolerans içinde ortogonal olmalıdır.")
    return matrix, translation


def rigid_transform(
    points: ArrayLike,
    q: ArrayLike,
    b: ArrayLike,
    *,
    atol: float = 1e-12,
) -> FloatArray:
    """Satırları nokta olan diziye ``F(x)=Qx+b`` rijit hareketini uygular."""

    point_array = _finite_array(points, name="points")
    if point_array.ndim == 1:
        if point_array.shape != (2,):
            raise ValueError("Tek nokta (2,) biçiminde olmalıdır.")
    elif point_array.ndim == 2:
        if point_array.shape[1] != 2:
            raise ValueError("Noktalar (k, 2) biçiminde olmalıdır.")
    else:
        raise ValueError("points, (2,) veya (k, 2) biçiminde olmalıdır.")
    matrix, translation = _rigid_inputs(q, b, atol=atol)
    return point_array @ matrix.T + translation


@dataclass(frozen=True)
class RigidMotionDiagnostics:
    """Bir rijit hareketin sayısal değişmezlik ölçüleri."""

    orthogonality_residual: float
    determinant: float
    maximum_distance_error: float


def rigid_motion_diagnostics(
    points: ArrayLike,
    q: ArrayLike,
    b: ArrayLike,
    *,
    atol: float = 1e-12,
) -> RigidMotionDiagnostics:
    """Ortogonalite ve ikili uzaklık korunum artıklarını hesaplar."""

    point_array = _finite_array(points, name="points")
    if point_array.ndim != 2 or point_array.shape[1] != 2:
        raise ValueError("points, (k, 2) biçiminde olmalıdır.")
    matrix, translation = _rigid_inputs(q, b, atol=atol)
    transformed = point_array @ matrix.T + translation
    before = np.linalg.norm(point_array[:, None, :] - point_array[None, :, :], axis=2)
    after = np.linalg.norm(transformed[:, None, :] - transformed[None, :, :], axis=2)
    return RigidMotionDiagnostics(
        orthogonality_residual=float(np.linalg.norm(matrix.T @ matrix - np.eye(2))),
        determinant=float(np.linalg.det(matrix)),
        maximum_distance_error=float(np.max(np.abs(after - before), initial=0.0)),
    )


def perpendicular_bisector_residual(p: ArrayLike, a: ArrayLike, b: ArrayLike) -> float:
    """``||p-a||² - ||p-b||²`` eşit uzaklık artığını döndürür."""

    point_a, point_b = _same_dimension(a, b)
    point_p = _point(p, name="p")
    if point_p.shape != point_a.shape:
        raise ValueError("p, a ve b ile aynı boyutta olmalıdır.")
    return float(np.dot(point_p - point_a, point_p - point_a) - np.dot(point_p - point_b, point_p - point_b))


def circle_residuals(point: ArrayLike, anchors: ArrayLike, distances: ArrayLike) -> FloatArray:
    """Her çıpa için ``||point-anchor|| - distance`` artıklarını döndürür."""

    candidate = _point(point, name="point")
    anchor_array = _finite_array(anchors, name="anchors")
    distance_array = _finite_array(distances, name="distances")
    if anchor_array.ndim != 2 or anchor_array.shape[1] != candidate.size:
        raise ValueError("anchors, (k, n) biçiminde ve point ile aynı boyutta olmalıdır.")
    if distance_array.ndim != 1 or distance_array.shape[0] != anchor_array.shape[0]:
        raise ValueError("distances, çıpa sayısıyla eşleşen (k,) biçiminde olmalıdır.")
    if np.any(distance_array < 0.0):
        raise ValueError("Uzaklıklar negatif olamaz.")
    return np.linalg.norm(anchor_array - candidate, axis=1) - distance_array


@dataclass(frozen=True)
class TrilaterationResult:
    """Doğrusallaştırılmış en küçük kareler üçleme sonucu."""

    point: FloatArray
    rank: int
    singular_values: FloatArray
    range_residuals: FloatArray
    residual_norm: float


def trilaterate_linear(
    anchors: ArrayLike,
    distances: ArrayLike,
    *,
    rank_tolerance: float | None = None,
) -> TrilaterationResult:
    """En az üç düzlemsel çıpadan doğrusallaştırılmış üçleme yapar.

    İlk çember denklemi ötekilerden çıkarılır ve oluşan ``A p = c``
    sistemi en küçük karelerle çözülür. Çıpaların fark vektörleri düzlemi
    germiyorsa konum tek değildir ve işlev ``ValueError`` yükseltir.
    """

    anchor_array = _finite_array(anchors, name="anchors")
    distance_array = _finite_array(distances, name="distances")
    if anchor_array.ndim != 2 or anchor_array.shape[1] != 2 or anchor_array.shape[0] < 3:
        raise ValueError("anchors, en az üç satırlı (k, 2) biçiminde olmalıdır.")
    if distance_array.ndim != 1 or distance_array.shape[0] != anchor_array.shape[0]:
        raise ValueError("distances, çıpa sayısıyla eşleşen (k,) biçiminde olmalıdır.")
    if np.any(distance_array < 0.0):
        raise ValueError("Uzaklıklar negatif olamaz.")
    if rank_tolerance is not None and (rank_tolerance < 0.0 or not np.isfinite(rank_tolerance)):
        raise ValueError("rank_tolerance negatif olmayan sonlu bir sayı veya None olmalıdır.")

    reference = anchor_array[0]
    design = 2.0 * (anchor_array[1:] - reference)
    right_hand_side = (
        distance_array[0] ** 2
        - distance_array[1:] ** 2
        + np.sum(anchor_array[1:] ** 2, axis=1)
        - np.dot(reference, reference)
    )
    point, _, rank, singular_values = np.linalg.lstsq(
        design,
        right_hand_side,
        rcond=rank_tolerance,
    )
    if rank < 2:
        raise ValueError("Çıpa geometrisi rank 2 sağlamıyor; düzlemsel konum tek belirlenemez.")
    residuals = circle_residuals(point, anchor_array, distance_array)
    return TrilaterationResult(
        point=point,
        rank=int(rank),
        singular_values=singular_values,
        range_residuals=residuals,
        residual_norm=float(np.linalg.norm(residuals)),
    )
