import numpy as np
import pytest

from agbook import (
    line_line_angle_3d,
    line_line_diagnostics_3d,
    line_plane_angle_3d,
    line_plane_diagnostics_3d,
    plane_plane_angle_3d,
    plane_plane_diagnostics_3d,
    point_line_distance_3d,
    point_plane_distance_3d,
    project_point_to_line_3d,
    project_point_to_plane_3d,
    signed_point_plane_distance_3d,
)


RELATION_TOLERANCES = {
    "angular_tolerance": 1.0e-12,
    "absolute_tolerance": 1.0e-10,
    "relative_tolerance": 0.0,
    "reference_scale": 1.0,
}


def test_line_line_angle_is_acute_and_scale_invariant():
    reference = line_line_angle_3d([1.0, 0.0, 0.0], [1.0, 1.0, 0.0])
    scaled = line_line_angle_3d([-7.0, 0.0, 0.0], [-5.0, -5.0, 0.0])
    assert reference == pytest.approx(np.pi / 4.0)
    assert scaled == pytest.approx(reference)


@pytest.mark.parametrize(
    "first,second,expected",
    [
        ([1.0, 2.0, 3.0], [-2.0, -4.0, -6.0], 0.0),
        ([1.0, 0.0, 0.0], [0.0, -3.0, 0.0], np.pi / 2.0),
    ],
)
def test_line_line_angle_endpoints(first, second, expected):
    assert line_line_angle_3d(first, second) == pytest.approx(expected)


def test_line_plane_angle_endpoints_and_intermediate_value():
    plane = [0.0, 0.0, 2.0, -4.0]
    assert line_plane_angle_3d([1.0, 0.0, 0.0], plane) == pytest.approx(0.0)
    assert line_plane_angle_3d([0.0, 0.0, -5.0], plane) == pytest.approx(np.pi / 2.0)
    assert line_plane_angle_3d([1.0, 0.0, 1.0], plane) == pytest.approx(np.pi / 4.0)


def test_plane_plane_angle_is_small_and_scale_invariant():
    first = [1.0, 0.0, 0.0, -2.0]
    second = [1.0, 1.0, 0.0, 7.0]
    assert plane_plane_angle_3d(first, second) == pytest.approx(np.pi / 4.0)
    assert plane_plane_angle_3d(-3.0 * np.array(first), 8.0 * np.array(second)) == pytest.approx(
        np.pi / 4.0
    )


@pytest.mark.parametrize(
    "function,args",
    [
        (line_line_angle_3d, ([0.0, 0.0, 0.0], [1.0, 0.0, 0.0])),
        (line_line_angle_3d, ([1.0, 0.0], [1.0, 0.0, 0.0])),
        (line_plane_angle_3d, ([1.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0])),
        (plane_plane_angle_3d, ([1.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0])),
    ],
)
def test_angle_functions_reject_degenerate_or_bad_shapes(function, args):
    with pytest.raises(ValueError):
        function(*args)


def test_point_line_projection_returns_known_foot_distance_and_residuals():
    result = project_point_to_line_3d([0.0, 0.0, 0.0], [2.0, 0.0, 0.0], [1.0, 2.0, 3.0])
    np.testing.assert_allclose(result.foot, [1.0, 0.0, 0.0])
    np.testing.assert_allclose(result.displacement, [0.0, 2.0, 3.0])
    assert result.parameter == pytest.approx(0.5)
    assert result.distance == pytest.approx(np.sqrt(13.0))
    assert result.foot_line_residual == pytest.approx(0.0)
    assert result.orthogonality_residual == pytest.approx(0.0)
    assert point_line_distance_3d([0, 0, 0], [2, 0, 0], [1, 2, 3]) == pytest.approx(
        np.sqrt(13.0)
    )


def test_point_on_line_projects_to_itself():
    point = np.array([7.0, -2.0, 5.0])
    result = project_point_to_line_3d([1.0, 1.0, -1.0], [3.0, -1.5, 3.0], point)
    np.testing.assert_allclose(result.foot, point)
    assert result.distance == pytest.approx(0.0, abs=2.0e-15)


def test_point_line_projection_is_invariant_to_reparameterization():
    anchor = np.array([1.0, -2.0, 4.0])
    direction = np.array([2.0, 3.0, -1.0])
    point = np.array([-4.0, 5.0, 7.0])
    first = project_point_to_line_3d(anchor, direction, point)
    second = project_point_to_line_3d(anchor + 2.5 * direction, -7.0 * direction, point)
    np.testing.assert_allclose(first.foot, second.foot, atol=2.0e-14)
    assert first.distance == pytest.approx(second.distance)


def test_point_line_projection_respects_zero_tolerance():
    with pytest.raises(ValueError, match="eşik"):
        project_point_to_line_3d(
            [0.0, 0.0, 0.0],
            [1.0e-10, 0.0, 0.0],
            [1.0, 2.0, 3.0],
            zero_tolerance=1.0e-9,
        )


def test_point_plane_projection_returns_known_foot_and_signed_distance():
    result = project_point_to_plane_3d([0.0, 0.0, 2.0, -4.0], [1.0, 3.0, 5.0])
    np.testing.assert_allclose(result.canonical_plane, [0.0, 0.0, 1.0, -2.0])
    np.testing.assert_allclose(result.foot, [1.0, 3.0, 2.0])
    np.testing.assert_allclose(result.displacement, [0.0, 0.0, 3.0])
    assert result.signed_distance == pytest.approx(3.0)
    assert result.distance == pytest.approx(3.0)
    assert result.foot_plane_residual == pytest.approx(0.0)
    assert result.normal_alignment_residual == pytest.approx(0.0)


def test_signed_plane_distance_uses_canonical_orientation():
    assert signed_point_plane_distance_3d([-2.0, 0.0, 0.0, 4.0], [5.0, 1.0, 0.0]) == pytest.approx(
        3.0
    )
    assert point_plane_distance_3d([2.0, 0.0, 0.0, -4.0], [-1.0, 8.0, 9.0]) == pytest.approx(
        3.0
    )


def test_point_plane_projection_is_invariant_to_equation_scale():
    first = project_point_to_plane_3d([2.0, -1.0, 2.0, -6.0], [4.0, 5.0, -1.0])
    second = project_point_to_plane_3d([-14.0, 7.0, -14.0, 42.0], [4.0, 5.0, -1.0])
    np.testing.assert_allclose(first.foot, second.foot)
    assert first.signed_distance == pytest.approx(second.signed_distance)


def test_intersecting_lines_return_same_closest_point():
    result = line_line_diagnostics_3d(
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [1.0, -1.0, 0.0],
        [0.0, 1.0, 0.0],
        **RELATION_TOLERANCES,
    )
    assert result.relation == "intersecting"
    np.testing.assert_allclose(result.closest_point_first, [1.0, 0.0, 0.0])
    np.testing.assert_allclose(result.closest_point_second, [1.0, 0.0, 0.0])
    np.testing.assert_allclose(result.intersection_point, [1.0, 0.0, 0.0])
    assert result.first_parameter == pytest.approx(1.0)
    assert result.second_parameter == pytest.approx(1.0)
    assert result.distance == pytest.approx(0.0)
    assert result.small_angle == pytest.approx(np.pi / 2.0)


def test_skew_lines_return_unique_common_perpendicular():
    result = line_line_diagnostics_3d(
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 1.0],
        [0.0, 1.0, 0.0],
        **RELATION_TOLERANCES,
    )
    assert result.relation == "skew"
    np.testing.assert_allclose(result.closest_point_first, [0.0, 0.0, 0.0])
    np.testing.assert_allclose(result.closest_point_second, [0.0, 0.0, 1.0])
    np.testing.assert_allclose(result.separation_vector, [0.0, 0.0, 1.0])
    assert result.intersection_point is None
    assert result.distance == pytest.approx(1.0)
    assert result.coplanarity_residual == pytest.approx(1.0)
    assert result.first_orthogonality_residual == pytest.approx(0.0)
    assert result.second_orthogonality_residual == pytest.approx(0.0)


def test_parallel_and_coincident_lines_are_distinguished():
    parallel = line_line_diagnostics_3d(
        [0.0, 0.0, 0.0], [2.0, 0.0, 0.0], [4.0, 3.0, 0.0], [-5.0, 0.0, 0.0],
        **RELATION_TOLERANCES,
    )
    coincident = line_line_diagnostics_3d(
        [0.0, 0.0, 0.0], [2.0, 0.0, 0.0], [4.0, 0.0, 0.0], [-5.0, 0.0, 0.0],
        **RELATION_TOLERANCES,
    )
    assert parallel.relation == "parallel"
    assert parallel.distance == pytest.approx(3.0)
    assert parallel.condition_number == np.inf
    assert coincident.relation == "coincident"
    assert coincident.distance == pytest.approx(0.0)


def test_line_line_result_is_invariant_to_anchor_shift_and_direction_scale():
    first = line_line_diagnostics_3d(
        [0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 1.0], [0.0, 1.0, 0.0],
        **RELATION_TOLERANCES,
    )
    second = line_line_diagnostics_3d(
        [3.0, 0.0, 0.0], [-8.0, 0.0, 0.0], [0.0, -4.0, 1.0], [0.0, 2.0, 0.0],
        **RELATION_TOLERANCES,
    )
    assert first.relation == second.relation == "skew"
    np.testing.assert_allclose(first.closest_point_first, second.closest_point_first)
    np.testing.assert_allclose(first.closest_point_second, second.closest_point_second)
    assert first.distance == pytest.approx(second.distance)


def test_line_line_swap_reverses_separation_but_preserves_distance():
    first = line_line_diagnostics_3d(
        [0, 0, 0], [1, 0, 0], [0, 1, 2], [0, 1, 0], **RELATION_TOLERANCES
    )
    swapped = line_line_diagnostics_3d(
        [0, 1, 2], [0, 1, 0], [0, 0, 0], [1, 0, 0], **RELATION_TOLERANCES
    )
    assert swapped.relation == first.relation
    assert swapped.distance == pytest.approx(first.distance)
    np.testing.assert_allclose(swapped.separation_vector, -first.separation_vector)


def test_line_line_distance_scales_with_coordinate_unit_conversion():
    base = line_line_diagnostics_3d(
        [0, 0, 0], [1, 0, 0], [0, 1, 2], [0, 1, 0], **RELATION_TOLERANCES
    )
    millimetres = line_line_diagnostics_3d(
        [0, 0, 0], [1000, 0, 0], [0, 1000, 2000], [0, 1000, 0],
        angular_tolerance=1.0e-12,
        absolute_tolerance=1.0e-7,
        relative_tolerance=0.0,
        reference_scale=1000.0,
    )
    assert millimetres.relation == base.relation
    assert millimetres.distance == pytest.approx(1000.0 * base.distance)


def test_near_parallel_line_decision_depends_on_explicit_angular_tolerance():
    loose = line_line_diagnostics_3d(
        [0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1.0e-8, 0],
        angular_tolerance=1.0e-7, absolute_tolerance=1.0e-12,
        relative_tolerance=0.0, reference_scale=1.0,
    )
    strict = line_line_diagnostics_3d(
        [0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1.0e-8, 0],
        angular_tolerance=1.0e-10, absolute_tolerance=1.0e-12,
        relative_tolerance=0.0, reference_scale=1.0,
    )
    assert loose.relation == "parallel"
    assert loose.numerically_ambiguous
    assert strict.relation == "intersecting"
    assert strict.condition_number > 1.0e8


def test_distance_threshold_controls_near_intersection_decision():
    loose = line_line_diagnostics_3d(
        [0, 0, 0], [1, 0, 0], [0, 0, 1.0e-8], [0, 1, 0],
        angular_tolerance=1.0e-12, absolute_tolerance=1.0e-7,
        relative_tolerance=0.0, reference_scale=1.0,
    )
    strict = line_line_diagnostics_3d(
        [0, 0, 0], [1, 0, 0], [0, 0, 1.0e-8], [0, 1, 0],
        angular_tolerance=1.0e-12, absolute_tolerance=1.0e-9,
        relative_tolerance=0.0, reference_scale=1.0,
    )
    assert loose.relation == "intersecting" and loose.numerically_ambiguous
    assert strict.relation == "skew" and not strict.numerically_ambiguous


def test_cad_skew_line_scenario_recovers_ten_millimetre_connector():
    anchor = np.array([120.0, 80.0, 35.0])
    first_direction = np.array([16.0, -12.0, 15.0])
    second_anchor = np.array([115.2, 83.6, 43.0])
    second_direction = np.array([12.0, 16.0, 0.0])
    result = line_line_diagnostics_3d(
        anchor, first_direction, second_anchor, second_direction,
        angular_tolerance=1.0e-12, absolute_tolerance=1.0e-9,
        relative_tolerance=1.0e-12, reference_scale=200.0,
    )
    assert result.relation == "skew"
    np.testing.assert_allclose(result.closest_point_first, anchor, atol=3.0e-14)
    np.testing.assert_allclose(result.closest_point_second, second_anchor, atol=3.0e-14)
    assert result.distance == pytest.approx(10.0)


def test_line_intersects_plane_at_known_parameter():
    result = line_plane_diagnostics_3d(
        [1.0, 2.0, 3.0], [2.0, -1.0, 4.0], [0.0, 0.0, 1.0, -11.0],
        **RELATION_TOLERANCES,
    )
    assert result.relation == "intersecting"
    assert result.parameter == pytest.approx(2.0)
    np.testing.assert_allclose(result.intersection_point, [5.0, 0.0, 11.0])
    assert result.intersection_plane_residual == pytest.approx(0.0)
    assert result.distance == 0.0


def test_parallel_and_contained_line_plane_cases_are_distinguished():
    parallel = line_plane_diagnostics_3d(
        [0, 0, 3], [1, 2, 0], [0, 0, 1, -2], **RELATION_TOLERANCES
    )
    contained = line_plane_diagnostics_3d(
        [0, 0, 2], [1, 2, 0], [0, 0, 1, -2], **RELATION_TOLERANCES
    )
    assert parallel.relation == "parallel" and parallel.distance == pytest.approx(1.0)
    assert contained.relation == "contained" and contained.distance == pytest.approx(0.0)
    assert parallel.intersection_point is None and contained.intersection_point is None


def test_line_plane_is_invariant_to_line_and_plane_representations():
    first = line_plane_diagnostics_3d(
        [1, 2, 3], [2, -1, 4], [0, 0, 1, -11], **RELATION_TOLERANCES
    )
    second = line_plane_diagnostics_3d(
        [5, 0, 11], [-6, 3, -12], [0, 0, -7, 77], **RELATION_TOLERANCES
    )
    assert first.relation == second.relation == "intersecting"
    np.testing.assert_allclose(first.intersection_point, second.intersection_point)


def test_line_plane_unit_conversion_scales_distance_and_intersection():
    base = line_plane_diagnostics_3d(
        [0, 0, 3], [1, 2, 0], [0, 0, 1, -2], **RELATION_TOLERANCES
    )
    scaled = line_plane_diagnostics_3d(
        [0, 0, 3000], [1000, 2000, 0], [0, 0, 1, -2000],
        angular_tolerance=1.0e-12, absolute_tolerance=1.0e-7,
        relative_tolerance=0.0, reference_scale=1000.0,
    )
    assert scaled.relation == base.relation == "parallel"
    assert scaled.distance == pytest.approx(1000.0 * base.distance)


def test_near_parallel_line_plane_decision_reports_ambiguity():
    loose = line_plane_diagnostics_3d(
        [0, 0, 1], [1, 0, 1.0e-8], [0, 0, 1, 0],
        angular_tolerance=1.0e-7, absolute_tolerance=1.0e-12,
        relative_tolerance=0.0, reference_scale=1.0,
    )
    strict = line_plane_diagnostics_3d(
        [0, 0, 1], [1, 0, 1.0e-8], [0, 0, 1, 0],
        angular_tolerance=1.0e-10, absolute_tolerance=1.0e-12,
        relative_tolerance=0.0, reference_scale=1.0,
    )
    assert loose.relation == "parallel" and loose.numerically_ambiguous
    assert strict.relation == "intersecting"
    assert abs(strict.parameter) > 1.0e7


def test_cad_line_plane_scenario_recovers_hole_axis_anchor():
    anchor = np.array([120.0, 80.0, 35.0])
    result = line_plane_diagnostics_3d(
        anchor, [16.0, -12.0, 15.0], [0.64, -0.48, 0.60, -59.4],
        angular_tolerance=1.0e-12, absolute_tolerance=1.0e-9,
        relative_tolerance=1.0e-12, reference_scale=200.0,
    )
    assert result.relation == "intersecting"
    np.testing.assert_allclose(result.intersection_point, anchor)
    assert result.parameter == pytest.approx(0.0)


def test_intersecting_planes_return_minimum_norm_anchor_and_unit_direction():
    result = plane_plane_diagnostics_3d(
        [1, 0, 0, -2], [0, 1, 0, -3], **RELATION_TOLERANCES
    )
    assert result.relation == "intersecting"
    np.testing.assert_allclose(result.line_point, [2.0, 3.0, 0.0])
    np.testing.assert_allclose(result.line_direction, [0.0, 0.0, 1.0])
    np.testing.assert_allclose(result.line_point_residuals, 0.0)
    assert np.linalg.norm(result.line_direction) == pytest.approx(1.0)
    assert result.distance == 0.0


def test_parallel_and_coincident_planes_are_distinguished():
    parallel = plane_plane_diagnostics_3d(
        [0, 0, 1, -2], [0, 0, -3, 9], **RELATION_TOLERANCES
    )
    coincident = plane_plane_diagnostics_3d(
        [0, 0, 1, -2], [0, 0, -3, 6], **RELATION_TOLERANCES
    )
    assert parallel.relation == "parallel" and parallel.distance == pytest.approx(1.0)
    assert coincident.relation == "coincident" and coincident.distance == pytest.approx(0.0)
    assert parallel.line_point is None and coincident.line_direction is None


def test_plane_plane_result_is_invariant_to_scale_sign_and_order():
    first = plane_plane_diagnostics_3d(
        [1, 1, 0, -2], [0, 1, 1, -3], **RELATION_TOLERANCES
    )
    second = plane_plane_diagnostics_3d(
        [0, -5, -5, 15], [-7, -7, 0, 14], **RELATION_TOLERANCES
    )
    assert first.relation == second.relation == "intersecting"
    np.testing.assert_allclose(first.line_point, second.line_point, atol=2.0e-15)
    np.testing.assert_allclose(first.line_direction, second.line_direction, atol=2.0e-15)


def test_plane_plane_unit_conversion_scales_parallel_distance():
    base = plane_plane_diagnostics_3d(
        [0, 0, 1, -2], [0, 0, 1, -3], **RELATION_TOLERANCES
    )
    scaled = plane_plane_diagnostics_3d(
        [0, 0, 1, -2000], [0, 0, 1, -3000],
        angular_tolerance=1.0e-12, absolute_tolerance=1.0e-7,
        relative_tolerance=0.0, reference_scale=1000.0,
    )
    assert scaled.relation == base.relation == "parallel"
    assert scaled.distance == pytest.approx(1000.0 * base.distance)


def test_near_parallel_plane_decision_depends_on_angular_tolerance():
    first = [0, 0, 1, 0]
    second = [1.0e-8, 0, 1, -1]
    loose = plane_plane_diagnostics_3d(
        first, second, angular_tolerance=1.0e-7, absolute_tolerance=1.0e-12,
        relative_tolerance=0.0, reference_scale=1.0,
    )
    strict = plane_plane_diagnostics_3d(
        first, second, angular_tolerance=1.0e-10, absolute_tolerance=1.0e-12,
        relative_tolerance=0.0, reference_scale=1.0,
    )
    assert loose.relation == "parallel" and loose.numerically_ambiguous
    assert strict.relation == "intersecting"
    assert strict.condition_number > 1.0e8


def test_cad_plane_pair_recovers_hole_axis_direction():
    anchor = np.array([120.0, 80.0, 35.0])
    first_normal = np.array([0.6, 0.8, 0.0])
    second_normal = np.array([-0.48, 0.36, 0.8])
    first = [*first_normal, -float(first_normal @ anchor)]
    second = [*second_normal, -float(second_normal @ anchor)]
    result = plane_plane_diagnostics_3d(first, second, **RELATION_TOLERANCES)
    assert result.relation == "intersecting"
    np.testing.assert_allclose(result.line_direction, [0.64, -0.48, 0.60], atol=2.0e-15)
    np.testing.assert_allclose(result.line_point_residuals, 0.0, atol=3.0e-14)


@pytest.mark.parametrize(
    "function,args",
    [
        (project_point_to_line_3d, ([0, 0], [1, 0, 0], [0, 0, 0])),
        (project_point_to_line_3d, ([0, 0, 0], [0, 0, 0], [0, 0, 0])),
        (project_point_to_line_3d, ([0, 0, 0], [1, 0, 0], [0, np.nan, 0])),
        (project_point_to_plane_3d, ([0, 0, 0, 1], [0, 0, 0])),
        (project_point_to_plane_3d, ([0, 0, 1, 0], [0, 0])),
    ],
)
def test_projection_functions_reject_invalid_inputs(function, args):
    with pytest.raises(ValueError):
        function(*args)


@pytest.mark.parametrize(
    "keyword,value",
    [
        ("angular_tolerance", -1.0),
        ("angular_tolerance", 1.0),
        ("absolute_tolerance", -1.0),
        ("relative_tolerance", -1.0),
        ("relative_tolerance", 1.0),
        ("reference_scale", -1.0),
        ("reference_scale", np.inf),
    ],
)
def test_all_relation_diagnostics_reject_invalid_tolerances(keyword, value):
    keywords = dict(RELATION_TOLERANCES)
    keywords[keyword] = value
    with pytest.raises(ValueError):
        line_line_diagnostics_3d([0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 1, 0], **keywords)
    with pytest.raises(ValueError):
        line_plane_diagnostics_3d([0, 0, 0], [1, 0, 0], [0, 0, 1, 0], **keywords)
    with pytest.raises(ValueError):
        plane_plane_diagnostics_3d([1, 0, 0, 0], [0, 1, 0, 0], **keywords)


@pytest.mark.parametrize(
    "call",
    [
        lambda: line_line_diagnostics_3d(
            [0, 0], [1, 0, 0], [0, 0, 0], [0, 1, 0], **RELATION_TOLERANCES
        ),
        lambda: line_line_diagnostics_3d(
            [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 1, 0], **RELATION_TOLERANCES
        ),
        lambda: line_plane_diagnostics_3d(
            [0, 0, 0], [0, 0, 0], [0, 0, 1, 0], **RELATION_TOLERANCES
        ),
        lambda: plane_plane_diagnostics_3d(
            [0, 0, 0, 1], [0, 1, 0, 0], **RELATION_TOLERANCES
        ),
    ],
)
def test_relation_diagnostics_reject_degenerate_geometry(call):
    with pytest.raises(ValueError):
        call()


def test_projection_and_relation_operations_report_overflow():
    with pytest.raises(OverflowError):
        project_point_to_line_3d([-1.0e308, 0, 0], [1, 0, 0], [1.0e308, 0, 0])
    with pytest.raises(OverflowError):
        project_point_to_plane_3d([1, 1, 0, 0], [1.7e308, 1.7e308, 0])
    with pytest.raises(OverflowError):
        line_line_diagnostics_3d(
            [-1.0e308, 0, 0], [1, 0, 0], [1.0e308, 0, 0], [0, 1, 0],
            **RELATION_TOLERANCES,
        )
    with pytest.raises(OverflowError):
        plane_plane_diagnostics_3d(
            [1, 0, 0, 1.7e308], [1, 0, 0, -1.7e308], **RELATION_TOLERANCES
        )
