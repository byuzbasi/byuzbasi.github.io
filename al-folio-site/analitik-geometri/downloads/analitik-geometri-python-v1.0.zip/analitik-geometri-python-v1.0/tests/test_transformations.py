import numpy as np
import pytest

from agbook import (
    compose_rigid_motions,
    coordinates_from_frame,
    coordinates_in_frame,
    inverse_rigid_motion,
    line_reflection_motion,
    line_residuals,
    reflect_across_line,
    reflection_matrix_2d,
    rigid_transform,
    rotate_about_point,
    rotation_matrix_2d,
)


def test_reflection_matrix_across_x_axis_has_expected_form():
    matrix = reflection_matrix_2d([3.0, 0.0])
    np.testing.assert_allclose(matrix, [[1.0, 0.0], [0.0, -1.0]], atol=1e-14)
    np.testing.assert_allclose(matrix.T @ matrix, np.eye(2), atol=1e-14)
    assert np.linalg.det(matrix) == pytest.approx(-1.0)


def test_reflection_matrix_is_scale_invariant_and_involutory():
    first = reflection_matrix_2d([2.0, -1.0])
    second = reflection_matrix_2d([-14.0, 7.0])
    np.testing.assert_allclose(first, second, atol=1e-14)
    np.testing.assert_allclose(first @ first, np.eye(2), atol=1e-14)
    np.testing.assert_allclose(first, first.T, atol=1e-14)


def test_reflection_matrix_fixes_axis_and_reverses_normal():
    direction = np.array([2.0, 1.0])
    normal = np.array([-1.0, 2.0])
    matrix = reflection_matrix_2d(direction)
    np.testing.assert_allclose(matrix @ direction, direction, atol=1e-14)
    np.testing.assert_allclose(matrix @ normal, -normal, atol=1e-14)


@pytest.mark.parametrize("direction", ([0.0, 0.0], [1.0e-8, 0.0]))
def test_reflection_matrix_rejects_direction_at_or_below_threshold(direction):
    threshold = 0.0 if direction == [0.0, 0.0] else 1.0e-8
    with pytest.raises(ValueError, match="normu"):
        reflection_matrix_2d(direction, zero_tolerance=threshold)


def test_rotate_about_point_fixes_center_and_rotates_quarter_turn():
    center = np.array([3.0, -2.0])
    points = np.array([center, center + [2.0, 0.0], center + [0.0, 1.0]])
    result = rotate_about_point(points, np.pi / 2.0, center)
    np.testing.assert_allclose(result[0], center, atol=1e-14)
    np.testing.assert_allclose(result[1], center + [0.0, 2.0], atol=1e-14)
    np.testing.assert_allclose(result[2], center + [-1.0, 0.0], atol=1e-14)


def test_rotate_about_point_preserves_pairwise_distances():
    points = np.array([[0.0, 0.0], [3.0, 1.0], [-2.0, 4.0], [1.0, -5.0]])
    moved = rotate_about_point(points, np.deg2rad(37.0), [8.0, -3.0])
    before = np.linalg.norm(points[:, None, :] - points[None, :, :], axis=2)
    after = np.linalg.norm(moved[:, None, :] - moved[None, :, :], axis=2)
    np.testing.assert_allclose(after, before, atol=2e-14)


def test_line_reflection_motion_matches_direct_axis_case():
    motion = line_reflection_motion([0.0, 2.0, 0.0])
    np.testing.assert_allclose(motion.matrix, [[1.0, 0.0], [0.0, -1.0]], atol=1e-14)
    np.testing.assert_allclose(motion.translation, [0.0, 0.0], atol=1e-14)
    assert motion.determinant == pytest.approx(-1.0)


def test_reflection_across_y_equals_x_swaps_coordinates():
    points = np.array([[3.0, -1.0], [2.5, 2.5], [-4.0, 7.0]])
    reflected = reflect_across_line(points, [1.0, -1.0, 0.0])
    np.testing.assert_allclose(reflected, points[:, ::-1], atol=1e-14)


def test_arbitrary_line_reflection_is_scale_invariant():
    point = np.array([4.0, -1.0])
    first = reflect_across_line(point, [2.0, -1.0, -3.0])
    second = reflect_across_line(point, [-18.0, 9.0, 27.0])
    np.testing.assert_allclose(first, second, atol=1e-14)


def test_reflection_midpoint_is_on_axis_and_double_reflection_returns_point():
    line = np.array([2.0, -1.0, -3.0])
    points = np.array([[4.0, -1.0], [0.0, 3.0], [-2.0, 5.0]])
    reflected = reflect_across_line(points, line)
    midpoints = 0.5 * (points + reflected)
    np.testing.assert_allclose(line_residuals(line, midpoints), 0.0, atol=2e-14)
    np.testing.assert_allclose(reflect_across_line(reflected, line), points, atol=3e-14)


def test_compose_rigid_motions_matches_sequential_application():
    points = np.array([[0.0, 0.0], [2.0, 1.0], [-1.0, 3.0]])
    q_before = rotation_matrix_2d(np.deg2rad(20.0))
    t_before = np.array([4.0, -1.0])
    q_after = reflection_matrix_2d([1.0, 2.0])
    t_after = np.array([-2.0, 5.0])
    sequential = rigid_transform(
        rigid_transform(points, q_before, t_before),
        q_after,
        t_after,
    )
    composed = compose_rigid_motions(q_after, t_after, q_before, t_before)
    direct = rigid_transform(points, composed.matrix, composed.translation)
    np.testing.assert_allclose(direct, sequential, atol=2e-14)


def test_rotation_and_translation_order_is_not_generally_commutative():
    point = np.array([1.0, 0.0])
    rotation = rotation_matrix_2d(np.pi / 2.0)
    translation = np.array([2.0, 0.0])
    rotate_then_translate = compose_rigid_motions(
        np.eye(2), translation, rotation, [0.0, 0.0]
    )
    translate_then_rotate = compose_rigid_motions(
        rotation, [0.0, 0.0], np.eye(2), translation
    )
    first = rigid_transform(point, rotate_then_translate.matrix, rotate_then_translate.translation)
    second = rigid_transform(point, translate_then_rotate.matrix, translate_then_rotate.translation)
    assert not np.allclose(first, second)


def test_inverse_rigid_motion_round_trip():
    points = np.array([[1.0, 2.0], [-3.0, 5.0], [0.5, -4.0]])
    matrix = rotation_matrix_2d(np.deg2rad(-28.0))
    translation = np.array([7.0, 11.0])
    moved = rigid_transform(points, matrix, translation)
    inverse = inverse_rigid_motion(matrix, translation)
    recovered = rigid_transform(moved, inverse.matrix, inverse.translation)
    np.testing.assert_allclose(recovered, points, atol=3e-14)
    assert inverse.determinant == pytest.approx(1.0)


def test_frame_coordinates_round_trip_for_point_cloud():
    local = np.array([[0.0, 0.0], [120.0, 0.0], [120.0, 60.0], [0.0, 60.0]])
    axes = rotation_matrix_2d(np.deg2rad(35.0))
    origin = np.array([420.0, 180.0])
    world = coordinates_from_frame(local, origin, axes)
    recovered = coordinates_in_frame(world, origin, axes)
    np.testing.assert_allclose(recovered, local, atol=1e-12)


def test_active_rotation_and_passive_coordinates_use_transposes():
    point = np.array([3.0, 1.0])
    axes = rotation_matrix_2d(np.deg2rad(30.0))
    active = rigid_transform(point, axes, [0.0, 0.0])
    passive = coordinates_in_frame(point, [0.0, 0.0], axes)
    np.testing.assert_allclose(active, axes @ point, atol=1e-14)
    np.testing.assert_allclose(passive, axes.T @ point, atol=1e-14)


def test_frame_functions_reject_nonorthogonal_axes():
    bad_axes = np.array([[1.0, 0.2], [0.0, 1.0]])
    with pytest.raises(ValueError, match="ortogonal"):
        coordinates_from_frame([1.0, 2.0], [0.0, 0.0], bad_axes)
    with pytest.raises(ValueError, match="ortogonal"):
        coordinates_in_frame([1.0, 2.0], [0.0, 0.0], bad_axes)


@pytest.mark.parametrize(
    "call",
    [
        lambda: rotate_about_point([[1.0, 2.0, 3.0]], 0.0, [0.0, 0.0]),
        lambda: reflect_across_line([], [1.0, 0.0, 0.0]),
        lambda: coordinates_from_frame([np.nan, 0.0], [0.0, 0.0], np.eye(2)),
        lambda: reflection_matrix_2d([1.0, 0.0], zero_tolerance=-1.0),
    ],
)
def test_transformations_reject_invalid_inputs(call):
    with pytest.raises(ValueError):
        call()
