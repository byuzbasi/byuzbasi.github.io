from __future__ import annotations

import math

import numpy as np
import pytest

from agbook import (
    fit_circle_geometric,
    fit_conic_implicit,
    fit_ellipse_direct,
    fit_line_tls,
    fit_line_vertical_ols,
    fit_quadric_implicit,
    implicit_first_order_residuals,
    normalize_points_isotropic,
)


def _rotation_2d(angle: float) -> np.ndarray:
    cosine, sine = math.cos(angle), math.sin(angle)
    return np.array([[cosine, -sine], [sine, cosine]])


def _ellipse_points(
    *,
    center: np.ndarray = np.array([2.0, -1.0]),
    axes: np.ndarray = np.array([4.0, 1.5]),
    angle: float = 0.43,
    count: int = 80,
) -> np.ndarray:
    parameter = np.linspace(0.0, 2.0 * np.pi, count, endpoint=False)
    local = np.column_stack((axes[0] * np.cos(parameter), axes[1] * np.sin(parameter)))
    return local @ _rotation_2d(angle).T + center


def _ellipsoid_points(
    *,
    center: np.ndarray = np.array([1.5, -2.0, 0.75]),
    axes: np.ndarray = np.array([4.0, 2.5, 1.25]),
) -> np.ndarray:
    azimuth = np.linspace(0.0, 2.0 * np.pi, 16, endpoint=False)
    polar = np.linspace(0.2, np.pi - 0.2, 9)
    aa, pp = np.meshgrid(azimuth, polar)
    local = np.column_stack(
        (
            axes[0] * np.sin(pp.ravel()) * np.cos(aa.ravel()),
            axes[1] * np.sin(pp.ravel()) * np.sin(aa.ravel()),
            axes[2] * np.cos(pp.ravel()),
        )
    )
    ax, ay, az = 0.31, -0.27, 0.52
    cx, sx = np.cos(ax), np.sin(ax)
    cy, sy = np.cos(ay), np.sin(ay)
    cz, sz = np.cos(az), np.sin(az)
    rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return local @ (rz @ ry @ rx).T + center


@pytest.mark.parametrize("dimension", [2, 3])
def test_isotropic_normalization_has_declared_centroid_and_rms(dimension: int) -> None:
    rng = np.random.default_rng(2300 + dimension)
    points = rng.normal(size=(17, dimension)) * np.arange(1, dimension + 1) + 1.0e4
    original = points.copy()
    result = normalize_points_isotropic(points)
    np.testing.assert_allclose(np.mean(result.points, axis=0), 0.0, atol=2e-12)
    rms = np.sqrt(np.mean(np.sum(result.points**2, axis=1)))
    assert rms == pytest.approx(np.sqrt(dimension), abs=2e-12)
    homogeneous = np.column_stack((points, np.ones(points.shape[0])))
    transformed = (result.transform @ homogeneous.T).T[:, :dimension]
    restored = (result.inverse_transform @ np.column_stack((result.points, np.ones(points.shape[0]))).T).T
    np.testing.assert_allclose(transformed, result.points, atol=2e-12)
    np.testing.assert_allclose(restored[:, :dimension], points, atol=2e-12)
    np.testing.assert_array_equal(points, original)


@pytest.mark.parametrize(
    "points",
    [
        np.ones((3, 2)),
        np.array([[0.0, np.nan], [1.0, 2.0]]),
        np.ones((3, 4)),
        np.ones((1, 2)),
    ],
)
def test_isotropic_normalization_rejects_invalid_inputs(points: np.ndarray) -> None:
    with pytest.raises(ValueError):
        normalize_points_isotropic(points)


def test_tls_line_exact_recovery_and_canonical_sign() -> None:
    x = np.linspace(-4.0, 5.0, 21)
    points = np.column_stack((x, 2.0 * x - 3.0))
    result = fit_line_tls(points)
    assert result.rms_orthogonal < 2e-15
    np.testing.assert_allclose(points @ result.normal + result.coefficients[2], 0.0, atol=4e-15)
    assert result.coefficients[np.argmax(np.abs(result.coefficients[:2]))] > 0.0
    assert result.diagnostics.effective_rank == 1


def test_tls_line_is_similarity_equivariant() -> None:
    rng = np.random.default_rng(2303)
    parameter = np.linspace(-3.0, 3.0, 40)
    direction = np.array([0.8, -0.6])
    normal = np.array([0.6, 0.8])
    points = np.array([2.0, -1.0]) + parameter[:, None] * direction
    points += rng.normal(scale=0.03, size=(40, 1)) * normal
    base = fit_line_tls(points)
    rotation = _rotation_2d(0.71)
    factor = 17.0
    translation = np.array([-8.0, 12.0])
    moved = factor * (points @ rotation.T) + translation
    transformed = fit_line_tls(moved)
    assert abs(transformed.direction @ (rotation @ base.direction)) == pytest.approx(1.0, abs=3e-14)
    assert transformed.rms_orthogonal == pytest.approx(factor * base.rms_orthogonal, rel=2e-13)


def test_vertical_ols_matches_exact_nonvertical_line() -> None:
    x = np.linspace(-2.0, 3.0, 12)
    points = np.column_stack((x, -1.25 * x + 4.0))
    result = fit_line_vertical_ols(points)
    assert result.slope == pytest.approx(-1.25)
    assert result.intercept == pytest.approx(4.0)
    assert result.rms_vertical < 3e-15


def test_vertical_ols_rejects_vertical_design() -> None:
    with pytest.raises(ValueError, match="x koordinatlarında"):
        fit_line_vertical_ols([[2.0, -1.0], [2.0, 0.0], [2.0, 3.0]])


def test_circle_exact_recovery_and_objective_improvement() -> None:
    theta = np.linspace(0.0, 2.0 * np.pi, 24, endpoint=False)
    center = np.array([3.5, -2.25])
    radius = 4.2
    points = center + radius * np.column_stack((np.cos(theta), np.sin(theta)))
    result = fit_circle_geometric(points)
    np.testing.assert_allclose(result.center, center, atol=2e-14)
    assert result.radius == pytest.approx(radius, abs=2e-14)
    assert result.final_sum_squares <= result.initial_sum_squares + 1e-26
    assert result.covariance is None
    assert result.standard_errors is None


def test_noisy_circle_geometric_step_does_not_worsen_linear_objective() -> None:
    rng = np.random.default_rng(2304)
    theta = np.linspace(0.0, 2.0 * np.pi, 60, endpoint=False)
    true_center = np.array([12.0, -7.0])
    radial = 8.0 + rng.normal(scale=0.18, size=theta.size)
    points = true_center + radial[:, None] * np.column_stack((np.cos(theta), np.sin(theta)))
    result = fit_circle_geometric(points)
    assert result.final_sum_squares <= result.initial_sum_squares + 1e-12
    np.testing.assert_allclose(result.center, true_center, atol=0.08)
    assert result.radius == pytest.approx(8.0, abs=0.08)


def test_circle_similarity_equivariance() -> None:
    rng = np.random.default_rng(2305)
    theta = np.linspace(0.0, 2.0 * np.pi, 45, endpoint=False)
    radial = 2.5 + rng.normal(scale=0.03, size=theta.size)
    points = np.array([-1.0, 4.0]) + radial[:, None] * np.column_stack((np.cos(theta), np.sin(theta)))
    base = fit_circle_geometric(points)
    rotation = _rotation_2d(-0.37)
    factor = 9.0
    translation = np.array([20.0, -11.0])
    moved = factor * (points @ rotation.T) + translation
    transformed = fit_circle_geometric(moved)
    np.testing.assert_allclose(transformed.center, factor * (rotation @ base.center) + translation, atol=2e-12)
    assert transformed.radius == pytest.approx(factor * base.radius, rel=3e-13)
    assert transformed.rms_geometric == pytest.approx(factor * base.rms_geometric, rel=3e-13)


def test_circle_covariance_requires_explicit_measurement_model() -> None:
    theta = np.linspace(0.0, 2.0 * np.pi, 20, endpoint=False)
    points = np.array([1.0, -3.0]) + 5.0 * np.column_stack((np.cos(theta), np.sin(theta)))
    result = fit_circle_geometric(points, measurement_sigma=0.05)
    assert result.measurement_sigma == 0.05
    assert result.covariance is not None
    assert result.standard_errors is not None
    np.testing.assert_allclose(result.covariance, result.covariance.T, atol=1e-18)
    assert np.all(result.standard_errors > 0.0)


def test_circle_robust_loss_is_explicit_and_reduces_outlier_influence() -> None:
    theta = np.linspace(0.0, 2.0 * np.pi, 40, endpoint=False)
    center = np.array([2.0, 1.0])
    points = center + 3.0 * np.column_stack((np.cos(theta), np.sin(theta)))
    points[0] += np.array([8.0, 4.0])
    ordinary = fit_circle_geometric(points)
    robust = fit_circle_geometric(points, loss="soft_l1", loss_scale=0.15)
    assert np.linalg.norm(robust.center - center) < np.linalg.norm(ordinary.center - center)
    assert abs(robust.radius - 3.0) < abs(ordinary.radius - 3.0)
    with pytest.raises(ValueError, match="loss_scale"):
        fit_circle_geometric(points, loss="huber")
    with pytest.raises(ValueError, match="kovaryansı"):
        fit_circle_geometric(points, loss="huber", loss_scale=0.2, measurement_sigma=0.1)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"loss": "unknown"},
        {"loss_scale": 1.0},
        {"measurement_sigma": 0.0},
        {"max_nfev": 0},
        {"relative_tolerance": -1.0},
    ],
)
def test_circle_rejects_invalid_options(kwargs: dict[str, object]) -> None:
    points = np.array([[1.0, 0.0], [0.0, 1.0], [-1.0, 0.0], [0.0, -1.0]])
    with pytest.raises(ValueError):
        fit_circle_geometric(points, **kwargs)


def test_circle_rejects_collinear_points() -> None:
    points = np.column_stack((np.arange(6.0), 2.0 * np.arange(6.0) + 1.0))
    with pytest.raises(ValueError, match="doğrusal"):
        fit_circle_geometric(points)


@pytest.mark.parametrize("fit", [fit_conic_implicit, fit_ellipse_direct])
def test_ellipse_fit_exact_recovery_and_classification(fit) -> None:
    points = _ellipse_points()
    result = fit(points)
    assert result.conic_diagnostics.locus_type == "ellipse"
    assert np.max(np.abs(result.algebraic_residuals)) < 2e-13
    assert np.max(np.abs(result.first_order_residuals.approximate_signed_distances)) < 2e-13
    np.testing.assert_allclose(result.conic_diagnostics.center, [2.0, -1.0], atol=2e-13)
    np.testing.assert_allclose(np.sort(result.conic_diagnostics.semi_axes), [1.5, 4.0], atol=3e-13)
    assert result.coefficients[np.argmax(np.abs(result.coefficients))] > 0.0


def test_conic_fit_is_similarity_equivariant_in_geometry() -> None:
    points = _ellipse_points()
    base = fit_ellipse_direct(points)
    rotation = _rotation_2d(0.62)
    factor = 3.5
    translation = np.array([-7.0, 9.0])
    moved_points = factor * (points @ rotation.T) + translation
    moved = fit_ellipse_direct(moved_points)
    expected_center = factor * (rotation @ base.conic_diagnostics.center) + translation
    np.testing.assert_allclose(moved.conic_diagnostics.center, expected_center, atol=2e-12)
    np.testing.assert_allclose(
        np.sort(moved.conic_diagnostics.semi_axes),
        factor * np.sort(base.conic_diagnostics.semi_axes),
        atol=3e-12,
    )


def test_conic_partial_arc_exposes_weaker_nullspace_separation() -> None:
    full = _ellipse_points(count=120)
    parameter = np.linspace(-0.12, 0.12, 120)
    local = np.column_stack((4.0 * np.cos(parameter), 1.5 * np.sin(parameter)))
    partial = local @ _rotation_2d(0.43).T + np.array([2.0, -1.0])
    full_fit = fit_conic_implicit(full)
    partial_fit = fit_conic_implicit(partial)
    assert full_fit.diagnostics.nullspace_gap is not None
    assert partial_fit.diagnostics.nullspace_gap is not None
    assert partial_fit.diagnostics.nullspace_gap < full_fit.diagnostics.nullspace_gap


def test_conic_rejects_rank_deficient_configuration() -> None:
    x = np.linspace(-2.0, 2.0, 12)
    points = np.column_stack((x, 3.0 * x - 1.0))
    with pytest.raises(ValueError, match="beş bağımsız"):
        fit_conic_implicit(points)
    with pytest.raises(ValueError, match="beş bağımsız"):
        fit_ellipse_direct(points)


def test_first_order_conic_residual_flags_zero_gradient() -> None:
    result = implicit_first_order_residuals(
        [1.0, 0.0, 1.0, 0.0, 0.0, 0.0],
        [[0.0, 0.0], [1.0, 0.0]],
    )
    np.testing.assert_array_equal(result.valid, [False, True])
    assert np.isnan(result.approximate_signed_distances[0])
    assert result.approximate_signed_distances[1] == pytest.approx(0.5)


def test_quadric_fit_exact_ellipsoid_and_classification() -> None:
    points = _ellipsoid_points()
    result = fit_quadric_implicit(points)
    assert result.quadric_diagnostics.locus_type == "ellipsoid"
    assert np.max(np.abs(result.algebraic_residuals)) < 2e-13
    np.testing.assert_allclose(result.quadric_diagnostics.center, [1.5, -2.0, 0.75], atol=3e-13)
    np.testing.assert_allclose(
        np.sort(result.quadric_diagnostics.semi_axes),
        [1.25, 2.5, 4.0],
        atol=5e-13,
    )
    assert result.diagnostics.effective_rank == 9


def test_quadric_fit_similarity_equivariance() -> None:
    points = _ellipsoid_points()
    base = fit_quadric_implicit(points)
    factor = 11.0
    translation = np.array([30.0, -50.0, 7.0])
    moved = fit_quadric_implicit(factor * points + translation)
    np.testing.assert_allclose(
        moved.quadric_diagnostics.center,
        factor * base.quadric_diagnostics.center + translation,
        atol=2e-11,
    )
    np.testing.assert_allclose(
        np.sort(moved.quadric_diagnostics.semi_axes),
        factor * np.sort(base.quadric_diagnostics.semi_axes),
        atol=3e-11,
    )


def test_quadric_rejects_planar_configuration() -> None:
    x, y = np.meshgrid(np.linspace(-1.0, 1.0, 5), np.linspace(-2.0, 2.0, 4))
    points = np.column_stack((x.ravel(), y.ravel(), np.zeros(x.size)))
    with pytest.raises(ValueError, match="dokuz bağımsız"):
        fit_quadric_implicit(points)


def test_first_order_quadric_residual_flags_singular_vertex() -> None:
    coefficients = [1.0, 0.0, 0.0, 1.0, 0.0, -1.0, 0.0, 0.0, 0.0, 0.0]
    result = implicit_first_order_residuals(
        coefficients,
        [[0.0, 0.0, 0.0], [1.0, 0.0, 1.0]],
    )
    np.testing.assert_array_equal(result.valid, [False, True])
    assert np.isnan(result.approximate_signed_distances[0])
    assert result.approximate_signed_distances[1] == pytest.approx(0.0)


@pytest.mark.parametrize(
    "coefficients, points",
    [
        ([1.0] * 5, np.zeros((2, 2))),
        ([1.0] * 6, np.zeros((2, 3))),
        ([1.0] * 10, np.zeros((2, 2))),
    ],
)
def test_first_order_residuals_reject_shape_mismatch(coefficients, points) -> None:
    with pytest.raises(ValueError):
        implicit_first_order_residuals(coefficients, points)


def test_fitting_functions_do_not_mutate_input() -> None:
    points = _ellipse_points()
    original = points.copy()
    fit_conic_implicit(points)
    fit_ellipse_direct(points)
    np.testing.assert_array_equal(points, original)


@pytest.mark.parametrize("tolerance", [-1.0, 1.0, np.inf, np.nan])
def test_relative_tolerance_validation(tolerance: float) -> None:
    points = _ellipse_points()
    with pytest.raises(ValueError):
        fit_conic_implicit(points, relative_tolerance=tolerance)
