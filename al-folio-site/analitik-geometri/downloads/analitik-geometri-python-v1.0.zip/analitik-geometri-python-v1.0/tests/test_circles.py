import numpy as np
import pytest

from agbook import (
    circle_line_intersections,
    circle_membership_diagnostics,
    general_circle_diagnostics,
    polar_line_of_point,
    rotation_matrix_2d,
    tangent_line_at_circle_point,
    tangent_points_from_point,
)


TOLERANCES = {
    "absolute_tolerance": 1e-12,
    "relative_tolerance": 1e-12,
    "reference_scale": 10.0,
}


def test_general_circle_recovers_center_and_radius():
    result = general_circle_diagnostics([1.0, -4.0, 6.0, -12.0])
    assert result.locus_type == "circle"
    np.testing.assert_allclose(result.normalized_coefficients, [1.0, -4.0, 6.0, -12.0])
    np.testing.assert_allclose(result.center, [2.0, -3.0])
    assert result.radius_squared == pytest.approx(25.0)
    assert result.radius == pytest.approx(5.0)


def test_general_circle_is_invariant_under_common_nonzero_scale():
    first = general_circle_diagnostics([1.0, -4.0, 6.0, -12.0])
    second = general_circle_diagnostics([-7.0, 28.0, -42.0, 84.0])
    np.testing.assert_allclose(second.normalized_coefficients, first.normalized_coefficients)
    np.testing.assert_allclose(second.center, first.center)
    assert second.radius_squared == pytest.approx(first.radius_squared)


@pytest.mark.parametrize(
    ("coefficients", "expected_type", "expected_radius"),
    [
        ([1.0, -2.0, 4.0, 5.0], "point", 0.0),
        ([1.0, -2.0, 4.0, 6.0], "empty", None),
    ],
)
def test_general_circle_classifies_degenerate_real_loci(
    coefficients, expected_type, expected_radius
):
    result = general_circle_diagnostics(coefficients)
    assert result.locus_type == expected_type
    assert result.radius == expected_radius


def test_general_circle_uses_explicit_squared_length_tolerance():
    result = general_circle_diagnostics(
        [1.0, -2.0, 4.0, 5.0 + 5e-10],
        radius_squared_tolerance=1e-9,
    )
    assert result.locus_type == "point"
    assert result.radius_squared == pytest.approx(-5e-10, abs=2e-15)


def test_membership_reports_length_and_squared_length_residuals():
    result = circle_membership_diagnostics([1.0, 2.0], 5.0, [4.0, 6.0], **TOLERANCES)
    assert result.center_distance == pytest.approx(5.0)
    assert result.radial_residual == pytest.approx(0.0)
    assert result.algebraic_residual == pytest.approx(0.0)
    assert result.on_circle
    assert result.algebraic_threshold == pytest.approx(
        result.length_threshold * 10.0
    )


def test_membership_tolerance_is_explicit_and_scale_aware():
    point = [5.0 + 5e-8, 0.0]
    strict = circle_membership_diagnostics(
        [0.0, 0.0],
        5.0,
        point,
        absolute_tolerance=0.0,
        relative_tolerance=1e-10,
        reference_scale=10.0,
    )
    loose = circle_membership_diagnostics(
        [0.0, 0.0],
        5.0,
        point,
        absolute_tolerance=0.0,
        relative_tolerance=1e-8,
        reference_scale=10.0,
    )
    assert not strict.on_circle
    assert loose.on_circle


def test_line_circle_secant_returns_foot_and_two_intersections():
    result = circle_line_intersections([1.0, 2.0], 5.0, [1.0, 0.0, -1.0], **TOLERANCES)
    assert result.relation == "secant"
    np.testing.assert_allclose(result.foot, [1.0, 2.0])
    np.testing.assert_allclose(result.points, [[1.0, -3.0], [1.0, 7.0]])
    assert result.half_chord_length == pytest.approx(5.0)
    assert result.chord_length == pytest.approx(10.0)
    np.testing.assert_allclose(result.line_residuals, 0.0, atol=1e-14)
    np.testing.assert_allclose(result.radial_residuals, 0.0, atol=1e-14)


def test_line_circle_tangent_returns_single_contact_point():
    result = circle_line_intersections([1.0, 2.0], 5.0, [0.0, 1.0, -7.0], **TOLERANCES)
    assert result.relation == "tangent"
    np.testing.assert_allclose(result.points, [[1.0, 7.0]])
    assert result.chord_length == pytest.approx(0.0)


def test_line_circle_disjoint_returns_empty_point_array():
    result = circle_line_intersections([1.0, 2.0], 5.0, [0.0, 1.0, -8.0], **TOLERANCES)
    assert result.relation == "disjoint"
    assert result.points.shape == (0, 2)
    assert result.half_chord_length is None
    assert result.chord_length is None


def test_line_circle_classification_is_invariant_under_line_scaling():
    first = circle_line_intersections([1.0, 2.0], 5.0, [0.0, 1.0, -4.0], **TOLERANCES)
    second = circle_line_intersections([1.0, 2.0], 5.0, [0.0, -11.0, 44.0], **TOLERANCES)
    assert first.relation == second.relation == "secant"
    np.testing.assert_allclose(first.points, second.points)
    assert first.chord_length == pytest.approx(second.chord_length)


def test_near_tangent_line_is_labelled_by_declared_tolerance():
    result = circle_line_intersections(
        [0.0, 0.0],
        5.0,
        [0.0, 1.0, -(5.0 + 5e-10)],
        absolute_tolerance=1e-9,
        relative_tolerance=0.0,
        reference_scale=5.0,
    )
    assert result.relation == "tangent"
    assert result.radial_residuals[0] == pytest.approx(5e-10, abs=2e-15)


def test_chord_identity_holds_for_offset_secant():
    result = circle_line_intersections([0.0, 0.0], 5.0, [0.0, 1.0, -3.0], **TOLERANCES)
    assert result.center_distance**2 + result.half_chord_length**2 == pytest.approx(25.0)
    assert result.chord_length == pytest.approx(8.0)


def test_tangent_line_at_circle_point_has_radial_normal():
    line = tangent_line_at_circle_point([1.0, 2.0], 5.0, [4.0, 6.0], **TOLERANCES)
    expected = np.array([3.0, 4.0, -36.0]) / 5.0
    np.testing.assert_allclose(line, expected)
    assert np.dot(line[:2], [4.0, 6.0]) + line[2] == pytest.approx(0.0)


def test_tangent_line_rejects_point_outside_tolerance():
    with pytest.raises(ValueError, match="çember üzerinde değildir"):
        tangent_line_at_circle_point([0.0, 0.0], 5.0, [6.0, 0.0], **TOLERANCES)


def test_external_point_has_two_tangent_points_and_expected_length():
    result = tangent_points_from_point([0.0, 0.0], 5.0, [13.0, 0.0], **TOLERANCES)
    assert result.relation == "outside"
    np.testing.assert_allclose(
        result.points,
        [[25.0 / 13.0, -60.0 / 13.0], [25.0 / 13.0, 60.0 / 13.0]],
    )
    assert result.tangent_length == pytest.approx(12.0)
    np.testing.assert_allclose(result.radial_residuals, 0.0, atol=2e-14)
    np.testing.assert_allclose(result.orthogonality_residuals, 0.0, atol=2e-14)


def test_boundary_point_has_one_tangent_contact():
    result = tangent_points_from_point([0.0, 0.0], 5.0, [5.0, 0.0], **TOLERANCES)
    assert result.relation == "on_circle"
    np.testing.assert_allclose(result.points, [[5.0, 0.0]])
    assert result.tangent_length == pytest.approx(0.0)


def test_interior_point_has_no_real_tangent_contact():
    result = tangent_points_from_point([0.0, 0.0], 5.0, [1.0, 0.0], **TOLERANCES)
    assert result.relation == "inside"
    assert result.points.shape == (0, 2)
    assert result.tangent_length is None


def test_polar_of_external_point_is_chord_of_contact():
    polar = polar_line_of_point([0.0, 0.0], 5.0, [13.0, 0.0])
    contacts = tangent_points_from_point([0.0, 0.0], 5.0, [13.0, 0.0], **TOLERANCES)
    np.testing.assert_allclose(polar, [1.0, 0.0, -25.0 / 13.0])
    np.testing.assert_allclose(contacts.points @ polar[:2] + polar[2], 0.0, atol=2e-14)


def test_polar_of_circle_point_equals_tangent():
    polar = polar_line_of_point([1.0, 2.0], 5.0, [4.0, 6.0])
    tangent = tangent_line_at_circle_point([1.0, 2.0], 5.0, [4.0, 6.0], **TOLERANCES)
    np.testing.assert_allclose(polar, tangent)


def test_pole_polar_reciprocity():
    first = np.array([13.0, 0.0])
    second = np.array([25.0 / 13.0, 2.0])
    first_polar = polar_line_of_point([0.0, 0.0], 5.0, first)
    second_polar = polar_line_of_point([0.0, 0.0], 5.0, second)
    assert np.dot(first_polar[:2], second) + first_polar[2] == pytest.approx(0.0)
    assert np.dot(second_polar[:2], first) + second_polar[2] == pytest.approx(0.0)


def test_rigid_motion_preserves_line_circle_intersections():
    center = np.array([1.0, 2.0])
    line = np.array([0.0, 1.0, -4.0])
    before = circle_line_intersections(center, 5.0, line, **TOLERANCES)
    rotation = rotation_matrix_2d(np.deg2rad(37.0))
    translation = np.array([8.0, -3.0])
    moved_center = rotation @ center + translation
    moved_normal = rotation @ line[:2]
    moved_line = np.r_[moved_normal, line[2] - np.dot(moved_normal, translation)]
    after = circle_line_intersections(moved_center, 5.0, moved_line, **TOLERANCES)
    expected_points = before.points @ rotation.T + translation
    assert after.relation == before.relation
    assert after.chord_length == pytest.approx(before.chord_length)
    actual_order = np.lexsort((after.points[:, 1], after.points[:, 0]))
    expected_order = np.lexsort((expected_points[:, 1], expected_points[:, 0]))
    np.testing.assert_allclose(
        after.points[actual_order],
        expected_points[expected_order],
        atol=2e-14,
    )


@pytest.mark.parametrize(
    "call",
    [
        lambda: general_circle_diagnostics([0.0, 1.0, 2.0, 3.0]),
        lambda: general_circle_diagnostics([1.0, 2.0, 3.0]),
        lambda: general_circle_diagnostics([1.0, 2.0, np.nan, 3.0]),
        lambda: general_circle_diagnostics([1.0, 2.0, 3.0, 4.0], radius_squared_tolerance=-1.0),
        lambda: circle_membership_diagnostics([0.0, 0.0], -1.0, [0.0, 0.0], **TOLERANCES),
        lambda: circle_membership_diagnostics([0.0], 1.0, [0.0, 0.0], **TOLERANCES),
        lambda: circle_membership_diagnostics([0.0, 0.0], 1.0, [np.inf, 0.0], **TOLERANCES),
        lambda: circle_membership_diagnostics(
            [0.0, 0.0], 1.0, [1.0, 0.0], absolute_tolerance=0.0,
            relative_tolerance=1.0, reference_scale=1.0
        ),
        lambda: circle_membership_diagnostics(
            [0.0, 0.0], 1.0, [1.0, 0.0], absolute_tolerance=0.0,
            relative_tolerance=0.0, reference_scale=0.0
        ),
        lambda: circle_line_intersections([0.0, 0.0], 0.0, [1.0, 0.0, 0.0], **TOLERANCES),
        lambda: circle_line_intersections([0.0, 0.0], 1.0, [0.0, 0.0, 1.0], **TOLERANCES),
        lambda: tangent_line_at_circle_point([0.0, 0.0], 0.0, [0.0, 0.0], **TOLERANCES),
        lambda: tangent_points_from_point([0.0, 0.0], 0.0, [1.0, 0.0], **TOLERANCES),
        lambda: polar_line_of_point([0.0, 0.0], 5.0, [0.0, 0.0]),
        lambda: polar_line_of_point([0.0, 0.0], 0.0, [1.0, 0.0]),
        lambda: polar_line_of_point([0.0, 0.0], 5.0, [1e-10, 0.0], zero_tolerance=1e-9),
    ],
)
def test_circle_functions_reject_invalid_inputs(call):
    with pytest.raises((ValueError, OverflowError)):
        call()
