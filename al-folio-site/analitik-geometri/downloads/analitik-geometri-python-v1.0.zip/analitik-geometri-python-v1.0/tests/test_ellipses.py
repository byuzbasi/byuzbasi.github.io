import numpy as np
import pytest

from agbook import (
    ellipse_algebraic_residuals,
    ellipse_focal_sum_residuals,
    ellipse_frame_from_center_axes,
    ellipse_frame_from_foci,
    ellipse_points,
    ellipse_reflection_diagnostics,
    ellipse_tangent_line,
    rotation_matrix_2d,
)


def line_values(line, points):
    points = np.asarray(points, dtype=float)
    return points @ line[:2] + line[2]


def test_center_axes_frame_has_expected_geometry():
    frame = ellipse_frame_from_center_axes([2.0, -1.0], [3.0, 4.0], 5.0, 3.0)
    np.testing.assert_allclose(frame.major_direction, [0.6, 0.8])
    np.testing.assert_allclose(frame.minor_direction, [-0.8, 0.6])
    np.testing.assert_allclose(frame.first_focus, [-0.4, -4.2])
    np.testing.assert_allclose(frame.second_focus, [4.4, 2.2])
    assert frame.focal_distance == pytest.approx(4.0)
    assert frame.eccentricity == pytest.approx(0.8)


def test_frame_directrices_have_expected_positions():
    frame = ellipse_frame_from_center_axes([2.0, -1.0], [3.0, 4.0], 5.0, 3.0)
    offset = frame.semi_major / frame.eccentricity
    first_point = frame.center - offset * frame.major_direction
    second_point = frame.center + offset * frame.major_direction
    assert line_values(frame.first_directrix, first_point) == pytest.approx(0.0)
    assert line_values(frame.second_directrix, second_point) == pytest.approx(0.0)
    assert abs(line_values(frame.first_directrix, frame.center)) == pytest.approx(offset)
    assert abs(line_values(frame.second_directrix, frame.center)) == pytest.approx(offset)


def test_foci_frame_recovers_center_axes_and_minor_radius():
    frame = ellipse_frame_from_foci([-4.0, 1.0], [6.0, 1.0], 13.0)
    np.testing.assert_allclose(frame.center, [1.0, 1.0])
    np.testing.assert_allclose(frame.major_direction, [1.0, 0.0])
    np.testing.assert_allclose(frame.minor_direction, [0.0, 1.0])
    assert frame.focal_distance == pytest.approx(5.0)
    assert frame.semi_minor == pytest.approx(12.0)
    assert frame.eccentricity == pytest.approx(5.0 / 13.0)


def test_center_axes_and_foci_constructors_agree():
    axes = ellipse_frame_from_center_axes([1.0, -2.0], [2.0, 1.0], 7.0, 4.0)
    foci = ellipse_frame_from_foci(
        axes.first_focus,
        axes.second_focus,
        axes.semi_major,
    )
    np.testing.assert_allclose(foci.center, axes.center)
    np.testing.assert_allclose(foci.major_direction, axes.major_direction)
    np.testing.assert_allclose(foci.minor_direction, axes.minor_direction)
    assert foci.semi_minor == pytest.approx(axes.semi_minor)
    assert foci.eccentricity == pytest.approx(axes.eccentricity)


def test_stable_focal_distance_formula_near_circle_boundary():
    major = 1.0e8
    minor = np.nextafter(major, 0.0)
    frame = ellipse_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], major, minor)
    expected = np.sqrt((major - minor) * (major + minor))
    assert frame.focal_distance == expected
    assert 0.0 < frame.eccentricity < 1.0


def test_ellipse_points_support_scalar_and_vector_parameters():
    scalar = ellipse_points([1.0, 2.0], [1.0, 0.0], 5.0, 3.0, np.pi / 2.0)
    rows = ellipse_points(
        [1.0, 2.0],
        [1.0, 0.0],
        5.0,
        3.0,
        [0.0, np.pi / 2.0, np.pi],
    )
    assert scalar.shape == (2,)
    assert rows.shape == (3, 2)
    np.testing.assert_allclose(scalar, [1.0, 5.0], atol=1e-14)
    np.testing.assert_allclose(rows, [[6.0, 2.0], [1.0, 5.0], [-4.0, 2.0]], atol=1e-14)


def test_cardinal_parameters_give_vertices_and_covertices():
    frame = ellipse_frame_from_center_axes([2.0, -3.0], [3.0, 4.0], 5.0, 2.0)
    points = ellipse_points(
        frame.center,
        frame.major_direction,
        frame.semi_major,
        frame.semi_minor,
        [0.0, np.pi / 2.0, np.pi, 3.0 * np.pi / 2.0],
    )
    expected = np.vstack(
        [
            frame.center + frame.semi_major * frame.major_direction,
            frame.center + frame.semi_minor * frame.minor_direction,
            frame.center - frame.semi_major * frame.major_direction,
            frame.center - frame.semi_minor * frame.minor_direction,
        ]
    )
    np.testing.assert_allclose(points, expected, atol=2e-14)


def test_parameter_points_satisfy_both_ellipse_definitions():
    frame = ellipse_frame_from_center_axes([1.0, -2.0], [2.0, -1.0], 8.0, 5.0)
    points = ellipse_points(
        frame.center,
        frame.major_direction,
        frame.semi_major,
        frame.semi_minor,
        np.linspace(-2.0 * np.pi, 2.0 * np.pi, 41),
    )
    np.testing.assert_allclose(
        ellipse_algebraic_residuals(
            points,
            frame.center,
            frame.major_direction,
            frame.semi_major,
            frame.semi_minor,
        ),
        0.0,
        atol=5e-15,
    )
    np.testing.assert_allclose(
        ellipse_focal_sum_residuals(
            points,
            frame.first_focus,
            frame.second_focus,
            frame.semi_major,
        ),
        0.0,
        atol=5e-15,
    )


def test_residual_functions_return_scalars_for_one_point():
    frame = ellipse_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], 5.0, 3.0)
    point = [5.0, 0.0]
    algebraic = ellipse_algebraic_residuals(point, [0.0, 0.0], [1.0, 0.0], 5.0, 3.0)
    focal = ellipse_focal_sum_residuals(
        point,
        frame.first_focus,
        frame.second_focus,
        frame.semi_major,
    )
    assert isinstance(algebraic, float)
    assert isinstance(focal, float)
    assert algebraic == pytest.approx(0.0)
    assert focal == pytest.approx(0.0)


def test_off_curve_residuals_have_declared_units_and_signs():
    frame = ellipse_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], 5.0, 3.0)
    point = [0.0, 0.0]
    assert ellipse_algebraic_residuals(point, [0.0, 0.0], [1.0, 0.0], 5.0, 3.0) == pytest.approx(-1.0)
    assert ellipse_focal_sum_residuals(
        point,
        frame.first_focus,
        frame.second_focus,
        frame.semi_major,
    ) == pytest.approx(-2.0)


@pytest.mark.parametrize("parameter", [-2.7, -1.0, 0.0, 0.8, np.pi / 2.0, 2.9])
def test_tangent_contains_point_and_is_normal_to_velocity(parameter):
    center = np.array([1.0, -2.0])
    axis = np.array([3.0, 4.0])
    frame = ellipse_frame_from_center_axes(center, axis, 7.0, 2.5)
    point = ellipse_points(center, axis, 7.0, 2.5, parameter)
    tangent = ellipse_tangent_line(center, axis, 7.0, 2.5, parameter)
    velocity = (
        -7.0 * np.sin(parameter) * frame.major_direction
        + 2.5 * np.cos(parameter) * frame.minor_direction
    )
    assert line_values(tangent, point) == pytest.approx(0.0, abs=3e-14)
    assert tangent[:2] @ velocity == pytest.approx(0.0, abs=3e-14)


def test_vertex_tangents_are_perpendicular_to_major_axis():
    frame = ellipse_frame_from_center_axes([2.0, 1.0], [-1.0, 2.0], 6.0, 4.0)
    for parameter in (0.0, np.pi):
        tangent = ellipse_tangent_line(
            frame.center,
            frame.major_direction,
            frame.semi_major,
            frame.semi_minor,
            parameter,
        )
        assert abs(tangent[:2] @ frame.major_direction) == pytest.approx(1.0)


def test_first_focus_rays_reflect_toward_second_focus():
    diagnostics = ellipse_reflection_diagnostics(
        [0.0, 0.0],
        [1.0, 0.0],
        10.0,
        6.0,
        np.linspace(0.0, 2.0 * np.pi, 33, endpoint=False),
    )
    np.testing.assert_allclose(
        np.linalg.norm(diagnostics.unit_normals, axis=1),
        1.0,
        atol=2e-14,
    )
    np.testing.assert_allclose(
        diagnostics.reflected_directions,
        diagnostics.focus_directions,
        atol=2e-14,
    )
    np.testing.assert_allclose(diagnostics.focal_path_lengths, 20.0, atol=5e-14)
    assert diagnostics.maximum_focal_sum_residual < 5e-14
    assert diagnostics.maximum_direction_error < 2e-14
    assert diagnostics.maximum_focus_line_residual < 1e-13


def test_reflection_diagnostics_accept_one_parameter_as_one_row():
    diagnostics = ellipse_reflection_diagnostics(
        [0.0, 0.0], [1.0, 0.0], 5.0, 3.0, 0.0
    )
    assert diagnostics.parameters.shape == (1,)
    assert diagnostics.points.shape == (1, 2)
    np.testing.assert_allclose(diagnostics.reflected_directions[0], [-1.0, 0.0])


def test_rigid_motion_preserves_ellipse_and_reflection_directions():
    center = np.array([0.5, -1.0])
    axis = np.array([1.0, 2.0])
    parameters = np.array([-1.5, -0.25, 0.75, 2.0])
    rotation = rotation_matrix_2d(np.deg2rad(37.0))
    translation = np.array([5.0, -3.0])
    before = ellipse_reflection_diagnostics(center, axis, 7.0, 4.0, parameters)
    moved_center = rotation @ center + translation
    moved_axis = rotation @ (axis / np.linalg.norm(axis))
    after = ellipse_reflection_diagnostics(
        moved_center,
        moved_axis,
        7.0,
        4.0,
        parameters,
    )
    np.testing.assert_allclose(after.points, before.points @ rotation.T + translation)
    np.testing.assert_allclose(
        after.reflected_directions,
        before.reflected_directions @ rotation.T,
        atol=2e-14,
    )
    np.testing.assert_allclose(after.focal_path_lengths, before.focal_path_lengths)


def test_uniform_scaling_preserves_eccentricity_and_directions():
    parameters = np.array([-1.0, 0.0, 0.7, 2.0])
    before = ellipse_reflection_diagnostics([1.0, -2.0], [1.0, 0.0], 5.0, 3.0, parameters)
    after = ellipse_reflection_diagnostics([4.0, -8.0], [1.0, 0.0], 20.0, 12.0, parameters)
    np.testing.assert_allclose(after.points, 4.0 * before.points)
    np.testing.assert_allclose(after.reflected_directions, before.reflected_directions)
    np.testing.assert_allclose(after.focal_path_lengths, 4.0 * before.focal_path_lengths)
    assert ellipse_frame_from_center_axes([0, 0], [1, 0], 20, 12).eccentricity == pytest.approx(
        ellipse_frame_from_center_axes([0, 0], [1, 0], 5, 3).eccentricity
    )


def test_major_axis_sign_change_swaps_foci_but_preserves_locus():
    frame = ellipse_frame_from_center_axes([1.0, 2.0], [2.0, -1.0], 6.0, 4.0)
    reversed_frame = ellipse_frame_from_center_axes([1.0, 2.0], [-2.0, 1.0], 6.0, 4.0)
    np.testing.assert_allclose(reversed_frame.first_focus, frame.second_focus)
    np.testing.assert_allclose(reversed_frame.second_focus, frame.first_focus)
    parameters = np.array([-1.2, 0.0, 0.9, 2.7])
    forward = ellipse_points(frame.center, frame.major_direction, 6.0, 4.0, parameters)
    backward = ellipse_points(
        reversed_frame.center,
        reversed_frame.major_direction,
        6.0,
        4.0,
        parameters + np.pi,
    )
    np.testing.assert_allclose(backward, forward, atol=3e-14)


@pytest.mark.parametrize(
    "call",
    [
        lambda: ellipse_frame_from_center_axes([0.0, 0.0], [0.0, 0.0], 5.0, 3.0),
        lambda: ellipse_frame_from_center_axes([0.0, 0.0], [1.0], 5.0, 3.0),
        lambda: ellipse_frame_from_center_axes([np.nan, 0.0], [1.0, 0.0], 5.0, 3.0),
        lambda: ellipse_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], 3.0, 5.0),
        lambda: ellipse_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], 5.0, 5.0),
        lambda: ellipse_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], 5.0, 0.0),
        lambda: ellipse_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], np.inf, 3.0),
        lambda: ellipse_frame_from_foci([0.0, 0.0], [0.0, 0.0], 5.0),
        lambda: ellipse_frame_from_foci([0.0, 0.0], [1e-9, 0.0], 5.0, focus_tolerance=1e-8),
        lambda: ellipse_frame_from_foci([-5.0, 0.0], [5.0, 0.0], 5.0),
        lambda: ellipse_frame_from_foci([-5.0, 0.0], [5.0, 0.0], 4.0),
        lambda: ellipse_frame_from_foci([-1.0, 0.0], [1.0, 0.0], 5.0, focus_tolerance=-1.0),
        lambda: ellipse_points([0.0, 0.0], [1.0, 0.0], 5.0, 3.0, []),
        lambda: ellipse_points([0.0, 0.0], [1.0, 0.0], 5.0, 3.0, [[0.0, 1.0]]),
        lambda: ellipse_points([0.0, 0.0], [1.0, 0.0], 5.0, 3.0, np.nan),
        lambda: ellipse_algebraic_residuals([1.0, 2.0, 3.0], [0.0, 0.0], [1.0, 0.0], 5.0, 3.0),
        lambda: ellipse_focal_sum_residuals([1.0, 2.0, 3.0], [-4.0, 0.0], [4.0, 0.0], 5.0),
        lambda: ellipse_tangent_line([0.0, 0.0], [1.0, 0.0], 5.0, 3.0, np.inf),
        lambda: ellipse_reflection_diagnostics([0.0, 0.0], [1.0, 0.0], 5.0, 3.0, []),
    ],
)
def test_ellipse_functions_reject_invalid_inputs(call):
    with pytest.raises(ValueError):
        call()
