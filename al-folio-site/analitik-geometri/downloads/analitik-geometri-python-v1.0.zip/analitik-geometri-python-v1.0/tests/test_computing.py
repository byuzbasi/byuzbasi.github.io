import numpy as np
import pytest

from agbook import (
    canonical_array_sha256,
    geometric_close,
    pairwise_distances,
    point_set_tolerance_diagnostics,
    rigid_transform,
    rotation_matrix_2d,
)


def test_pairwise_distances_known_triangle():
    points = np.array([[0.0, 0.0], [3.0, 0.0], [0.0, 4.0]])
    expected = np.array([[0.0, 3.0, 4.0], [3.0, 0.0, 5.0], [4.0, 5.0, 0.0]])
    np.testing.assert_allclose(pairwise_distances(points), expected, rtol=0.0, atol=0.0)


def test_pairwise_distances_are_symmetric_with_zero_diagonal():
    points = np.array([[1.0, -2.0], [4.0, 5.0], [-3.0, 0.5], [2.0, 8.0]])
    distances = pairwise_distances(points)
    np.testing.assert_allclose(distances, distances.T, rtol=0.0, atol=0.0)
    np.testing.assert_array_equal(np.diag(distances), np.zeros(4))


def test_pairwise_distances_are_rigid_motion_invariant():
    points = np.array([[0.0, 0.0], [2.0, 1.0], [-1.0, 4.0]])
    transformed = rigid_transform(
        points,
        rotation_matrix_2d(np.deg2rad(37.0)),
        [1.0e4, -2.0e4],
    )
    np.testing.assert_allclose(
        pairwise_distances(transformed),
        pairwise_distances(points),
        rtol=1.0e-12,
        atol=1.0e-12,
    )


@pytest.mark.parametrize(
    "points",
    [
        [1.0, 2.0],
        [],
        [[1.0, 2.0], [3.0, np.nan]],
        [[1.0, 2.0], [3.0, np.inf]],
    ],
)
def test_pairwise_distances_reject_invalid_shapes_and_values(points):
    with pytest.raises(ValueError):
        pairwise_distances(points)


def test_pairwise_distances_detect_coordinate_subtraction_overflow():
    with pytest.raises(OverflowError, match="Koordinat farkı"):
        pairwise_distances([[-1.0e308, 0.0], [1.0e308, 0.0]])


def test_geometric_close_reports_threshold_and_decision():
    result = geometric_close(
        [10.0, 5.0],
        [10.003, 5.004],
        absolute_tolerance=0.002,
        relative_tolerance=0.001,
        reference_scale=10.0,
    )
    assert result.distance == pytest.approx(0.005)
    assert result.threshold == pytest.approx(0.012)
    assert result.close is True


def test_geometric_close_is_symmetric_for_external_reference_scale():
    keywords = {
        "absolute_tolerance": 1.0e-9,
        "relative_tolerance": 1.0e-6,
        "reference_scale": 20.0,
    }
    forward = geometric_close([2.0, 3.0], [2.00001, 3.0], **keywords)
    reverse = geometric_close([2.00001, 3.0], [2.0, 3.0], **keywords)
    assert forward == reverse


def test_geometric_close_scales_consistently_with_units():
    metres = geometric_close(
        [0.0, 0.0],
        [0.001, 0.0],
        absolute_tolerance=0.0005,
        relative_tolerance=0.001,
        reference_scale=1.0,
    )
    millimetres = geometric_close(
        [0.0, 0.0],
        [1.0, 0.0],
        absolute_tolerance=0.5,
        relative_tolerance=0.001,
        reference_scale=1000.0,
    )
    assert metres.close == millimetres.close
    assert millimetres.distance == pytest.approx(1000.0 * metres.distance)
    assert millimetres.threshold == pytest.approx(1000.0 * metres.threshold)


@pytest.mark.parametrize(
    "keywords",
    [
        {"absolute_tolerance": -1.0, "relative_tolerance": 0.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": -1.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": 1.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": 0.0, "reference_scale": -1.0},
        {"absolute_tolerance": np.inf, "relative_tolerance": 0.0, "reference_scale": 1.0},
    ],
)
def test_geometric_close_rejects_invalid_tolerances(keywords):
    with pytest.raises(ValueError):
        geometric_close([0.0, 0.0], [1.0, 0.0], **keywords)


def test_point_set_tolerance_accept_review_reject_and_overall_precedence():
    nominal = np.array([[0.0, 0.0], [10.0, 0.0], [20.0, 0.0]])
    observed = np.array([[0.02, 0.0], [10.09, 0.0], [20.16, 0.0]])
    result = point_set_tolerance_diagnostics(
        nominal,
        observed,
        specification_limit=0.10,
        measurement_uncertainty=0.02,
    )
    assert result.point_errors == pytest.approx([0.02, 0.09, 0.16])
    assert result.point_classifications == ("accept", "review", "reject")
    assert result.overall_classification == "reject"
    assert result.worst_index == 2
    assert result.worst_error == pytest.approx(0.16)


def test_point_set_tolerance_boundary_rules_are_explicit():
    nominal = [[0.0, 0.0], [1.0, 0.0]]
    observed = [[0.09375, 0.0], [1.15625, 0.0]]
    result = point_set_tolerance_diagnostics(
        nominal,
        observed,
        specification_limit=0.125,
        measurement_uncertainty=0.03125,
    )
    assert result.point_classifications == ("accept", "review")
    assert result.overall_classification == "review"


def test_point_set_tolerance_all_accept():
    result = point_set_tolerance_diagnostics(
        [[0.0, 0.0], [1.0, 0.0]],
        [[0.01, 0.0], [1.02, 0.0]],
        specification_limit=0.10,
        measurement_uncertainty=0.01,
    )
    assert result.overall_classification == "accept"


@pytest.mark.parametrize(
    "nominal,observed",
    [
        ([[0.0, 0.0]], [[0.0, 0.0], [1.0, 0.0]]),
        ([[0.0, 0.0]], [[0.0, 0.0, 0.0]]),
        ([0.0, 0.0], [0.0, 0.0]),
    ],
)
def test_point_set_tolerance_rejects_shape_mismatch(nominal, observed):
    with pytest.raises(ValueError):
        point_set_tolerance_diagnostics(
            nominal,
            observed,
            specification_limit=0.1,
            measurement_uncertainty=0.01,
        )


def test_point_set_tolerance_rejects_negative_physical_values():
    with pytest.raises(ValueError, match="specification_limit"):
        point_set_tolerance_diagnostics(
            [[0.0, 0.0]],
            [[0.0, 0.0]],
            specification_limit=-0.1,
            measurement_uncertainty=0.01,
        )
    with pytest.raises(ValueError, match="measurement_uncertainty"):
        point_set_tolerance_diagnostics(
            [[0.0, 0.0]],
            [[0.0, 0.0]],
            specification_limit=0.1,
            measurement_uncertainty=-0.01,
        )


def test_canonical_hash_is_repeatable_and_shape_sensitive():
    values = np.array([[1.0, 2.0], [3.0, 4.0]])
    assert canonical_array_sha256(values) == canonical_array_sha256(values.copy())
    assert canonical_array_sha256(values) != canonical_array_sha256(values.reshape(4))


def test_canonical_hash_normalizes_float_byte_order():
    little = np.array([1.0, 2.0, 3.0], dtype="<f8")
    big = np.array([1.0, 2.0, 3.0], dtype=">f8")
    assert canonical_array_sha256(little) == canonical_array_sha256(big)


def test_canonical_hash_rejects_empty_and_nonfinite_arrays():
    with pytest.raises(ValueError, match="boş olmayan"):
        canonical_array_sha256([])
    with pytest.raises(ValueError, match="sonlu"):
        canonical_array_sha256([1.0, np.nan])
