import numpy as np
import pytest

from agbook import cartesian_to_polar, polar_to_cartesian


def test_polar_to_cartesian_known_quadrant_points():
    polar = np.array(
        [
            [2.0, 0.0],
            [3.0, np.pi / 2.0],
            [4.0, np.pi],
            [5.0, 3.0 * np.pi / 2.0],
        ]
    )
    expected = np.array([[2.0, 0.0], [0.0, 3.0], [-4.0, 0.0], [0.0, -5.0]])
    np.testing.assert_allclose(polar_to_cartesian(polar), expected, atol=1e-14)


def test_negative_radius_has_equivalent_positive_representation():
    first = polar_to_cartesian([-3.0, np.pi / 6.0])
    second = polar_to_cartesian([3.0, 7.0 * np.pi / 6.0])
    np.testing.assert_allclose(first, second, atol=1e-14)


def test_cartesian_to_polar_uses_canonical_angle_range():
    points = np.array([[1.0, -1.0], [-1.0, 1.0], [-1.0, -1.0]])
    polar = cartesian_to_polar(points)
    np.testing.assert_allclose(polar[:, 0], np.sqrt(2.0), atol=1e-14)
    np.testing.assert_allclose(
        polar[:, 1],
        [7.0 * np.pi / 4.0, 3.0 * np.pi / 4.0, 5.0 * np.pi / 4.0],
        atol=1e-14,
    )
    assert np.all((polar[:, 1] >= 0.0) & (polar[:, 1] < 2.0 * np.pi))


def test_origin_uses_explicit_zero_angle_convention():
    np.testing.assert_array_equal(cartesian_to_polar([0.0, 0.0]), [0.0, 0.0])


def test_cartesian_polar_round_trip_for_point_cloud():
    points = np.array(
        [[2.0, 3.0], [-4.0, 5.0], [-6.0, -1.5], [7.0, -2.0], [0.0, 0.0]]
    )
    recovered = polar_to_cartesian(cartesian_to_polar(points))
    np.testing.assert_allclose(recovered, points, atol=3e-14)


@pytest.mark.parametrize(
    "call",
    [
        lambda: polar_to_cartesian([]),
        lambda: polar_to_cartesian([1.0, 2.0, 3.0]),
        lambda: polar_to_cartesian([[1.0, np.nan]]),
        lambda: cartesian_to_polar(np.empty((0, 2))),
        lambda: cartesian_to_polar([[1.0, 2.0, 3.0]]),
        lambda: cartesian_to_polar([np.inf, 0.0]),
    ],
)
def test_coordinate_functions_reject_invalid_inputs(call):
    with pytest.raises(ValueError):
        call()
