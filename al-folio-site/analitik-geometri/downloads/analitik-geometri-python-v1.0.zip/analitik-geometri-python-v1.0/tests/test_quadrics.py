from __future__ import annotations

import numpy as np
import pytest

from agbook import (
    quadric_diagnostics,
    quadric_matrices,
    quadric_plane_trace,
    quadric_residuals,
    quadric_tangent_plane_diagnostics,
    quadratic_conic_diagnostics,
    transform_quadric,
)


CASES = [
    ("ellipsoid", [1 / 4, 0, 0, 1 / 9, 0, 1 / 16, 0, 0, 0, -1]),
    ("hyperboloid_one_sheet", [1, 0, 0, 1, 0, -1, 0, 0, 0, -1]),
    ("hyperboloid_two_sheets", [-1, 0, 0, -1, 0, 1, 0, 0, 0, -1]),
    ("elliptic_cone", [1, 0, 0, 1, 0, -1, 0, 0, 0, 0]),
    ("elliptic_paraboloid", [1, 0, 0, 1, 0, 0, 0, 0, -1, 0]),
    ("hyperbolic_paraboloid", [1, 0, 0, -1, 0, 0, 0, 0, -1, 0]),
    ("elliptic_cylinder", [1 / 4, 0, 0, 1 / 9, 0, 0, 0, 0, 0, -1]),
    ("hyperbolic_cylinder", [1, 0, 0, -1, 0, 0, 0, 0, 0, -1]),
    ("parabolic_cylinder", [1, 0, 0, 0, 0, 0, 0, -1, 0, 0]),
    ("intersecting_planes", [1, 0, 0, -1, 0, 0, 0, 0, 0, 0]),
    ("parallel_planes", [1, 0, 0, 0, 0, 0, 0, 0, 0, -1]),
    ("double_plane", [1, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
    ("line", [1, 0, 0, 1, 0, 0, 0, 0, 0, 0]),
    ("point", [1, 0, 0, 1, 0, 1, 0, 0, 0, 0]),
    ("plane", [0, 0, 0, 0, 0, 0, 1, 0, 0, -1]),
    ("all_space", [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
    ("empty", [1, 0, 0, 1, 0, 1, 0, 0, 0, 1]),
]


def _rotation_xyz(ax: float, ay: float, az: float) -> np.ndarray:
    cx, sx = np.cos(ax), np.sin(ax)
    cy, sy = np.cos(ay), np.sin(ay)
    cz, sz = np.cos(az), np.sin(az)
    rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]], dtype=float)
    ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]], dtype=float)
    rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]], dtype=float)
    return rz @ ry @ rx


def _world_coefficients(
    canonical: np.ndarray,
    rotation: np.ndarray,
    center: np.ndarray,
) -> np.ndarray:
    return transform_quadric(canonical, rotation.T, -rotation.T @ center)


def test_quadric_matrices_reproduce_polynomial() -> None:
    coefficients = np.arange(1.0, 11.0)
    point = np.array([0.5, -2.0, 3.0])
    quadratic, linear, homogeneous = quadric_matrices(coefficients)
    x, y, z = point
    direct = (
        coefficients[0] * x * x
        + coefficients[1] * x * y
        + coefficients[2] * x * z
        + coefficients[3] * y * y
        + coefficients[4] * y * z
        + coefficients[5] * z * z
        + coefficients[6] * x
        + coefficients[7] * y
        + coefficients[8] * z
        + coefficients[9]
    )
    assert point @ quadratic @ point + 2.0 * linear @ point + coefficients[-1] == pytest.approx(direct)
    homogeneous_point = np.r_[point, 1.0]
    assert homogeneous_point @ homogeneous @ homogeneous_point == pytest.approx(direct)
    np.testing.assert_allclose(quadratic, quadratic.T)
    np.testing.assert_allclose(homogeneous, homogeneous.T)


@pytest.mark.parametrize(("expected", "coefficients"), CASES)
@pytest.mark.parametrize("factor", [1.0, -7.5, 1.0e8])
def test_all_quadric_classes_are_common_factor_invariant(
    expected: str,
    coefficients: list[float],
    factor: float,
) -> None:
    diagnostics = quadric_diagnostics(factor * np.asarray(coefficients))
    assert diagnostics.locus_type == expected
    assert diagnostics.relative_tolerance == 0.0
    assert not diagnostics.numerically_ambiguous


@pytest.mark.parametrize(
    ("locus_type", "rank", "inertia"),
    [
        ("ellipsoid", 3, (3, 0, 0)),
        ("hyperboloid_one_sheet", 3, (2, 1, 0)),
        ("elliptic_paraboloid", 2, (2, 0, 1)),
        ("hyperbolic_paraboloid", 2, (1, 1, 1)),
        ("parabolic_cylinder", 1, (1, 0, 2)),
        ("plane", 0, (0, 0, 3)),
    ],
)
def test_rank_and_inertia_are_reported(
    locus_type: str,
    rank: int,
    inertia: tuple[int, int, int],
) -> None:
    coefficients = dict(CASES)[locus_type]
    diagnostics = quadric_diagnostics(coefficients)
    assert diagnostics.quadratic_rank == rank
    assert diagnostics.inertia == inertia


@pytest.mark.parametrize("factor", [0.125, 1.0, 3.0, 1.0e6, -0.125, -3.0])
def test_residual_common_factor_behavior(factor: float) -> None:
    coefficients = np.array([1, 2, -1, 3, 4, -2, 5, -6, 7, -8], dtype=float)
    points = np.array([[1.0, 2.0, -1.0], [-3.0, 0.5, 2.0]])
    baseline = quadric_residuals(coefficients, points, coordinate_scale=4.0)
    changed = quadric_residuals(factor * coefficients, points, coordinate_scale=4.0)
    np.testing.assert_allclose(changed, np.sign(factor) * baseline)


def test_residual_scalar_and_vector_shapes() -> None:
    coefficients = np.array(dict(CASES)["ellipsoid"])
    assert isinstance(quadric_residuals(coefficients, [2, 0, 0]), float)
    residuals = quadric_residuals(coefficients, [[2, 0, 0], [0, 0, 0]])
    assert residuals.shape == (2,)
    np.testing.assert_allclose(residuals, [0.0, -1.0])


def test_coordinate_unit_invariance_for_residuals_and_axes() -> None:
    millimetre = np.array([1, 0, 0, 1, 0, 1, 0, 0, 0, -1_000_000], dtype=float)
    metre = np.array([1, 0, 0, 1, 0, 1, 0, 0, 0, -1], dtype=float)
    points_mm = np.array([[1000, 0, 0], [500, 0, 0]], dtype=float)
    points_m = points_mm / 1000.0
    np.testing.assert_allclose(
        quadric_residuals(millimetre, points_mm, coordinate_scale=1000.0),
        quadric_residuals(metre, points_m, coordinate_scale=1.0),
    )
    diag_mm = quadric_diagnostics(millimetre, coordinate_scale=1000.0)
    diag_m = quadric_diagnostics(metre, coordinate_scale=1.0)
    np.testing.assert_allclose(diag_mm.semi_axes / 1000.0, diag_m.semi_axes)


@pytest.mark.parametrize(
    "point",
    [
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 1.0],
        [1.0, 2.0, 3.0],
        [-2.0, 0.5, 4.0],
        [10.0, -3.0, 2.0],
        [-1.5, -2.5, 0.25],
    ],
)
def test_transform_quadric_matches_direct_substitution(point: list[float]) -> None:
    coefficients = np.arange(1.0, 11.0)
    rotation = _rotation_xyz(0.2, -0.4, 0.7)
    translation = np.array([2.0, -3.0, 5.0])
    transformed = transform_quadric(coefficients, rotation, translation)
    y = np.asarray(point)
    x = rotation @ y + translation
    q_old = quadric_residuals(coefficients, x, coordinate_scale=5.0)
    q_new = quadric_residuals(transformed, y, coordinate_scale=5.0)
    raw_old = quadric_matrices(coefficients)
    raw_new = quadric_matrices(transformed)
    value_old = x @ raw_old[0] @ x + 2 * raw_old[1] @ x + coefficients[-1]
    value_new = y @ raw_new[0] @ y + 2 * raw_new[1] @ y + transformed[-1]
    assert value_new == pytest.approx(value_old, rel=1e-12, abs=1e-12)
    assert np.isfinite(q_old)
    assert np.isfinite(q_new)


def test_rotated_shifted_ellipsoid_recovery() -> None:
    center = np.array([120.0, -80.0, 45.0])
    axes = np.array([60.0, 35.0, 20.0])
    rotation = _rotation_xyz(np.deg2rad(15), np.deg2rad(-20), np.deg2rad(35))
    canonical = np.array(
        [1 / axes[0] ** 2, 0, 0, 1 / axes[1] ** 2, 0, 1 / axes[2] ** 2, 0, 0, 0, -1]
    )
    coefficients = _world_coefficients(canonical, rotation, center)
    diagnostics = quadric_diagnostics(coefficients, coordinate_scale=100.0)
    assert diagnostics.locus_type == "ellipsoid"
    np.testing.assert_allclose(diagnostics.center, center, atol=2e-12)
    np.testing.assert_allclose(diagnostics.semi_axes, axes, atol=2e-12)
    alignment = np.abs(rotation.T @ diagnostics.principal_directions)
    np.testing.assert_allclose(alignment, np.eye(3), atol=2e-12)


@pytest.mark.parametrize(
    "locus_type",
    [
        "ellipsoid",
        "hyperboloid_one_sheet",
        "hyperboloid_two_sheets",
        "elliptic_cone",
        "elliptic_paraboloid",
        "hyperbolic_paraboloid",
    ],
)
def test_rigid_motion_preserves_nondegenerate_class(locus_type: str) -> None:
    canonical = np.asarray(dict(CASES)[locus_type], dtype=float)
    rotation = _rotation_xyz(0.31, -0.23, 0.47)
    center = np.array([4.0, -2.0, 7.0])
    coefficients = _world_coefficients(canonical, rotation, center)
    diagnostics = quadric_diagnostics(
        coefficients,
        coordinate_scale=10.0,
        relative_tolerance=1e-12,
    )
    assert diagnostics.locus_type == locus_type


def test_positive_tolerance_marks_near_rank_decision_as_ambiguous() -> None:
    coefficients = np.array([1, 0, 0, 1, 0, 1e-10, 0, 0, 0, -1], dtype=float)
    exact = quadric_diagnostics(coefficients)
    tolerant = quadric_diagnostics(coefficients, relative_tolerance=1e-8)
    assert exact.locus_type == "ellipsoid"
    assert not exact.numerically_ambiguous
    assert tolerant.locus_type == "elliptic_cylinder"
    assert tolerant.numerically_ambiguous


def test_repeated_eigenvalues_flag_nonunique_principal_frame() -> None:
    sphere = quadric_diagnostics([1, 0, 0, 1, 0, 1, 0, 0, 0, -1])
    triaxial = quadric_diagnostics([1, 0, 0, 2, 0, 3, 0, 0, 0, -1])
    assert sphere.repeated_eigenvalues
    assert not triaxial.repeated_eigenvalues


def test_projective_degeneracy_distinguishes_cylinder_from_ellipsoid() -> None:
    cylinder = quadric_diagnostics(dict(CASES)["elliptic_cylinder"])
    ellipsoid = quadric_diagnostics(dict(CASES)["ellipsoid"])
    assert cylinder.degenerate
    assert cylinder.homogeneous_rank == 3
    assert not ellipsoid.degenerate
    assert ellipsoid.homogeneous_rank == 4


@pytest.mark.parametrize(
    ("locus_type", "sample_points"),
    [
        ("intersecting_planes", [[0, 0, 3], [2, 2, -1], [-4, 4, 0]]),
        ("parallel_planes", [[1, 2, 3], [-1, 5, -7]]),
        ("double_plane", [[0, 2, 3], [0, -5, 1]]),
        ("plane", [[1, 2, 3], [1, -5, -7]]),
    ],
)
def test_component_planes_contain_representative_points(
    locus_type: str,
    sample_points: list[list[float]],
) -> None:
    diagnostics = quadric_diagnostics(dict(CASES)[locus_type])
    planes = diagnostics.component_planes
    assert planes.shape[1] == 4
    for point in np.asarray(sample_points, dtype=float):
        residuals = planes[:, :3] @ point + planes[:, 3]
        assert np.min(np.abs(residuals)) == pytest.approx(0.0, abs=1e-14)


def test_plane_trace_of_sphere_is_circle() -> None:
    sphere = np.array([1, 0, 0, 1, 0, 1, 0, 0, 0, -25], dtype=float)
    trace = quadric_plane_trace(
        sphere,
        [0, 0, 3],
        np.array([[1, 0], [0, 1], [0, 0]], dtype=float),
    )
    np.testing.assert_allclose(trace.conic_coefficients, [1, 0, 1, 0, 0, -16])
    assert trace.orthonormal
    conic = quadratic_conic_diagnostics(trace.conic_coefficients)
    assert conic.locus_type == "circle"
    np.testing.assert_allclose(conic.semi_axes, [4, 4])


@pytest.mark.parametrize("u", [-3.0, -1.0, 0.0, 0.5, 2.0])
@pytest.mark.parametrize("v", [-2.0, 0.0, 1.5])
def test_plane_trace_matches_three_dimensional_polynomial(u: float, v: float) -> None:
    coefficients = np.arange(1.0, 11.0)
    point = np.array([2.0, -1.0, 3.0])
    basis = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, -1.0]])
    trace = quadric_plane_trace(coefficients, point, basis)
    world = point + basis @ np.array([u, v])
    quadratic, linear, _ = quadric_matrices(coefficients)
    world_value = world @ quadratic @ world + 2 * linear @ world + coefficients[-1]
    a, b, c, d, e, f0 = trace.conic_coefficients
    trace_value = a * u * u + b * u * v + c * v * v + d * u + e * v + f0
    assert trace_value == pytest.approx(world_value)
    assert not trace.orthonormal


def test_tangent_plane_of_sphere() -> None:
    sphere = np.array([1, 0, 0, 1, 0, 1, 0, 0, 0, -4], dtype=float)
    diagnostics = quadric_tangent_plane_diagnostics(sphere, [2, 0, 0])
    assert diagnostics.point_on_surface
    assert diagnostics.regular
    np.testing.assert_allclose(diagnostics.gradient, [4, 0, 0])
    np.testing.assert_allclose(diagnostics.plane_coefficients, [1, 0, 0, -2])


def test_tangent_plane_is_common_factor_invariant() -> None:
    coefficients = np.array([1, 0, 0, 1, 0, 1, 0, 0, 0, -4], dtype=float)
    positive = quadric_tangent_plane_diagnostics(coefficients, [0, 2, 0])
    negative = quadric_tangent_plane_diagnostics(-7 * coefficients, [0, 2, 0])
    np.testing.assert_allclose(positive.plane_coefficients, negative.plane_coefficients)


def test_cone_vertex_is_singular_and_has_no_tangent_plane() -> None:
    cone = dict(CASES)["elliptic_cone"]
    diagnostics = quadric_tangent_plane_diagnostics(cone, [0, 0, 0])
    assert diagnostics.point_on_surface
    assert not diagnostics.regular
    assert diagnostics.plane_coefficients is None


def test_off_surface_point_does_not_receive_tangent_plane() -> None:
    sphere = np.array([1, 0, 0, 1, 0, 1, 0, 0, 0, -4], dtype=float)
    diagnostics = quadric_tangent_plane_diagnostics(sphere, [1, 0, 0])
    assert diagnostics.regular
    assert not diagnostics.point_on_surface
    assert diagnostics.plane_coefficients is None


@pytest.mark.parametrize(
    ("function_name", "arguments", "message"),
    [
        ("matrices", ([1, 2],), "coefficients"),
        ("matrices", ([0] * 9 + [np.inf],), "sonlu"),
        ("residuals", ([0] * 10, [1, 2]), "points"),
        ("residuals", ([0] * 10, [1, 2, np.inf]), "sonlu"),
        ("diagnostics", ([0] * 11,), "coefficients"),
        ("trace_point", ([0] * 10, [1, 2], np.eye(3)[:, :2]), "plane_point"),
        ("trace_basis", ([0] * 10, [0, 0, 0], np.eye(3)), "plane_basis"),
        ("trace_rank", ([0] * 10, [0, 0, 0], np.ones((3, 2))), "bağımsız"),
        ("tangent", ([0] * 10, [1, 2]), "point"),
    ],
)
def test_invalid_shapes_are_rejected(
    function_name: str,
    arguments: tuple[object, ...],
    message: str,
) -> None:
    functions = {
        "matrices": quadric_matrices,
        "residuals": quadric_residuals,
        "diagnostics": quadric_diagnostics,
        "trace_point": quadric_plane_trace,
        "trace_basis": quadric_plane_trace,
        "trace_rank": quadric_plane_trace,
        "tangent": quadric_tangent_plane_diagnostics,
    }
    with pytest.raises(ValueError, match=message):
        functions[function_name](*arguments)


@pytest.mark.parametrize(
    ("keyword", "value"),
    [
        ("coordinate_scale", 0.0),
        ("coordinate_scale", -1.0),
        ("coordinate_scale", np.inf),
        ("relative_tolerance", -1e-6),
        ("relative_tolerance", 1.0),
        ("relative_tolerance", np.nan),
    ],
)
def test_invalid_diagnostic_parameters_are_rejected(keyword: str, value: float) -> None:
    with pytest.raises(ValueError):
        quadric_diagnostics(dict(CASES)["ellipsoid"], **{keyword: value})


@pytest.mark.parametrize(
    ("rotation", "translation"),
    [
        (np.eye(2), np.zeros(3)),
        (np.eye(3), np.zeros(2)),
        (np.diag([1.0, 1.0, 2.0]), np.zeros(3)),
        (np.full((3, 3), np.nan), np.zeros(3)),
    ],
)
def test_invalid_transform_inputs_are_rejected(
    rotation: np.ndarray,
    translation: np.ndarray,
) -> None:
    with pytest.raises(ValueError):
        transform_quadric(dict(CASES)["ellipsoid"], rotation, translation)
