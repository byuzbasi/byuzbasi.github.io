import numpy as np
import pytest

from agbook import (
    classify_eccentricity,
    classify_standard_cone_plane,
    focus_directrix_diagnostics,
    focus_directrix_ratios,
    focus_directrix_residuals,
    rotation_matrix_2d,
)


PARABOLA_POINTS = np.array(
    [[0.0, 0.0], [1.0, 2.0], [1.0, -2.0], [4.0, 4.0], [4.0, -4.0]]
)


def test_parabola_points_have_zero_focus_directrix_residual():
    residuals = focus_directrix_residuals(
        PARABOLA_POINTS,
        [1.0, 0.0],
        [1.0, 0.0, 1.0],
        1.0,
    )
    np.testing.assert_allclose(residuals, 0.0, atol=2e-14)


def test_ellipse_points_have_constant_eccentricity_ratio():
    points = np.array([[5.0 / 3.0, 0.0], [-5.0, 0.0], [0.0, 2.5], [0.0, -2.5]])
    ratios = focus_directrix_ratios(points, [0.0, 0.0], [1.0, 0.0, -5.0])
    np.testing.assert_allclose(ratios, 0.5, atol=2e-14)


def test_hyperbola_points_have_constant_eccentricity_ratio():
    points = np.array([[4.0, 0.0], [4.0 / 3.0, 0.0], [0.0, 4.0], [0.0, -4.0]])
    ratios = focus_directrix_ratios(points, [0.0, 0.0], [1.0, 0.0, -2.0])
    np.testing.assert_allclose(ratios, 2.0, atol=2e-14)


def test_single_point_calls_return_scalars():
    residual = focus_directrix_residuals([1.0, 2.0], [1.0, 0.0], [1.0, 0.0, 1.0], 1.0)
    ratio = focus_directrix_ratios([1.0, 2.0], [1.0, 0.0], [1.0, 0.0, 1.0])
    assert isinstance(residual, float)
    assert isinstance(ratio, float)
    assert residual == pytest.approx(0.0, abs=1e-14)
    assert ratio == pytest.approx(1.0, abs=1e-14)


def test_directrix_scaling_does_not_change_results():
    first_ratios = focus_directrix_ratios(
        PARABOLA_POINTS,
        [1.0, 0.0],
        [1.0, 0.0, 1.0],
    )
    second_ratios = focus_directrix_ratios(
        PARABOLA_POINTS,
        [1.0, 0.0],
        [-7.0, 0.0, -7.0],
    )
    np.testing.assert_allclose(first_ratios, second_ratios, atol=1e-14)


def test_rigid_change_of_frame_preserves_ratios_and_residuals():
    rotation = rotation_matrix_2d(np.pi / 2.0)
    translation = np.array([3.0, -2.0])
    transformed_points = PARABOLA_POINTS @ rotation.T + translation
    transformed_focus = np.array([1.0, 0.0]) @ rotation.T + translation
    transformed_normal = rotation @ np.array([1.0, 0.0])
    transformed_offset = 1.0 - float(np.dot(transformed_normal, translation))
    transformed_line = np.r_[transformed_normal, transformed_offset]

    before_ratios = focus_directrix_ratios(
        PARABOLA_POINTS,
        [1.0, 0.0],
        [1.0, 0.0, 1.0],
    )
    after_ratios = focus_directrix_ratios(
        transformed_points,
        transformed_focus,
        transformed_line,
    )
    after_residuals = focus_directrix_residuals(
        transformed_points,
        transformed_focus,
        transformed_line,
        1.0,
    )
    np.testing.assert_allclose(after_ratios, before_ratios, atol=2e-14)
    np.testing.assert_allclose(after_residuals, 0.0, atol=2e-14)


def test_uniform_scale_preserves_ratio_and_scales_residual():
    point = np.array([2.0, 0.0])
    original_ratio = focus_directrix_ratios(point, [1.0, 0.0], [1.0, 0.0, 1.0])
    original_residual = focus_directrix_residuals(
        point,
        [1.0, 0.0],
        [1.0, 0.0, 1.0],
        1.0,
    )
    scaled_ratio = focus_directrix_ratios([6.0, 0.0], [3.0, 0.0], [1.0, 0.0, 3.0])
    scaled_residual = focus_directrix_residuals(
        [6.0, 0.0],
        [3.0, 0.0],
        [1.0, 0.0, 3.0],
        1.0,
    )
    assert scaled_ratio == pytest.approx(original_ratio)
    assert scaled_residual == pytest.approx(3.0 * original_residual)


def test_nonuniform_affine_scale_need_not_preserve_ratio():
    original = focus_directrix_ratios([1.0, 2.0], [1.0, 0.0], [1.0, 0.0, 1.0])
    transformed = focus_directrix_ratios([2.0, 2.0], [2.0, 0.0], [1.0, 0.0, 2.0])
    assert original == pytest.approx(1.0)
    assert transformed == pytest.approx(0.5)


def test_diagnostics_report_expected_arrays_and_maxima():
    diagnostics = focus_directrix_diagnostics(
        PARABOLA_POINTS,
        [1.0, 0.0],
        [1.0, 0.0, 1.0],
        1.0,
        reference_scale=1.0,
    )
    assert diagnostics.conic_type == "parabola"
    assert diagnostics.eccentricity == 1.0
    assert diagnostics.focus_distances.shape == (5,)
    np.testing.assert_allclose(diagnostics.ratios, 1.0, atol=2e-14)
    assert diagnostics.maximum_absolute_residual < 2e-14
    assert diagnostics.maximum_scaled_residual < 2e-14


@pytest.mark.parametrize(
    ("eccentricity", "expected"),
    [(0.25, "ellipse"), (1.0, "parabola"), (2.5, "hyperbola")],
)
def test_eccentricity_classification(eccentricity, expected):
    assert classify_eccentricity(eccentricity) == expected


def test_eccentricity_classification_uses_explicit_tolerance():
    assert classify_eccentricity(1.0 - 5e-10) == "ellipse"
    assert classify_eccentricity(1.0 - 5e-10, atol=1e-9) == "parabola"
    assert classify_eccentricity(1.0 + 5e-10) == "hyperbola"
    assert classify_eccentricity(1.0 + 5e-10, atol=1e-9) == "parabola"


@pytest.mark.parametrize(
    ("slopes", "offset", "expected", "degenerate"),
    [
        ([0.0, 0.0], 2.0, "circle", False),
        ([0.5, 0.0], 2.0, "ellipse", False),
        ([1.0, 0.0], 2.0, "parabola", False),
        ([1.25, 0.0], 2.0, "hyperbola", False),
        ([0.5, 0.0], 0.0, "point", True),
        ([1.0, 0.0], 0.0, "repeated_line", True),
        ([1.25, 0.0], 0.0, "intersecting_lines", True),
    ],
)
def test_standard_cone_plane_classification(slopes, offset, expected, degenerate):
    result = classify_standard_cone_plane(slopes, offset)
    assert result.section_type == expected
    assert result.degenerate is degenerate
    assert result.quadratic_determinant == pytest.approx(
        1.0 - result.slope_norm**2
    )


def test_standard_cone_plane_uses_separate_tolerances():
    result = classify_standard_cone_plane(
        [1.0 + 2e-10, 0.0],
        3e-10,
        slope_tolerance=1e-9,
        offset_tolerance=1e-9,
    )
    assert result.section_type == "repeated_line"
    assert result.degenerate


def test_residual_allows_a_point_on_directrix_but_ratio_rejects_it():
    residual = focus_directrix_residuals([0.0, 1.0], [2.0, 0.0], [1.0, 0.0, 0.0], 1.0)
    assert residual == pytest.approx(np.sqrt(5.0))
    with pytest.raises(ValueError, match="oran tanımsızdır"):
        focus_directrix_ratios([0.0, 1.0], [2.0, 0.0], [1.0, 0.0, 0.0])


@pytest.mark.parametrize(
    "call",
    [
        lambda: classify_eccentricity(0.0),
        lambda: classify_eccentricity(-1.0),
        lambda: classify_eccentricity(np.inf),
        lambda: classify_eccentricity(1.0, atol=-1.0),
        lambda: classify_eccentricity(1.0, atol=1.0),
        lambda: focus_directrix_residuals([], [0.0, 0.0], [1.0, 0.0, 0.0], 1.0),
        lambda: focus_directrix_residuals([1.0, 2.0, 3.0], [0.0, 0.0], [1.0, 0.0, 0.0], 1.0),
        lambda: focus_directrix_residuals([1.0, 2.0], [0.0, 0.0, 0.0], [1.0, 0.0, 0.0], 1.0),
        lambda: focus_directrix_residuals([1.0, 2.0], [0.0, 0.0], [0.0, 0.0, 1.0], 1.0),
        lambda: focus_directrix_residuals([np.nan, 2.0], [0.0, 0.0], [1.0, 0.0, 0.0], 1.0),
        lambda: focus_directrix_ratios([1.0, 2.0], [0.0, 0.0], [1.0, 0.0, 0.0], zero_tolerance=-1.0),
        lambda: focus_directrix_diagnostics([1.0, 2.0], [0.0, 0.0], [1.0, 0.0, 0.0], 1.0, reference_scale=0.0),
        lambda: classify_standard_cone_plane([1.0], 2.0),
        lambda: classify_standard_cone_plane([1.0, 0.0], np.nan),
        lambda: classify_standard_cone_plane([1.0, 0.0], 2.0, slope_tolerance=0.5),
        lambda: classify_standard_cone_plane([1.0, 0.0], 2.0, offset_tolerance=-1.0),
    ],
)
def test_conic_functions_reject_invalid_inputs(call):
    with pytest.raises(ValueError):
        call()
