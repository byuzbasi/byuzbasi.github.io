import math

import numpy as np
import pytest

from agbook import (
    axis_coordinates_3d,
    axis_frame_3d,
    circular_cone_diagnostics,
    circular_cone_points,
    circular_cylinder_diagnostics,
    circular_cylinder_points,
    conical_surface_points,
    piecewise_linear_revolution_diagnostics,
    revolution_surface_point_diagnostics,
    ruled_surface_points,
    surface_of_revolution_points,
)


@pytest.mark.parametrize(
    "axis_direction",
    [
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 1.0],
        [-2.0, 0.0, 0.0],
        [1.0, 2.0, 3.0],
        [-4.0, 5.0, -6.0],
    ],
)
def test_axis_frame_is_right_handed_and_orthonormal(axis_direction):
    frame = axis_frame_3d([3.0, -2.0, 7.0], axis_direction)
    basis = np.column_stack((frame.radial_u, frame.radial_v, frame.unit_axis))
    assert basis.T @ basis == pytest.approx(np.eye(3), abs=2.0e-15)
    assert np.linalg.det(basis) == pytest.approx(1.0, abs=2.0e-15)
    assert np.cross(frame.radial_u, frame.radial_v) == pytest.approx(frame.unit_axis)
    assert frame.used_default_reference


@pytest.mark.parametrize("scale", [0.25, 3.0, 1000.0])
def test_axis_frame_is_invariant_to_positive_direction_scaling(scale):
    base = axis_frame_3d([0, 0, 0], [1.0, 2.0, 3.0], radial_reference=[1.0, 0.0, 0.0])
    scaled = axis_frame_3d(
        [0, 0, 0],
        scale * np.array([1.0, 2.0, 3.0]),
        radial_reference=[1.0, 0.0, 0.0],
    )
    assert scaled.unit_axis == pytest.approx(base.unit_axis)
    assert scaled.radial_u == pytest.approx(base.radial_u)
    assert scaled.radial_v == pytest.approx(base.radial_v)
    assert not scaled.used_default_reference


@pytest.mark.parametrize(
    ("axis_point", "axis_direction", "kwargs"),
    [
        ([0.0, 0.0], [0.0, 0.0, 1.0], {}),
        ([0.0, 0.0, 0.0], [0.0, 1.0], {}),
        ([0.0, 0.0, 0.0], [0.0, 0.0, 0.0], {}),
        ([0.0, math.nan, 0.0], [0.0, 0.0, 1.0], {}),
        ([0.0, 0.0, 0.0], [0.0, math.inf, 1.0], {}),
        ([0.0, 0.0, 0.0], [0.0, 0.0, 1.0], {"radial_reference": [1.0, 0.0]}),
        ([0.0, 0.0, 0.0], [0.0, 0.0, 1.0], {"radial_reference": [0.0, 0.0, 0.0]}),
        ([0.0, 0.0, 0.0], [0.0, 0.0, 1.0], {"radial_reference": [0.0, 0.0, 2.0]}),
        ([0.0, 0.0, 0.0], [0.0, 0.0, 1.0], {"direction_zero_tolerance": -1.0}),
        ([0.0, 0.0, 0.0], [0.0, 0.0, 1.0], {"angular_tolerance": math.pi}),
    ],
)
def test_axis_frame_rejects_invalid_inputs(axis_point, axis_direction, kwargs):
    with pytest.raises((ValueError, OverflowError)):
        axis_frame_3d(axis_point, axis_direction, **kwargs)


@pytest.mark.parametrize(
    ("point", "expected_axial", "expected_radial"),
    [
        ([4.0, 6.0, 8.0], 5.0, 5.0),
        ([1.0, 2.0, 3.0], 0.0, 0.0),
        ([1.0, 2.0, -2.0], -5.0, 0.0),
        ([-2.0, -2.0, 8.0], 5.0, 5.0),
    ],
)
def test_axis_coordinates_known_z_axis(point, expected_axial, expected_radial):
    result = axis_coordinates_3d(point, [1.0, 2.0, 3.0], [0.0, 0.0, 7.0])
    assert result.axial_coordinate == pytest.approx(expected_axial)
    assert result.radial_distance == pytest.approx(expected_radial)
    assert result.axis_projection + result.radial_vector == pytest.approx(point)
    assert result.reconstruction_residual == pytest.approx(0.0)


def test_axis_coordinates_are_translation_covariant():
    shift = np.array([13.0, -8.0, 21.0])
    base = axis_coordinates_3d([3.0, 4.0, 5.0], [1.0, 1.0, 1.0], [1.0, 2.0, -1.0])
    moved = axis_coordinates_3d(
        np.array([3.0, 4.0, 5.0]) + shift,
        np.array([1.0, 1.0, 1.0]) + shift,
        [1.0, 2.0, -1.0],
    )
    assert moved.axial_coordinate == pytest.approx(base.axial_coordinate)
    assert moved.radial_distance == pytest.approx(base.radial_distance)
    assert moved.axis_projection == pytest.approx(base.axis_projection + shift)


@pytest.mark.parametrize(
    "bad_point",
    [[1.0, 2.0], [], [1.0, 2.0, 3.0, 4.0], [1.0, math.nan, 3.0]],
)
def test_axis_coordinates_reject_invalid_points(bad_point):
    with pytest.raises(ValueError):
        axis_coordinates_3d(bad_point, [0, 0, 0], [0, 0, 1])


@pytest.mark.parametrize(
    (
        "point",
        "bounds",
        "radial_relation",
        "axial_relation",
        "lateral",
        "cap",
        "boundary",
        "solid",
    ),
    [
        ([2.0, 0.0, 3.0], None, "on_surface", "unbounded", True, False, True, True),
        ([1.0, 0.0, 3.0], None, "inside", "unbounded", False, False, False, True),
        ([3.0, 0.0, 3.0], None, "outside", "unbounded", False, False, False, False),
        ([2.0, 0.0, 2.0], (0.0, 5.0), "on_surface", "within", True, False, True, True),
        ([1.0, 0.0, 0.0], (0.0, 5.0), "inside", "lower_boundary", False, True, True, True),
        ([2.0, 0.0, 0.0], (0.0, 5.0), "on_surface", "lower_boundary", True, True, True, True),
        ([1.0, 0.0, 5.0], (0.0, 5.0), "inside", "upper_boundary", False, True, True, True),
        ([1.0, 0.0, -1.0], (0.0, 5.0), "inside", "below", False, False, False, False),
        ([1.0, 0.0, 6.0], (0.0, 5.0), "inside", "above", False, False, False, False),
        ([3.0, 0.0, 0.0], (0.0, 5.0), "outside", "lower_boundary", False, False, False, False),
    ],
)
def test_cylinder_membership_cases(
    point,
    bounds,
    radial_relation,
    axial_relation,
    lateral,
    cap,
    boundary,
    solid,
):
    result = circular_cylinder_diagnostics(
        [0, 0, 0], [0, 0, 4], 2.0, point, axial_bounds=bounds
    )
    assert result.radial_relation == radial_relation
    assert result.axial_relation == axial_relation
    assert result.lateral_surface_member is lateral
    assert result.cap_member is cap
    assert result.boundary_member is boundary
    assert result.closed_solid_member is solid


def test_cylinder_tolerance_only_changes_numerical_classification():
    result = circular_cylinder_diagnostics(
        [0, 0, 0],
        [0, 0, 1],
        2.0,
        [2.0005, 0.0, -0.0005],
        axial_bounds=(0.0, 5.0),
        absolute_tolerance=0.001,
    )
    assert result.radial_relation == "on_surface"
    assert result.axial_relation == "lower_boundary"
    assert result.length_tolerance == pytest.approx(0.001)


def test_cylinder_is_rigid_motion_and_scale_consistent():
    rotation = np.array([[0.0, -1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
    shift = np.array([7.0, -3.0, 11.0])
    axis_point = np.array([1.0, 2.0, 3.0])
    axis_direction = np.array([1.0, 1.0, 2.0])
    point = np.array([2.0, 1.0, 6.0])
    base = circular_cylinder_diagnostics(axis_point, axis_direction, 2.0, point)
    moved = circular_cylinder_diagnostics(
        rotation @ axis_point + shift,
        rotation @ axis_direction,
        2.0,
        rotation @ point + shift,
    )
    scaled = circular_cylinder_diagnostics(1000 * axis_point, axis_direction, 2000.0, 1000 * point)
    assert moved.radial_distance == pytest.approx(base.radial_distance)
    assert moved.axial_coordinate == pytest.approx(base.axial_coordinate)
    assert scaled.radial_distance == pytest.approx(1000.0 * base.radial_distance)
    assert scaled.signed_radial_residual == pytest.approx(1000.0 * base.signed_radial_residual)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"radius": -1.0},
        {"radius": math.inf},
        {"axial_bounds": (2.0, 1.0)},
        {"axial_bounds": (1.0, 1.0)},
        {"axial_bounds": (0.0,)},
        {"absolute_tolerance": -1.0},
        {"relative_tolerance": -1.0},
        {"relative_tolerance": 1.0},
        {"reference_scale": 0.0},
        {"reference_scale": math.inf},
    ],
)
def test_cylinder_rejects_invalid_scalar_settings(kwargs):
    settings = {"radius": 2.0}
    settings.update(kwargs)
    radius = settings.pop("radius")
    with pytest.raises((ValueError, TypeError)):
        circular_cylinder_diagnostics([0, 0, 0], [0, 0, 1], radius, [2, 0, 0], **settings)


@pytest.mark.parametrize(
    ("point", "nappe", "side", "relation", "is_apex", "allowed"),
    [
        ([0.0, 0.0, 0.0], "double", "apex", "on_surface", True, True),
        ([1.0, 0.0, 1.0], "double", "positive", "on_surface", False, True),
        ([1.0, 0.0, -1.0], "double", "negative", "on_surface", False, True),
        ([0.5, 0.0, 1.0], "double", "positive", "inside", False, True),
        ([2.0, 0.0, 1.0], "double", "positive", "outside", False, True),
        ([1.0, 0.0, -1.0], "positive", "negative", "wrong_nappe", False, False),
        ([1.0, 0.0, 1.0], "negative", "positive", "wrong_nappe", False, False),
        ([1.0, 0.0, -1.0], "negative", "negative", "on_surface", False, True),
        ([1.0, 0.0, 0.0], "double", "equatorial", "outside", False, True),
        ([0.0, 0.0, 0.0], "positive", "apex", "on_surface", True, True),
    ],
)
def test_cone_membership_cases(point, nappe, side, relation, is_apex, allowed):
    result = circular_cone_diagnostics(
        [0, 0, 0],
        [0, 0, 2],
        math.pi / 4.0,
        point,
        nappe=nappe,
        absolute_tolerance=2.0e-15,
    )
    assert result.side == side
    assert result.relation == relation
    assert result.is_apex is is_apex
    assert result.allowed_nappe is allowed


def test_cone_handles_arbitrary_axis():
    result = circular_cone_diagnostics(
        [1.0, -1.0, 2.0],
        [3.0, 0.0, 0.0],
        math.pi / 4.0,
        [3.0, 1.0, 2.0],
        nappe="positive",
        absolute_tolerance=2.0e-15,
    )
    assert result.axial_coordinate == pytest.approx(2.0)
    assert result.radial_distance == pytest.approx(2.0)
    assert result.relation == "on_surface"


def test_cone_is_rigid_motion_and_unit_consistent():
    rotation = np.array([[0.0, 0.0, 1.0], [0.0, 1.0, 0.0], [-1.0, 0.0, 0.0]])
    shift = np.array([8.0, 2.0, -5.0])
    apex = np.array([1.0, 2.0, 3.0])
    direction = np.array([1.0, -2.0, 2.0])
    point = np.array([4.0, 2.0, 3.0])
    base = circular_cone_diagnostics(apex, direction, 0.6, point)
    moved = circular_cone_diagnostics(rotation @ apex + shift, rotation @ direction, 0.6, rotation @ point + shift)
    scaled = circular_cone_diagnostics(0.001 * apex, direction, 0.6, 0.001 * point)
    assert moved.axial_coordinate == pytest.approx(base.axial_coordinate)
    assert moved.radial_distance == pytest.approx(base.radial_distance)
    assert scaled.axial_coordinate == pytest.approx(0.001 * base.axial_coordinate)
    assert scaled.radial_distance == pytest.approx(0.001 * base.radial_distance)


@pytest.mark.parametrize(
    ("angle", "kwargs"),
    [
        (0.0, {}),
        (-0.1, {}),
        (math.pi / 2.0, {}),
        (math.nan, {}),
        (0.5, {"nappe": "upper"}),
        (0.5, {"absolute_tolerance": -1.0}),
        (0.5, {"relative_tolerance": 1.0}),
        (0.5, {"reference_scale": 0.0}),
    ],
)
def test_cone_rejects_invalid_settings(angle, kwargs):
    with pytest.raises(ValueError):
        circular_cone_diagnostics([0, 0, 0], [0, 0, 1], angle, [1, 0, 1], **kwargs)


def test_ruled_surface_points_follow_each_generator():
    directrix = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])
    result = ruled_surface_points(directrix, [0.0, 0.0, 2.0], [-1.0, 0.0, 3.0])
    assert result.shape == (2, 3, 3)
    assert result[:, 1, :] == pytest.approx(directrix)
    assert result[0, 2] - result[0, 0] == pytest.approx([0.0, 0.0, 8.0])


@pytest.mark.parametrize(
    ("directrix", "direction", "parameters"),
    [
        ([], [0, 0, 1], [0, 1]),
        ([[1, 2]], [0, 0, 1], [0, 1]),
        ([[1, 2, 3]], [0, 0, 0], [0, 1]),
        ([[1, 2, 3]], [0, 0, 1], []),
    ],
)
def test_ruled_surface_rejects_invalid_inputs(directrix, direction, parameters):
    with pytest.raises(ValueError):
        ruled_surface_points(directrix, direction, parameters)


def test_conical_surface_points_include_apex_and_directrix():
    apex = np.array([1.0, 2.0, 3.0])
    directrix = np.array([[3.0, 2.0, 5.0], [1.0, 6.0, 7.0]])
    result = conical_surface_points(apex, directrix, [0.0, 0.5, 1.0])
    assert result.shape == (2, 3, 3)
    assert result[:, 0, :] == pytest.approx(np.repeat(apex[None, :], 2, axis=0))
    assert result[:, -1, :] == pytest.approx(directrix)


@pytest.mark.parametrize(
    ("apex", "directrix", "scales"),
    [
        ([0, 0], [[1, 0, 0]], [0, 1]),
        ([0, 0, 0], [], [0, 1]),
        ([0, 0, 0], [[1, 0, 0]], []),
        ([0, 0, math.nan], [[1, 0, 0]], [0, 1]),
    ],
)
def test_conical_surface_rejects_invalid_inputs(apex, directrix, scales):
    with pytest.raises(ValueError):
        conical_surface_points(apex, directrix, scales)


def test_circular_cylinder_parameterization_shape_seam_and_membership():
    axial = np.array([-2.0, 0.0, 4.0])
    angles = np.linspace(0.0, 2.0 * math.pi, 9)
    points = circular_cylinder_points([1, 2, 3], [1, -2, 2], 5.0, axial, angles)
    assert points.shape == (3, 9, 3)
    assert points[:, 0, :] == pytest.approx(points[:, -1, :])
    for point in points.reshape(-1, 3):
        assert circular_cylinder_diagnostics([1, 2, 3], [1, -2, 2], 5.0, point, absolute_tolerance=2e-14).lateral_surface_member


def test_circular_cone_parameterization_satisfies_double_cone():
    axial = np.array([-3.0, 0.0, 2.0])
    angles = np.linspace(0.0, 2.0 * math.pi, 7)
    points = circular_cone_points([0, 0, 0], [2, 1, -2], 0.5, axial, angles)
    assert points.shape == (3, 7, 3)
    assert points[:, 0, :] == pytest.approx(points[:, -1, :])
    for point in points.reshape(-1, 3):
        result = circular_cone_diagnostics([0, 0, 0], [2, 1, -2], 0.5, point, absolute_tolerance=2e-14)
        assert result.relation == "on_surface"


def test_surface_of_revolution_matches_profile_coordinates():
    axial = np.array([0.0, 2.0, 5.0])
    radial = np.array([0.0, 3.0, 1.0])
    angles = np.linspace(0.0, 2.0 * math.pi, 5)
    points = surface_of_revolution_points([4, -2, 7], [0, 0, 1], axial, radial, angles)
    assert points.shape == (3, 5, 3)
    assert points[:, 0, :] == pytest.approx(points[:, -1, :])
    for row, expected_radius in zip(points, radial, strict=True):
        distances = [axis_coordinates_3d(point, [4, -2, 7], [0, 0, 1]).radial_distance for point in row]
        assert distances == pytest.approx(np.full(5, expected_radius))


@pytest.mark.parametrize(
    ("axial", "radial", "angles"),
    [
        ([0, 1], [1], [0, 1]),
        ([0], [-1], [0, 1]),
        ([], [], [0, 1]),
        ([0], [1], []),
    ],
)
def test_surface_of_revolution_rejects_invalid_profiles(axial, radial, angles):
    with pytest.raises(ValueError):
        surface_of_revolution_points([0, 0, 0], [0, 0, 1], axial, radial, angles)


def test_revolution_diagnostics_for_cylinder_profile():
    result = revolution_surface_point_diagnostics(
        [0, 0, 0], [0, 0, 1], 3.0, 2.0, 1.0, 0.0, 0.7
    )
    assert result.regular
    assert result.area_density == pytest.approx(2.0)
    assert result.normal_norm == pytest.approx(2.0)
    assert np.dot(result.profile_tangent, result.angular_tangent) == pytest.approx(0.0)
    assert np.dot(result.unit_normal, result.profile_tangent) == pytest.approx(0.0)
    assert np.dot(result.unit_normal, result.angular_tangent) == pytest.approx(0.0)


@pytest.mark.parametrize(
    ("radial", "axial_prime", "radial_prime", "regular", "density"),
    [
        (2.0, 1.0, 1.0, True, 2.0 * math.sqrt(2.0)),
        (0.0, 1.0, 1.0, False, 0.0),
        (2.0, 0.0, 0.0, False, 0.0),
        (1.0e-8, 1.0, 0.0, True, 1.0e-8),
    ],
)
def test_revolution_regularity_cases(radial, axial_prime, radial_prime, regular, density):
    result = revolution_surface_point_diagnostics(
        [0, 0, 0], [1, 0, 0], 1.0, radial, axial_prime, radial_prime, 1.2
    )
    assert result.regular is regular
    assert result.area_density == pytest.approx(density)
    assert result.is_axis_point is (radial == 0.0)


def test_revolution_normal_tolerance_can_mark_near_degenerate_point():
    result = revolution_surface_point_diagnostics(
        [0, 0, 0], [0, 1, 0], 0.0, 1.0e-9, 1.0, 0.0, 0.0, normal_zero_tolerance=1.0e-8
    )
    assert not result.regular
    assert result.unit_normal is None


@pytest.mark.parametrize(
    "kwargs",
    [
        {"radial_coordinate": -1.0},
        {"axial_derivative": math.inf},
        {"radial_derivative": math.nan},
        {"angle": math.inf},
        {"normal_zero_tolerance": -1.0},
    ],
)
def test_revolution_diagnostics_reject_invalid_values(kwargs):
    settings = dict(
        axial_coordinate=0.0,
        radial_coordinate=1.0,
        axial_derivative=1.0,
        radial_derivative=0.0,
        angle=0.0,
    )
    settings.update(kwargs)
    with pytest.raises(ValueError):
        revolution_surface_point_diagnostics([0, 0, 0], [0, 0, 1], **settings)


def test_piecewise_application_profile_has_exact_expected_areas():
    result = piecewise_linear_revolution_diagnostics(
        [0.0, 30.0, 60.0, 90.0], [18.0, 18.0, 12.0, 12.0]
    )
    assert result.segment_types == ("cylinder", "frustum", "cylinder")
    assert result.slant_lengths == pytest.approx([30.0, 6.0 * math.sqrt(26.0), 30.0])
    assert result.segment_lateral_areas == pytest.approx(
        [1080.0 * math.pi, 180.0 * math.pi * math.sqrt(26.0), 720.0 * math.pi]
    )
    assert result.total_lateral_area == pytest.approx(180.0 * math.pi * (10.0 + math.sqrt(26.0)))
    assert result.smooth_interior_joins == (False, False)


@pytest.mark.parametrize(
    ("axial", "radial", "expected_type"),
    [
        ([0.0, 2.0], [3.0, 3.0], "cylinder"),
        ([0.0, 2.0], [3.0, 1.0], "frustum"),
        ([0.0, 2.0], [0.0, 3.0], "cone"),
        ([0.0, 0.0], [1.0, 3.0], "annulus"),
        ([0.0, 2.0], [0.0, 0.0], "axis"),
    ],
)
def test_piecewise_profile_classifies_segment_types(axial, radial, expected_type):
    result = piecewise_linear_revolution_diagnostics(axial, radial)
    assert result.segment_types == (expected_type,)


def test_piecewise_profile_area_scales_with_square_of_length_unit():
    base = piecewise_linear_revolution_diagnostics([0, 30, 60, 90], [18, 18, 12, 12])
    metres = piecewise_linear_revolution_diagnostics(
        np.array([0, 30, 60, 90]) / 1000.0,
        np.array([18, 18, 12, 12]) / 1000.0,
    )
    assert metres.total_lateral_area == pytest.approx(base.total_lateral_area / 1.0e6)


def test_piecewise_profile_detects_smooth_and_sharp_joins():
    smooth = piecewise_linear_revolution_diagnostics(
        [0.0, 1.0, 2.0], [1.0, 2.0, 3.0], angular_tolerance=1.0e-12
    )
    sharp = piecewise_linear_revolution_diagnostics(
        [0.0, 1.0, 2.0], [1.0, 1.0, 2.0], angular_tolerance=1.0e-12
    )
    assert smooth.smooth_interior_joins == (True,)
    assert sharp.smooth_interior_joins == (False,)


@pytest.mark.parametrize(
    ("axial", "radial", "kwargs"),
    [
        ([0.0], [1.0], {}),
        ([0.0, 1.0], [1.0], {}),
        ([0.0, 1.0], [1.0, -1.0], {}),
        ([0.0, 0.0], [1.0, 1.0], {}),
        ([0.0, 1.0], [1.0, 2.0], {"length_tolerance": -1.0}),
        ([0.0, 1.0], [1.0, 2.0], {"angular_tolerance": math.pi}),
    ],
)
def test_piecewise_profile_rejects_invalid_inputs(axial, radial, kwargs):
    with pytest.raises(ValueError):
        piecewise_linear_revolution_diagnostics(axial, radial, **kwargs)
