from __future__ import annotations

import math

import numpy as np
import pytest

from agbook import (
    apply_similarity_registration,
    fit_similarity_registration,
    orbit_ellipse_frame_3d,
    orbit_ellipse_points_3d,
    project_pinhole,
    ray_plane_intersection,
    reflect_direction,
    triangulate_point_dlt,
)


def _rotation_2d(angle: float) -> np.ndarray:
    cosine, sine = math.cos(angle), math.sin(angle)
    return np.array([[cosine, -sine], [sine, cosine]])


def _rotation_3d(ax: float, ay: float, az: float) -> np.ndarray:
    cx, sx = math.cos(ax), math.sin(ax)
    cy, sy = math.cos(ay), math.sin(ay)
    cz, sz = math.cos(az), math.sin(az)
    rx = np.array([[1.0, 0.0, 0.0], [0.0, cx, -sx], [0.0, sx, cx]])
    ry = np.array([[cy, 0.0, sy], [0.0, 1.0, 0.0], [-sy, 0.0, cy]])
    rz = np.array([[cz, -sz, 0.0], [sz, cz, 0.0], [0.0, 0.0, 1.0]])
    return rz @ ry @ rx


def _camera(center: np.ndarray) -> np.ndarray:
    intrinsic = np.array([[900.0, 0.0, 640.0], [0.0, 900.0, 360.0], [0.0, 0.0, 1.0]])
    return intrinsic @ np.column_stack((np.eye(3), -center))


def test_similarity_registration_recovers_exact_2d_transform() -> None:
    source = np.array([[-2.0, 1.0], [0.0, -1.0], [3.0, 2.0], [1.0, 4.0]])
    rotation = _rotation_2d(0.63)
    scale = 1.7
    translation = np.array([12.0, -5.0])
    target = scale * (source @ rotation.T) + translation
    result = fit_similarity_registration(source, target)
    np.testing.assert_allclose(result.rotation, rotation, atol=2e-15)
    np.testing.assert_allclose(result.translation, translation, atol=3e-15)
    assert result.scale == pytest.approx(scale, abs=2e-15)
    assert result.rms_residual < 4e-15
    assert np.linalg.det(result.rotation) == pytest.approx(1.0)


def test_rigid_registration_recovers_exact_3d_transform() -> None:
    source = np.array(
        [[0.0, 0.0, 0.0], [2.0, 0.0, 0.0], [0.0, 3.0, 0.0], [1.0, 1.0, 4.0]]
    )
    rotation = _rotation_3d(0.2, -0.4, 0.7)
    translation = np.array([8.0, -3.0, 5.0])
    target = source @ rotation.T + translation
    result = fit_similarity_registration(source, target, estimate_scale=False)
    np.testing.assert_allclose(result.rotation, rotation, atol=5e-15)
    np.testing.assert_allclose(result.translation, translation, atol=5e-15)
    assert result.scale == 1.0
    assert result.rms_residual < 7e-15


def test_registration_weights_reduce_declared_outlier_influence() -> None:
    source = np.array([[-2.0, 0.0], [0.0, -1.0], [2.0, 0.5], [0.0, 2.0], [1.0, 1.0]])
    rotation = _rotation_2d(-0.41)
    target = 1.2 * (source @ rotation.T) + np.array([4.0, -7.0])
    contaminated = target.copy()
    contaminated[-1] += np.array([12.0, -9.0])
    ordinary = fit_similarity_registration(source, contaminated)
    weighted = fit_similarity_registration(
        source,
        contaminated,
        weights=[1.0, 1.0, 1.0, 1.0, 0.001],
    )
    ordinary_error = np.linalg.norm(ordinary.rotation - rotation) + abs(ordinary.scale - 1.2)
    weighted_error = np.linalg.norm(weighted.rotation - rotation) + abs(weighted.scale - 1.2)
    assert weighted_error < ordinary_error


def test_apply_registration_matches_stored_transformed_source() -> None:
    source = np.array([[0.0, 0.0], [2.0, 0.0], [0.0, 3.0]])
    target = 2.0 * (source @ _rotation_2d(0.3).T) + np.array([7.0, -4.0])
    result = fit_similarity_registration(source, target)
    np.testing.assert_allclose(apply_similarity_registration(source, result), target, atol=2e-15)
    np.testing.assert_allclose(result.transformed_source, target, atol=2e-15)


def test_registration_homogeneous_matrix_matches_row_formula() -> None:
    source = np.array([[-1.0, 2.0], [2.0, 1.0], [0.0, -3.0]])
    target = 0.75 * (source @ _rotation_2d(-0.7).T) + np.array([3.0, 9.0])
    result = fit_similarity_registration(source, target)
    homogeneous = np.column_stack((source, np.ones(source.shape[0])))
    transformed = (result.homogeneous_matrix @ homogeneous.T).T[:, :2]
    np.testing.assert_allclose(transformed, target, atol=3e-15)


def test_registration_unit_scaling_is_equivariant() -> None:
    source = np.array([[0.0, 0.0], [2.0, -1.0], [4.0, 3.0], [-2.0, 1.0]])
    target = 1.05 * (source @ _rotation_2d(0.2).T) + np.array([10.0, -4.0])
    base = fit_similarity_registration(source, target)
    converted = fit_similarity_registration(1000.0 * source, 1000.0 * target)
    np.testing.assert_allclose(converted.rotation, base.rotation, atol=2e-15)
    assert converted.scale == pytest.approx(base.scale, abs=2e-15)
    np.testing.assert_allclose(converted.translation, 1000.0 * base.translation, atol=3e-12)
    assert converted.rms_residual == pytest.approx(1000.0 * base.rms_residual, abs=2e-12)


def test_registration_does_not_mutate_inputs() -> None:
    source = np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]])
    target = source + np.array([2.0, 3.0])
    weights = np.array([1.0, 2.0, 3.0])
    copies = (source.copy(), target.copy(), weights.copy())
    fit_similarity_registration(source, target, weights=weights)
    np.testing.assert_array_equal(source, copies[0])
    np.testing.assert_array_equal(target, copies[1])
    np.testing.assert_array_equal(weights, copies[2])


def test_registration_prohibits_reflection() -> None:
    source = np.array([[0.0, 0.0], [2.0, 0.0], [0.0, 1.0], [1.0, 2.0]])
    target = source * np.array([-1.0, 1.0])
    result = fit_similarity_registration(source, target, estimate_scale=False)
    assert np.linalg.det(result.rotation) == pytest.approx(1.0)
    assert result.reflection_correction_applied
    assert result.rms_residual > 0.5


def test_two_distinct_points_determine_2d_similarity() -> None:
    source = np.array([[0.0, 0.0], [3.0, 0.0]])
    target = np.array([[2.0, -1.0], [2.0, 5.0]])
    result = fit_similarity_registration(source, target)
    np.testing.assert_allclose(result.transformed_source, target, atol=2e-15)
    assert result.scale == pytest.approx(2.0)


def test_rigid_option_keeps_unit_scale_for_inexact_data() -> None:
    source = np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]])
    target = 2.0 * source + np.array([1.0, 1.0])
    result = fit_similarity_registration(source, target, estimate_scale=False)
    assert result.scale == 1.0
    assert result.rms_residual > 0.4


@pytest.mark.parametrize(
    ("source", "target"),
    [
        (np.ones((3, 4)), np.ones((3, 4))),
        (np.ones((3, 2)), np.ones((4, 2))),
        (np.ones((1, 2)), np.ones((1, 2))),
        (np.array([[0.0, np.nan], [1.0, 2.0]]), np.ones((2, 2))),
        (np.ones((2, 3)), np.ones((2, 3))),
    ],
)
def test_registration_rejects_invalid_point_inputs(source, target) -> None:
    with pytest.raises(ValueError):
        fit_similarity_registration(source, target)


@pytest.mark.parametrize(
    "weights",
    [[1.0, 2.0], [1.0, 0.0, 1.0], [1.0, -1.0, 1.0], [1.0, np.nan, 1.0]],
)
def test_registration_rejects_invalid_weights(weights) -> None:
    source = np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]])
    with pytest.raises(ValueError):
        fit_similarity_registration(source, source, weights=weights)


def test_registration_rejects_collinear_3d_configuration() -> None:
    source = np.array([[0.0, 0.0, 0.0], [1.0, 2.0, 3.0], [2.0, 4.0, 6.0]])
    with pytest.raises(ValueError, match="rank"):
        fit_similarity_registration(source, source)


def test_pinhole_projection_matches_normalized_coordinates() -> None:
    camera = np.column_stack((np.eye(3), np.zeros(3)))
    points = np.array([[2.0, -1.0, 4.0], [-3.0, 2.0, 5.0]])
    result = project_pinhole(camera, points)
    np.testing.assert_allclose(result.image_points, [[0.5, -0.25], [-0.6, 0.4]])
    assert np.all(result.in_front)


@pytest.mark.parametrize("factor", [0.001, 7.0, -4.0])
def test_camera_matrix_scale_does_not_change_projection(factor: float) -> None:
    camera = _camera(np.array([1.0, -0.5, 0.0]))
    points = np.array([[0.2, 0.3, 4.0], [-1.0, 0.5, 7.0]])
    base = project_pinhole(camera, points)
    scaled = project_pinhole(factor * camera, points)
    np.testing.assert_allclose(scaled.image_points, base.image_points, atol=2e-13)
    np.testing.assert_array_equal(scaled.in_front, base.in_front)


def test_projection_preserves_behind_camera_diagnostic() -> None:
    camera = np.column_stack((np.eye(3), np.zeros(3)))
    result = project_pinhole(camera, [[1.0, 1.0, -2.0]])
    np.testing.assert_allclose(result.image_points, [[-0.5, -0.5]])
    assert not result.in_front[0]


def test_projection_rejects_point_on_camera_plane() -> None:
    camera = np.column_stack((np.eye(3), np.zeros(3)))
    with pytest.raises(ValueError, match="sonlu olmayan"):
        project_pinhole(camera, [[1.0, 2.0, 0.0]])


@pytest.mark.parametrize(
    "camera",
    [np.ones((3, 3)), np.zeros((3, 4)), np.full((3, 4), np.nan)],
)
def test_projection_rejects_invalid_camera(camera) -> None:
    with pytest.raises(ValueError):
        project_pinhole(camera, [[0.0, 0.0, 1.0]])


def test_two_view_dlt_recovers_exact_point() -> None:
    cameras = np.stack((_camera(np.array([0.0, 0.0, 0.0])), _camera(np.array([1.2, 0.0, 0.0]))))
    point = np.array([[0.4, -0.3, 5.0]])
    images = np.vstack([project_pinhole(camera, point).image_points[0] for camera in cameras])
    result = triangulate_point_dlt(cameras, images)
    np.testing.assert_allclose(result.point, point[0], atol=4e-14)
    assert result.rms_reprojection < 2e-12
    assert np.all(result.in_front)


def test_three_view_dlt_recovers_exact_point() -> None:
    centers = np.array([[0.0, 0.0, 0.0], [1.2, 0.0, 0.0], [0.0, 0.8, 0.0]])
    cameras = np.stack([_camera(center) for center in centers])
    point = np.array([[0.7, 0.4, 6.5]])
    images = np.vstack([project_pinhole(camera, point).image_points[0] for camera in cameras])
    result = triangulate_point_dlt(cameras, images)
    np.testing.assert_allclose(result.point, point[0], atol=8e-14)
    assert result.diagnostics.effective_rank == 3


def test_noisy_triangulation_reports_reprojection_residual() -> None:
    cameras = np.stack((_camera(np.zeros(3)), _camera(np.array([1.0, 0.0, 0.0]))))
    point = np.array([[0.3, 0.2, 4.5]])
    images = np.vstack([project_pinhole(camera, point).image_points[0] for camera in cameras])
    images += np.array([[0.4, -0.2], [-0.3, 0.15]])
    result = triangulate_point_dlt(cameras, images)
    assert result.rms_reprojection > 0.0
    assert result.rms_reprojection < 1.0
    assert np.all(result.in_front)


def test_triangulation_is_invariant_to_independent_camera_scales() -> None:
    cameras = np.stack((_camera(np.zeros(3)), _camera(np.array([1.5, 0.0, 0.0]))))
    point = np.array([[0.6, -0.2, 8.0]])
    images = np.vstack([project_pinhole(camera, point).image_points[0] for camera in cameras])
    base = triangulate_point_dlt(cameras, images)
    scaled = triangulate_point_dlt(cameras * np.array([3.0, -0.02])[:, None, None], images)
    np.testing.assert_allclose(scaled.point, base.point, atol=2e-13)


def test_identical_cameras_do_not_triangulate_unique_point() -> None:
    camera = _camera(np.zeros(3))
    cameras = np.stack((camera, camera))
    with pytest.raises(ValueError, match="benzersiz"):
        triangulate_point_dlt(cameras, [[640.0, 360.0], [640.0, 360.0]])


@pytest.mark.parametrize(
    ("cameras", "images"),
    [
        (np.ones((1, 3, 4)), np.ones((1, 2))),
        (np.ones((2, 4, 4)), np.ones((2, 2))),
        (np.ones((2, 3, 4)), np.ones((3, 2))),
    ],
)
def test_triangulation_rejects_invalid_shapes(cameras, images) -> None:
    with pytest.raises(ValueError):
        triangulate_point_dlt(cameras, images)


def test_ray_plane_forward_intersection() -> None:
    result = ray_plane_intersection([0.0, 0.0, 3.0], [0.0, 0.0, -2.0], [0, 0, 0], [0, 0, 1])
    assert result.classification == "intersecting"
    assert result.ray_parameter == pytest.approx(3.0)
    np.testing.assert_allclose(result.point, [0.0, 0.0, 0.0])


def test_ray_origin_on_plane_has_zero_parameter() -> None:
    result = ray_plane_intersection([1.0, 2.0, 0.0], [0.0, 0.0, 1.0], [0, 0, 0], [0, 0, 1])
    assert result.classification == "intersecting"
    assert result.ray_parameter == 0.0
    np.testing.assert_allclose(result.point, [1.0, 2.0, 0.0])


def test_ray_plane_reports_intersection_behind_origin() -> None:
    result = ray_plane_intersection([0.0, 0.0, 2.0], [0.0, 0.0, 1.0], [0, 0, 0], [0, 0, 1])
    assert result.classification == "behind"
    assert result.ray_parameter == pytest.approx(-2.0)


def test_ray_plane_parallel_and_coplanar_are_distinct() -> None:
    parallel = ray_plane_intersection([0, 0, 2], [1, 0, 0], [0, 0, 0], [0, 0, 1])
    coplanar = ray_plane_intersection([0, 0, 0], [1, 0, 0], [0, 0, 0], [0, 0, 1])
    assert parallel.classification == "parallel"
    assert coplanar.classification == "coplanar"
    assert parallel.point is None and coplanar.point is None


def test_ray_plane_is_invariant_to_direction_and_normal_scale() -> None:
    base = ray_plane_intersection([1, 2, 4], [1, 0, -2], [0, 0, 0], [0, 0, 1])
    scaled = ray_plane_intersection([1, 2, 4], [10, 0, -20], [0, 0, 0], [0, 0, -7])
    np.testing.assert_allclose(scaled.point, base.point, atol=2e-15)
    assert scaled.ray_parameter == pytest.approx(base.ray_parameter)


def test_reflection_preserves_norm_and_angle_law() -> None:
    incoming = np.array([1.0, 0.0, -2.0])
    normal = np.array([0.0, 0.0, 1.0])
    reflected = reflect_direction(incoming, normal)
    np.testing.assert_allclose(reflected, [1.0, 0.0, 2.0])
    assert np.linalg.norm(reflected) == pytest.approx(np.linalg.norm(incoming))
    assert abs(reflected @ normal) == pytest.approx(abs(incoming @ normal))


def test_reflection_is_invariant_to_normal_sign() -> None:
    direction = np.array([0.3, -0.4, -0.8])
    np.testing.assert_allclose(
        reflect_direction(direction, [0, 0, 1]),
        reflect_direction(direction, [0, 0, -5]),
    )


@pytest.mark.parametrize(
    "call",
    [
        lambda: reflect_direction([0, 0, 0], [0, 0, 1]),
        lambda: reflect_direction([1, 0, 0], [0, 0, 0]),
        lambda: ray_plane_intersection([0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 1]),
        lambda: ray_plane_intersection([0, 0, 0], [1, 0, 0], [0, 0, 0], [0, 0, 0]),
    ],
)
def test_ray_and_reflection_reject_zero_directions(call) -> None:
    with pytest.raises(ValueError):
        call()


def test_orbit_frame_recovers_apsides_and_axes() -> None:
    frame = orbit_ellipse_frame_3d([0, 0, 0], [1, 0, 0], [0, 0, 1], 7.0, 13.0)
    assert frame.semi_major_axis == pytest.approx(10.0)
    assert frame.focal_distance == pytest.approx(3.0)
    assert frame.semi_minor_axis == pytest.approx(math.sqrt(91.0))
    assert frame.eccentricity == pytest.approx(0.3)
    assert frame.semi_latus_rectum == pytest.approx(9.1)
    np.testing.assert_allclose(frame.periapsis, [7.0, 0.0, 0.0])
    np.testing.assert_allclose(frame.apoapsis, [-13.0, 0.0, 0.0])


def test_orbit_samples_satisfy_focal_sum() -> None:
    frame = orbit_ellipse_frame_3d([2, -1, 4], [1, 2, 0], [1, -0.5, 3], 8.0, 20.0)
    parameters = np.linspace(0.0, 2.0 * np.pi, 81)
    points = orbit_ellipse_points_3d(frame, parameters)
    focal_sum = np.linalg.norm(points - frame.focus, axis=1) + np.linalg.norm(
        points - frame.second_focus,
        axis=1,
    )
    np.testing.assert_allclose(focal_sum, 2.0 * frame.semi_major_axis, atol=8e-14)


def test_orbit_samples_lie_in_declared_plane() -> None:
    frame = orbit_ellipse_frame_3d([3, 1, -2], [2, 1, 4], [1, -2, 2], 5.0, 11.0)
    points = orbit_ellipse_points_3d(frame, np.linspace(0.0, 2.0 * np.pi, 25))
    residuals = (points - frame.focus) @ frame.plane_normal
    np.testing.assert_allclose(residuals, 0.0, atol=3e-15)


def test_equal_apsides_produce_circle() -> None:
    frame = orbit_ellipse_frame_3d([0, 0, 0], [1, 0, 0], [0, 0, 1], 6.0, 6.0)
    assert frame.eccentricity == 0.0
    assert frame.semi_major_axis == frame.semi_minor_axis == 6.0
    np.testing.assert_allclose(frame.center, frame.focus)
    np.testing.assert_allclose(frame.second_focus, frame.focus)


def test_periapsis_direction_is_projected_into_plane() -> None:
    frame = orbit_ellipse_frame_3d([0, 0, 0], [2, 0, 7], [0, 0, 1], 3.0, 9.0)
    np.testing.assert_allclose(frame.periapsis_direction, [1, 0, 0])
    assert frame.periapsis_direction @ frame.plane_normal == pytest.approx(0.0)


def test_orbit_geometry_scales_with_length_unit() -> None:
    base = orbit_ellipse_frame_3d([1, 2, 3], [1, 0, 0], [0, 0, 1], 4.0, 10.0)
    converted = orbit_ellipse_frame_3d([1000, 2000, 3000], [1, 0, 0], [0, 0, 1], 4000.0, 10000.0)
    np.testing.assert_allclose(converted.center, 1000.0 * base.center)
    np.testing.assert_allclose(converted.periapsis, 1000.0 * base.periapsis)
    assert converted.semi_major_axis == pytest.approx(1000.0 * base.semi_major_axis)
    assert converted.eccentricity == pytest.approx(base.eccentricity)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"periapsis_radius": 0.0, "apoapsis_radius": 2.0},
        {"periapsis_radius": 3.0, "apoapsis_radius": 2.0},
        {"periapsis_radius": 1.0, "apoapsis_radius": np.inf},
    ],
)
def test_orbit_rejects_invalid_apsis_distances(kwargs) -> None:
    with pytest.raises(ValueError):
        orbit_ellipse_frame_3d([0, 0, 0], [1, 0, 0], [0, 0, 1], **kwargs)


def test_orbit_rejects_direction_parallel_to_normal() -> None:
    with pytest.raises(ValueError, match="düzleminde"):
        orbit_ellipse_frame_3d([0, 0, 0], [0, 0, 2], [0, 0, 1], 2.0, 5.0)


def test_orbit_sampling_rejects_empty_or_nonvector_parameters() -> None:
    frame = orbit_ellipse_frame_3d([0, 0, 0], [1, 0, 0], [0, 0, 1], 2.0, 5.0)
    with pytest.raises(ValueError):
        orbit_ellipse_points_3d(frame, [])
    with pytest.raises(ValueError):
        orbit_ellipse_points_3d(frame, [[0.0, 1.0]])
