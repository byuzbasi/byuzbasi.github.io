import numpy as np
import pytest

from agbook import (
    circle_line_intersections,
    circle_pencil_member,
    point_power,
    radical_axis_diagnostics,
    radical_center_diagnostics,
    rotation_matrix_2d,
    tangent_points_from_point,
)


TOLERANCES = {
    "absolute_tolerance": 1e-12,
    "relative_tolerance": 1e-12,
    "reference_scale": 20.0,
}

CENTER_TOLERANCES = {
    "angular_tolerance": 1e-12,
    **TOLERANCES,
}


def test_point_power_has_signed_inside_boundary_outside_classes():
    assert point_power([0.0, 0.0], 5.0, [0.0, 0.0]) == pytest.approx(-25.0)
    assert point_power([0.0, 0.0], 5.0, [3.0, 4.0]) == pytest.approx(0.0)
    assert point_power([0.0, 0.0], 5.0, [13.0, 0.0]) == pytest.approx(144.0)


def test_point_power_is_rigid_invariant_and_scales_quadratically():
    center = np.array([1.0, -2.0])
    point = np.array([7.0, 3.0])
    power = point_power(center, 4.0, point)
    rotation = rotation_matrix_2d(np.deg2rad(31.0))
    translation = np.array([8.0, -5.0])
    moved_power = point_power(
        rotation @ center + translation,
        4.0,
        rotation @ point + translation,
    )
    assert moved_power == pytest.approx(power)
    assert point_power(3.0 * center, 12.0, 3.0 * point) == pytest.approx(9.0 * power)


@pytest.mark.parametrize("point", [[10.0, 0.0], [0.0, 0.0]])
def test_directed_secant_parameter_product_equals_point_power(point):
    point_array = np.asarray(point, dtype=float)
    intersections = circle_line_intersections(
        [0.0, 0.0],
        5.0,
        [0.0, 1.0, 0.0],
        **TOLERANCES,
    )
    parameters = intersections.points[:, 0] - point_array[0]
    assert np.prod(parameters) == pytest.approx(
        point_power([0.0, 0.0], 5.0, point_array)
    )


def test_external_tangent_length_squared_equals_point_power():
    tangents = tangent_points_from_point(
        [0.0, 0.0], 5.0, [13.0, 0.0], **TOLERANCES
    )
    assert tangents.tangent_length**2 == pytest.approx(
        point_power([0.0, 0.0], 5.0, [13.0, 0.0])
    )


def test_radical_axis_is_equal_power_line_perpendicular_to_centers():
    axis = radical_axis_diagnostics(
        [0.0, 0.0], 5.0, [6.0, 0.0], 4.0, **TOLERANCES
    )
    assert axis.relation == "line"
    np.testing.assert_allclose(axis.line_coefficients, [1.0, 0.0, -3.75])
    for point in ([3.75, -8.0], [3.75, 4.0]):
        assert point_power([0.0, 0.0], 5.0, point) == pytest.approx(
            point_power([6.0, 0.0], 4.0, point)
        )
    assert np.dot(axis.line_coefficients[:2], [0.0, 1.0]) == pytest.approx(0.0)


def test_radical_axis_contains_common_chord_points():
    axis = radical_axis_diagnostics(
        [0.0, 0.0], 5.0, [6.0, 0.0], 5.0, **TOLERANCES
    )
    expected = np.array([[3.0, -4.0], [3.0, 4.0]])
    np.testing.assert_allclose(
        expected @ axis.line_coefficients[:2] + axis.line_coefficients[2],
        0.0,
        atol=1e-14,
    )
    for point in expected:
        assert point_power([0.0, 0.0], 5.0, point) == pytest.approx(0.0)
        assert point_power([6.0, 0.0], 5.0, point) == pytest.approx(0.0)


def test_radical_axis_exists_for_tangent_and_disjoint_circles():
    tangent = radical_axis_diagnostics(
        [0.0, 0.0], 2.0, [5.0, 0.0], 3.0, **TOLERANCES
    )
    disjoint = radical_axis_diagnostics(
        [0.0, 0.0], 2.0, [8.0, 0.0], 3.0, **TOLERANCES
    )
    assert tangent.relation == disjoint.relation == "line"
    assert np.dot(tangent.line_coefficients[:2], [2.0, 0.0]) + tangent.line_coefficients[2] == pytest.approx(0.0)
    axis_point = [59.0 / 16.0, 1.0]
    assert point_power([0.0, 0.0], 2.0, axis_point) == pytest.approx(
        point_power([8.0, 0.0], 3.0, axis_point)
    )


def test_concentric_radical_axis_limits_are_not_fake_lines():
    identical = radical_axis_diagnostics(
        [1.0, 2.0], 5.0, [1.0, 2.0], 5.0, **TOLERANCES
    )
    unequal = radical_axis_diagnostics(
        [1.0, 2.0], 5.0, [1.0, 2.0], 3.0, **TOLERANCES
    )
    assert identical.relation == "all_plane"
    assert identical.line_coefficients is None
    assert unequal.relation == "empty"
    assert unequal.line_coefficients is None


def test_near_concentric_classification_records_declared_tolerance():
    result = radical_axis_diagnostics(
        [0.0, 0.0],
        5.0,
        [5e-10, 0.0],
        5.0,
        absolute_tolerance=1e-9,
        relative_tolerance=0.0,
        reference_scale=5.0,
    )
    assert result.relation == "all_plane"
    assert result.center_distance == pytest.approx(5e-10)
    assert result.length_threshold == pytest.approx(1e-9)


def test_radical_axis_transforms_with_a_rigid_frame():
    first_center = np.array([0.0, 0.0])
    second_center = np.array([6.0, 0.0])
    before = radical_axis_diagnostics(
        first_center, 5.0, second_center, 4.0, **TOLERANCES
    )
    rotation = rotation_matrix_2d(np.deg2rad(27.0))
    translation = np.array([10.0, -7.0])
    after = radical_axis_diagnostics(
        rotation @ first_center + translation,
        5.0,
        rotation @ second_center + translation,
        4.0,
        **TOLERANCES,
    )
    moved_normal = rotation @ before.line_coefficients[:2]
    moved_offset = before.line_coefficients[2] - np.dot(moved_normal, translation)
    expected = np.r_[moved_normal, moved_offset]
    if expected[0] < 0.0 or (expected[0] == 0.0 and expected[1] < 0.0):
        expected = -expected
    np.testing.assert_allclose(after.line_coefficients, expected, atol=2e-14)


def test_three_noncollinear_circles_have_unique_radical_center():
    centers = np.array([[0.0, 0.0], [8.0, 0.0], [0.0, 6.0]])
    radii = np.array([5.0, 3.0, 4.0])
    result = radical_center_diagnostics(centers, radii, **CENTER_TOLERANCES)
    assert result.relation == "point"
    np.testing.assert_allclose(result.point, [5.0, 3.75])
    np.testing.assert_allclose(result.power_values, 14.0625, atol=1e-13)
    assert result.power_spread == pytest.approx(0.0, abs=1e-13)
    assert result.max_axis_residual == pytest.approx(0.0, abs=1e-13)


def test_radical_center_is_invariant_under_circle_permutation():
    centers = np.array([[0.0, 0.0], [8.0, 0.0], [0.0, 6.0]])
    radii = np.array([5.0, 3.0, 4.0])
    first = radical_center_diagnostics(centers, radii, **CENTER_TOLERANCES)
    second = radical_center_diagnostics(
        centers[[2, 0, 1]], radii[[2, 0, 1]], **CENTER_TOLERANCES
    )
    np.testing.assert_allclose(second.point, first.point)
    assert second.power_spread == pytest.approx(first.power_spread, abs=1e-13)


def test_duplicate_circle_and_third_circle_leave_one_radical_line():
    centers = np.array([[0.0, 0.0], [0.0, 0.0], [6.0, 0.0]])
    radii = np.array([5.0, 5.0, 4.0])
    result = radical_center_diagnostics(centers, radii, **CENTER_TOLERANCES)
    assert result.relation == "line"
    np.testing.assert_allclose(result.line_coefficients, [1.0, 0.0, -3.75])


def test_three_identical_circles_have_all_plane_equal_power_locus():
    result = radical_center_diagnostics(
        [[1.0, 2.0], [1.0, 2.0], [1.0, 2.0]],
        [5.0, 5.0, 5.0],
        **CENTER_TOLERANCES,
    )
    assert result.relation == "all_plane"


def test_concentric_unequal_pair_makes_radical_center_empty():
    result = radical_center_diagnostics(
        [[0.0, 0.0], [0.0, 0.0], [3.0, 0.0]],
        [5.0, 4.0, 2.0],
        **CENTER_TOLERANCES,
    )
    assert result.relation == "empty"


def test_collinear_coaxal_system_can_have_common_radical_line():
    result = radical_center_diagnostics(
        [[0.0, 0.0], [4.0, 0.0], [8.0, 0.0]],
        [5.0, 5.0, np.sqrt(57.0)],
        **CENTER_TOLERANCES,
    )
    assert result.relation == "line"
    np.testing.assert_allclose(result.line_coefficients, [1.0, 0.0, -2.0])


def test_collinear_noncoaxal_system_has_no_radical_center():
    result = radical_center_diagnostics(
        [[0.0, 0.0], [4.0, 0.0], [8.0, 0.0]],
        [5.0, 5.0, 5.0],
        **CENTER_TOLERANCES,
    )
    assert result.relation == "empty"


def test_circle_pencil_endpoints_and_input_scale_invariance():
    first = [1.0, 0.0, 0.0, -25.0]
    second = [1.0, -12.0, 0.0, 20.0]
    start = circle_pencil_member(first, second, 0.0)
    end = circle_pencil_member(first, second, 1.0)
    scaled = circle_pencil_member(np.multiply(first, -7.0), np.multiply(second, 3.0), 0.25)
    reference = circle_pencil_member(first, second, 0.25)
    np.testing.assert_allclose(start.normalized_coefficients, first)
    np.testing.assert_allclose(end.normalized_coefficients, second)
    np.testing.assert_allclose(scaled.normalized_coefficients, reference.normalized_coefficients)


def test_two_pencil_members_share_original_radical_axis():
    first = [1.0, 0.0, 0.0, -25.0]
    second = [1.0, -12.0, 0.0, 20.0]
    member_a = circle_pencil_member(first, second, 0.25)
    member_b = circle_pencil_member(first, second, 0.75)
    original_axis = radical_axis_diagnostics(
        [0.0, 0.0], 5.0, [6.0, 0.0], 4.0, **TOLERANCES
    )
    member_axis = radical_axis_diagnostics(
        member_a.center,
        member_a.radius,
        member_b.center,
        member_b.radius,
        **TOLERANCES,
    )
    np.testing.assert_allclose(member_axis.line_coefficients, original_axis.line_coefficients)


def test_circle_pencil_can_cross_point_and_empty_real_members():
    first = [1.0, 0.0, 0.0, -1.0]
    second = [1.0, 0.0, 0.0, -9.0]
    point_member = circle_pencil_member(first, second, -0.125)
    empty_member = circle_pencil_member(first, second, -0.25)
    assert point_member.locus_type == "point"
    assert point_member.radius_squared == pytest.approx(0.0)
    assert empty_member.locus_type == "empty"
    assert empty_member.radius_squared == pytest.approx(-1.0)


@pytest.mark.parametrize(
    "call",
    [
        lambda: point_power([0.0], 1.0, [0.0, 0.0]),
        lambda: point_power([0.0, 0.0], -1.0, [0.0, 0.0]),
        lambda: point_power([0.0, 0.0], 1.0, [np.inf, 0.0]),
        lambda: point_power([0.0, 0.0], 1.0, [1e308, 1e308]),
        lambda: radical_axis_diagnostics(
            [0.0, 0.0], 1.0, [1.0, 0.0], 1.0,
            absolute_tolerance=-1.0, relative_tolerance=0.0, reference_scale=1.0
        ),
        lambda: radical_center_diagnostics(
            [[0.0, 0.0], [1.0, 0.0]], [1.0, 1.0], **CENTER_TOLERANCES
        ),
        lambda: radical_center_diagnostics(
            [[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]],
            [1.0, -1.0, 1.0],
            **CENTER_TOLERANCES,
        ),
        lambda: radical_center_diagnostics(
            [[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]],
            [1.0, 1.0, 1.0],
            angular_tolerance=1.0,
            **TOLERANCES,
        ),
        lambda: circle_pencil_member([0.0, 1.0, 2.0, 3.0], [1.0, 0.0, 0.0, -1.0], 0.5),
        lambda: circle_pencil_member([1.0, 0.0, 0.0, -1.0], [1.0, 0.0, 0.0, -4.0], np.nan),
        lambda: circle_pencil_member(
            [1.0, 0.0, 0.0, -1.0], [1.0, 0.0, 0.0, -4.0], 0.5,
            radius_squared_tolerance=-1.0
        ),
    ],
)
def test_circle_system_functions_reject_invalid_inputs(call):
    with pytest.raises((ValueError, OverflowError)):
        call()
