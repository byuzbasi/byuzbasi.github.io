import numpy as np
import pytest

from agbook import (
    angle_between,
    inner_product,
    orthogonal_decomposition,
    scalar_projection,
    unit_vector,
    vector_norm,
    vector_projection,
)


def test_inner_product_matches_component_sum():
    assert inner_product([3.0, -2.0, 4.0], [-1.0, 5.0, 2.0]) == pytest.approx(-5.0)


def test_inner_product_rejects_dimension_mismatch():
    with pytest.raises(ValueError, match="aynı boyutta"):
        inner_product([1.0, 2.0], [1.0, 2.0, 3.0])


def test_vector_norm_handles_large_finite_components_without_intermediate_overflow():
    assert vector_norm([1.0e307, 1.0e307]) == pytest.approx(np.sqrt(2.0) * 1.0e307)


def test_vector_norm_is_homogeneous():
    vector = np.array([3.0, -4.0, 12.0])
    assert vector_norm(-2.5 * vector) == pytest.approx(2.5 * vector_norm(vector))


def test_unit_vector_has_unit_norm_and_preserves_direction():
    result = unit_vector([-3.0, 4.0])
    np.testing.assert_allclose(result, [-0.6, 0.8])
    assert vector_norm(result) == pytest.approx(1.0)


def test_unit_vector_rejects_zero_vector():
    with pytest.raises(ValueError, match="yönü tanımlı değildir"):
        unit_vector([0.0, 0.0])


def test_unit_vector_rejects_application_defined_near_zero_vector():
    with pytest.raises(ValueError, match="eşik altındaki"):
        unit_vector([1.0e-10, 0.0], zero_tolerance=1.0e-9)


def test_negative_zero_tolerance_is_rejected():
    with pytest.raises(ValueError, match="negatif olmayan"):
        unit_vector([1.0, 0.0], zero_tolerance=-1.0)


@pytest.mark.parametrize(
    "u,v,expected",
    [
        ([1.0, 0.0], [0.0, 1.0], 90.0),
        ([1.0, 2.0], [2.0, 4.0], 0.0),
        ([1.0, 2.0], [-2.0, -4.0], 180.0),
    ],
)
def test_angle_between_canonical_cases(u, v, expected):
    assert angle_between(u, v, degrees=True) == pytest.approx(expected)


def test_angle_is_invariant_under_positive_rescaling():
    reference = angle_between([2.0, -1.0], [4.0, 3.0])
    scaled = angle_between([2.0e100, -1.0e100], [4.0e-120, 3.0e-120])
    assert scaled == pytest.approx(reference)


def test_angle_of_nearly_parallel_large_vectors_is_finite():
    angle = angle_between([1.0e307, 1.0e307], [1.0e307, 1.0e307 - 1.0e292])
    assert np.isfinite(angle)
    assert 0.0 <= angle <= np.pi


def test_angle_rejects_zero_vector():
    with pytest.raises(ValueError, match="yönü tanımlı değildir"):
        angle_between([0.0, 0.0], [1.0, 0.0])


def test_scalar_projection_keeps_orientation_sign():
    assert scalar_projection([-3.0, 4.0], [1.0, 0.0]) == pytest.approx(-3.0)


def test_vector_projection_matches_closed_form():
    result = vector_projection([5.0, 1.0], [2.0, 1.0])
    np.testing.assert_allclose(result, [22.0 / 5.0, 11.0 / 5.0])


def test_projection_is_invariant_under_nonzero_direction_rescaling():
    expected = vector_projection([5.0, 1.0], [2.0, 1.0])
    np.testing.assert_allclose(vector_projection([5.0, 1.0], [2.0e8, 1.0e8]), expected)
    np.testing.assert_allclose(vector_projection([5.0, 1.0], [-6.0, -3.0]), expected)


def test_projection_rejects_zero_direction():
    with pytest.raises(ValueError, match="yönü tanımlı değildir"):
        vector_projection([1.0, 2.0], [0.0, 0.0])


def test_orthogonal_decomposition_reconstructs_vector_and_is_perpendicular():
    result = orthogonal_decomposition([5.0, 1.0], [2.0, 1.0])
    np.testing.assert_allclose(result.parallel + result.perpendicular, [5.0, 1.0])
    np.testing.assert_allclose(result.perpendicular, [3.0 / 5.0, -6.0 / 5.0])
    assert inner_product(result.perpendicular, [2.0, 1.0]) == pytest.approx(0.0, abs=1e-14)
    assert result.reconstruction_residual == pytest.approx(0.0)
    assert result.orthogonality_residual < 1e-14


def test_perpendicular_vector_has_zero_projection():
    result = orthogonal_decomposition([3.0, -6.0], [2.0, 1.0])
    np.testing.assert_allclose(result.parallel, [0.0, 0.0], atol=1e-14)
    np.testing.assert_allclose(result.perpendicular, [3.0, -6.0], atol=1e-14)


@pytest.mark.parametrize(
    "u,v",
    [
        ([1.0, 2.0], [3.0, 4.0]),
        ([-2.0, 5.0, 1.0], [4.0, -1.0, 3.0]),
        ([0.5, -7.0, 2.0, 9.0], [-3.0, 1.0, 4.0, 2.0]),
    ],
)
def test_cauchy_schwarz_numerically(u, v):
    assert abs(inner_product(u, v)) <= vector_norm(u) * vector_norm(v) + 1e-14


def test_triangle_inequality_numerically():
    u = np.array([3.0, -4.0, 1.0])
    v = np.array([-2.0, 7.0, 5.0])
    assert vector_norm(u + v) <= vector_norm(u) + vector_norm(v) + 1e-14


def test_nonfinite_vector_is_rejected():
    with pytest.raises(ValueError, match="sonlu"):
        vector_norm([1.0, np.inf])
