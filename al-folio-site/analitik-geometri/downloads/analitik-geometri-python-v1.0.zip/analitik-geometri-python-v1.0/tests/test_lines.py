import numpy as np
import pytest

from agbook import (
    canonical_line_coefficients,
    line_direction,
    line_from_point_direction,
    line_from_points,
    line_membership_diagnostics,
    line_residuals,
    parametric_line_points,
)


def test_canonical_coefficients_normalize_and_fix_sign():
    result = canonical_line_coefficients([2.0, -4.0, 10.0])
    np.testing.assert_allclose(result, [1.0 / np.sqrt(5.0), -2.0 / np.sqrt(5.0), 5.0 / np.sqrt(5.0)])
    assert np.linalg.norm(result[:2]) == pytest.approx(1.0)


@pytest.mark.parametrize("scale", [3.5, -7.0, 1.0e120, -1.0e-120])
def test_canonical_coefficients_ignore_nonzero_common_scale(scale):
    reference = canonical_line_coefficients([1.0, -2.0, 5.0])
    np.testing.assert_allclose(
        canonical_line_coefficients(scale * np.array([1.0, -2.0, 5.0])),
        reference,
        rtol=1.0e-14,
        atol=1.0e-14,
    )


def test_line_from_two_points_matches_known_general_equation():
    result = line_from_points([-1.0, 2.0], [3.0, 4.0])
    expected = canonical_line_coefficients([1.0, -2.0, 5.0])
    np.testing.assert_allclose(result, expected, rtol=0.0, atol=1.0e-15)
    np.testing.assert_allclose(line_residuals(result, [[-1.0, 2.0], [3.0, 4.0]]), 0.0, atol=1.0e-15)


def test_line_is_invariant_under_anchor_shift_and_direction_rescaling():
    first = line_from_point_direction([1.0, -2.0], [3.0, 4.0])
    second = line_from_point_direction([7.0, 6.0], [-9.0, -12.0])
    np.testing.assert_allclose(first, second, rtol=0.0, atol=1.0e-15)


def test_vertical_and_horizontal_lines_need_no_slope():
    vertical = line_from_point_direction([-4.0, 3.0], [0.0, 5.0])
    horizontal = line_from_point_direction([2.0, 3.0], [-7.0, 0.0])
    np.testing.assert_allclose(vertical, [1.0, 0.0, 4.0])
    np.testing.assert_allclose(horizontal, [0.0, 1.0, -3.0])


def test_line_direction_is_unit_and_orthogonal_to_normal():
    coefficients = canonical_line_coefficients([3.0, 4.0, -5.0])
    direction = line_direction(coefficients)
    assert np.linalg.norm(direction) == pytest.approx(1.0)
    assert np.dot(direction, coefficients[:2]) == pytest.approx(0.0)


def test_parametric_points_have_expected_shape_and_zero_residuals():
    anchor = np.array([-2.0, 1.0])
    direction = np.array([4.0, 2.0])
    parameters = np.array([-1.0, 0.0, 0.5, 2.0])
    points = parametric_line_points(anchor, direction, parameters)
    assert points.shape == (4, 2)
    np.testing.assert_allclose(points[2], [0.0, 2.0])
    coefficients = line_from_point_direction(anchor, direction)
    np.testing.assert_allclose(line_residuals(coefficients, points), 0.0, atol=1.0e-15)


def test_raw_residuals_follow_equation_scale():
    points = np.array([[1.0, 2.0], [3.0, -1.0]])
    reference = line_residuals([2.0, -1.0, 3.0], points)
    scaled = line_residuals([-5.0, 2.5, -7.5], points)
    np.testing.assert_allclose(scaled, -2.5 * reference)


def test_membership_decision_is_invariant_under_coefficient_scale():
    keywords = {
        "absolute_tolerance": 0.01,
        "relative_tolerance": 0.001,
        "reference_scale": 10.0,
    }
    first = line_membership_diagnostics([3.0, 4.0, -5.0], [1.0, 0.49], **keywords)
    second = line_membership_diagnostics([-30.0, -40.0, 50.0], [1.0, 0.49], **keywords)
    assert first.on_line == second.on_line
    assert second.residual_magnitude == pytest.approx(10.0 * first.residual_magnitude)
    assert second.threshold == pytest.approx(10.0 * first.threshold)


def test_membership_reports_accept_and_reject_boundaries():
    accepted = line_membership_diagnostics(
        [1.0, 0.0, 0.0],
        [0.01, 2.0],
        absolute_tolerance=0.01,
        relative_tolerance=0.0,
        reference_scale=2.0,
    )
    rejected = line_membership_diagnostics(
        [1.0, 0.0, 0.0],
        [0.01001, 2.0],
        absolute_tolerance=0.01,
        relative_tolerance=0.0,
        reference_scale=2.0,
    )
    assert accepted.on_line is True
    assert rejected.on_line is False


@pytest.mark.parametrize(
    "coefficients",
    [[0.0, 0.0, 1.0], [0.0, 0.0, 0.0], [1.0, 2.0], [1.0, np.inf, 0.0]],
)
def test_canonical_coefficients_reject_invalid_lines(coefficients):
    with pytest.raises(ValueError):
        canonical_line_coefficients(coefficients)


def test_zero_tolerance_rejects_near_zero_normal_and_direction():
    with pytest.raises(ValueError, match="eşik altında"):
        canonical_line_coefficients([1.0e-10, 0.0, 1.0], zero_tolerance=1.0e-9)
    with pytest.raises(ValueError, match="eşik altındaki"):
        line_from_point_direction([0.0, 0.0], [1.0e-10, 0.0], zero_tolerance=1.0e-9)


def test_line_from_points_rejects_coincident_points():
    with pytest.raises(ValueError, match="yönü tanımlı değildir"):
        line_from_points([2.0, -1.0], [2.0, -1.0])


@pytest.mark.parametrize(
    "point,direction,parameters",
    [
        ([0.0, 0.0], [1.0, 0.0], 2.0),
        ([0.0, 0.0], [1.0, 0.0], []),
        ([0.0, 0.0, 1.0], [1.0, 0.0], [0.0]),
        ([0.0, 0.0], [0.0, 0.0], [0.0]),
        ([0.0, 0.0], [1.0, np.nan], [0.0]),
    ],
)
def test_parametric_points_reject_invalid_inputs(point, direction, parameters):
    with pytest.raises(ValueError):
        parametric_line_points(point, direction, parameters)


def test_line_residuals_require_nonempty_point_cloud():
    with pytest.raises(ValueError, match=r"\(n, 2\)"):
        line_residuals([1.0, 0.0, 0.0], [1.0, 2.0])
    with pytest.raises(ValueError, match="boş olmayan"):
        line_residuals([1.0, 0.0, 0.0], [])


@pytest.mark.parametrize(
    "keywords",
    [
        {"absolute_tolerance": -1.0, "relative_tolerance": 0.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": -1.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": 1.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": 0.0, "reference_scale": -1.0},
    ],
)
def test_membership_rejects_invalid_tolerances(keywords):
    with pytest.raises(ValueError):
        line_membership_diagnostics([1.0, 0.0, 0.0], [0.0, 0.0], **keywords)


def test_overflow_is_reported_explicitly():
    with pytest.raises(OverflowError, match="yön"):
        line_from_points([-1.0e308, 0.0], [1.0e308, 0.0])
    with pytest.raises(OverflowError, match="Parametrik"):
        parametric_line_points([1.0e308, 0.0], [1.0e308, 0.0], [2.0])
