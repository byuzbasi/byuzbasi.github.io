import numpy as np
import pytest

from agbook import (
    focus_directrix_residuals,
    parabola_algebraic_residuals,
    parabola_frame_from_focus_directrix,
    parabola_frame_from_vertex_axis,
    parabola_points,
    parabola_reflection_diagnostics,
    parabola_tangent_line,
    parabolic_reflector_focal_length,
    rotation_matrix_2d,
)


def line_values(line, points):
    points = np.asarray(points, dtype=float)
    return points @ line[:2] + line[2]


def test_vertex_axis_frame_has_expected_focus_and_directrix():
    frame = parabola_frame_from_vertex_axis([2.0, -1.0], [3.0, 4.0], 2.5)
    np.testing.assert_allclose(frame.axis_direction, [0.6, 0.8])
    np.testing.assert_allclose(frame.transverse_direction, [-0.8, 0.6])
    np.testing.assert_allclose(frame.focus, [3.5, 1.0])
    directrix_point = frame.vertex - frame.focal_length * frame.axis_direction
    assert line_values(frame.directrix, directrix_point) == pytest.approx(0.0)
    assert abs(line_values(frame.directrix, frame.focus)) == pytest.approx(5.0)


def test_focus_directrix_frame_recovers_vertex_axis_and_focal_length():
    frame = parabola_frame_from_focus_directrix([2.0, 1.0], [1.0, 0.0, 2.0])
    np.testing.assert_allclose(frame.vertex, [0.0, 1.0])
    np.testing.assert_allclose(frame.axis_direction, [1.0, 0.0])
    np.testing.assert_allclose(frame.transverse_direction, [0.0, 1.0])
    assert frame.focal_length == pytest.approx(2.0)


def test_focus_directrix_frame_is_independent_of_line_scaling():
    first = parabola_frame_from_focus_directrix([2.0, 1.0], [1.0, 0.0, 2.0])
    second = parabola_frame_from_focus_directrix([2.0, 1.0], [-7.0, 0.0, -14.0])
    np.testing.assert_allclose(first.vertex, second.vertex)
    np.testing.assert_allclose(first.axis_direction, second.axis_direction)
    np.testing.assert_allclose(first.directrix, second.directrix)
    assert first.focal_length == pytest.approx(second.focal_length)


def test_focus_on_other_side_of_directrix_reverses_opening_direction():
    frame = parabola_frame_from_focus_directrix([-3.0, 2.0], [1.0, 0.0, 1.0])
    np.testing.assert_allclose(frame.vertex, [-2.0, 2.0])
    np.testing.assert_allclose(frame.axis_direction, [-1.0, 0.0])
    assert frame.focal_length == pytest.approx(1.0)


def test_parabola_points_support_scalar_and_vector_parameters():
    scalar = parabola_points([0.0, 0.0], [1.0, 0.0], 2.0, 1.5)
    rows = parabola_points([0.0, 0.0], [1.0, 0.0], 2.0, [-1.0, 0.0, 1.0])
    assert scalar.shape == (2,)
    assert rows.shape == (3, 2)
    np.testing.assert_allclose(scalar, [4.5, 6.0])
    np.testing.assert_allclose(rows, [[2.0, -4.0], [0.0, 0.0], [2.0, 4.0]])


def test_parameter_points_satisfy_algebraic_and_focus_directrix_equations():
    frame = parabola_frame_from_vertex_axis([1.0, -2.0], [2.0, 1.0], 3.0)
    points = parabola_points(
        frame.vertex,
        frame.axis_direction,
        frame.focal_length,
        np.linspace(-3.0, 3.0, 13),
    )
    np.testing.assert_allclose(
        parabola_algebraic_residuals(
            points,
            frame.vertex,
            frame.axis_direction,
            frame.focal_length,
        ),
        0.0,
        atol=3e-13,
    )
    np.testing.assert_allclose(
        focus_directrix_residuals(points, frame.focus, frame.directrix, 1.0),
        0.0,
        atol=2e-14,
    )


def test_algebraic_residual_returns_scalar_for_one_point():
    residual = parabola_algebraic_residuals(
        [2.0, 4.0], [0.0, 0.0], [1.0, 0.0], 2.0
    )
    assert isinstance(residual, float)
    assert residual == pytest.approx(0.0)


def test_parameters_plus_minus_one_give_latus_rectum_endpoints():
    frame = parabola_frame_from_vertex_axis([3.0, 1.0], [0.0, -1.0], 2.0)
    endpoints = parabola_points(frame.vertex, frame.axis_direction, 2.0, [-1.0, 1.0])
    expected = np.vstack(
        [
            frame.focus - 4.0 * frame.transverse_direction,
            frame.focus + 4.0 * frame.transverse_direction,
        ]
    )
    np.testing.assert_allclose(endpoints, expected)
    assert np.linalg.norm(endpoints[1] - endpoints[0]) == pytest.approx(8.0)


@pytest.mark.parametrize("parameter", [-2.0, -0.5, 0.0, 1.25, 3.0])
def test_tangent_line_contains_parameter_point_and_is_tangent(parameter):
    vertex = np.array([1.0, -1.0])
    axis = np.array([3.0, 4.0])
    focal_length = 1.75
    frame = parabola_frame_from_vertex_axis(vertex, axis, focal_length)
    point = parabola_points(vertex, axis, focal_length, parameter)
    line = parabola_tangent_line(vertex, axis, focal_length, parameter)
    tangent_direction = parameter * frame.axis_direction + frame.transverse_direction
    assert line_values(line, point) == pytest.approx(0.0, abs=2e-14)
    assert line[:2] @ tangent_direction == pytest.approx(0.0, abs=2e-14)


def test_vertex_tangent_is_perpendicular_to_axis():
    frame = parabola_frame_from_vertex_axis([2.0, 3.0], [-2.0, 1.0], 4.0)
    tangent = parabola_tangent_line(frame.vertex, frame.axis_direction, 4.0, 0.0)
    assert abs(tangent[:2] @ frame.axis_direction) == pytest.approx(1.0)
    assert line_values(tangent, frame.vertex) == pytest.approx(0.0)


def test_parallel_incident_rays_reflect_exactly_toward_focus():
    diagnostics = parabola_reflection_diagnostics(
        [0.0, 0.0], [1.0, 0.0], 2.0, np.linspace(-2.5, 2.5, 21)
    )
    assert diagnostics.points.shape == (21, 2)
    np.testing.assert_allclose(
        np.linalg.norm(diagnostics.unit_normals, axis=1), 1.0, atol=2e-14
    )
    np.testing.assert_allclose(
        diagnostics.reflected_directions,
        diagnostics.focus_directions,
        atol=2e-14,
    )
    assert diagnostics.maximum_direction_error < 2e-14
    assert diagnostics.maximum_focus_line_residual < 2e-13


def test_reflection_diagnostics_accept_one_parameter_as_one_row():
    diagnostics = parabola_reflection_diagnostics([0.0, 0.0], [0.0, 1.0], 3.0, 0.0)
    assert diagnostics.parameters.shape == (1,)
    assert diagnostics.points.shape == (1, 2)
    np.testing.assert_allclose(diagnostics.reflected_directions[0], [0.0, 1.0])


def test_rigid_motion_preserves_points_tangents_and_reflection_directions():
    vertex = np.array([0.5, -1.0])
    axis = np.array([1.0, 2.0])
    focal_length = 2.25
    parameters = np.array([-1.5, -0.25, 0.75, 2.0])
    rotation = rotation_matrix_2d(np.deg2rad(37.0))
    translation = np.array([5.0, -3.0])

    before = parabola_reflection_diagnostics(vertex, axis, focal_length, parameters)
    moved_vertex = rotation @ vertex + translation
    moved_axis = rotation @ (axis / np.linalg.norm(axis))
    after = parabola_reflection_diagnostics(
        moved_vertex, moved_axis, focal_length, parameters
    )

    np.testing.assert_allclose(after.points, before.points @ rotation.T + translation)
    np.testing.assert_allclose(
        after.reflected_directions,
        before.reflected_directions @ rotation.T,
        atol=2e-14,
    )
    np.testing.assert_allclose(
        after.focus_directions,
        before.focus_directions @ rotation.T,
        atol=2e-14,
    )


def test_uniform_scaling_scales_geometry_but_not_reflection_directions():
    parameters = np.array([-1.0, 0.0, 1.0])
    before = parabola_reflection_diagnostics([1.0, -2.0], [1.0, 0.0], 2.0, parameters)
    after = parabola_reflection_diagnostics([3.0, -6.0], [1.0, 0.0], 6.0, parameters)
    np.testing.assert_allclose(after.points, 3.0 * before.points)
    np.testing.assert_allclose(after.reflected_directions, before.reflected_directions)
    np.testing.assert_allclose(
        parabola_algebraic_residuals(
            [4.0, 1.0], [3.0, -6.0], [1.0, 0.0], 6.0
        ),
        9.0
        * parabola_algebraic_residuals(
            np.array([4.0, 1.0]) / 3.0,
            [1.0, -2.0],
            [1.0, 0.0],
            2.0,
        ),
    )


@pytest.mark.parametrize(
    ("diameter", "depth", "expected"),
    [(8.0, 1.0, 4.0), (6.0, 0.75, 3.0), (2.4, 0.3, 1.2)],
)
def test_reflector_focal_length(diameter, depth, expected):
    assert parabolic_reflector_focal_length(diameter, depth) == pytest.approx(expected)


def test_reflector_formula_is_unit_scale_covariant():
    metres = parabolic_reflector_focal_length(8.0, 1.0)
    millimetres = parabolic_reflector_focal_length(8000.0, 1000.0)
    assert millimetres == pytest.approx(1000.0 * metres)


@pytest.mark.parametrize(
    "call",
    [
        lambda: parabola_frame_from_vertex_axis([0.0, 0.0], [0.0, 0.0], 1.0),
        lambda: parabola_frame_from_vertex_axis([0.0, 0.0], [1.0], 1.0),
        lambda: parabola_frame_from_vertex_axis([0.0, np.nan], [1.0, 0.0], 1.0),
        lambda: parabola_frame_from_vertex_axis([0.0, 0.0], [1.0, 0.0], 0.0),
        lambda: parabola_frame_from_vertex_axis([0.0, 0.0], [1.0, 0.0], -1.0),
        lambda: parabola_frame_from_focus_directrix([0.0, 0.0], [1.0, 0.0, 0.0]),
        lambda: parabola_frame_from_focus_directrix(
            [1e-9, 0.0], [1.0, 0.0, 0.0], zero_tolerance=1e-8
        ),
        lambda: parabola_frame_from_focus_directrix(
            [1.0, 0.0], [1.0, 0.0, 0.0], zero_tolerance=-1.0
        ),
        lambda: parabola_points([0.0, 0.0], [1.0, 0.0], 1.0, []),
        lambda: parabola_points([0.0, 0.0], [1.0, 0.0], 1.0, [[0.0, 1.0]]),
        lambda: parabola_points([0.0, 0.0], [1.0, 0.0], 1.0, np.nan),
        lambda: parabola_algebraic_residuals(
            [1.0, 2.0, 3.0], [0.0, 0.0], [1.0, 0.0], 1.0
        ),
        lambda: parabola_tangent_line([0.0, 0.0], [1.0, 0.0], 1.0, np.inf),
        lambda: parabola_reflection_diagnostics(
            [0.0, 0.0], [1.0, 0.0], 1.0, []
        ),
        lambda: parabolic_reflector_focal_length(0.0, 1.0),
        lambda: parabolic_reflector_focal_length(1.0, 0.0),
        lambda: parabolic_reflector_focal_length(-1.0, 1.0),
        lambda: parabolic_reflector_focal_length(1.0, np.inf),
    ],
)
def test_parabola_functions_reject_invalid_inputs(call):
    with pytest.raises(ValueError):
        call()
