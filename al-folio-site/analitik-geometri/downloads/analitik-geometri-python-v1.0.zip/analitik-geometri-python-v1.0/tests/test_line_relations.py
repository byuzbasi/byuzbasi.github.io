import numpy as np
import pytest

from agbook import (
    canonical_line_coefficients,
    line_angle,
    line_intersection_diagnostics,
    line_pencil_member,
    line_residuals,
    parallel_line_at_offset,
    parallel_line_through_point,
    perpendicular_line_through_point,
    point_line_distance,
    project_point_to_line,
    signed_point_line_distance,
)


RELATION_TOLERANCES = {
    "angular_tolerance": 1.0e-12,
    "absolute_tolerance": 1.0e-10,
    "relative_tolerance": 0.0,
    "reference_scale": 1.0,
}


def test_intersection_diagnostics_find_unique_point_and_residuals():
    result = line_intersection_diagnostics(
        [1.0, 1.0, -3.0],
        [1.0, -1.0, -1.0],
        **RELATION_TOLERANCES,
    )
    assert result.relation == "intersecting"
    np.testing.assert_allclose(result.point, [2.0, 1.0], atol=1.0e-15)
    np.testing.assert_allclose(result.residuals, 0.0, atol=5.0e-16)
    assert result.normalized_determinant_magnitude == pytest.approx(1.0)
    assert result.condition_number == pytest.approx(1.0)


def test_intersection_is_invariant_under_equation_scale_and_order():
    first = line_intersection_diagnostics(
        [2.0, 2.0, -6.0],
        [-3.0, 3.0, 3.0],
        **RELATION_TOLERANCES,
    )
    second = line_intersection_diagnostics(
        [3.0, -3.0, -3.0],
        [-2.0, -2.0, 6.0],
        **RELATION_TOLERANCES,
    )
    assert first.relation == second.relation == "intersecting"
    np.testing.assert_allclose(first.point, second.point, atol=1.0e-15)


def test_parallel_and_coincident_lines_are_distinguished():
    parallel = line_intersection_diagnostics(
        [1.0, 2.0, -3.0],
        [-2.0, -4.0, 10.0],
        **RELATION_TOLERANCES,
    )
    coincident = line_intersection_diagnostics(
        [1.0, 2.0, -3.0],
        [-5.0, -10.0, 15.0],
        **RELATION_TOLERANCES,
    )
    assert parallel.relation == "parallel"
    assert parallel.point is None and parallel.residuals is None
    assert parallel.aligned_offset_difference == pytest.approx(2.0 / np.sqrt(5.0))
    assert parallel.condition_number > 1.0e15
    assert coincident.relation == "coincident"
    assert coincident.aligned_offset_difference == pytest.approx(0.0, abs=1.0e-15)


def test_near_parallel_decision_depends_on_explicit_angular_tolerance():
    loose = line_intersection_diagnostics(
        [0.0, 1.0, 0.0],
        [1.0e-8, 1.0, -1.0],
        angular_tolerance=1.0e-7,
        absolute_tolerance=1.0e-12,
        relative_tolerance=0.0,
        reference_scale=1.0,
    )
    strict = line_intersection_diagnostics(
        [0.0, 1.0, 0.0],
        [1.0e-8, 1.0, -1.0],
        angular_tolerance=1.0e-10,
        absolute_tolerance=1.0e-12,
        relative_tolerance=0.0,
        reference_scale=1.0,
    )
    assert loose.relation == "parallel"
    assert strict.relation == "intersecting"
    np.testing.assert_allclose(strict.point, [1.0e8, 0.0], rtol=1.0e-15)
    assert strict.condition_number > 1.0e8


@pytest.mark.parametrize(
    "keyword,value",
    [
        ("angular_tolerance", -1.0),
        ("angular_tolerance", 1.0),
        ("absolute_tolerance", -1.0),
        ("relative_tolerance", -1.0),
        ("relative_tolerance", 1.0),
        ("reference_scale", -1.0),
    ],
)
def test_intersection_rejects_invalid_tolerances(keyword, value):
    keywords = dict(RELATION_TOLERANCES)
    keywords[keyword] = value
    with pytest.raises(ValueError):
        line_intersection_diagnostics([1.0, 0.0, 0.0], [0.0, 1.0, 0.0], **keywords)


def test_line_angle_is_acute_and_scale_invariant():
    reference = line_angle([0.0, 1.0, 0.0], [1.0, -1.0, 0.0])
    scaled = line_angle([0.0, -7.0, 0.0], [-5.0, 5.0, 20.0])
    assert reference == pytest.approx(np.pi / 4.0)
    assert scaled == pytest.approx(reference)


def test_horizontal_and_vertical_lines_have_right_angle():
    assert line_angle([0.0, 1.0, -2.0], [1.0, 0.0, 5.0]) == pytest.approx(np.pi / 2.0)


def test_signed_and_unsigned_point_line_distances():
    assert signed_point_line_distance([3.0, 4.0, -5.0], [0.0, 0.0]) == pytest.approx(-1.0)
    assert point_line_distance([-6.0, -8.0, 10.0], [0.0, 0.0]) == pytest.approx(1.0)


def test_projection_returns_known_foot_and_two_residual_checks():
    result = project_point_to_line([3.0, 4.0, -5.0], [4.0, 1.0])
    np.testing.assert_allclose(result.foot, [67.0 / 25.0, -19.0 / 25.0], atol=1.0e-15)
    assert result.signed_distance == pytest.approx(11.0 / 5.0)
    assert result.distance == pytest.approx(11.0 / 5.0)
    assert result.foot_residual == pytest.approx(0.0, abs=5.0e-16)
    assert result.orthogonality_residual == pytest.approx(0.0, abs=5.0e-16)


def test_projection_of_point_on_line_is_the_same_point():
    result = project_point_to_line([1.0, -2.0, 5.0], [-1.0, 2.0])
    np.testing.assert_allclose(result.foot, [-1.0, 2.0])
    assert result.distance == pytest.approx(0.0)


def test_parallel_and_perpendicular_constructors_pass_through_point():
    base = np.array([2.0, -1.0, 3.0])
    point = np.array([4.0, -2.0])
    parallel = parallel_line_through_point(base, point)
    perpendicular = perpendicular_line_through_point(base, point)
    np.testing.assert_allclose(line_residuals(parallel, point[None, :]), 0.0, atol=1.0e-15)
    np.testing.assert_allclose(line_residuals(perpendicular, point[None, :]), 0.0, atol=1.0e-15)
    assert line_angle(base, parallel) == pytest.approx(0.0)
    assert line_angle(base, perpendicular) == pytest.approx(np.pi / 2.0)


def test_parallel_line_at_offset_uses_canonical_normal_direction():
    positive = parallel_line_at_offset([1.0, 0.0, 0.0], 2.0)
    negative = parallel_line_at_offset([1.0, 0.0, 0.0], -3.0)
    np.testing.assert_allclose(positive, [1.0, 0.0, -2.0])
    np.testing.assert_allclose(negative, [1.0, 0.0, 3.0])
    assert signed_point_line_distance([1.0, 0.0, 0.0], [2.0, 0.0]) == pytest.approx(2.0)


def test_line_pencil_member_contains_common_point_and_is_scale_invariant():
    first = [1.0, 0.0, -1.0]
    second = [0.0, 1.0, -2.0]
    member = line_pencil_member(first, second, 2.0, -3.0, angular_tolerance=1.0e-12)
    scaled = line_pencil_member(
        [-7.0, 0.0, 7.0],
        [0.0, 5.0, -10.0],
        -20.0,
        30.0,
        angular_tolerance=1.0e-12,
    )
    np.testing.assert_allclose(member, scaled, atol=1.0e-15)
    np.testing.assert_allclose(line_residuals(member, [[1.0, 2.0]]), 0.0, atol=1.0e-15)


@pytest.mark.parametrize(
    "first,second,weights,angular_tolerance",
    [
        ([1.0, 0.0, 0.0], [2.0, 0.0, 1.0], (1.0, 1.0), 1.0e-12),
        ([1.0, 0.0, 0.0], [0.0, 1.0, 0.0], (0.0, 0.0), 1.0e-12),
        ([1.0, 0.0, 0.0], [0.0, 1.0, 0.0], (np.nan, 1.0), 1.0e-12),
        ([1.0, 0.0, 0.0], [0.0, 1.0, 0.0], (1.0, 1.0), 1.0),
    ],
)
def test_line_pencil_rejects_invalid_inputs(first, second, weights, angular_tolerance):
    with pytest.raises(ValueError):
        line_pencil_member(
            first,
            second,
            weights[0],
            weights[1],
            angular_tolerance=angular_tolerance,
        )


@pytest.mark.parametrize(
    "function,args",
    [
        (line_angle, ([1.0, 0.0], [0.0, 1.0, 0.0])),
        (signed_point_line_distance, ([1.0, 0.0, 0.0], [0.0, np.inf])),
        (point_line_distance, ([0.0, 0.0, 1.0], [0.0, 0.0])),
        (project_point_to_line, ([1.0, 0.0, 0.0], [0.0, 0.0, 0.0])),
        (parallel_line_through_point, ([1.0, 0.0, 0.0], [0.0])),
        (perpendicular_line_through_point, ([1.0, np.nan, 0.0], [0.0, 0.0])),
        (parallel_line_at_offset, ([1.0, 0.0, 0.0], np.inf)),
    ],
)
def test_new_line_operations_reject_invalid_shapes_and_values(function, args):
    with pytest.raises(ValueError):
        function(*args)


def test_projection_and_signed_distance_report_overflow():
    with pytest.raises(OverflowError):
        signed_point_line_distance([1.0, 1.0, 0.0], [1.7e308, 1.7e308])
    with pytest.raises(OverflowError):
        project_point_to_line([1.0, 1.0, 0.0], [1.7e308, 1.7e308])


def test_pencil_member_matches_expected_canonical_equation():
    member = line_pencil_member(
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        1.0,
        1.0,
        angular_tolerance=0.0,
    )
    np.testing.assert_allclose(member, canonical_line_coefficients([1.0, 1.0, 0.0]))
