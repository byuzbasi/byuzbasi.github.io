import numpy as np
import pytest

from agbook import (
    affine_combination,
    apply_affine_map,
    compose_affine_maps,
    homogeneous_affine_matrix,
    inverse_affine_map,
    polygon_signed_area,
)


def test_apply_affine_map_matches_hand_calculation():
    matrix = np.array([[2.0, 0.5], [0.0, -1.0]])
    translation = np.array([3.0, 4.0])
    point = np.array([2.0, -1.0])
    np.testing.assert_allclose(
        apply_affine_map(point, matrix, translation),
        [6.5, 5.0],
        atol=1e-14,
    )


def test_affine_map_preserves_affine_combinations():
    points = np.array([[0.0, 1.0], [3.0, -2.0], [5.0, 4.0]])
    weights = np.array([0.2, -0.5, 1.3])
    matrix = np.array([[1.5, 0.4], [-0.2, 0.8]])
    translation = np.array([7.0, -3.0])
    image_of_combination = apply_affine_map(
        affine_combination(points, weights),
        matrix,
        translation,
    )
    combination_of_images = affine_combination(
        apply_affine_map(points, matrix, translation),
        weights,
    )
    np.testing.assert_allclose(image_of_combination, combination_of_images, atol=2e-14)


def test_signed_area_is_scaled_by_determinant():
    polygon = np.array([[0.0, 0.0], [4.0, 0.0], [3.0, 2.0], [0.0, 1.0]])
    matrix = np.array([[1.5, 0.75], [0.0, -2.0]])
    translation = np.array([10.0, -8.0])
    image = apply_affine_map(polygon, matrix, translation)
    expected = np.linalg.det(matrix) * polygon_signed_area(polygon)
    assert polygon_signed_area(image) == pytest.approx(expected, abs=1e-12)


def test_singular_map_can_be_applied_but_has_no_inverse():
    matrix = np.array([[1.0, 2.0], [2.0, 4.0]])
    points = np.array([[0.0, 0.0], [1.0, -1.0], [3.0, 2.0]])
    image = apply_affine_map(points, matrix, [4.0, -2.0])
    assert np.linalg.matrix_rank(image[1:] - image[0]) <= 1
    with pytest.raises(ValueError, match="tekildir"):
        inverse_affine_map(matrix, [4.0, -2.0])


def test_compose_affine_maps_matches_sequential_application():
    points = np.array([[0.0, 0.0], [2.0, 1.0], [-1.0, 3.0]])
    matrix_before = np.array([[1.0, 0.6], [0.0, 1.0]])
    shift_before = np.array([2.0, -1.0])
    matrix_after = np.array([[1.8, 0.0], [0.0, 0.5]])
    shift_after = np.array([-3.0, 4.0])
    sequential = apply_affine_map(
        apply_affine_map(points, matrix_before, shift_before),
        matrix_after,
        shift_after,
    )
    composed = compose_affine_maps(
        matrix_after,
        shift_after,
        matrix_before,
        shift_before,
    )
    direct = apply_affine_map(points, composed.matrix, composed.translation)
    np.testing.assert_allclose(direct, sequential, atol=2e-14)
    assert composed.determinant == pytest.approx(
        np.linalg.det(matrix_after) * np.linalg.det(matrix_before)
    )


def test_inverse_affine_map_round_trip_and_diagnostics():
    points = np.array([[1.0, 2.0], [-3.0, 5.0], [0.5, -4.0]])
    matrix = np.array([[1.4, 0.3], [-0.2, 0.9]])
    translation = np.array([7.0, 11.0])
    image = apply_affine_map(points, matrix, translation)
    inverse = inverse_affine_map(matrix, translation)
    recovered = apply_affine_map(image, inverse.matrix, inverse.translation)
    np.testing.assert_allclose(recovered, points, atol=3e-14)
    assert inverse.rank == 2
    assert inverse.condition_number >= 1.0


def test_inverse_affine_map_respects_explicit_determinant_threshold():
    matrix = np.diag([1.0, 1.0e-9])
    with pytest.raises(ValueError, match="eşikte tekildir"):
        inverse_affine_map(matrix, [0.0, 0.0], singular_tolerance=1.0e-8)
    inverse = inverse_affine_map(
        matrix,
        [0.0, 0.0],
        singular_tolerance=1.0e-10,
    )
    np.testing.assert_allclose(inverse.matrix, np.diag([1.0, 1.0e9]))


def test_homogeneous_matrix_matches_affine_application():
    matrix = np.array([[1.2, -0.4], [0.3, 0.8]])
    translation = np.array([5.0, -2.0])
    point = np.array([3.0, 7.0])
    homogeneous = homogeneous_affine_matrix(matrix, translation)
    augmented_image = homogeneous @ np.array([point[0], point[1], 1.0])
    np.testing.assert_allclose(
        augmented_image[:2],
        apply_affine_map(point, matrix, translation),
        atol=1e-14,
    )
    assert augmented_image[2] == pytest.approx(1.0)


@pytest.mark.parametrize(
    "call",
    [
        lambda: apply_affine_map([], np.eye(2), [0.0, 0.0]),
        lambda: apply_affine_map([1.0, 2.0, 3.0], np.eye(2), [0.0, 0.0]),
        lambda: apply_affine_map([1.0, 2.0], np.eye(3), [0.0, 0.0]),
        lambda: apply_affine_map([1.0, 2.0], np.eye(2), [np.inf, 0.0]),
        lambda: inverse_affine_map(np.eye(2), [0.0, 0.0], singular_tolerance=-1.0),
    ],
)
def test_affine_functions_reject_invalid_inputs(call):
    with pytest.raises(ValueError):
        call()
