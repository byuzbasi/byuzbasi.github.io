import numpy as np
import pytest

from agbook import (
    focus_directrix_residuals,
    polar_conic_algebraic_residuals,
    polar_conic_diagnostics,
    polar_conic_frame,
    polar_conic_points,
    polar_conic_radii,
    rational_conic_points,
    rotation_matrix_2d,
)


@pytest.mark.parametrize(
    ("eccentricity", "expected"),
    [(0.4, "ellipse"), (1.0, "parabola"), (1.8, "hyperbola")],
)
def test_polar_frame_classifies_eccentricity(eccentricity, expected):
    frame = polar_conic_frame([1.0, -2.0], [3.0, 4.0], eccentricity, 6.0)
    assert frame.conic_type == expected
    assert frame.eccentricity == eccentricity
    assert frame.semilatus_rectum == 6.0


def test_polar_frame_normalizes_axis_and_constructs_directrix():
    frame = polar_conic_frame([1.0, -2.0], [3.0, 4.0], 0.5, 2.0)
    np.testing.assert_allclose(frame.axis_direction, [0.6, 0.8], atol=1e-15)
    np.testing.assert_allclose(
        frame.transverse_direction,
        [-0.8, 0.6],
        atol=1e-15,
    )
    np.testing.assert_allclose(frame.directrix, [0.6, 0.8, -3.0], atol=1e-15)
    assert float(frame.axis_direction @ frame.transverse_direction) == pytest.approx(
        0.0,
        abs=1e-15,
    )


def test_rational_limit_and_singular_parameters_follow_conic_type():
    ellipse = polar_conic_frame([0.0, 0.0], [1.0, 0.0], 0.5, 3.0)
    parabola = polar_conic_frame([0.0, 0.0], [1.0, 0.0], 1.0, 3.0)
    hyperbola = polar_conic_frame([0.0, 0.0], [1.0, 0.0], 2.0, 3.0)

    np.testing.assert_allclose(ellipse.rational_limit_point, [-6.0, 0.0])
    assert ellipse.rational_singular_parameters.size == 0
    assert parabola.rational_limit_point is None
    assert parabola.rational_singular_parameters.size == 0
    np.testing.assert_allclose(hyperbola.rational_limit_point, [3.0, 0.0])
    np.testing.assert_allclose(
        hyperbola.rational_singular_parameters,
        [-np.sqrt(3.0), np.sqrt(3.0)],
    )


def test_polar_radius_and_point_scalar_contract():
    radius = polar_conic_radii(0.5, 3.0, 0.0)
    point = polar_conic_points([2.0, -1.0], [1.0, 0.0], 0.5, 3.0, 0.0)
    assert isinstance(radius, float)
    assert radius == pytest.approx(2.0)
    assert point.shape == (2,)
    np.testing.assert_allclose(point, [4.0, -1.0])


def test_polar_vector_contract_and_ellipse_axis_points():
    angles = np.array([0.0, np.pi / 2.0, np.pi])
    points = polar_conic_points([0.0, 0.0], [1.0, 0.0], 0.5, 3.0, angles)
    assert points.shape == (3, 2)
    np.testing.assert_allclose(
        points,
        [[2.0, 0.0], [0.0, 3.0], [-6.0, 0.0]],
        atol=1e-14,
    )


@pytest.mark.parametrize(
    ("eccentricity", "angles"),
    [
        (0.5, np.linspace(-np.pi, np.pi, 25)),
        (1.0, np.linspace(-2.6, 2.6, 25)),
        (2.0, np.linspace(-1.9, 1.9, 25)),
    ],
)
def test_focus_side_points_satisfy_both_conic_definitions(eccentricity, angles):
    focus = np.array([1.0, -2.0])
    axis = np.array([3.0, 4.0])
    semilatus = 2.5
    frame = polar_conic_frame(focus, axis, eccentricity, semilatus)
    points = polar_conic_points(focus, axis, eccentricity, semilatus, angles)
    algebraic = polar_conic_algebraic_residuals(
        points,
        focus,
        axis,
        eccentricity,
        semilatus,
    )
    geometric = focus_directrix_residuals(
        points,
        focus,
        frame.directrix,
        eccentricity,
    )
    np.testing.assert_allclose(algebraic, 0.0, atol=3e-13)
    np.testing.assert_allclose(geometric, 0.0, atol=3e-14)


def test_hyperbola_far_side_generates_second_branch():
    angles = np.linspace(-0.9, 0.9, 17)
    points = polar_conic_points(
        [0.0, 0.0],
        [1.0, 0.0],
        2.0,
        3.0,
        angles,
        branch="far_side",
    )
    frame = polar_conic_frame([0.0, 0.0], [1.0, 0.0], 2.0, 3.0)
    assert np.all(points[:, 0] >= 3.0)
    np.testing.assert_allclose(points[len(points) // 2], [3.0, 0.0])
    np.testing.assert_allclose(
        focus_directrix_residuals(
            points,
            frame.focus,
            frame.directrix,
            frame.eccentricity,
        ),
        0.0,
        atol=3e-14,
    )


def test_rational_and_polar_parametrizations_agree_on_focus_side():
    angles = np.array([-1.2, -0.4, 0.0, 0.7, 1.5])
    parameters = np.tan(angles / 2.0)
    polar = polar_conic_points([2.0, 1.0], [4.0, -3.0], 0.7, 5.0, angles)
    rational = rational_conic_points(
        [2.0, 1.0],
        [4.0, -3.0],
        0.7,
        5.0,
        parameters,
    )
    np.testing.assert_allclose(rational, polar, atol=3e-14)


@pytest.mark.parametrize("eccentricity", [0.4, 1.0, 2.0])
def test_rational_points_satisfy_algebraic_and_focus_directrix_conditions(
    eccentricity,
):
    parameters = np.array([-3.0, -0.75, 0.0, 0.5, 2.5])
    focus = np.array([-1.0, 2.0])
    axis = np.array([1.0, 2.0])
    frame = polar_conic_frame(focus, axis, eccentricity, 4.0)
    points = rational_conic_points(focus, axis, eccentricity, 4.0, parameters)
    np.testing.assert_allclose(
        polar_conic_algebraic_residuals(
            points,
            focus,
            axis,
            eccentricity,
            4.0,
        ),
        0.0,
        atol=3e-13,
    )
    np.testing.assert_allclose(
        focus_directrix_residuals(
            points,
            focus,
            frame.directrix,
            eccentricity,
        ),
        0.0,
        atol=5e-14,
    )


def test_rational_ellipse_converges_to_its_single_missing_point():
    frame = polar_conic_frame([1.0, -1.0], [0.0, 1.0], 0.25, 3.0)
    points = rational_conic_points(
        frame.focus,
        frame.axis_direction,
        frame.eccentricity,
        frame.semilatus_rectum,
        [-1e7, 1e7],
    )
    expected = np.vstack([frame.rational_limit_point, frame.rational_limit_point])
    np.testing.assert_allclose(points, expected, atol=1e-6)


def test_rational_parabola_has_no_finite_limit_point():
    frame = polar_conic_frame([0.0, 0.0], [1.0, 0.0], 1.0, 4.0)
    point = rational_conic_points(
        frame.focus,
        frame.axis_direction,
        frame.eccentricity,
        frame.semilatus_rectum,
        2.0,
    )
    assert frame.rational_limit_point is None
    np.testing.assert_allclose(point, [-6.0, 8.0])


def test_rational_hyperbola_outer_intervals_reach_far_side():
    points = rational_conic_points(
        [0.0, 0.0],
        [1.0, 0.0],
        2.0,
        3.0,
        [-2.0, 2.0],
    )
    np.testing.assert_allclose(points, [[9.0, 12.0], [9.0, -12.0]])


def test_rigid_motion_commutes_with_polar_and_rational_points():
    rotation = rotation_matrix_2d(0.73)
    translation = np.array([4.0, -5.0])
    focus = np.array([1.0, 2.0])
    axis = np.array([3.0, -1.0])
    angles = np.array([-0.8, 0.0, 1.1])
    parameters = np.tan(angles / 2.0)

    base_polar = polar_conic_points(focus, axis, 0.6, 4.0, angles)
    base_rational = rational_conic_points(focus, axis, 0.6, 4.0, parameters)
    moved_focus = rotation @ focus + translation
    moved_axis = rotation @ axis
    moved_polar = polar_conic_points(
        moved_focus,
        moved_axis,
        0.6,
        4.0,
        angles,
    )
    moved_rational = rational_conic_points(
        moved_focus,
        moved_axis,
        0.6,
        4.0,
        parameters,
    )
    np.testing.assert_allclose(moved_polar, base_polar @ rotation.T + translation)
    np.testing.assert_allclose(
        moved_rational,
        base_rational @ rotation.T + translation,
    )


def test_diagnostics_expose_denominators_and_maximum_residuals():
    angles = np.linspace(-1.5, 1.5, 31)
    result = polar_conic_diagnostics(
        [1.0, -2.0],
        [3.0, 4.0],
        1.0,
        2.0,
        angles,
    )
    np.testing.assert_allclose(result.angles, angles)
    assert result.branch == "focus_side"
    assert result.points.shape == (31, 2)
    assert np.all(result.radii > 0.0)
    assert np.all(result.denominators > 0.0)
    assert result.maximum_absolute_algebraic_residual < 3e-14
    assert result.maximum_absolute_focus_directrix_residual < 3e-14


def test_algebraic_residual_is_invariant_under_uniform_unit_change():
    point = polar_conic_points([1.0, -2.0], [2.0, 1.0], 0.4, 3.0, 0.7)
    original = polar_conic_algebraic_residuals(
        point,
        [1.0, -2.0],
        [2.0, 1.0],
        0.4,
        3.0,
    )
    scaled = polar_conic_algebraic_residuals(
        1000.0 * point,
        [1000.0, -2000.0],
        [2.0, 1.0],
        0.4,
        3000.0,
    )
    assert scaled == pytest.approx(original, abs=2e-14)


def test_denominator_tolerance_rejects_near_asymptotic_polar_sample():
    boundary = np.arccos(-0.5)
    with pytest.raises(ValueError, match="pozitif tolerans"):
        polar_conic_radii(
            2.0,
            3.0,
            boundary - 1e-8,
            denominator_tolerance=1e-7,
        )


def test_rational_hyperbola_rejects_exact_singular_parameter():
    with pytest.raises(ValueError, match="sıfır toleransından"):
        rational_conic_points(
            [0.0, 0.0],
            [1.0, 0.0],
            2.0,
            3.0,
            np.sqrt(3.0),
            denominator_tolerance=1e-14,
        )


@pytest.mark.parametrize(
    "call",
    [
        lambda: polar_conic_frame([0.0], [1.0, 0.0], 0.5, 1.0),
        lambda: polar_conic_frame([0.0, 0.0], [0.0, 0.0], 0.5, 1.0),
        lambda: polar_conic_frame([0.0, 0.0], [1.0, 0.0], 0.0, 1.0),
        lambda: polar_conic_frame([0.0, 0.0], [1.0, 0.0], 0.5, 0.0),
        lambda: polar_conic_radii(0.5, 1.0, [], branch="focus_side"),
        lambda: polar_conic_radii(0.5, 1.0, 0.0, branch="unknown"),
        lambda: polar_conic_radii(0.5, 1.0, 0.0, branch="far_side"),
        lambda: polar_conic_radii(2.0, 1.0, np.pi, branch="focus_side"),
        lambda: polar_conic_radii(2.0, 1.0, 0.0, denominator_tolerance=-1.0),
        lambda: rational_conic_points(
            [0.0, 0.0], [1.0, 0.0], 0.5, 1.0, [[0.0]]
        ),
        lambda: polar_conic_algebraic_residuals(
            [1.0, 2.0, 3.0], [0.0, 0.0], [1.0, 0.0], 0.5, 1.0
        ),
    ],
)
def test_polar_conic_functions_reject_invalid_inputs(call):
    with pytest.raises(ValueError):
        call()
