import numpy as np
import pytest

from agbook.spheres import (
    general_sphere_diagnostics,
    line_sphere_intersections_3d,
    radical_plane_diagnostics,
    sphere_membership_diagnostics,
    sphere_pencil_member,
    sphere_plane_section_diagnostics,
    sphere_point_power,
    sphere_sphere_intersection_diagnostics,
    sphere_system_diagnostics,
    tangent_plane_at_sphere_point,
)


TOLERANCES = {
    "absolute_tolerance": 1e-12,
    "relative_tolerance": 1e-12,
    "reference_scale": 20.0,
}

SYSTEM_TOLERANCES = {
    "rank_tolerance": 1e-12,
    **TOLERANCES,
}


def test_sphere_point_power_has_inside_surface_outside_signs():
    assert sphere_point_power([0.0, 0.0, 0.0], 5.0, [0.0, 0.0, 0.0]) == -25.0
    assert sphere_point_power([0.0, 0.0, 0.0], 5.0, [3.0, 4.0, 0.0]) == 0.0
    assert sphere_point_power([0.0, 0.0, 0.0], 5.0, [13.0, 0.0, 0.0]) == 144.0


def test_sphere_point_power_is_rigid_invariant_and_scales_quadratically():
    center = np.array([1.0, -2.0, 3.0])
    point = np.array([6.0, 4.0, -1.0])
    rotation = np.array(
        [
            [0.0, -1.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0],
        ]
    )
    translation = np.array([8.0, -5.0, 2.0])
    original = sphere_point_power(center, 4.0, point)
    moved = sphere_point_power(
        rotation @ center + translation,
        4.0,
        rotation @ point + translation,
    )
    assert moved == pytest.approx(original)
    assert sphere_point_power(3.0 * center, 12.0, 3.0 * point) == pytest.approx(
        9.0 * original
    )


def test_general_sphere_recovers_center_and_radius():
    result = general_sphere_diagnostics([1.0, -2.0, 4.0, -6.0, -2.0])
    assert result.locus_type == "sphere"
    np.testing.assert_allclose(result.center, [1.0, -2.0, 3.0])
    assert result.radius_squared == pytest.approx(16.0)
    assert result.radius == pytest.approx(4.0)


def test_general_sphere_normalization_is_input_scale_invariant():
    first = general_sphere_diagnostics([1.0, -2.0, 4.0, -6.0, -2.0])
    second = general_sphere_diagnostics([-7.0, 14.0, -28.0, 42.0, 14.0])
    np.testing.assert_allclose(second.normalized_coefficients, first.normalized_coefficients)
    np.testing.assert_allclose(second.center, first.center)
    assert second.radius == pytest.approx(first.radius)


@pytest.mark.parametrize(
    ("constant", "expected"),
    [(14.0, "point"), (15.0, "empty")],
)
def test_general_sphere_classifies_degenerate_real_loci(constant, expected):
    result = general_sphere_diagnostics([1.0, -2.0, 4.0, -6.0, constant])
    assert result.locus_type == expected


def test_general_sphere_uses_declared_squared_length_tolerance():
    result = general_sphere_diagnostics(
        [1.0, 0.0, 0.0, 0.0, 5e-10],
        radius_squared_tolerance=1e-9,
    )
    assert result.locus_type == "point"
    assert result.radius_squared == pytest.approx(-5e-10)
    assert result.radius_squared_tolerance == pytest.approx(1e-9)


def test_sphere_membership_reports_length_and_squared_length_residuals():
    result = sphere_membership_diagnostics(
        [0.0, 0.0, 0.0], 5.0, [3.0, 4.0 + 1e-11, 0.0], **TOLERANCES
    )
    assert result.on_sphere
    assert result.radial_residual > 0.0
    assert result.algebraic_residual > 0.0
    assert result.algebraic_threshold == pytest.approx(
        result.length_threshold * (result.center_distance + 5.0)
    )


def test_sphere_membership_rejects_point_outside_tolerance():
    result = sphere_membership_diagnostics(
        [0.0, 0.0, 0.0], 5.0, [0.0, 0.0, 5.001], **TOLERANCES
    )
    assert not result.on_sphere


def test_line_sphere_secant_returns_ordered_points_parameters_and_residuals():
    result = line_sphere_intersections_3d(
        [0.0, 0.0, 0.0],
        5.0,
        [0.0, 3.0, 0.0],
        [2.0, 0.0, 0.0],
        **TOLERANCES,
    )
    assert result.relation == "secant"
    np.testing.assert_allclose(result.points, [[-4.0, 3.0, 0.0], [4.0, 3.0, 0.0]])
    np.testing.assert_allclose(result.parameters, [-2.0, 2.0])
    np.testing.assert_allclose(result.radial_residuals, 0.0, atol=1e-14)
    np.testing.assert_allclose(result.line_residuals, 0.0, atol=1e-14)
    assert result.chord_length == pytest.approx(8.0)


@pytest.mark.parametrize(
    ("line_y", "expected", "count"),
    [(5.0, "tangent", 1), (6.0, "disjoint", 0)],
)
def test_line_sphere_classifies_tangent_and_disjoint(line_y, expected, count):
    result = line_sphere_intersections_3d(
        [0.0, 0.0, 0.0],
        5.0,
        [0.0, line_y, 0.0],
        [1.0, 0.0, 0.0],
        **TOLERANCES,
    )
    assert result.relation == expected
    assert result.points.shape == (count, 3)


def test_line_point_sphere_intersection_is_not_called_a_tangent_surface():
    result = line_sphere_intersections_3d(
        [1.0, 0.0, 0.0],
        0.0,
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        **TOLERANCES,
    )
    assert result.relation == "point"
    np.testing.assert_allclose(result.points, [[1.0, 0.0, 0.0]])


def test_line_sphere_tolerance_band_is_recorded():
    result = line_sphere_intersections_3d(
        [0.0, 0.0, 0.0],
        5.0,
        [0.0, 5.0 + 5e-10, 0.0],
        [1.0, 0.0, 0.0],
        absolute_tolerance=1e-9,
        relative_tolerance=0.0,
        reference_scale=5.0,
    )
    assert result.relation == "tangent"
    assert result.clearance == pytest.approx(5e-10)
    assert result.length_threshold == pytest.approx(1e-9)


def test_directed_line_parameter_product_matches_power_after_direction_scaling():
    result = line_sphere_intersections_3d(
        [0.0, 0.0, 0.0],
        5.0,
        [10.0, 0.0, 0.0],
        [2.0, 0.0, 0.0],
        **TOLERANCES,
    )
    parameter_product = float(np.prod(result.parameters))
    assert result.direction_norm**2 * parameter_product == pytest.approx(
        sphere_point_power([0.0, 0.0, 0.0], 5.0, [10.0, 0.0, 0.0])
    )


@pytest.mark.parametrize(
    ("plane", "expected", "radius"),
    [
        ([0.0, 0.0, 1.0, 0.0], "circle", 5.0),
        ([0.0, 0.0, 1.0, -3.0], "circle", 4.0),
        ([0.0, 0.0, 1.0, -5.0], "tangent", 0.0),
        ([0.0, 0.0, 1.0, -6.0], "disjoint", None),
    ],
)
def test_sphere_plane_section_classes(plane, expected, radius):
    result = sphere_plane_section_diagnostics(
        [0.0, 0.0, 0.0], 5.0, plane, **TOLERANCES
    )
    assert result.relation == expected
    assert result.section_radius == pytest.approx(radius) if radius is not None else result.section_radius is None
    assert result.section_center_plane_residual == pytest.approx(0.0, abs=1e-14)


def test_sphere_plane_section_uses_signed_distance_for_section_center():
    result = sphere_plane_section_diagnostics(
        [1.0, -2.0, 4.0],
        5.0,
        [0.0, 0.0, 2.0, -2.0],
        **TOLERANCES,
    )
    np.testing.assert_allclose(result.canonical_plane, [0.0, 0.0, 1.0, -1.0])
    np.testing.assert_allclose(result.section_center, [1.0, -2.0, 1.0])
    assert result.signed_center_distance == pytest.approx(3.0)
    assert result.section_radius == pytest.approx(4.0)


def test_point_sphere_plane_section_is_a_point():
    result = sphere_plane_section_diagnostics(
        [1.0, 2.0, 3.0],
        0.0,
        [0.0, 0.0, 1.0, -3.0],
        **TOLERANCES,
    )
    assert result.relation == "point"
    np.testing.assert_allclose(result.section_center, [1.0, 2.0, 3.0])


def test_tangent_plane_uses_radius_as_normal_and_contains_tangent_point():
    plane = tangent_plane_at_sphere_point(
        [0.0, 0.0, 0.0], 5.0, [3.0, 4.0, 0.0], **TOLERANCES
    )
    np.testing.assert_allclose(plane, [0.6, 0.8, 0.0, -5.0], atol=1e-14)
    assert np.dot(plane[:3], [3.0, 4.0, 0.0]) + plane[3] == pytest.approx(0.0)


def test_tangent_plane_rejects_off_surface_and_point_sphere():
    with pytest.raises(ValueError, match="yüzeyinde"):
        tangent_plane_at_sphere_point(
            [0.0, 0.0, 0.0], 5.0, [3.0, 3.0, 0.0], **TOLERANCES
        )
    with pytest.raises(ValueError, match="teğet düzlemi"):
        tangent_plane_at_sphere_point(
            [0.0, 0.0, 0.0], 0.0, [0.0, 0.0, 0.0], **TOLERANCES
        )


@pytest.mark.parametrize(
    ("second_center", "second_radius", "expected"),
    [
        ([0.0, 0.0, 0.0], 5.0, "coincident"),
        ([0.0, 0.0, 0.0], 3.0, "concentric_disjoint"),
        ([11.0, 0.0, 0.0], 5.0, "separate"),
        ([10.0, 0.0, 0.0], 5.0, "externally_tangent"),
        ([6.0, 0.0, 0.0], 5.0, "intersection_circle"),
        ([2.0, 0.0, 0.0], 3.0, "internally_tangent"),
        ([1.0, 0.0, 0.0], 3.0, "contained"),
    ],
)
def test_sphere_sphere_seven_position_classes(second_center, second_radius, expected):
    result = sphere_sphere_intersection_diagnostics(
        [0.0, 0.0, 0.0], 5.0, second_center, second_radius, **TOLERANCES
    )
    assert result.relation == expected


def test_equal_radius_spheres_have_expected_intersection_circle():
    result = sphere_sphere_intersection_diagnostics(
        [0.0, 0.0, 0.0], 5.0, [6.0, 0.0, 0.0], 5.0, **TOLERANCES
    )
    np.testing.assert_allclose(result.circle_center, [3.0, 0.0, 0.0])
    assert result.circle_radius == pytest.approx(4.0)
    np.testing.assert_allclose(result.circle_plane, [1.0, 0.0, 0.0, -3.0])


def test_internal_tangent_point_lies_on_both_spheres():
    result = sphere_sphere_intersection_diagnostics(
        [0.0, 0.0, 0.0], 5.0, [2.0, 0.0, 0.0], 3.0, **TOLERANCES
    )
    np.testing.assert_allclose(result.tangent_point, [5.0, 0.0, 0.0])
    np.testing.assert_allclose(result.tangent_power_residuals, 0.0, atol=1e-14)


def test_external_tangent_point_lies_between_centers():
    result = sphere_sphere_intersection_diagnostics(
        [0.0, 0.0, 0.0], 2.0, [5.0, 0.0, 0.0], 3.0, **TOLERANCES
    )
    np.testing.assert_allclose(result.tangent_point, [2.0, 0.0, 0.0])


def test_radical_plane_equals_common_circle_plane():
    intersection = sphere_sphere_intersection_diagnostics(
        [0.0, 0.0, 0.0], 5.0, [6.0, 0.0, 0.0], 5.0, **TOLERANCES
    )
    radical = radical_plane_diagnostics(
        [0.0, 0.0, 0.0], 5.0, [6.0, 0.0, 0.0], 5.0, **TOLERANCES
    )
    assert radical.relation == "plane"
    np.testing.assert_allclose(radical.plane_coefficients, intersection.circle_plane)


def test_radical_plane_exists_without_real_sphere_intersection():
    radical = radical_plane_diagnostics(
        [0.0, 0.0, 0.0], 2.0, [8.0, 0.0, 0.0], 3.0, **TOLERANCES
    )
    assert radical.relation == "plane"
    point = np.array([59.0 / 16.0, 2.0, -4.0])
    assert sphere_point_power([0.0, 0.0, 0.0], 2.0, point) == pytest.approx(
        sphere_point_power([8.0, 0.0, 0.0], 3.0, point)
    )


def test_concentric_radical_plane_limits_are_not_fake_planes():
    identical = radical_plane_diagnostics(
        [1.0, 2.0, 3.0], 5.0, [1.0, 2.0, 3.0], 5.0, **TOLERANCES
    )
    unequal = radical_plane_diagnostics(
        [1.0, 2.0, 3.0], 5.0, [1.0, 2.0, 3.0], 4.0, **TOLERANCES
    )
    assert identical.relation == "all_space"
    assert identical.plane_coefficients is None
    assert unequal.relation == "empty"
    assert unequal.plane_coefficients is None


def _positioning_data():
    centers = np.array(
        [
            [0.0, 0.0, 0.0],
            [12.0, 0.0, 0.0],
            [0.0, 16.0, 0.0],
            [0.0, 0.0, 20.0],
        ]
    )
    radii = np.sqrt([196.0, 244.0, 260.0, 116.0])
    return centers, radii


def test_three_positioning_spheres_leave_radical_line_and_two_mirror_points():
    centers, radii = _positioning_data()
    result = sphere_system_diagnostics(centers[:3], radii[:3], **SYSTEM_TOLERANCES)
    assert result.relation == "line"
    assert result.rank == 2
    np.testing.assert_allclose(result.anchor, [4.0, 6.0, 0.0], atol=1e-12)
    assert result.common_locus_type == "two_points"
    expected = np.array([[4.0, 6.0, -12.0], [4.0, 6.0, 12.0]])
    np.testing.assert_allclose(result.common_points, expected, atol=1e-11)


def test_four_positioning_spheres_select_unique_common_point():
    centers, radii = _positioning_data()
    result = sphere_system_diagnostics(centers, radii, **SYSTEM_TOLERANCES)
    assert result.relation == "point"
    assert result.rank == 3
    assert result.common_locus_type == "point"
    np.testing.assert_allclose(result.anchor, [4.0, 6.0, 12.0], atol=1e-12)
    np.testing.assert_allclose(result.common_points, [[4.0, 6.0, 12.0]], atol=1e-12)
    np.testing.assert_allclose(result.power_values, 0.0, atol=2e-12)
    np.testing.assert_allclose(result.equation_residuals, 0.0, atol=2e-12)


def test_unique_equal_power_point_need_not_be_a_common_sphere_point():
    centers, radii = _positioning_data()
    radii[-1] = 10.0
    result = sphere_system_diagnostics(centers, radii, **SYSTEM_TOLERANCES)
    assert result.relation == "point"
    assert result.common_locus_type == "none"
    assert result.power_spread == pytest.approx(0.0, abs=1e-11)
    assert abs(result.power_values[0]) > result.power_threshold


def test_duplicate_center_with_unequal_radius_makes_system_inconsistent():
    centers, radii = _positioning_data()
    centers = np.vstack((centers, centers[0]))
    radii = np.r_[radii, 13.0]
    result = sphere_system_diagnostics(centers, radii, **SYSTEM_TOLERANCES)
    assert result.relation == "empty"
    assert result.anchor is None
    assert result.common_locus_type == "none"


def test_two_spheres_produce_radical_plane_and_common_circle():
    result = sphere_system_diagnostics(
        [[0.0, 0.0, 0.0], [6.0, 0.0, 0.0]],
        [5.0, 5.0],
        **SYSTEM_TOLERANCES,
    )
    assert result.relation == "plane"
    assert result.rank == 1
    assert result.common_locus_type == "circle"
    np.testing.assert_allclose(result.common_circle_center, [3.0, 0.0, 0.0])
    assert result.common_circle_radius == pytest.approx(4.0)
    np.testing.assert_allclose(result.common_circle_normal, [1.0, 0.0, 0.0])


def test_two_separate_spheres_still_have_plane_but_no_common_surface_locus():
    result = sphere_system_diagnostics(
        [[0.0, 0.0, 0.0], [8.0, 0.0, 0.0]],
        [2.0, 3.0],
        **SYSTEM_TOLERANCES,
    )
    assert result.relation == "plane"
    assert result.common_locus_type == "none"


@pytest.mark.parametrize(
    ("radius", "expected"),
    [(1.0, "none"), (np.sqrt(2.0), "point")],
)
def test_three_equal_radius_spheres_can_leave_empty_or_tangent_common_line_locus(
    radius, expected
):
    result = sphere_system_diagnostics(
        [[0.0, 0.0, 0.0], [2.0, 0.0, 0.0], [0.0, 2.0, 0.0]],
        [radius, radius, radius],
        **SYSTEM_TOLERANCES,
    )
    assert result.relation == "line"
    assert result.common_locus_type == expected


def test_identical_spheres_have_all_space_equal_power_and_common_sphere():
    result = sphere_system_diagnostics(
        [[1.0, 2.0, 3.0]] * 3,
        [5.0, 5.0, 5.0],
        **SYSTEM_TOLERANCES,
    )
    assert result.relation == "all_space"
    assert result.rank == 0
    assert result.common_locus_type == "sphere"


def test_identical_point_spheres_have_one_common_point():
    result = sphere_system_diagnostics(
        [[1.0, 2.0, 3.0]] * 2,
        [0.0, 0.0],
        **SYSTEM_TOLERANCES,
    )
    assert result.relation == "all_space"
    assert result.common_locus_type == "point"
    np.testing.assert_allclose(result.common_points, [[1.0, 2.0, 3.0]])


def test_system_solution_is_invariant_under_sphere_permutation():
    centers, radii = _positioning_data()
    first = sphere_system_diagnostics(centers, radii, **SYSTEM_TOLERANCES)
    order = [2, 0, 3, 1]
    second = sphere_system_diagnostics(centers[order], radii[order], **SYSTEM_TOLERANCES)
    np.testing.assert_allclose(second.anchor, first.anchor, atol=2e-12)
    assert second.power_spread == pytest.approx(first.power_spread, abs=2e-12)


def test_system_solution_is_rigid_motion_invariant():
    centers, radii = _positioning_data()
    rotation = np.array(
        [
            [0.0, -1.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0],
        ]
    )
    translation = np.array([30.0, -10.0, 7.0])
    moved_centers = centers @ rotation.T + translation
    result = sphere_system_diagnostics(
        moved_centers,
        radii,
        rank_tolerance=1e-12,
        absolute_tolerance=1e-12,
        relative_tolerance=1e-12,
        reference_scale=60.0,
    )
    expected = rotation @ np.array([4.0, 6.0, 12.0]) + translation
    np.testing.assert_allclose(result.anchor, expected, atol=2e-12)
    assert result.common_locus_type == "point"


def test_system_uniform_scaling_preserves_class_and_condition_number():
    centers, radii = _positioning_data()
    base = sphere_system_diagnostics(centers, radii, **SYSTEM_TOLERANCES)
    scaled = sphere_system_diagnostics(
        100.0 * centers,
        100.0 * radii,
        rank_tolerance=1e-12,
        absolute_tolerance=1e-10,
        relative_tolerance=1e-12,
        reference_scale=2000.0,
    )
    assert scaled.relation == base.relation
    np.testing.assert_allclose(scaled.anchor, 100.0 * base.anchor, atol=2e-10)
    assert scaled.condition_number == pytest.approx(base.condition_number)
    np.testing.assert_allclose(scaled.power_values, 1e4 * base.power_values, atol=3e-8)


def test_system_rank_threshold_is_explicit_and_recorded():
    centers = np.array(
        [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 1e-13]]
    )
    result = sphere_system_diagnostics(
        centers,
        [2.0, 2.0, 2.0],
        rank_tolerance=1e-10,
        absolute_tolerance=1e-14,
        relative_tolerance=0.0,
        reference_scale=2.0,
    )
    assert result.rank == 2
    assert result.singular_value_threshold == pytest.approx(
        1e-10 * result.singular_values[0]
    )


def test_sphere_pencil_endpoints_and_input_scaling():
    first = [1.0, 0.0, 0.0, 0.0, -25.0]
    second = [1.0, -12.0, 0.0, 0.0, 20.0]
    start = sphere_pencil_member(first, second, 0.0)
    end = sphere_pencil_member(first, second, 1.0)
    reference = sphere_pencil_member(first, second, 0.25)
    scaled = sphere_pencil_member(
        np.multiply(first, -7.0), np.multiply(second, 3.0), 0.25
    )
    np.testing.assert_allclose(start.normalized_coefficients, first)
    np.testing.assert_allclose(end.normalized_coefficients, second)
    np.testing.assert_allclose(scaled.normalized_coefficients, reference.normalized_coefficients)


def test_sphere_pencil_members_share_original_radical_plane():
    first = [1.0, 0.0, 0.0, 0.0, -25.0]
    second = [1.0, -12.0, 0.0, 0.0, 20.0]
    member_a = sphere_pencil_member(first, second, 0.25)
    member_b = sphere_pencil_member(first, second, 0.75)
    original = radical_plane_diagnostics(
        [0.0, 0.0, 0.0], 5.0, [6.0, 0.0, 0.0], 4.0, **TOLERANCES
    )
    member = radical_plane_diagnostics(
        member_a.center,
        member_a.radius,
        member_b.center,
        member_b.radius,
        **TOLERANCES,
    )
    np.testing.assert_allclose(member.plane_coefficients, original.plane_coefficients)


def test_sphere_pencil_can_cross_point_and_empty_real_members():
    first = [1.0, 0.0, 0.0, 0.0, -1.0]
    second = [1.0, 0.0, 0.0, 0.0, -9.0]
    point_member = sphere_pencil_member(first, second, -0.125)
    empty_member = sphere_pencil_member(first, second, -0.25)
    assert point_member.locus_type == "point"
    assert point_member.radius_squared == pytest.approx(0.0)
    assert empty_member.locus_type == "empty"
    assert empty_member.radius_squared == pytest.approx(-1.0)


@pytest.mark.parametrize(
    "call",
    [
        lambda: sphere_point_power([0.0], 1.0, [0.0, 0.0, 0.0]),
        lambda: sphere_point_power([0.0, 0.0, 0.0], -1.0, [0.0, 0.0, 0.0]),
        lambda: sphere_point_power([0.0, 0.0, 0.0], 1.0, [np.inf, 0.0, 0.0]),
        lambda: sphere_point_power(
            [0.0, 0.0, 0.0], 1.0, [1e308, 1e308, 1e308]
        ),
        lambda: general_sphere_diagnostics([1.0, 0.0, 0.0, 0.0]),
        lambda: general_sphere_diagnostics([0.0, 1.0, 2.0, 3.0, 4.0]),
        lambda: general_sphere_diagnostics(
            [1.0, 0.0, 0.0, 0.0, 1.0], radius_squared_tolerance=-1.0
        ),
        lambda: line_sphere_intersections_3d(
            [0.0, 0.0, 0.0], 1.0, [0.0, 0.0, 0.0], [0.0, 0.0, 0.0], **TOLERANCES
        ),
        lambda: sphere_plane_section_diagnostics(
            [0.0, 0.0, 0.0], 1.0, [0.0, 0.0, 0.0, 1.0], **TOLERANCES
        ),
        lambda: radical_plane_diagnostics(
            [0.0, 0.0, 0.0],
            1.0,
            [1.0, 0.0, 0.0],
            1.0,
            absolute_tolerance=-1.0,
            relative_tolerance=0.0,
            reference_scale=1.0,
        ),
        lambda: sphere_system_diagnostics(
            [[0.0, 0.0, 0.0]], [1.0], **SYSTEM_TOLERANCES
        ),
        lambda: sphere_system_diagnostics(
            [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            [1.0],
            **SYSTEM_TOLERANCES,
        ),
        lambda: sphere_system_diagnostics(
            [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            [1.0, -1.0],
            **SYSTEM_TOLERANCES,
        ),
        lambda: sphere_system_diagnostics(
            [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            [1.0, 1.0],
            rank_tolerance=1.0,
            **TOLERANCES,
        ),
        lambda: sphere_pencil_member(
            [0.0, 1.0, 2.0, 3.0, 4.0],
            [1.0, 0.0, 0.0, 0.0, -1.0],
            0.5,
        ),
        lambda: sphere_pencil_member(
            [1.0, 0.0, 0.0, 0.0, -1.0],
            [1.0, 0.0, 0.0, 0.0, -4.0],
            np.nan,
        ),
    ],
)
def test_sphere_functions_reject_invalid_inputs(call):
    with pytest.raises((ValueError, OverflowError)):
        call()
