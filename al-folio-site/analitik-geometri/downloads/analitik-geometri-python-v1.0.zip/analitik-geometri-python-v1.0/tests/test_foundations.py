import numpy as np
import pytest

from agbook import (
    affine_combination,
    circle_residuals,
    displacement,
    euclidean_distance,
    internal_division,
    midpoint,
    perpendicular_bisector_residual,
    rigid_motion_diagnostics,
    rigid_transform,
    rotation_matrix_2d,
    trilaterate_linear,
)


def test_displacement_and_distance_form_a_3_4_5_triangle():
    a = np.array([1.0, -2.0])
    b = np.array([4.0, 2.0])
    np.testing.assert_allclose(displacement(a, b), [3.0, 4.0])
    assert euclidean_distance(a, b) == pytest.approx(5.0)


def test_midpoint_is_equidistant_from_endpoints():
    a = np.array([-2.0, 1.0])
    b = np.array([6.0, 5.0])
    m = midpoint(a, b)
    np.testing.assert_allclose(m, [2.0, 3.0])
    assert euclidean_distance(a, m) == pytest.approx(euclidean_distance(m, b))


def test_internal_division_respects_directed_ratio():
    a = np.array([0.0, 0.0])
    b = np.array([8.0, 4.0])
    p = internal_division(a, b, m=3.0, n=1.0)
    np.testing.assert_allclose(p, [6.0, 3.0])
    assert euclidean_distance(a, p) / euclidean_distance(p, b) == pytest.approx(3.0)


@pytest.mark.parametrize("m,n", [(0.0, 1.0), (1.0, -1.0), (-1.0, 2.0)])
def test_internal_division_rejects_nonpositive_ratios(m, n):
    with pytest.raises(ValueError, match="pozitif"):
        internal_division([0, 0], [1, 1], m=m, n=n)


def test_affine_combination_is_translation_equivariant():
    points = np.array([[0.0, 0.0], [2.0, 0.0], [0.0, 2.0]])
    weights = np.array([0.2, 0.3, 0.5])
    translation = np.array([7.0, -4.0])
    left = affine_combination(points + translation, weights)
    right = affine_combination(points, weights) + translation
    np.testing.assert_allclose(left, right)


def test_affine_combination_rejects_weights_not_summing_to_one():
    with pytest.raises(ValueError, match="toplamı 1"):
        affine_combination([[0, 0], [1, 1]], [0.2, 0.2])


def test_rotation_matrix_is_orthogonal_with_positive_determinant():
    q = rotation_matrix_2d(np.pi / 3.0)
    np.testing.assert_allclose(q.T @ q, np.eye(2), atol=1e-14)
    assert np.linalg.det(q) == pytest.approx(1.0)


def test_rigid_transform_preserves_all_pairwise_distances():
    points = np.array([[0.0, 0.0], [3.0, 0.0], [1.0, 2.0], [-2.0, 1.0]])
    q = rotation_matrix_2d(np.deg2rad(37.0))
    diagnostics = rigid_motion_diagnostics(points, q, [4.0, -3.0])
    assert diagnostics.orthogonality_residual < 1e-14
    assert diagnostics.determinant == pytest.approx(1.0)
    assert diagnostics.maximum_distance_error < 2e-15


def test_rigid_transform_accepts_single_point():
    q = rotation_matrix_2d(np.pi / 2.0)
    np.testing.assert_allclose(rigid_transform([1.0, 0.0], q, [2.0, 3.0]), [2.0, 4.0], atol=1e-14)


def test_rigid_transform_rejects_nonorthogonal_matrix():
    with pytest.raises(ValueError, match="ortogonal"):
        rigid_transform([[0.0, 0.0]], [[2.0, 0.0], [0.0, 1.0]], [0.0, 0.0])


def test_perpendicular_bisector_residual_vanishes_on_locus():
    assert perpendicular_bisector_residual([2.0, 9.0], [0.0, 0.0], [4.0, 0.0]) == pytest.approx(0.0)


def test_circle_residuals_vanish_for_exact_ranges():
    point = np.array([1.0, 1.0])
    anchors = np.array([[0.0, 0.0], [4.0, 0.0], [0.0, 3.0]])
    ranges = np.linalg.norm(anchors - point, axis=1)
    np.testing.assert_allclose(circle_residuals(point, anchors, ranges), 0.0, atol=1e-14)


def test_exact_trilateration_recovers_point():
    target = np.array([1.0, 1.0])
    anchors = np.array([[0.0, 0.0], [4.0, 0.0], [0.0, 3.0]])
    ranges = np.linalg.norm(anchors - target, axis=1)
    result = trilaterate_linear(anchors, ranges)
    np.testing.assert_allclose(result.point, target, atol=1e-14)
    assert result.rank == 2
    assert result.residual_norm < 1e-14


def test_overdetermined_noisy_trilateration_is_close_to_target():
    target = np.array([2.3, 1.7])
    anchors = np.array([[0.0, 0.0], [6.0, 0.0], [0.0, 5.0], [6.0, 5.0]])
    noise = np.array([0.010, -0.006, 0.004, -0.008])
    ranges = np.linalg.norm(anchors - target, axis=1) + noise
    result = trilaterate_linear(anchors, ranges)
    assert np.linalg.norm(result.point - target) < 0.02
    assert np.isfinite(result.residual_norm)


def test_trilateration_rejects_collinear_anchors():
    with pytest.raises(ValueError, match="rank 2"):
        trilaterate_linear([[0, 0], [1, 0], [2, 0]], [1, 1, 1])


def test_nonfinite_input_is_rejected():
    with pytest.raises(ValueError, match="sonlu"):
        euclidean_distance([0.0, np.nan], [1.0, 1.0])
