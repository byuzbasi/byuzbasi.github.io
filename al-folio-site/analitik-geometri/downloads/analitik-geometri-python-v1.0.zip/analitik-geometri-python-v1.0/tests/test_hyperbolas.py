import numpy as np
import pytest

from agbook import (
    focus_directrix_ratios,
    hyperbola_algebraic_residuals,
    hyperbola_asymptote_lines,
    hyperbola_diagnostics,
    hyperbola_focal_difference_residuals,
    hyperbola_frame_from_center_axes,
    hyperbola_frame_from_foci,
    hyperbola_points,
    hyperbola_tangent_line,
    rigid_transform,
    rotation_matrix_2d,
)


def line_values(line, points):
    points = np.asarray(points, dtype=float)
    return points @ line[:2] + line[2]


def test_center_axes_frame_has_expected_geometry():
    frame = hyperbola_frame_from_center_axes([2.0, -1.0], [3.0, 4.0], 3.0, 4.0)
    np.testing.assert_allclose(frame.transverse_direction, [0.6, 0.8])
    np.testing.assert_allclose(frame.conjugate_direction, [-0.8, 0.6])
    np.testing.assert_allclose(frame.first_focus, [-1.0, -5.0])
    np.testing.assert_allclose(frame.second_focus, [5.0, 3.0])
    assert frame.focal_distance == pytest.approx(5.0)
    assert frame.eccentricity == pytest.approx(5.0 / 3.0)


def test_frame_directrices_have_expected_positions():
    frame = hyperbola_frame_from_center_axes([2.0, -1.0], [3.0, 4.0], 3.0, 4.0)
    offset = frame.semi_transverse / frame.eccentricity
    first_point = frame.center - offset * frame.transverse_direction
    second_point = frame.center + offset * frame.transverse_direction
    assert line_values(frame.first_directrix, first_point) == pytest.approx(0.0)
    assert line_values(frame.second_directrix, second_point) == pytest.approx(0.0)
    assert abs(line_values(frame.first_directrix, frame.center)) == pytest.approx(offset)
    assert abs(line_values(frame.second_directrix, frame.center)) == pytest.approx(offset)


def test_frame_asymptotes_pass_through_center():
    frame = hyperbola_frame_from_center_axes([2.0, -1.0], [3.0, 4.0], 3.0, 4.0)
    assert line_values(frame.first_asymptote, frame.center) == pytest.approx(0.0)
    assert line_values(frame.second_asymptote, frame.center) == pytest.approx(0.0)
    assert np.linalg.norm(frame.first_asymptote[:2]) == pytest.approx(1.0)
    assert np.linalg.norm(frame.second_asymptote[:2]) == pytest.approx(1.0)


def test_foci_frame_recovers_center_axes_and_conjugate_radius():
    frame = hyperbola_frame_from_foci([-4.0, 1.0], [6.0, 1.0], 3.0)
    np.testing.assert_allclose(frame.center, [1.0, 1.0])
    np.testing.assert_allclose(frame.transverse_direction, [1.0, 0.0])
    np.testing.assert_allclose(frame.conjugate_direction, [0.0, 1.0])
    assert frame.focal_distance == pytest.approx(5.0)
    assert frame.semi_conjugate == pytest.approx(4.0)
    assert frame.eccentricity == pytest.approx(5.0 / 3.0)


def test_center_axes_and_foci_constructors_agree():
    axes = hyperbola_frame_from_center_axes([1.0, -2.0], [2.0, 1.0], 4.0, 7.0)
    foci = hyperbola_frame_from_foci(
        axes.first_focus,
        axes.second_focus,
        axes.semi_transverse,
    )
    np.testing.assert_allclose(foci.center, axes.center)
    np.testing.assert_allclose(foci.transverse_direction, axes.transverse_direction)
    np.testing.assert_allclose(foci.conjugate_direction, axes.conjugate_direction)
    assert foci.semi_conjugate == pytest.approx(axes.semi_conjugate)
    assert foci.eccentricity == pytest.approx(axes.eccentricity)


def test_equal_axes_are_valid_rectangular_hyperbola():
    frame = hyperbola_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], 2.0, 2.0)
    assert frame.focal_distance == pytest.approx(2.0 * np.sqrt(2.0))
    assert frame.eccentricity == pytest.approx(np.sqrt(2.0))
    normals = np.vstack([frame.first_asymptote[:2], frame.second_asymptote[:2]])
    assert abs(float(normals[0] @ normals[1])) < 1e-14


def test_hyperbola_points_support_scalar_and_vector_parameters():
    scalar = hyperbola_points(
        [1.0, 2.0], [1.0, 0.0], 3.0, 2.0, 0.0, branch=1
    )
    rows = hyperbola_points(
        [1.0, 2.0], [1.0, 0.0], 3.0, 2.0, [-1.0, 0.0, 1.0], branch=-1
    )
    assert scalar.shape == (2,)
    assert rows.shape == (3, 2)
    np.testing.assert_allclose(scalar, [4.0, 2.0])
    np.testing.assert_allclose(rows[1], [-2.0, 2.0])


def test_zero_parameter_gives_both_vertices():
    frame = hyperbola_frame_from_center_axes([2.0, -3.0], [3.0, 4.0], 5.0, 2.0)
    right = hyperbola_points(
        frame.center,
        frame.transverse_direction,
        frame.semi_transverse,
        frame.semi_conjugate,
        0.0,
        branch=1,
    )
    left = hyperbola_points(
        frame.center,
        frame.transverse_direction,
        frame.semi_transverse,
        frame.semi_conjugate,
        0.0,
        branch=-1,
    )
    np.testing.assert_allclose(
        right, frame.center + frame.semi_transverse * frame.transverse_direction
    )
    np.testing.assert_allclose(
        left, frame.center - frame.semi_transverse * frame.transverse_direction
    )


@pytest.mark.parametrize("branch", [-1, 1])
def test_parameter_points_satisfy_algebraic_equation(branch):
    frame = hyperbola_frame_from_center_axes([1.0, -2.0], [2.0, -1.0], 4.0, 3.0)
    points = hyperbola_points(
        frame.center,
        frame.transverse_direction,
        frame.semi_transverse,
        frame.semi_conjugate,
        np.linspace(-3.0, 3.0, 41),
        branch=branch,
    )
    residuals = hyperbola_algebraic_residuals(
        points,
        frame.center,
        frame.transverse_direction,
        frame.semi_transverse,
        frame.semi_conjugate,
    )
    np.testing.assert_allclose(residuals, 0.0, atol=2e-13)


@pytest.mark.parametrize("branch", [-1, 1])
def test_parameter_points_satisfy_focal_difference_definition(branch):
    frame = hyperbola_frame_from_center_axes([1.0, -2.0], [2.0, -1.0], 4.0, 3.0)
    points = hyperbola_points(
        frame.center,
        frame.transverse_direction,
        frame.semi_transverse,
        frame.semi_conjugate,
        np.linspace(-2.5, 2.5, 31),
        branch=branch,
    )
    residuals = hyperbola_focal_difference_residuals(
        points,
        frame.first_focus,
        frame.second_focus,
        frame.semi_transverse,
    )
    np.testing.assert_allclose(residuals, 0.0, atol=2e-13)


def test_signed_focal_difference_identifies_branch():
    right = hyperbola_diagnostics(
        [0.0, 0.0], [1.0, 0.0], 3.0, 4.0, [-2.0, 0.0, 2.0], branch=1
    )
    left = hyperbola_diagnostics(
        [0.0, 0.0], [1.0, 0.0], 3.0, 4.0, [-2.0, 0.0, 2.0], branch=-1
    )
    np.testing.assert_allclose(right.signed_focal_differences, 6.0, atol=1e-13)
    np.testing.assert_allclose(left.signed_focal_differences, -6.0, atol=1e-13)


def test_scalar_residual_functions_return_float():
    frame = hyperbola_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], 3.0, 4.0)
    point = hyperbola_points([0.0, 0.0], [1.0, 0.0], 3.0, 4.0, 0.5, branch=1)
    algebraic = hyperbola_algebraic_residuals(point, [0.0, 0.0], [1.0, 0.0], 3.0, 4.0)
    focal = hyperbola_focal_difference_residuals(
        point, frame.first_focus, frame.second_focus, 3.0
    )
    assert isinstance(algebraic, float)
    assert isinstance(focal, float)


def test_right_focus_directrix_ratio_equals_eccentricity():
    frame = hyperbola_frame_from_center_axes([0.0, 0.0], [1.0, 0.0], 3.0, 4.0)
    points = hyperbola_points(
        frame.center, frame.transverse_direction, 3.0, 4.0, [-1.0, 0.4, 1.2], branch=1
    )
    ratios = focus_directrix_ratios(points, frame.second_focus, frame.second_directrix)
    np.testing.assert_allclose(ratios, frame.eccentricity, atol=2e-14)


def test_standard_asymptotes_have_expected_slopes():
    lines = hyperbola_asymptote_lines([0.0, 0.0], [1.0, 0.0], 3.0, 4.0)
    assert lines.shape == (2, 3)
    for line in lines:
        assert line_values(line, [0.0, 0.0]) == pytest.approx(0.0)
    values_at_three = np.array([-line[0] * 3.0 / line[1] for line in lines])
    np.testing.assert_allclose(np.sort(values_at_three), [-4.0, 4.0])


@pytest.mark.parametrize("branch", [-1, 1])
def test_asymptote_distance_decreases_along_positive_end(branch):
    diagnostics = hyperbola_diagnostics(
        [0.0, 0.0], [1.0, 0.0], 3.0, 4.0, [1.0, 2.0, 3.0], branch=branch
    )
    distances = diagnostics.nearest_asymptote_distances
    assert np.all(np.diff(distances) < 0.0)
    assert distances[-1] < distances[0] / 5.0


@pytest.mark.parametrize("branch", [-1, 1])
def test_tangent_contains_parameter_point_and_is_orthogonal_to_velocity(branch):
    center = np.array([1.0, -2.0])
    direction = np.array([2.0, 1.0])
    frame = hyperbola_frame_from_center_axes(center, direction, 4.0, 3.0)
    parameter = 0.7
    point = hyperbola_points(center, direction, 4.0, 3.0, parameter, branch=branch)
    line = hyperbola_tangent_line(
        center, direction, 4.0, 3.0, parameter, branch=branch
    )
    velocity = (
        branch * frame.semi_transverse * np.sinh(parameter)
        * frame.transverse_direction
        + frame.semi_conjugate * np.cosh(parameter) * frame.conjugate_direction
    )
    assert line_values(line, point) == pytest.approx(0.0, abs=2e-14)
    assert float(line[:2] @ velocity) == pytest.approx(0.0, abs=2e-14)


def test_tangent_at_right_vertex_is_perpendicular_to_transverse_axis():
    line = hyperbola_tangent_line(
        [2.0, -1.0], [3.0, 4.0], 3.0, 4.0, 0.0, branch=1
    )
    direction = np.array([0.6, 0.8])
    assert abs(float(line[:2] @ direction)) == pytest.approx(1.0)


def test_diagnostics_report_small_residuals_and_consistent_shapes():
    result = hyperbola_diagnostics(
        [1.0, 2.0], [3.0, -1.0], 5.0, 2.0, np.linspace(-2.0, 2.0, 17), branch=-1
    )
    assert result.parameters.shape == (17,)
    assert result.points.shape == (17, 2)
    assert result.branch == -1
    assert result.maximum_absolute_algebraic_residual < 2e-13
    assert result.maximum_absolute_focal_difference_residual < 2e-13


@pytest.mark.parametrize("branch", [-1, 1])
def test_rigid_motion_preserves_geometry(branch):
    center = np.array([1.0, -2.0])
    direction = np.array([2.0, -1.0])
    parameters = np.linspace(-1.5, 1.5, 13)
    points = hyperbola_points(center, direction, 4.0, 3.0, parameters, branch=branch)
    rotation = rotation_matrix_2d(0.73)
    translation = np.array([-5.0, 2.5])
    moved_center = rigid_transform(center, rotation, translation)
    moved_direction = rotation @ (direction / np.linalg.norm(direction))
    expected = rigid_transform(points, rotation, translation)
    actual = hyperbola_points(
        moved_center, moved_direction, 4.0, 3.0, parameters, branch=branch
    )
    np.testing.assert_allclose(actual, expected, atol=3e-14)


def test_uniform_scaling_preserves_dimensionless_residual_and_scales_length():
    frame = hyperbola_frame_from_center_axes([1.0, -2.0], [2.0, 1.0], 4.0, 3.0)
    point = hyperbola_points(frame.center, frame.transverse_direction, 4.0, 3.0, 0.8, branch=1)
    perturbed = point + np.array([1e-5, -2e-5])
    scale = 7.0
    original_algebraic = hyperbola_algebraic_residuals(
        perturbed, frame.center, frame.transverse_direction, 4.0, 3.0
    )
    scaled_algebraic = hyperbola_algebraic_residuals(
        scale * perturbed,
        scale * frame.center,
        frame.transverse_direction,
        scale * 4.0,
        scale * 3.0,
    )
    original_focal = hyperbola_focal_difference_residuals(
        perturbed, frame.first_focus, frame.second_focus, 4.0
    )
    scaled_focal = hyperbola_focal_difference_residuals(
        scale * perturbed,
        scale * frame.first_focus,
        scale * frame.second_focus,
        scale * 4.0,
    )
    assert scaled_algebraic == pytest.approx(original_algebraic, rel=1e-10, abs=1e-15)
    assert scaled_focal == pytest.approx(scale * original_focal, rel=2e-10, abs=1e-14)


def test_reversing_axis_and_branch_parameter_labels_preserves_points():
    center = [1.0, 2.0]
    direction = np.array([2.0, -3.0])
    parameters = np.array([-1.2, -0.2, 0.0, 0.9])
    original = hyperbola_points(center, direction, 4.0, 3.0, parameters, branch=1)
    relabelled = hyperbola_points(
        center, -direction, 4.0, 3.0, -parameters, branch=-1
    )
    np.testing.assert_allclose(relabelled, original, atol=2e-14)


@pytest.mark.parametrize(
    ("semi_transverse", "semi_conjugate"),
    [(0.0, 1.0), (-1.0, 1.0), (1.0, 0.0), (1.0, -1.0)],
)
def test_nonpositive_axes_are_rejected(semi_transverse, semi_conjugate):
    with pytest.raises(ValueError):
        hyperbola_frame_from_center_axes(
            [0.0, 0.0], [1.0, 0.0], semi_transverse, semi_conjugate
        )


@pytest.mark.parametrize("direction", [[0.0, 0.0], [np.nan, 1.0], [1.0]])
def test_invalid_transverse_directions_are_rejected(direction):
    with pytest.raises(ValueError):
        hyperbola_frame_from_center_axes([0.0, 0.0], direction, 3.0, 4.0)


@pytest.mark.parametrize("branch", [0, 2, -2, 0.5, np.nan, True])
def test_invalid_branches_are_rejected(branch):
    with pytest.raises(ValueError):
        hyperbola_points(
            [0.0, 0.0], [1.0, 0.0], 3.0, 4.0, 0.0, branch=branch
        )


def test_empty_and_nonfinite_parameters_are_rejected():
    with pytest.raises(ValueError):
        hyperbola_points([0.0, 0.0], [1.0, 0.0], 3.0, 4.0, [], branch=1)
    with pytest.raises(ValueError):
        hyperbola_points(
            [0.0, 0.0], [1.0, 0.0], 3.0, 4.0, [0.0, np.inf], branch=1
        )


@pytest.mark.parametrize(
    ("first", "second", "semi_transverse"),
    [
        ([0.0, 0.0], [0.0, 0.0], 1.0),
        ([-1.0, 0.0], [1.0, 0.0], 1.0),
        ([-1.0, 0.0], [1.0, 0.0], 2.0),
    ],
)
def test_invalid_foci_constructions_are_rejected(first, second, semi_transverse):
    with pytest.raises(ValueError):
        hyperbola_frame_from_foci(first, second, semi_transverse)


def test_focus_tolerance_rejects_unresolved_axis():
    with pytest.raises(ValueError):
        hyperbola_frame_from_foci(
            [0.0, 0.0], [1e-8, 0.0], 1e-9, focus_tolerance=1e-7
        )


@pytest.mark.parametrize("points", [[], [1.0], [[1.0, 2.0, 3.0]], [[[1.0, 2.0]]]])
def test_malformed_point_inputs_are_rejected(points):
    with pytest.raises(ValueError):
        hyperbola_algebraic_residuals(
            points, [0.0, 0.0], [1.0, 0.0], 3.0, 4.0
        )


def test_nonfinite_points_are_rejected():
    with pytest.raises(ValueError):
        hyperbola_algebraic_residuals(
            [[1.0, 2.0], [np.inf, 0.0]],
            [0.0, 0.0],
            [1.0, 0.0],
            3.0,
            4.0,
        )


def test_large_parameters_raise_explicit_overflow():
    with pytest.raises(OverflowError):
        hyperbola_points(
            [0.0, 0.0], [1.0, 0.0], 3.0, 4.0, 1000.0, branch=1
        )
    with pytest.raises(OverflowError):
        hyperbola_tangent_line(
            [0.0, 0.0], [1.0, 0.0], 3.0, 4.0, 1000.0, branch=1
        )


def test_huge_axes_that_exceed_float_range_raise_overflow():
    with pytest.raises(OverflowError):
        hyperbola_frame_from_center_axes(
            [0.0, 0.0], [1.0, 0.0], 1.7e308, 1.7e308
        )
