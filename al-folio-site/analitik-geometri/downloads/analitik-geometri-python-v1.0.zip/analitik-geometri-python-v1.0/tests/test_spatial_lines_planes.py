import numpy as np
import pytest

from agbook.spatial_lines_planes import (
    affine_system_diagnostics_3d,
    canonical_plane_coefficients,
    parametric_line_points_3d,
    plane_from_point_normal,
    plane_from_points_3d,
    plane_membership_diagnostics_3d,
    plane_residuals_3d,
)


def test_parametric_line_points_match_known_values():
    points = parametric_line_points_3d(
        [1.0, -2.0, 3.0],
        [2.0, 1.0, -4.0],
        [-1.0, 0.0, 0.5, 2.0],
    )
    np.testing.assert_allclose(
        points,
        [[-1.0, -3.0, 7.0], [1.0, -2.0, 3.0], [2.0, -1.5, 1.0], [5.0, 0.0, -5.0]],
    )


def test_parametric_line_reparameterization_preserves_points():
    anchor = np.array([1.0, 2.0, -1.0])
    direction = np.array([2.0, -3.0, 4.0])
    shifted_anchor = anchor + 2.0 * direction
    scaled_direction = -3.0 * direction
    parameters = np.array([-2.0, -0.5, 0.0, 1.5])
    first = parametric_line_points_3d(
        shifted_anchor,
        scaled_direction,
        parameters,
    )
    second = parametric_line_points_3d(
        anchor,
        direction,
        2.0 - 3.0 * parameters,
    )
    np.testing.assert_allclose(first, second)


def test_parametric_segment_endpoints_use_zero_and_one():
    point_a = np.array([-2.0, 1.0, 5.0])
    point_b = np.array([4.0, -3.0, 2.0])
    points = parametric_line_points_3d(point_a, point_b - point_a, [0.0, 1.0])
    np.testing.assert_allclose(points, [point_a, point_b])


def test_parametric_line_rejects_zero_or_thresholded_direction():
    with pytest.raises(ValueError, match="doğrusu"):
        parametric_line_points_3d([0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0])
    with pytest.raises(ValueError, match="eşik"):
        parametric_line_points_3d(
            [0.0, 0.0, 0.0],
            [1.0e-10, 0.0, 0.0],
            [0.0],
            zero_tolerance=1.0e-9,
        )


@pytest.mark.parametrize(
    "point,direction,parameters",
    [
        ([0.0, 0.0], [1.0, 0.0, 0.0], [0.0]),
        ([0.0, 0.0, 0.0], [1.0, 0.0], [0.0]),
        ([0.0, 0.0, 0.0], [1.0, 0.0, 0.0], 1.0),
        ([0.0, 0.0, 0.0], [1.0, 0.0, 0.0], []),
        ([0.0, np.nan, 0.0], [1.0, 0.0, 0.0], [0.0]),
        ([0.0, 0.0, 0.0], [1.0, np.inf, 0.0], [0.0]),
    ],
)
def test_parametric_line_rejects_invalid_inputs(point, direction, parameters):
    with pytest.raises(ValueError):
        parametric_line_points_3d(point, direction, parameters)


def test_parametric_line_reports_overflow():
    with pytest.raises(OverflowError, match="Parametrik"):
        parametric_line_points_3d(
            [1.0e308, 0.0, 0.0],
            [1.0e308, 0.0, 0.0],
            [2.0],
        )


def test_canonical_plane_normalizes_and_fixes_sign():
    result = canonical_plane_coefficients([-2.0, 2.0, -1.0, 3.0])
    np.testing.assert_allclose(result, [2.0 / 3.0, -2.0 / 3.0, 1.0 / 3.0, -1.0])
    assert np.linalg.norm(result[:3]) == pytest.approx(1.0)


@pytest.mark.parametrize("scale", [3.5, -7.0, 1.0e120, -1.0e-120])
def test_canonical_plane_ignores_nonzero_common_scale(scale):
    reference = canonical_plane_coefficients([2.0, -3.0, 6.0, -14.0])
    scaled = canonical_plane_coefficients(scale * np.array([2.0, -3.0, 6.0, -14.0]))
    np.testing.assert_allclose(scaled, reference, rtol=1.0e-14, atol=1.0e-14)


def test_canonical_coordinate_plane_needs_no_slope():
    np.testing.assert_allclose(
        canonical_plane_coefficients([0.0, 0.0, -5.0, 15.0]),
        [0.0, 0.0, 1.0, -3.0],
    )


@pytest.mark.parametrize(
    "coefficients",
    [[0.0, 0.0, 0.0, 1.0], [0.0, 0.0, 0.0, 0.0], [1.0, 2.0, 3.0], [1.0, np.inf, 0.0, 1.0]],
)
def test_canonical_plane_rejects_invalid_coefficients(coefficients):
    with pytest.raises(ValueError):
        canonical_plane_coefficients(coefficients)


def test_canonical_plane_rejects_thresholded_normal():
    with pytest.raises(ValueError, match="eşik"):
        canonical_plane_coefficients(
            [1.0e-10, 0.0, 0.0, 1.0],
            zero_tolerance=1.0e-9,
        )


def test_canonical_plane_reports_norm_overflow():
    with pytest.raises(OverflowError, match="normu"):
        canonical_plane_coefficients([1.5e308, 1.5e308, 1.5e308, 0.0])


def test_plane_from_point_normal_contains_anchor():
    point = np.array([1.0, -2.0, 4.0])
    plane = plane_from_point_normal(point, [2.0, -1.0, 2.0])
    np.testing.assert_allclose(plane, [2.0 / 3.0, -1.0 / 3.0, 2.0 / 3.0, -4.0])
    np.testing.assert_allclose(plane_residuals_3d(plane, [point]), 0.0, atol=1.0e-15)


def test_plane_from_point_normal_ignores_normal_scale_and_sign():
    first = plane_from_point_normal([2.0, 3.0, -1.0], [1.0, -2.0, 2.0])
    second = plane_from_point_normal([2.0, 3.0, -1.0], [-5.0, 10.0, -10.0])
    np.testing.assert_allclose(first, second)


def test_plane_from_point_normal_rejects_zero_normal():
    with pytest.raises(ValueError, match="normal"):
        plane_from_point_normal([1.0, 2.0, 3.0], [0.0, 0.0, 0.0])


def test_plane_from_point_normal_reports_offset_overflow():
    with pytest.raises(OverflowError, match="sabit"):
        plane_from_point_normal([2.0, 0.0, 0.0], [1.0e308, 0.0, 0.0])


def test_plane_from_three_points_recovers_coordinate_plane():
    plane = plane_from_points_3d([0.0, 0.0, 2.0], [3.0, 0.0, 2.0], [0.0, 4.0, 2.0])
    np.testing.assert_allclose(plane, [0.0, 0.0, 1.0, -2.0])


def test_plane_from_three_points_recovers_cad_datum():
    point_a = np.array([120.0, 80.0, 35.0])
    point_b = np.array([156.0, 128.0, 35.0])
    point_c = np.array([96.0, 98.0, 75.0])
    plane = plane_from_points_3d(point_a, point_b, point_c)
    np.testing.assert_allclose(plane, [0.64, -0.48, 0.60, -59.4], atol=1.0e-14)
    np.testing.assert_allclose(
        plane_residuals_3d(plane, [point_a, point_b, point_c]),
        0.0,
        atol=2.0e-14,
    )


def test_plane_from_points_is_invariant_to_order_after_sign_canonicalization():
    points = np.array([[1.0, 2.0, 3.0], [4.0, 0.0, 5.0], [-2.0, 1.0, 4.0]])
    first = plane_from_points_3d(*points)
    second = plane_from_points_3d(points[0], points[2], points[1])
    np.testing.assert_allclose(first, second, atol=1.0e-15)


def test_plane_translation_preserves_normal_and_updates_offset():
    points = np.array([[0.0, 0.0, 0.0], [2.0, 0.0, 0.0], [0.0, 3.0, 0.0]])
    translation = np.array([4.0, -5.0, 7.0])
    original = plane_from_points_3d(*points)
    moved = plane_from_points_3d(*(points + translation))
    np.testing.assert_allclose(moved[:3], original[:3])
    assert moved[3] == pytest.approx(original[3] - np.dot(original[:3], translation))


@pytest.mark.parametrize(
    "points",
    [
        ([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], [2.0, 2.0, 2.0]),
        ([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], [0.0, 1.0, 0.0]),
    ],
)
def test_plane_from_points_rejects_collinear_or_coincident_data(points):
    with pytest.raises(ValueError, match="düzlem"):
        plane_from_points_3d(*points)


def test_plane_from_points_respects_area_tolerance():
    with pytest.raises(ValueError, match="eşik"):
        plane_from_points_3d(
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [1.0, 1.0e-10, 0.0],
            zero_tolerance=1.0e-9,
        )


def test_plane_from_points_reports_difference_overflow():
    with pytest.raises(OverflowError, match="farkı"):
        plane_from_points_3d(
            [-1.0e308, 0.0, 0.0],
            [1.0e308, 0.0, 0.0],
            [0.0, 1.0, 0.0],
        )


def test_plane_residuals_match_general_equation():
    residuals = plane_residuals_3d(
        [2.0, -1.0, 3.0, -4.0],
        [[1.0, 1.0, 1.0], [0.0, 2.0, 2.0], [2.0, 0.0, 0.0]],
    )
    np.testing.assert_allclose(residuals, [0.0, 0.0, 0.0])


def test_raw_plane_residuals_follow_equation_scale():
    points = np.array([[1.0, 2.0, 3.0], [-2.0, 4.0, 1.0]])
    first = plane_residuals_3d([2.0, -1.0, 3.0, -4.0], points)
    second = plane_residuals_3d([-10.0, 5.0, -15.0, 20.0], points)
    np.testing.assert_allclose(second, -5.0 * first)


@pytest.mark.parametrize(
    "coefficients,points",
    [
        ([1.0, 0.0, 0.0], [[0.0, 0.0, 0.0]]),
        ([0.0, 0.0, 0.0, 1.0], [[0.0, 0.0, 0.0]]),
        ([1.0, 0.0, 0.0, 0.0], [0.0, 0.0, 0.0]),
        ([1.0, 0.0, 0.0, 0.0], []),
        ([1.0, 0.0, 0.0, 0.0], [[0.0, np.nan, 0.0]]),
    ],
)
def test_plane_residuals_reject_invalid_inputs(coefficients, points):
    with pytest.raises(ValueError):
        plane_residuals_3d(coefficients, points)


def test_plane_residuals_report_overflow():
    with pytest.raises(OverflowError, match="artığı"):
        plane_residuals_3d([1.0e308, 0.0, 0.0, 1.0e308], [[2.0, 0.0, 0.0]])


def test_plane_membership_is_invariant_under_coefficient_scale():
    keywords = {
        "absolute_tolerance": 0.01,
        "relative_tolerance": 0.001,
        "reference_scale": 10.0,
    }
    first = plane_membership_diagnostics_3d(
        [2.0, -1.0, 3.0, -4.0],
        [1.0, 1.0, 1.005],
        **keywords,
    )
    second = plane_membership_diagnostics_3d(
        [-10.0, 5.0, -15.0, 20.0],
        [1.0, 1.0, 1.005],
        **keywords,
    )
    assert first.on_plane == second.on_plane
    assert first.normalized_residual == pytest.approx(second.normalized_residual)


def test_plane_membership_reports_boundary_decisions():
    accepted = plane_membership_diagnostics_3d(
        [1.0, 0.0, 0.0, 0.0],
        [0.01, 2.0, 3.0],
        absolute_tolerance=0.01,
        relative_tolerance=0.0,
        reference_scale=3.0,
    )
    rejected = plane_membership_diagnostics_3d(
        [1.0, 0.0, 0.0, 0.0],
        [0.01001, 2.0, 3.0],
        absolute_tolerance=0.01,
        relative_tolerance=0.0,
        reference_scale=3.0,
    )
    assert accepted.on_plane is True
    assert rejected.on_plane is False


@pytest.mark.parametrize(
    "keywords",
    [
        {"absolute_tolerance": -1.0, "relative_tolerance": 0.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": -1.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": 1.0, "reference_scale": 1.0},
        {"absolute_tolerance": 0.0, "relative_tolerance": 0.0, "reference_scale": -1.0},
    ],
)
def test_plane_membership_rejects_invalid_tolerances(keywords):
    with pytest.raises(ValueError):
        plane_membership_diagnostics_3d(
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0],
            **keywords,
        )


def test_plane_membership_reports_threshold_overflow():
    with pytest.raises(OverflowError, match="eşiği"):
        plane_membership_diagnostics_3d(
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0],
            absolute_tolerance=1.7e308,
            relative_tolerance=0.9,
            reference_scale=1.7e308,
        )


def test_empty_affine_system_represents_all_space():
    result = affine_system_diagnostics_3d(
        np.empty((0, 3)),
        np.empty(0),
        rank_relative_tolerance=1.0e-12,
        reference_scale=1.0,
    )
    assert result.classification == "space"
    assert result.solution_dimension == 3
    assert result.consistent is True
    np.testing.assert_allclose(result.least_squares_point, 0.0)


def test_one_independent_plane_has_dimension_two():
    result = affine_system_diagnostics_3d(
        [[1.0, -2.0, 2.0]],
        [3.0],
        rank_relative_tolerance=1.0e-12,
        reference_scale=10.0,
    )
    assert (result.coefficient_rank, result.augmented_rank) == (1, 1)
    assert result.classification == "plane"
    assert result.solution_dimension == 2


def test_two_independent_planes_have_line_solution_set():
    result = affine_system_diagnostics_3d(
        [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]],
        [2.0, -3.0],
        rank_relative_tolerance=1.0e-12,
        reference_scale=10.0,
    )
    assert (result.coefficient_rank, result.augmented_rank) == (2, 2)
    assert result.classification == "line"
    assert result.solution_dimension == 1
    np.testing.assert_allclose(result.least_squares_point, [2.0, -3.0, 0.0])


def test_three_independent_planes_have_unique_point():
    result = affine_system_diagnostics_3d(
        np.eye(3),
        [2.0, -3.0, 4.0],
        rank_relative_tolerance=1.0e-12,
        reference_scale=10.0,
    )
    assert (result.coefficient_rank, result.augmented_rank) == (3, 3)
    assert result.classification == "point"
    assert result.solution_dimension == 0
    np.testing.assert_allclose(result.least_squares_point, [2.0, -3.0, 4.0])
    assert result.maximum_equation_residual == pytest.approx(0.0)


def test_inconsistent_parallel_planes_have_empty_solution_set():
    result = affine_system_diagnostics_3d(
        [[1.0, 0.0, 0.0], [2.0, 0.0, 0.0]],
        [1.0, 4.0],
        rank_relative_tolerance=1.0e-12,
        reference_scale=10.0,
    )
    assert (result.coefficient_rank, result.augmented_rank) == (1, 2)
    assert result.classification == "empty"
    assert result.solution_dimension is None
    assert result.consistent is False
    assert result.maximum_equation_residual > 0.0


def test_equivalent_scaled_planes_still_form_one_plane():
    result = affine_system_diagnostics_3d(
        [[1.0, -2.0, 2.0], [-5.0, 10.0, -10.0]],
        [3.0, -15.0],
        rank_relative_tolerance=1.0e-12,
        reference_scale=10.0,
    )
    assert (result.coefficient_rank, result.augmented_rank) == (1, 1)
    assert result.classification == "plane"
    assert result.maximum_equation_residual < 1.0e-12


def test_overdetermined_consistent_system_keeps_unique_point():
    matrix = np.vstack([np.eye(3), [1.0, 1.0, 1.0]])
    rhs = np.array([2.0, -3.0, 4.0, 3.0])
    result = affine_system_diagnostics_3d(
        matrix,
        rhs,
        rank_relative_tolerance=1.0e-12,
        reference_scale=10.0,
    )
    assert result.classification == "point"
    np.testing.assert_allclose(result.least_squares_point, [2.0, -3.0, 4.0], atol=2.0e-14)


def test_affine_system_is_invariant_under_independent_row_scaling():
    matrix = np.array([[1.0, -2.0, 2.0], [2.0, 1.0, 0.0]])
    rhs = np.array([3.0, -4.0])
    first = affine_system_diagnostics_3d(
        matrix,
        rhs,
        rank_relative_tolerance=1.0e-12,
        reference_scale=10.0,
    )
    scales = np.array([-7.0, 1.0e80])
    second = affine_system_diagnostics_3d(
        scales[:, None] * matrix,
        scales * rhs,
        rank_relative_tolerance=1.0e-12,
        reference_scale=10.0,
    )
    assert first.classification == second.classification == "line"
    assert first.coefficient_rank == second.coefficient_rank == 2
    np.testing.assert_allclose(first.least_squares_point, second.least_squares_point)


def test_coordinate_unit_scaling_preserves_rank_and_scales_solution():
    matrix = np.eye(3)
    rhs_mm = np.array([120.0, 80.0, 35.0])
    millimetres = affine_system_diagnostics_3d(
        matrix,
        rhs_mm,
        rank_relative_tolerance=1.0e-12,
        reference_scale=200.0,
    )
    metres = affine_system_diagnostics_3d(
        matrix,
        1.0e-3 * rhs_mm,
        rank_relative_tolerance=1.0e-12,
        reference_scale=0.2,
    )
    assert millimetres.classification == metres.classification == "point"
    assert millimetres.coefficient_rank == metres.coefficient_rank == 3
    np.testing.assert_allclose(metres.least_squares_point, 1.0e-3 * millimetres.least_squares_point)


def test_cad_axis_two_plane_system_has_rank_two_and_normal_null_direction():
    point_a = np.array([120.0, 80.0, 35.0])
    row_1 = np.array([0.6, 0.8, 0.0])
    row_2 = np.array([-0.48, 0.36, 0.8])
    matrix = np.vstack([row_1, row_2])
    rhs = matrix @ point_a
    result = affine_system_diagnostics_3d(
        matrix,
        rhs,
        rank_relative_tolerance=1.0e-12,
        reference_scale=200.0,
    )
    normal = np.array([0.64, -0.48, 0.60])
    assert result.classification == "line"
    assert result.solution_dimension == 1
    np.testing.assert_allclose(matrix @ normal, 0.0, atol=1.0e-15)
    np.testing.assert_allclose(matrix @ point_a, rhs)


def test_cad_axis_plus_datum_plane_has_unique_anchor():
    point_a = np.array([120.0, 80.0, 35.0])
    matrix = np.array(
        [
            [0.6, 0.8, 0.0],
            [-0.48, 0.36, 0.8],
            [0.64, -0.48, 0.60],
        ]
    )
    rhs = matrix @ point_a
    result = affine_system_diagnostics_3d(
        matrix,
        rhs,
        rank_relative_tolerance=1.0e-12,
        reference_scale=200.0,
    )
    assert result.classification == "point"
    np.testing.assert_allclose(result.least_squares_point, point_a, atol=3.0e-14)


def test_zero_equations_distinguish_redundancy_from_inconsistency():
    redundant = affine_system_diagnostics_3d(
        [[0.0, 0.0, 0.0]],
        [0.0],
        rank_relative_tolerance=1.0e-12,
        reference_scale=1.0,
    )
    inconsistent = affine_system_diagnostics_3d(
        [[0.0, 0.0, 0.0]],
        [1.0],
        rank_relative_tolerance=1.0e-12,
        reference_scale=1.0,
    )
    assert redundant.classification == "space"
    assert inconsistent.classification == "empty"


def test_rank_classification_changes_only_with_reported_threshold():
    matrix = np.array([[1.0, 0.0, 0.0], [1.0, 1.0e-10, 0.0]])
    rhs = np.zeros(2)
    coarse = affine_system_diagnostics_3d(
        matrix,
        rhs,
        rank_relative_tolerance=1.0e-8,
        reference_scale=1.0,
    )
    fine = affine_system_diagnostics_3d(
        matrix,
        rhs,
        rank_relative_tolerance=1.0e-12,
        reference_scale=1.0,
    )
    assert coarse.classification == "plane"
    assert fine.classification == "line"
    assert coarse.rank_threshold > fine.rank_threshold


@pytest.mark.parametrize(
    "matrix,rhs,rank_tolerance,reference_scale",
    [
        ([1.0, 0.0, 0.0], [1.0], 1.0e-12, 1.0),
        ([[1.0, 0.0]], [1.0], 1.0e-12, 1.0),
        ([[1.0, 0.0, 0.0]], [[1.0]], 1.0e-12, 1.0),
        ([[1.0, 0.0, 0.0]], [1.0, 2.0], 1.0e-12, 1.0),
        ([[1.0, 0.0, 0.0]], [1.0], 0.0, 1.0),
        ([[1.0, 0.0, 0.0]], [1.0], 1.0, 1.0),
        ([[1.0, 0.0, 0.0]], [1.0], 1.0e-12, 0.0),
        ([[1.0, np.nan, 0.0]], [1.0], 1.0e-12, 1.0),
    ],
)
def test_affine_system_rejects_invalid_inputs(matrix, rhs, rank_tolerance, reference_scale):
    with pytest.raises(ValueError):
        affine_system_diagnostics_3d(
            matrix,
            rhs,
            rank_relative_tolerance=rank_tolerance,
            reference_scale=reference_scale,
        )


def test_affine_system_reports_normalization_overflow():
    with pytest.raises(OverflowError, match="normalleştirmesi"):
        affine_system_diagnostics_3d(
            [[1.0e-308, 0.0, 0.0]],
            [1.0e308],
            rank_relative_tolerance=1.0e-12,
            reference_scale=1.0,
        )
