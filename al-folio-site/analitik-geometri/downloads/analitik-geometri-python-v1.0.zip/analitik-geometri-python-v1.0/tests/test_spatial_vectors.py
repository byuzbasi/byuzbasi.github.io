"""Bölüm 17 uzay vektörü, alan, hacim ve yönelim testleri."""

from __future__ import annotations

import numpy as np
import pytest

from agbook.spatial_vectors import (
    cross_product_3d,
    parallelepiped_volume,
    parallelogram_area_3d,
    scalar_triple_product,
    spatial_orientation_diagnostics,
    tetrahedron_signed_volume,
    tetrahedron_volume,
    triangle_area_3d,
    unit_normal_3d,
)


def rational_rotation() -> np.ndarray:
    """Sütunları tam rasyonel ve sağ yönlü ortonormal bir çerçeve."""

    return np.array(
        [
            [3.0 / 5.0, -12.0 / 25.0, 16.0 / 25.0],
            [4.0 / 5.0, 9.0 / 25.0, -12.0 / 25.0],
            [0.0, 20.0 / 25.0, 15.0 / 25.0],
        ]
    )


def test_cross_product_of_standard_basis_is_right_handed():
    np.testing.assert_allclose(
        cross_product_3d([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        [0.0, 0.0, 1.0],
    )


def test_cross_product_matches_component_formula():
    np.testing.assert_allclose(
        cross_product_3d([2.0, -1.0, 3.0], [4.0, 5.0, -2.0]),
        [-13.0, 16.0, 14.0],
    )


def test_cross_product_is_anticommutative():
    u = np.array([2.0, -1.0, 3.0])
    v = np.array([4.0, 5.0, -2.0])
    np.testing.assert_allclose(cross_product_3d(v, u), -cross_product_3d(u, v))


def test_cross_product_is_bilinear():
    u = np.array([1.0, 2.0, -1.0])
    v = np.array([3.0, -2.0, 4.0])
    w = np.array([-1.0, 5.0, 2.0])
    np.testing.assert_allclose(
        cross_product_3d(2.5 * u - 3.0 * v, w),
        2.5 * cross_product_3d(u, w) - 3.0 * cross_product_3d(v, w),
    )


def test_cross_product_is_perpendicular_to_both_inputs():
    u = np.array([2.0, -1.0, 3.0])
    v = np.array([4.0, 5.0, -2.0])
    normal = cross_product_3d(u, v)
    assert np.dot(normal, u) == pytest.approx(0.0, abs=1e-14)
    assert np.dot(normal, v) == pytest.approx(0.0, abs=1e-14)


def test_lagrange_identity():
    u = np.array([2.0, -1.0, 3.0])
    v = np.array([4.0, 5.0, -2.0])
    left = np.dot(cross_product_3d(u, v), cross_product_3d(u, v))
    right = np.dot(u, u) * np.dot(v, v) - np.dot(u, v) ** 2
    assert left == pytest.approx(right)


def test_unit_normal_has_unit_length_and_ordered_direction():
    result = unit_normal_3d([3.0, 0.0, 0.0], [0.0, 4.0, 0.0])
    np.testing.assert_allclose(result, [0.0, 0.0, 1.0])
    assert np.linalg.norm(result) == pytest.approx(1.0)


def test_unit_normal_reverses_when_input_order_is_swapped():
    first = unit_normal_3d([2.0, -1.0, 3.0], [4.0, 5.0, -2.0])
    second = unit_normal_3d([4.0, 5.0, -2.0], [2.0, -1.0, 3.0])
    np.testing.assert_allclose(second, -first)


def test_unit_normal_rejects_parallel_vectors():
    with pytest.raises(ValueError, match="birim normali"):
        unit_normal_3d([1.0, 2.0, 3.0], [2.0, 4.0, 6.0])


def test_unit_normal_uses_area_dimensioned_threshold():
    with pytest.raises(ValueError, match="eşik altındaki"):
        unit_normal_3d(
            [1.0e-5, 0.0, 0.0],
            [0.0, 1.0e-5, 0.0],
            zero_tolerance=1.0e-9,
        )


def test_parallelogram_and_triangle_area():
    assert parallelogram_area_3d([3.0, 0.0, 0.0], [0.0, 4.0, 0.0]) == pytest.approx(12.0)
    assert triangle_area_3d([1.0, 2.0, 3.0], [4.0, 2.0, 3.0], [1.0, 6.0, 3.0]) == pytest.approx(6.0)


def test_triangle_area_is_translation_invariant():
    points = np.array([[1.0, 2.0, 3.0], [5.0, 3.0, 4.0], [2.0, 7.0, 6.0]])
    translation = np.array([1.0e8, -2.0e8, 3.0e8])
    assert triangle_area_3d(*(points + translation)) == pytest.approx(
        triangle_area_3d(*points)
    )


def test_scalar_triple_product_matches_known_value():
    assert scalar_triple_product(
        [1.0, 2.0, 3.0], [0.0, -1.0, 4.0], [2.0, 1.0, 0.0]
    ) == pytest.approx(18.0)


def test_scalar_triple_product_matches_determinant():
    u = np.array([2.0, -1.0, 3.0])
    v = np.array([4.0, 5.0, -2.0])
    w = np.array([-1.0, 2.0, 6.0])
    expected = np.linalg.det(np.column_stack([u, v, w]))
    assert scalar_triple_product(u, v, w) == pytest.approx(expected)


def test_scalar_triple_product_cyclic_permutations_and_swap():
    u = np.array([2.0, -1.0, 3.0])
    v = np.array([4.0, 5.0, -2.0])
    w = np.array([-1.0, 2.0, 6.0])
    value = scalar_triple_product(u, v, w)
    assert scalar_triple_product(v, w, u) == pytest.approx(value)
    assert scalar_triple_product(w, u, v) == pytest.approx(value)
    assert scalar_triple_product(v, u, w) == pytest.approx(-value)


def test_parallelepiped_volume_discards_only_orientation_sign():
    u = [2.0, 0.0, 0.0]
    v = [0.0, 3.0, 0.0]
    w = [0.0, 0.0, -4.0]
    assert scalar_triple_product(u, v, w) == pytest.approx(-24.0)
    assert parallelepiped_volume(u, v, w) == pytest.approx(24.0)


def test_tetrahedron_signed_and_unsigned_volume():
    a = [1.0, 2.0, 3.0]
    b = [3.0, 2.0, 3.0]
    c = [1.0, 5.0, 3.0]
    d = [1.0, 2.0, 7.0]
    assert tetrahedron_signed_volume(a, b, c, d) == pytest.approx(4.0)
    assert tetrahedron_signed_volume(a, c, b, d) == pytest.approx(-4.0)
    assert tetrahedron_volume(a, c, b, d) == pytest.approx(4.0)


def test_tetrahedron_volume_is_translation_invariant():
    points = np.array(
        [[1.0, 2.0, 3.0], [4.0, 3.0, 3.0], [2.0, 6.0, 4.0], [3.0, 4.0, 9.0]]
    )
    translation = np.array([1.0e7, -2.0e7, 3.0e7])
    assert tetrahedron_signed_volume(*(points + translation)) == pytest.approx(
        tetrahedron_signed_volume(*points)
    )


def test_area_and_volume_have_expected_uniform_scaling():
    u = np.array([2.0, -1.0, 3.0])
    v = np.array([4.0, 5.0, -2.0])
    w = np.array([-1.0, 2.0, 6.0])
    factor = 7.5
    assert parallelogram_area_3d(factor * u, factor * v) == pytest.approx(
        factor**2 * parallelogram_area_3d(u, v)
    )
    assert parallelepiped_volume(factor * u, factor * v, factor * w) == pytest.approx(
        factor**3 * parallelepiped_volume(u, v, w)
    )


def test_orientation_diagnostics_right_and_left_handed():
    right = spatial_orientation_diagnostics(
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 1.0],
        relative_tolerance=1.0e-12,
    )
    left = spatial_orientation_diagnostics(
        [0.0, 1.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        relative_tolerance=1.0e-12,
    )
    assert right.classification == "right_handed"
    assert right.normalized_triple_product == pytest.approx(1.0)
    assert not right.numerically_ambiguous
    assert left.classification == "left_handed"
    assert left.normalized_triple_product == pytest.approx(-1.0)


def test_exact_coplanarity_is_distinct_from_numerical_uncertainty():
    result = spatial_orientation_diagnostics(
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [1.0, 1.0, 0.0],
        relative_tolerance=1.0e-12,
    )
    assert result.classification == "coplanar"
    assert result.scalar_triple_product == pytest.approx(0.0)
    assert not result.numerically_ambiguous


@pytest.mark.parametrize(
    ("u", "v", "w"),
    [
        ([0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        ([1.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        ([1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 0.0]),
    ],
)
def test_zero_vector_makes_orientation_degenerate(u, v, w):
    result = spatial_orientation_diagnostics(u, v, w, relative_tolerance=0.0)
    assert result.classification == "degenerate"
    assert not result.numerically_ambiguous


def test_near_coplanarity_uses_only_explicit_relative_tolerance():
    vectors = ([1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [1.0, 1.0, 1.0e-14])
    exact_float = spatial_orientation_diagnostics(*vectors, relative_tolerance=0.0)
    thresholded = spatial_orientation_diagnostics(*vectors, relative_tolerance=1.0e-12)
    assert exact_float.classification == "right_handed"
    assert not exact_float.numerically_ambiguous
    assert thresholded.classification == "uncertain"
    assert thresholded.numerically_ambiguous


def test_normalized_orientation_is_invariant_under_positive_rescaling():
    vectors = (
        np.array([2.0, -1.0, 3.0]),
        np.array([4.0, 5.0, -2.0]),
        np.array([-1.0, 2.0, 6.0]),
    )
    original = spatial_orientation_diagnostics(*vectors, relative_tolerance=1.0e-12)
    scaled = spatial_orientation_diagnostics(
        1.0e80 * vectors[0],
        1.0e-70 * vectors[1],
        1.0e40 * vectors[2],
        relative_tolerance=1.0e-12,
    )
    assert scaled.normalized_triple_product == pytest.approx(
        original.normalized_triple_product
    )
    assert scaled.classification == original.classification


def test_cross_and_triple_products_under_right_handed_rotation():
    rotation = rational_rotation()
    u = np.array([2.0, -1.0, 3.0])
    v = np.array([4.0, 5.0, -2.0])
    w = np.array([-1.0, 2.0, 6.0])
    np.testing.assert_allclose(
        cross_product_3d(rotation @ u, rotation @ v),
        rotation @ cross_product_3d(u, v),
        atol=2e-14,
    )
    assert scalar_triple_product(rotation @ u, rotation @ v, rotation @ w) == pytest.approx(
        scalar_triple_product(u, v, w)
    )


def test_reflection_flips_pseudovector_and_orientation_sign():
    reflection = np.diag([-1.0, 1.0, 1.0])
    u = np.array([2.0, -1.0, 3.0])
    v = np.array([4.0, 5.0, -2.0])
    w = np.array([-1.0, 2.0, 6.0])
    np.testing.assert_allclose(
        cross_product_3d(reflection @ u, reflection @ v),
        -reflection @ cross_product_3d(u, v),
    )
    assert scalar_triple_product(reflection @ u, reflection @ v, reflection @ w) == pytest.approx(
        -scalar_triple_product(u, v, w)
    )


def test_frozen_cad_tetrahedron_values():
    rotation = rational_rotation()
    a = np.array([120.0, 80.0, 35.0])
    b = a + 60.0 * rotation[:, 0]
    c = a + 50.0 * rotation[:, 1]
    d = a + 75.0 * rotation[:, 2]
    assert triangle_area_3d(a, b, c) == pytest.approx(1500.0)
    assert scalar_triple_product(b - a, c - a, d - a) == pytest.approx(225000.0)
    assert tetrahedron_volume(a, b, c, d) == pytest.approx(37500.0)
    orientation = spatial_orientation_diagnostics(
        b - a, c - a, d - a, relative_tolerance=1.0e-12
    )
    assert orientation.classification == "right_handed"
    assert orientation.normalized_triple_product == pytest.approx(1.0)


def test_metre_millimetre_conversion_scales_area_and_volume():
    rotation = rational_rotation()
    points_mm = np.vstack(
        [
            np.array([120.0, 80.0, 35.0]),
            np.array([120.0, 80.0, 35.0]) + 60.0 * rotation[:, 0],
            np.array([120.0, 80.0, 35.0]) + 50.0 * rotation[:, 1],
            np.array([120.0, 80.0, 35.0]) + 75.0 * rotation[:, 2],
        ]
    )
    points_m = points_mm / 1000.0
    assert triangle_area_3d(*points_m[:3]) == pytest.approx(
        1.0e-6 * triangle_area_3d(*points_mm[:3])
    )
    assert tetrahedron_volume(*points_m) == pytest.approx(
        1.0e-9 * tetrahedron_volume(*points_mm)
    )


@pytest.mark.parametrize("value", [-1.0, 1.0, np.inf, np.nan])
def test_invalid_relative_tolerance_is_rejected(value):
    with pytest.raises(ValueError, match=r"\[0, 1\)"):
        spatial_orientation_diagnostics(
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
            relative_tolerance=value,
        )


@pytest.mark.parametrize(
    "call",
    [
        lambda: cross_product_3d([1.0, 2.0], [3.0, 4.0]),
        lambda: cross_product_3d([1.0, 2.0, 3.0], [3.0, 4.0]),
        lambda: cross_product_3d([1.0, 2.0, np.inf], [3.0, 4.0, 5.0]),
        lambda: unit_normal_3d([1.0, 0.0, 0.0], [0.0, 1.0, 0.0], zero_tolerance=-1.0),
        lambda: triangle_area_3d([0.0, 0.0], [1.0, 0.0], [0.0, 1.0]),
        lambda: scalar_triple_product([1.0, 0.0, 0.0], [0.0, 1.0], [0.0, 0.0, 1.0]),
        lambda: tetrahedron_volume(
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, np.nan],
        ),
    ],
)
def test_invalid_shapes_and_values_are_rejected(call):
    with pytest.raises(ValueError):
        call()


def test_cross_product_overflow_is_explicit():
    with pytest.raises(OverflowError, match="ara çarpımı"):
        cross_product_3d([0.0, 1.0e308, 0.0], [0.0, 0.0, 1.0e308])


def test_scalar_triple_product_overflow_is_explicit():
    with pytest.raises(OverflowError, match="Karma çarpımın ara"):
        scalar_triple_product(
            [1.0e200, 0.0, 0.0],
            [0.0, 1.0e100, 0.0],
            [0.0, 0.0, 1.0e100],
        )


def test_coordinate_difference_overflow_is_explicit():
    with pytest.raises(OverflowError, match="koordinatı farkı"):
        triangle_area_3d(
            [1.0e308, 0.0, 0.0],
            [-1.0e308, 0.0, 0.0],
            [0.0, 1.0, 0.0],
        )
