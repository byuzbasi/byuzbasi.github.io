import numpy as np
import pytest

from agbook import (
    determinant_2d,
    orientation_diagnostics,
    polygon_area,
    polygon_signed_area,
    signed_double_area,
    triangle_area,
)


def test_determinant_matches_component_formula():
    assert determinant_2d([3.0, 1.0], [2.0, 4.0]) == pytest.approx(10.0)


def test_determinant_is_alternating():
    value = determinant_2d([3.0, -2.0], [5.0, 7.0])
    assert determinant_2d([5.0, 7.0], [3.0, -2.0]) == pytest.approx(-value)
    assert determinant_2d([3.0, -2.0], [3.0, -2.0]) == pytest.approx(0.0)


def test_determinant_is_linear_in_each_column():
    u = np.array([2.0, -1.0])
    w = np.array([3.0, 4.0])
    v = np.array([-2.0, 5.0])
    assert determinant_2d(2.5 * u - 3.0 * w, v) == pytest.approx(
        2.5 * determinant_2d(u, v) - 3.0 * determinant_2d(w, v)
    )


def test_shear_does_not_change_determinant():
    u = np.array([2.0, 1.0])
    v = np.array([-1.0, 4.0])
    assert determinant_2d(u, v + 7.5 * u) == pytest.approx(determinant_2d(u, v))


def test_determinant_rejects_nonplanar_vectors():
    with pytest.raises(ValueError, match="düzlemsel"):
        determinant_2d([1.0, 2.0, 3.0], [4.0, 5.0, 6.0])


def test_determinant_rejects_nonfinite_intermediate_product():
    with pytest.raises(OverflowError, match="ara çarpımı"):
        determinant_2d([1.0e308, 0.0], [0.0, 1.0e308])


def test_signed_double_area_and_triangle_area():
    a, b, c = [1.0, 1.0], [5.0, 1.0], [2.0, 4.0]
    assert signed_double_area(a, b, c) == pytest.approx(12.0)
    assert triangle_area(a, b, c) == pytest.approx(6.0)


@pytest.mark.parametrize(
    "points,classification,sign",
    [
        (([0.0, 0.0], [2.0, 0.0], [1.0, 3.0]), "counterclockwise", 1),
        (([0.0, 0.0], [1.0, 3.0], [2.0, 0.0]), "clockwise", -1),
    ],
)
def test_orientation_canonical_turns(points, classification, sign):
    result = orientation_diagnostics(*points, relative_tolerance=1.0e-12)
    assert result.classification == classification
    assert np.sign(result.signed_double_area) == sign


def test_orientation_cyclic_permutation_preserves_sign_and_swap_reverses_it():
    a, b, c = [0.0, 0.0], [3.0, 1.0], [1.0, 4.0]
    values = [
        signed_double_area(a, b, c),
        signed_double_area(b, c, a),
        signed_double_area(c, a, b),
    ]
    assert values[1:] == pytest.approx(values[:1] * 2)
    assert signed_double_area(a, c, b) == pytest.approx(-values[0])


def test_orientation_is_translation_invariant():
    points = np.array([[1.0, 2.0], [4.0, 3.0], [2.0, 7.0]])
    shifted = points + np.array([1.0e8, -2.0e8])
    original = orientation_diagnostics(*points, relative_tolerance=1.0e-12)
    translated = orientation_diagnostics(*shifted, relative_tolerance=1.0e-12)
    assert translated.signed_double_area == pytest.approx(original.signed_double_area)
    assert translated.classification == original.classification


def test_orientation_is_invariant_under_positive_uniform_scaling():
    points = np.array([[0.0, 0.0], [2.0, 1.0], [-1.0, 3.0]])
    original = orientation_diagnostics(*points, relative_tolerance=1.0e-12)
    scaled = orientation_diagnostics(*(1.0e100 * points), relative_tolerance=1.0e-12)
    assert scaled.normalized_determinant == pytest.approx(original.normalized_determinant)
    assert scaled.classification == original.classification


def test_nearly_collinear_orientation_is_reported_as_uncertain():
    result = orientation_diagnostics(
        [0.0, 0.0], [1.0e8, 1.0e8], [2.0e8, 2.0e8 + 1.0], relative_tolerance=1.0e-8
    )
    assert result.signed_double_area == pytest.approx(1.0e8)
    assert 0.0 < result.normalized_determinant < 1.0e-8
    assert result.classification == "uncertain"


@pytest.mark.parametrize(
    "points",
    [
        ([1.0, 2.0], [1.0, 2.0], [3.0, 4.0]),
        ([1.0, 2.0], [3.0, 4.0], [1.0, 2.0]),
        ([1.0, 2.0], [3.0, 4.0], [3.0, 4.0]),
    ],
)
def test_any_repeated_point_is_degenerate(points):
    result = orientation_diagnostics(*points, relative_tolerance=0.0)
    assert result.classification == "degenerate"
    assert result.normalized_determinant == 0.0


@pytest.mark.parametrize("value", [-1.0, 1.0, np.inf, np.nan])
def test_invalid_relative_tolerance_is_rejected(value):
    with pytest.raises(ValueError, match="\[0, 1\)"):
        orientation_diagnostics([0.0, 0.0], [1.0, 0.0], [0.0, 1.0], relative_tolerance=value)


def test_polygon_square_area_and_winding_sign():
    square = np.array([[0.0, 0.0], [3.0, 0.0], [3.0, 2.0], [0.0, 2.0]])
    assert polygon_signed_area(square) == pytest.approx(6.0)
    assert polygon_signed_area(square[::-1]) == pytest.approx(-6.0)
    assert polygon_area(square[::-1]) == pytest.approx(6.0)


def test_concave_polygon_area():
    polygon = np.array([[0.0, 0.0], [4.0, 0.0], [4.0, 3.0], [2.0, 1.0], [0.0, 3.0]])
    assert polygon_area(polygon) == pytest.approx(8.0)


def test_polygon_area_is_translation_invariant_at_large_offset():
    polygon = np.array([[0.0, 0.0], [6.0, 0.0], [7.0, 3.0], [4.5, 5.0], [1.0, 4.0]])
    shifted = polygon + np.array([1.0e9, -2.0e9])
    assert polygon_signed_area(shifted) == pytest.approx(polygon_signed_area(polygon))


def test_repeating_first_vertex_at_end_does_not_change_polygon_area():
    polygon = np.array([[0.0, 0.0], [2.0, 0.0], [1.0, 3.0]])
    closed = np.vstack([polygon, polygon[0]])
    assert polygon_signed_area(closed) == pytest.approx(polygon_signed_area(polygon))


def test_linear_map_scales_polygon_area_by_absolute_determinant():
    polygon = np.array([[0.0, 0.0], [3.0, 0.0], [3.0, 2.0], [0.0, 2.0]])
    matrix = np.array([[1.2, 0.3], [-0.2, 0.8]])
    mapped = polygon @ matrix.T
    scale = abs(determinant_2d(matrix[:, 0], matrix[:, 1]))
    assert polygon_area(mapped) == pytest.approx(scale * polygon_area(polygon))


@pytest.mark.parametrize(
    "vertices",
    [
        [[0.0, 0.0], [1.0, 0.0]],
        [[0.0, 0.0, 1.0], [1.0, 0.0, 1.0], [0.0, 1.0, 1.0]],
        [[0.0, 0.0], [1.0, np.inf], [0.0, 1.0]],
    ],
)
def test_polygon_rejects_invalid_input(vertices):
    with pytest.raises(ValueError):
        polygon_area(vertices)
