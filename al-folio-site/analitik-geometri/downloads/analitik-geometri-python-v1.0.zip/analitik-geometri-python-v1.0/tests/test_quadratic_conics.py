"""Genel ikinci derece denklem sınıflandırmasının küçük analitik testleri."""

from __future__ import annotations

import numpy as np
import pytest

from agbook import (
    quadratic_conic_diagnostics,
    quadratic_conic_matrices,
    quadratic_conic_residuals,
    rotation_matrix_2d,
    transform_quadratic_conic,
)


def global_coefficients(
    canonical: np.ndarray,
    center: np.ndarray,
    angle_degrees: float,
) -> np.ndarray:
    """``q(R.T@(X-center))`` katsayılarını test içinde üretir."""

    rotation = rotation_matrix_2d(np.deg2rad(angle_degrees))
    return transform_quadratic_conic(
        canonical,
        rotation.T,
        -rotation.T @ center,
    )


def direction_projector(direction: np.ndarray) -> np.ndarray:
    return np.outer(direction, direction)


def test_matrices_reproduce_scalar_polynomial():
    coefficients = np.array([2.0, -3.0, 5.0, 7.0, -11.0, 13.0])
    point = np.array([1.5, -0.25])
    quadratic, linear, homogeneous = quadratic_conic_matrices(coefficients)
    direct = quadratic_conic_residuals(coefficients, point)
    expected = point @ quadratic @ point + 2.0 * linear @ point + coefficients[-1]
    homogeneous_point = np.r_[point, 1.0]
    assert direct == pytest.approx(expected / np.max(np.abs(coefficients)))
    assert homogeneous_point @ homogeneous @ homogeneous_point == pytest.approx(expected)
    np.testing.assert_allclose(quadratic, quadratic.T)
    np.testing.assert_allclose(homogeneous, homogeneous.T)


def test_residuals_accept_single_point_and_rows():
    coefficients = [1.0, 0.0, 1.0, 0.0, 0.0, -25.0]
    assert quadratic_conic_residuals(coefficients, [3.0, 4.0]) == pytest.approx(0.0)
    result = quadratic_conic_residuals(coefficients, [[3.0, 4.0], [0.0, 0.0]])
    np.testing.assert_allclose(result, [0.0, -1.0])


def test_residuals_ignore_nonzero_common_coefficient_factor():
    coefficients = np.array([1.0, 2.0, 3.0, -4.0, 5.0, -6.0])
    points = np.array([[0.25, -1.0], [2.0, 3.0]])
    positive = quadratic_conic_residuals(coefficients, points)
    negative = quadratic_conic_residuals(-7.5 * coefficients, points)
    np.testing.assert_allclose(negative, -positive)
    np.testing.assert_allclose(np.abs(negative), np.abs(positive))


def test_transform_matches_direct_coordinate_substitution():
    coefficients = np.array([2.0, 3.0, 5.0, -7.0, 11.0, -13.0])
    rotation = rotation_matrix_2d(np.deg2rad(37.0))
    translation = np.array([4.0, -2.0])
    transformed = transform_quadratic_conic(coefficients, rotation, translation)
    new_points = np.array([[0.0, 0.0], [1.0, -3.0], [2.5, 0.75]])
    old_points = new_points @ rotation.T + translation
    old_values = quadratic_conic_residuals(coefficients, old_points)
    new_values = quadratic_conic_residuals(transformed, new_points)
    old_raw_scale = np.max(np.abs(coefficients))
    new_raw_scale = np.max(np.abs(transformed))
    np.testing.assert_allclose(old_values * old_raw_scale, new_values * new_raw_scale, atol=2e-13)


def test_circle_diagnostics():
    result = quadratic_conic_diagnostics([1.0, 0.0, 1.0, 0.0, 0.0, -25.0])
    assert result.locus_type == "circle"
    assert result.quadratic_rank == 2
    assert result.homogeneous_rank == 3
    assert result.inertia == (2, 0, 0)
    assert not result.degenerate
    assert result.orientation_radians is None
    np.testing.assert_allclose(result.center, [0.0, 0.0])
    np.testing.assert_allclose(result.semi_axes, [5.0, 5.0])


def test_translated_ellipse_recovers_center_axes_and_direction():
    center = np.array([4.0, -3.0])
    coefficients = global_coefficients(
        np.array([1.0 / 25.0, 0.0, 1.0 / 9.0, 0.0, 0.0, -1.0]),
        center,
        28.0,
    )
    result = quadratic_conic_diagnostics(coefficients, coordinate_scale=5.0, relative_tolerance=1e-12)
    expected_major = rotation_matrix_2d(np.deg2rad(28.0))[:, 0]
    assert result.locus_type == "ellipse"
    np.testing.assert_allclose(result.center, center, atol=2e-13)
    np.testing.assert_allclose(result.semi_axes, [5.0, 3.0], atol=2e-13)
    np.testing.assert_allclose(
        direction_projector(result.principal_directions[:, 0]),
        direction_projector(expected_major),
        atol=2e-13,
    )


def test_point_and_definite_empty_cases():
    point = quadratic_conic_diagnostics([1.0, 0.0, 1.0, -4.0, 6.0, 13.0])
    empty = quadratic_conic_diagnostics([1.0, 0.0, 1.0, 0.0, 0.0, 1.0])
    assert point.locus_type == "point"
    assert point.degenerate
    np.testing.assert_allclose(point.center, [2.0, -3.0])
    assert empty.locus_type == "empty"
    assert not empty.degenerate


def test_hyperbola_recovers_transverse_and_conjugate_axes():
    result = quadratic_conic_diagnostics([1.0 / 9.0, 0.0, -1.0 / 4.0, 0.0, 0.0, -1.0])
    assert result.locus_type == "hyperbola"
    assert result.inertia == (1, 1, 0)
    np.testing.assert_allclose(result.semi_axes, [3.0, 2.0])
    np.testing.assert_allclose(
        direction_projector(result.principal_directions[:, 0]),
        np.diag([1.0, 0.0]),
    )


def test_intersecting_lines_are_factored():
    result = quadratic_conic_diagnostics([1.0, 0.0, -1.0, 0.0, 0.0, 0.0])
    assert result.locus_type == "intersecting_lines"
    assert result.degenerate
    assert result.component_lines.shape == (2, 3)
    directions = np.column_stack([-result.component_lines[:, 1], result.component_lines[:, 0]])
    points = 3.0 * directions
    np.testing.assert_allclose(quadratic_conic_residuals(result.coefficients, points), 0.0, atol=2e-15)


def test_parabola_recovers_vertex_opening_and_focal_parameter():
    result = quadratic_conic_diagnostics([1.0, 0.0, 0.0, 0.0, -4.0, 0.0])
    assert result.locus_type == "parabola"
    assert result.quadratic_rank == 1
    assert result.homogeneous_rank == 3
    assert not result.degenerate
    np.testing.assert_allclose(result.vertex, [0.0, 0.0])
    np.testing.assert_allclose(result.principal_directions[:, 0], [0.0, 1.0])
    assert result.focal_parameter == pytest.approx(1.0)


def test_rotated_translated_parabola_is_covariant():
    center = np.array([8.0, -5.0])
    angle = 61.0
    coefficients = global_coefficients(
        np.array([1.0, 0.0, 0.0, 0.0, -8.0, 0.0]),
        center,
        angle,
    )
    result = quadratic_conic_diagnostics(coefficients, coordinate_scale=10.0, relative_tolerance=1e-12)
    expected_opening = rotation_matrix_2d(np.deg2rad(angle))[:, 1]
    assert result.locus_type == "parabola"
    np.testing.assert_allclose(result.vertex, center, atol=2e-12)
    np.testing.assert_allclose(result.principal_directions[:, 0], expected_opening, atol=2e-12)
    assert result.focal_parameter == pytest.approx(2.0)


@pytest.mark.parametrize(
    ("coefficients", "expected_type", "line_count"),
    [
        ([1.0, 0.0, 0.0, 0.0, 0.0, -4.0], "parallel_lines", 2),
        ([1.0, 0.0, 0.0, -4.0, 0.0, 4.0], "double_line", 1),
        ([1.0, 0.0, 0.0, 0.0, 0.0, 1.0], "empty", 0),
        ([0.0, 0.0, 0.0, 2.0, -4.0, 6.0], "line", 1),
        ([0.0, 0.0, 0.0, 0.0, 0.0, 1.0], "empty", 0),
        ([0.0, 0.0, 0.0, 0.0, 0.0, 0.0], "plane", 0),
    ],
)
def test_rank_deficient_catalogue(coefficients, expected_type, line_count):
    result = quadratic_conic_diagnostics(coefficients)
    assert result.locus_type == expected_type
    assert result.degenerate
    assert result.component_lines.shape == (line_count, 3)


def test_parallel_and_double_line_equations_are_returned_in_original_coordinates():
    parallel = quadratic_conic_diagnostics([1.0, 0.0, 0.0, -4.0, 0.0, 3.0])
    double = quadratic_conic_diagnostics([1.0, 0.0, 0.0, -4.0, 0.0, 4.0])
    np.testing.assert_allclose(np.sort(parallel.component_lines[:, 2]), [-3.0, -1.0])
    np.testing.assert_allclose(double.component_lines[0], [1.0, 0.0, -2.0])


def test_linear_component_line_is_normalized():
    result = quadratic_conic_diagnostics([0.0, 0.0, 0.0, 6.0, 8.0, -10.0])
    assert result.locus_type == "line"
    np.testing.assert_allclose(result.component_lines[0], [0.6, 0.8, -1.0])


def test_school_discriminant_matches_quadratic_determinant():
    result = quadratic_conic_diagnostics([3.0, -8.0, 2.0, 1.0, 4.0, -7.0])
    assert result.discriminant == pytest.approx(-4.0 * result.quadratic_determinant)


@pytest.mark.parametrize(
    ("coefficients", "expected_inertia"),
    [
        ([2.0, 0.0, 3.0, 0.0, 0.0, -1.0], (2, 0, 0)),
        ([-2.0, 0.0, -3.0, 0.0, 0.0, 1.0], (0, 2, 0)),
        ([2.0, 0.0, -3.0, 0.0, 0.0, -1.0], (1, 1, 0)),
        ([2.0, 0.0, 0.0, 0.0, -1.0, 0.0], (1, 0, 1)),
    ],
)
def test_inertia_counts_eigenvalue_signs(coefficients, expected_inertia):
    assert quadratic_conic_diagnostics(coefficients).inertia == expected_inertia


def test_negative_coefficient_scaling_preserves_locus_and_geometry():
    coefficients = global_coefficients(
        np.array([1.0 / 36.0, 0.0, 1.0 / 16.0, 0.0, 0.0, -1.0]),
        np.array([7.0, -4.0]),
        19.0,
    )
    first = quadratic_conic_diagnostics(coefficients, coordinate_scale=6.0, relative_tolerance=1e-12)
    second = quadratic_conic_diagnostics(-13.0 * coefficients, coordinate_scale=6.0, relative_tolerance=1e-12)
    assert first.locus_type == second.locus_type == "ellipse"
    np.testing.assert_allclose(first.center, second.center, atol=3e-13)
    np.testing.assert_allclose(first.semi_axes, second.semi_axes, atol=3e-13)
    np.testing.assert_allclose(
        direction_projector(first.principal_directions[:, 0]),
        direction_projector(second.principal_directions[:, 0]),
        atol=3e-13,
    )


def test_metre_millimetre_conversion_preserves_dimensionless_diagnostics():
    coefficients_mm = global_coefficients(
        np.array([1.0 / 45.0**2, 0.0, 1.0 / 20.0**2, 0.0, 0.0, -1.0]),
        np.array([120.0, 80.0]),
        32.0,
    )
    coefficients_m = coefficients_mm * np.array([1e6, 1e6, 1e6, 1e3, 1e3, 1.0])
    millimetres = quadratic_conic_diagnostics(
        coefficients_mm, coordinate_scale=100.0, relative_tolerance=1e-12
    )
    metres = quadratic_conic_diagnostics(
        coefficients_m, coordinate_scale=0.1, relative_tolerance=1e-12
    )
    assert millimetres.locus_type == metres.locus_type == "ellipse"
    np.testing.assert_allclose(millimetres.center / 1000.0, metres.center, atol=2e-14)
    np.testing.assert_allclose(millimetres.semi_axes / 1000.0, metres.semi_axes, atol=2e-14)
    np.testing.assert_allclose(
        millimetres.normalized_coefficients,
        metres.normalized_coefficients,
        atol=2e-15,
    )


def test_explicit_tolerance_marks_near_boundary_decision():
    exact_floating = quadratic_conic_diagnostics([1.0, 0.0, 1.0, 0.0, 0.0, 1e-14])
    thresholded = quadratic_conic_diagnostics(
        [1.0, 0.0, 1.0, 0.0, 0.0, 1e-14], relative_tolerance=1e-12
    )
    assert exact_floating.locus_type == "empty"
    assert not exact_floating.numerically_ambiguous
    assert thresholded.locus_type == "point"
    assert thresholded.numerically_ambiguous


def test_explicit_tolerance_can_expose_near_rank_loss():
    exact_floating = quadratic_conic_diagnostics([1.0, 0.0, 1e-14, 0.0, 0.0, -1.0])
    thresholded = quadratic_conic_diagnostics(
        [1.0, 0.0, 1e-14, 0.0, 0.0, -1.0], relative_tolerance=1e-12
    )
    assert exact_floating.locus_type == "ellipse"
    assert thresholded.locus_type == "parallel_lines"
    assert thresholded.numerically_ambiguous


def test_points_on_rotated_ellipse_have_small_dimensionless_residuals():
    center = np.array([120.0, 80.0])
    angle = 32.0
    rotation = rotation_matrix_2d(np.deg2rad(angle))
    coefficients = global_coefficients(
        np.array([1.0 / 45.0**2, 0.0, 1.0 / 20.0**2, 0.0, 0.0, -1.0]),
        center,
        angle,
    )
    parameters = np.linspace(0.0, 2.0 * np.pi, 17)
    local = np.column_stack([45.0 * np.cos(parameters), 20.0 * np.sin(parameters)])
    points = local @ rotation.T + center
    residuals = quadratic_conic_residuals(coefficients, points, coordinate_scale=100.0)
    assert np.max(np.abs(residuals)) < 2e-15


@pytest.mark.parametrize(
    "call",
    [
        lambda: quadratic_conic_matrices([1.0, 2.0]),
        lambda: quadratic_conic_matrices([1.0, 0.0, 1.0, 0.0, np.nan, -1.0]),
        lambda: quadratic_conic_residuals([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], [1.0]),
        lambda: quadratic_conic_residuals([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], [1.0, np.inf]),
        lambda: quadratic_conic_residuals([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], [1.0, 0.0], coordinate_scale=0.0),
        lambda: quadratic_conic_diagnostics([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], relative_tolerance=-1.0),
        lambda: quadratic_conic_diagnostics([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], relative_tolerance=1.0),
        lambda: transform_quadratic_conic([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], np.eye(3), [0.0, 0.0]),
        lambda: transform_quadratic_conic([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], np.eye(2), [0.0]),
        lambda: transform_quadratic_conic([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], [[1.0, 1.0], [0.0, 1.0]], [0.0, 0.0]),
        lambda: transform_quadratic_conic([1.0, 0.0, 1.0, 0.0, 0.0, -1.0], np.eye(2), [0.0, 0.0], orthogonality_tolerance=-1.0),
    ],
)
def test_invalid_inputs_are_rejected(call):
    with pytest.raises((ValueError, OverflowError)):
        call()


def test_coordinate_scaling_overflow_is_explicit():
    with pytest.raises(OverflowError, match="ölçekleme"):
        quadratic_conic_diagnostics(
            [1e308, 0.0, 1e308, 0.0, 0.0, -1.0],
            coordinate_scale=1e308,
        )
